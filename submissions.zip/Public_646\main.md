# Public_646

## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>XVIII</td><td>Vật liệu
ngành nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>18,1</td><td>Thiết bị điện, chiếu sáng Miền Bắc (Công ty TNHH thiết bị và chiếu sáng Miền Bắc)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Trụ sở: số 30, khu C, tổ dân phố Phũ Mỹ, Mỹ Đình 2, Nam Từ Liên, Hà Nội.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Nắp hố ga, song chắn rác bằng vật liệu Composite, Gang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2672</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite,
Gang Khung
960x530 tải trọng
12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2015</td><td>(860x430x60)mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.000.000</td></tr><tr><td>2673</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite,
Gang Khung
960x530 tải trọng 25
tấn</td><td>Cái</td><td>BS EN
124-
5:2016</td><td>(860x430x60)mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>3.250.000</td></tr><tr><td>2674</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite,
Gang Khung
960x530 tải trọng 40
tấn</td><td>Cái</td><td>BS EN
124-
5:2017</td><td>(860x430x60)mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>3.980.000</td></tr><tr><td>2675</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite , Gang
tải trọng 12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2018</td><td>(860x430x60)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>1.400.000</td></tr><tr><td>2676</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite , Gang
tải trọng 12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2019</td><td>(860x430x60)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.050.000</td></tr><tr><td>2677</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite , Gang
tải trọng 12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2020</td><td>(860x430x60)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.450.000</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2678</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite, Gang tải
trọng 12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2021</td><td>(960x530x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>1.680.000</td></tr><tr><td>2679</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite, Gang tải
trọng 25 tấn</td><td>Cái</td><td>BS EN
124-
5:2022</td><td>(960x530x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>1.850.000</td></tr><tr><td>2680</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite, Gang
tải trọng 40 tấn</td><td>Cái</td><td>BS EN
124-
5:2023</td><td>(960x530x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.250.000</td></tr><tr><td>2681</td><td>Thiết bị
ngành nước</td><td>Song chắn rác
Composite tải trọng
12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2024</td><td>(960x530x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.030.000</td></tr><tr><td>2682</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga
Composite, Gang tải
trọng 12.5 tấn</td><td>Cái</td><td>BS EN
124-
5:2025</td><td>(960x530x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.100.000</td></tr><tr><td>2683</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga
Composite, Gang tải
trọng 25 tấn</td><td>Cái</td><td>BS EN
124-
5:2026</td><td>(850x850x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>3.230.000</td></tr><tr><td>2684</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga
Composite, Gang tải
trọng 40 tấn</td><td>Cái</td><td>BS EN
124-
5:2027</td><td>(850x850x30)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>3.980.000</td></tr><tr><td>2685</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga
Composite, Gang
D700 tải trọng 12.5
tấn</td><td>Cái</td><td>BS EN
124-
5:2028</td><td>(900x900x60)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>2.700.000</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2686</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga
Composite, Gang
D700 tải trọng 25
tấn</td><td>Cái</td><td>BS EN
124-
5:2029</td><td>(900x900x60)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>3.750.000</td></tr><tr><td>2687</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga
Composite, Gang
D700 tải trọng 40
tấn</td><td>Cái</td><td>BS EN
124-
5:2030</td><td>(900x900x60)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>4.250.000</td></tr><tr><td>2688</td><td>Thiết bị
ngành nước</td><td>Nắp thăm thu kết
hợp CPS KT Tải
trọng 12,5 tấn</td><td>Cái</td><td>BS EN
124-
5:2031</td><td>(1050x745x80)
mm</td><td>Công ty TNHH
TB và CS Miền
Bắc</td><td>Không</td><td>Giá bán tại thành
phố Lạng Sơn,
chưa bao gồm vận
chuyển</td><td></td><td>3.600.000</td></tr><tr><td>18,2</td><td>Công ty
TNHH
Thương Mại
và Đầu tư
Thành An</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: số
37, ngõ
1/62/23 phố
Bùi Xương
Trạch,
phường
Khương Đình,
quận Thanh
Xuân, thành
phố Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Nắp hố ga,
song chắn
rác bằng vật
liệu
Composite,
Gang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2689</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga, kích
thước
850x850mm, tải
trọng 12,5 tấn</td><td>Cái</td><td>BS EN
124:
2015</td><td>850x850x75mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>3.035.000</td><td></td></tr><tr><td>2690</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga, kích
thước 850x850mm,
tải trọng 40 tấn</td><td>Cái</td><td>BS EN
124:
2016</td><td>850x850x75mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>3.740.000</td><td></td></tr><tr><td>2691</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga, kích
thước
900x900mm, tải
trọng 12,5 tấn</td><td>Cái</td><td>BS EN
124:
2017</td><td>850x850x75mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>3.098.000</td><td></td></tr><tr><td>2692</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga, kích
thước 900x900mm,
tải trọng 40 tấn</td><td>Cái</td><td>BS EN
124:
2018</td><td>850x850x75mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>4.010.000</td><td></td></tr><tr><td>2693</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga, kích
thước
1000x1000mm, tải
trọng 12,5 tấn</td><td>Cái</td><td>BS EN
124:
2019</td><td>1000x1000mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>3.320.000</td><td></td></tr><tr><td>2694</td><td>Thiết bị
ngành nước</td><td>Nắp hố ga, kích
thước
1000x1000mm, tải
trọng 40 tấn</td><td>Cái</td><td>BS EN
124:
2020</td><td>1000x1000mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>4.670.000</td><td></td></tr><tr><td>2695</td><td>Thiết bị
ngành nước</td><td>Song chắc rác, kích
thước 960x530, tải
trọng xe 12,5 tấn</td><td>Cái</td><td>BS EN
124:
2021</td><td>960x530mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>1.890.000</td><td></td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2696</td><td>Thiết bị
ngành nước</td><td>Song chắc rác, kích
thước 960x530, tải
trọng xe 25 tấn</td><td>Cái</td><td>BS EN
124:
2022</td><td>960x530mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>2.016.000</td><td></td></tr><tr><td>2697</td><td>Thiết bị
ngành nước</td><td>Song chắc rác, kích
thước 960x530, tải
trọng xe 40 tấn</td><td>Cái</td><td>BS EN
124:
2023</td><td>960x530mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>2.205.000</td><td></td></tr><tr><td>2698</td><td>Thiết bị
ngành nước</td><td>Nắp bể cáp, kích
thước 950x910, tải
trọng 12,5 tấn</td><td>Cái</td><td>BS EN
124:
2024</td><td>950x910mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>5.586.000</td><td></td></tr><tr><td>2699</td><td>Thiết bị
ngành nước</td><td>Nắp bể cáp, kích
thước 950x910, tải
trọng 40 tấn</td><td>Cái</td><td>BS EN
124:
2025</td><td>950x910mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>7.266.000</td><td></td></tr><tr><td>2700</td><td>Thiết bị
ngành nước</td><td>Nắp bể cáp, kích
thước 1.660x950, tải
trọng 12,5 tấn</td><td>Cái</td><td>BS EN
124:
2026</td><td>1660x950mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>9.290.000</td><td></td></tr><tr><td>2701</td><td>Thiết bị
ngành nước</td><td>Nắp bể cáp, kích
thước 1.660x950, tải
trọng 40 tấn</td><td>Cái</td><td>BS EN
124:
2027</td><td>1660x950mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>10.520.000</td><td></td></tr><tr><td>2702</td><td>Thiết bị
ngành nước</td><td>Ghi bảo vệ gốc cây</td><td>Cái</td><td>BS EN
124:
2028</td><td>1000x1000mm</td><td>Công ty TNHH
Thương Mại và
Đầu tư Thành An</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình tỉnh
Lạng Sơn</td><td>2.770.000</td><td></td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>18,2</td><td>Công ty Cổ
phần Đầu tư
và Sản xuất
HCL</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Van cổng ty
chìm mặt
bích tay quay
hiệu ATK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2703</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 50</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.700.000</td><td></td></tr><tr><td>2704</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 65</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.850.000</td><td></td></tr><tr><td>2705</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 80</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.550.000</td><td></td></tr><tr><td>2706</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 100</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.000.000</td><td></td></tr><tr><td>2707</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 125</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.500.000</td><td></td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2708</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 150</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.250.000</td><td></td></tr><tr><td>2709</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 200</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>8.000.000</td><td></td></tr><tr><td>2710</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 250</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>13.620.000</td><td></td></tr><tr><td>2711</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 300</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>18.670.000</td><td></td></tr><tr><td>2712</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 350</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>24.000.000</td><td></td></tr><tr><td>2713</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích tay quay -
DN 400</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>38.000.000</td><td></td></tr><tr><td>*</td><td>Van cổng ty chìm mặt bích nắp chụp hiệu ATK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2714</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 50</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.650.000</td><td></td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2715</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 65</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.800.000</td><td></td></tr><tr><td>2716</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 80</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.500.000</td><td></td></tr><tr><td>2717</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 100</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.950.000</td><td></td></tr><tr><td>2718</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 125</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.250.000</td><td></td></tr><tr><td>2719</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 150</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.150.000</td><td></td></tr><tr><td>2720</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 200</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>7.800.000</td><td></td></tr><tr><td>2721</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 250</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>12.840.000</td><td></td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2722</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 300</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>17.790.000</td><td></td></tr><tr><td>2723</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 350</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>23.000.000</td><td></td></tr><tr><td>2724</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
mặt bích nắp chụp -
DN 400</td><td>cái</td><td>EN 1074-1</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>37.000.000</td><td></td></tr><tr><td>*</td><td>Van cổng ty chìm kiểu EE/FF ngoàm đồng hiệu ATK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2726</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
kiểu EE/FF
- DN40 loại thấp lắp
ống HDPE</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.050.000</td><td></td></tr><tr><td>2727</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
kiểu EE/FF
- DN50 loại thấp lắp
ống HDPE</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.100.000</td><td></td></tr><tr><td>2728</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN 40
lắp ống HDPE</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.450.000</td><td></td></tr><tr><td>2729</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN 50
lắp ống HDPE D63</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.500.000</td><td></td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2730</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN 65
lắp ống HDPE D75</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.850.000</td><td></td></tr><tr><td>2731</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN 80
lắp ống HDPE D90</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.900.000</td><td></td></tr><tr><td>2732</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN
100 lắp ống HDPE
D110</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.900.000</td><td></td></tr><tr><td>2733</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN
150 lắp ống HDPE
D160</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>8.300.000</td><td></td></tr><tr><td>2734</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN
200 lắp ống HDPE
D200</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>11.900.000</td><td></td></tr><tr><td>2735</td><td>Thiết bị
ngành nước</td><td>Van cổng ty chìm
nắp chụp
kiểu EE/FF - DN
200 lắp ống HDPE
D225</td><td>cái</td><td>EN 1074-1</td><td>EE/FF</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>12.000.000</td><td></td></tr><tr><td>*</td><td>Van 1 chiều lá lật mặt bích hiệu ATK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2737</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN50</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.400.000</td><td></td></tr><tr><td>2738</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN65</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.600.000</td><td></td></tr><tr><td>2739</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN80</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.200.000</td><td></td></tr><tr><td>2740</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN100</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.800.000</td><td></td></tr><tr><td>2741</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN125</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.900.000</td><td></td></tr><tr><td>2742</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN150</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.300.000</td><td></td></tr><tr><td>2743</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN200</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>9.800.000</td><td></td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2744</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN250</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>15.000.000</td><td></td></tr><tr><td>2745</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN300</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>22.000.000</td><td></td></tr><tr><td>2746</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN350</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>30.000.000</td><td></td></tr><tr><td>2747</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
mặt bích hiệu ATK
DN400</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>40.000.000</td><td></td></tr><tr><td>2748</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN100</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.440.000</td><td></td></tr><tr><td>2749</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN125</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.760.000</td><td></td></tr><tr><td>2750</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN150</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>6.160.000</td><td></td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2751</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN200</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>10.870.000</td><td></td></tr><tr><td>2752</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN250</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>16.390.000</td><td></td></tr><tr><td>2753</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN300</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>23.710.000</td><td></td></tr><tr><td>2754</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN350</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>31.710.000</td><td></td></tr><tr><td>2755</td><td>Thiết bị
ngành nước</td><td>Van 1 chiều lá lật
đối trọng mặt bích
hiệu ATK DN400</td><td>cái</td><td>BS EN
1074-3</td><td>BS4504 PN10/16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>42.140.000</td><td></td></tr><tr><td>*</td><td>Van bướm kiểu kẹp hiệu ATK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2757</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay gạt DN50</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>800,000</td><td></td></tr><tr><td>2758</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay gạt DN65</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>950,000</td><td></td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2759</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay gạt DN80</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.100.000</td><td></td></tr><tr><td>2760</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay gạt DN100</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.500.000</td><td></td></tr><tr><td>2761</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay gạt DN125</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.000.000</td><td></td></tr><tr><td>2762</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay gạt DN150</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.700.000</td><td></td></tr><tr><td>2763</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay quay DN150</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.200.000</td><td></td></tr><tr><td>2764</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay quay DN200</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.200.000</td><td></td></tr><tr><td>2765</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay quay DN250</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>7.900.000</td><td></td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2766</td><td>Thiết bị
ngành nước</td><td>Van bướm kiểu kẹp
tay quay DN300</td><td>cái</td><td>EN 1074-1</td><td>PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>11.000.000</td><td></td></tr><tr><td>*</td><td>Khớp nối mềm gang cầu BE, gioăng cao su, Dùng nối các loại ống</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2768</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN50 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>488,000</td><td></td></tr><tr><td>2769</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 65 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>535,000</td><td></td></tr><tr><td>2770</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN80 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>744,000</td><td></td></tr><tr><td>2771</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 100
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>913,000</td><td></td></tr><tr><td>2772</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 125
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.009.000</td><td></td></tr><tr><td>2773</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN140
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.144.000</td><td></td></tr><tr><td>2774</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN150
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.359.000</td><td></td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2775</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN180
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.569.000</td><td></td></tr><tr><td>2776</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 200
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.901.000</td><td></td></tr><tr><td>2777</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 225
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.031.000</td><td></td></tr><tr><td>2778</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 250
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.726.000</td><td></td></tr><tr><td>2779</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 280
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.261.000</td><td></td></tr><tr><td>2780</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 300
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.508.000</td><td></td></tr><tr><td>2781</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 350
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.922.000</td><td></td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2782</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 400
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.845.000</td><td></td></tr><tr><td>2783</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 450
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>7.568.000</td><td></td></tr><tr><td>2784</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 500
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>9.721.000</td><td></td></tr><tr><td>2785</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN600
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>ISO 7005-2
PN10/PN16</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>12.920.000</td><td></td></tr><tr><td>*</td><td>Khớp nối mềm gang cầu BE, tích hợp gioăng đồng chuyên dùng nối ống HDPE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2787</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN50 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>736,000</td><td></td></tr><tr><td>2788</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 65 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>818,000</td><td></td></tr><tr><td>2789</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE DN80
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>971,000</td><td></td></tr><tr><td>2790</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE DN
100 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.235.000</td><td></td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2791</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE DN
125 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.345.000</td><td></td></tr><tr><td>2792</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN140 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.469.000</td><td></td></tr><tr><td>2793</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN150 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.808.000</td><td></td></tr><tr><td>2794</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN180 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.218.000</td><td></td></tr><tr><td>2795</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN200 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.489.000</td><td></td></tr><tr><td>2796</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN225 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.704.000</td><td></td></tr><tr><td>2797</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN250 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.554.000</td><td></td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2798</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 280
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.712.000</td><td></td></tr><tr><td>2799</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 300
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.129.000</td><td></td></tr><tr><td>2800</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 350
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>7.000.000</td><td></td></tr><tr><td>2801</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 400
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>8.732.000</td><td></td></tr><tr><td>2802</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 450
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>10.396.000</td><td></td></tr><tr><td>2803</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 500
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>13.168.000</td><td></td></tr><tr><td>2804</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm gang
cầu BE DN 560
(mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>17.048.000</td><td></td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2805</td><td>Thiết bị
ngành nước</td><td>Khớp nối mềm
gang cầu BE
DN600 (mm)</td><td>Bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>17326000</td><td></td></tr><tr><td>*</td><td>Phụ kiện gang, gioăng cao su dùng nối các loại ống</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2807</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
80</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.107.000</td><td></td></tr><tr><td>2808</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
100</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.354.000</td><td></td></tr><tr><td>2809</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
150</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.215.000</td><td></td></tr><tr><td>2810</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
180</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.830.000</td><td></td></tr><tr><td>2811</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
200</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.138.000</td><td></td></tr><tr><td>2812</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
225</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.257.000</td><td></td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2813</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
250</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.738.000</td><td></td></tr><tr><td>2814</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
280</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.599.000</td><td></td></tr><tr><td>2815</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
300</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.969.000</td><td></td></tr><tr><td>2816</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
350</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>9.082.000</td><td></td></tr><tr><td>2817</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ EE DN
400</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>10.828.000</td><td></td></tr><tr><td>2818</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN 80</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.170.000</td><td></td></tr><tr><td>2819</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
100</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.416.000</td><td></td></tr><tr><td>2820</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
150</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>2.277.000</td><td></td></tr><tr><td>2821</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
180</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.076.000</td><td></td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2822</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
200</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.322.000</td><td></td></tr><tr><td>2823</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
225</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.331.000</td><td></td></tr><tr><td>2824</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
250</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.762.000</td><td></td></tr><tr><td>2825</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
280</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.906.000</td><td></td></tr><tr><td>2826</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
300</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.399.000</td><td></td></tr><tr><td>2827</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
350</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.721.000</td><td></td></tr><tr><td>2828</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ EE DN
400</td><td>bộ</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>12.674.000</td><td></td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2829</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>923.000</td><td></td></tr><tr><td>2830</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.170.000</td><td></td></tr><tr><td>2831</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.945.000</td><td></td></tr><tr><td>2832</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.683.000</td><td></td></tr><tr><td>2833</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
225</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.298.000</td><td></td></tr><tr><td>2834</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.568.000</td><td></td></tr><tr><td>2835</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
280</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.307.000</td><td></td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2836</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.652.000</td><td></td></tr><tr><td>2837</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
350</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.374.000</td><td></td></tr><tr><td>2838</td><td>Thiết bị
ngành nước</td><td>Cút 45 độ BB DN
400</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.466.000</td><td></td></tr><tr><td>2839</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.047.000</td><td></td></tr><tr><td>2840</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.354.000</td><td></td></tr><tr><td>2841</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.191.000</td><td></td></tr><tr><td>2842</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.052.000</td><td></td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2843</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
225</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.011.000</td><td></td></tr><tr><td>2844</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.430.000</td><td></td></tr><tr><td>2845</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
280</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.476.000</td><td></td></tr><tr><td>2846</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.906.000</td><td></td></tr><tr><td>2847</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
350</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.250.000</td><td></td></tr><tr><td>2848</td><td>Thiết bị
ngành nước</td><td>Cút 90 độ BB DN
400</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>10.275.000</td><td></td></tr><tr><td>2849</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 80 L =
350mm</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>849.000</td><td></td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2850</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 100 L =
360mm</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.427.000</td><td></td></tr><tr><td>2851</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 150 L =
380mm</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.760.000</td><td></td></tr><tr><td>2852</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 200 L =
400mm</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.892.000</td><td></td></tr><tr><td>2853</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 250 L =
420mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.568.000</td><td></td></tr><tr><td>2854</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 300 L =
440 mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.242.000</td><td></td></tr><tr><td>2855</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 350 L =
460 mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.128.000</td><td></td></tr><tr><td>2856</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 400 L =
480 mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.922.000</td><td></td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2857</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 80 L =
200 mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>554.000</td><td></td></tr><tr><td>2858</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 100 L =
250mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>788.000</td><td></td></tr><tr><td>2859</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 150 L =
250mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.341.000</td><td></td></tr><tr><td>2860</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 200 L =
300mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.178.000</td><td></td></tr><tr><td>2861</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 250 L =
300mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.409.000</td><td></td></tr><tr><td>2862</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 300 L =
350 mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.061.000</td><td></td></tr><tr><td>2863</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 350 L =
350 mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.959.000</td><td></td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2864</td><td>Thiết bị
ngành nước</td><td>Bù BU DN 400 L =
400mm</td><td>Cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.744.000</td><td></td></tr><tr><td>2865</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN80*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.501.000</td><td></td></tr><tr><td>2866</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN100*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.723.000</td><td></td></tr><tr><td>2867</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
100*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.846.000</td><td></td></tr><tr><td>2868</td><td>Thiết bị
ngành nước</td><td>Tê gang FFFBDN
150*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.400.000</td><td></td></tr><tr><td>2869</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
150*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.584.000</td><td></td></tr><tr><td>2870</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
150*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.421.000</td><td></td></tr></tbody></table>

|<image_28>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2871</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
180 x 80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.076.000</td><td></td></tr><tr><td>2872</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
180 x 100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.322.000</td><td></td></tr><tr><td>2873</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
180 x 180</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.938.000</td><td></td></tr><tr><td>2874</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
200x 80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.322.000</td><td></td></tr><tr><td>2875</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN200*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.568.000</td><td></td></tr><tr><td>2876</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN200*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.184.000</td><td></td></tr><tr><td>2877</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN200*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.307.000</td><td></td></tr></tbody></table>

|<image_29>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2878</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN225*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.184.000</td><td></td></tr><tr><td>2879</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN225*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.461.000</td><td></td></tr><tr><td>2880</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN225*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.230.000</td><td></td></tr><tr><td>2881</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN225*225</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.383.000</td><td></td></tr><tr><td>2882</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB
DN250*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.476.000</td><td></td></tr><tr><td>2883</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
250*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.993.000</td><td></td></tr><tr><td>2884</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
250*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.276.000</td><td></td></tr></tbody></table>

|<image_30>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2885</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
250*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.399.000</td><td></td></tr><tr><td>2886</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
280*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.783.000</td><td></td></tr><tr><td>2887</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
280*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.522.000</td><td></td></tr><tr><td>2888</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
280*280</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.475.000</td><td></td></tr><tr><td>2889</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
300*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.338.000</td><td></td></tr><tr><td>2890</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
300*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.014.000</td><td></td></tr><tr><td>2891</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
300*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.629.000</td><td></td></tr></tbody></table>

|<image_31>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2892</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
300*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.229.000</td><td></td></tr><tr><td>2893</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
300*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.860.000</td><td></td></tr><tr><td>2894</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
350*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.967.000</td><td></td></tr><tr><td>2895</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
350*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>10459000</td><td></td></tr><tr><td>2896</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
350*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>11.567.000</td><td></td></tr><tr><td>2897</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
350*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>12.305.000</td><td></td></tr><tr><td>2898</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
350*350</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>13.105.000</td><td></td></tr></tbody></table>

|<image_32>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2899</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
400*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.773.000</td><td></td></tr><tr><td>2900</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
400*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>13.978.000</td><td></td></tr><tr><td>2901</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
400*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.520.000</td><td></td></tr><tr><td>2902</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
400*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.766.000</td><td></td></tr><tr><td>2903</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
400*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.828.000</td><td></td></tr><tr><td>2904</td><td>Thiết bị
ngành nước</td><td>Tê gang FFB DN
400*400</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>16.059.000</td><td></td></tr><tr><td>2905</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN80*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.624.000</td><td></td></tr></tbody></table>

|<image_33>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2906</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN100*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.846.000</td><td></td></tr><tr><td>2907</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN100*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.092.000</td><td></td></tr><tr><td>2908</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN150*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.916.000</td><td></td></tr><tr><td>2909</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN150*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.199.000</td><td></td></tr><tr><td>2910</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN150*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.421.000</td><td></td></tr><tr><td>2911</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN180*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.199.000</td><td></td></tr><tr><td>2912</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN180*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.568.000</td><td></td></tr></tbody></table>

|<image_34>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2913</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN180*180</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.184.000</td><td></td></tr><tr><td>2914</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN200*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.815.000</td><td></td></tr><tr><td>2915</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN200*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.307.000</td><td></td></tr><tr><td>2916</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN200*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.553.000</td><td></td></tr><tr><td>2917</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN200*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.861.000</td><td></td></tr><tr><td>2918</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN225*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.383.000</td><td></td></tr><tr><td>2919</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN225*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.691.000</td><td></td></tr></tbody></table>

|<image_35>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2920</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN225*225</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.075.000</td><td></td></tr><tr><td>2921</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN250*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.153.000</td><td></td></tr><tr><td>2922</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN250*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.399.000</td><td></td></tr><tr><td>2923</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN250*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.891.000</td><td></td></tr><tr><td>2924</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN250*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.014.000</td><td></td></tr><tr><td>2925</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN280*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.383.000</td><td></td></tr><tr><td>2926</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN280*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.629.000</td><td></td></tr></tbody></table>

|<image_36>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2927</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN280*280</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.721.000</td><td></td></tr><tr><td>2928</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN300*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.998.000</td><td></td></tr><tr><td>2929</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN300*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.367.000</td><td></td></tr><tr><td>2930</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN300*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.860.000</td><td></td></tr><tr><td>2931</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN300*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>11.075.000</td><td></td></tr><tr><td>2932</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF
DN300*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.967.000</td><td></td></tr><tr><td>2933</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
350*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>10.398.000</td><td></td></tr></tbody></table>

|<image_37>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2934</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
350*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>10.951.000</td><td></td></tr><tr><td>2935</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
350*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>12.268.000</td><td></td></tr><tr><td>2936</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
350*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>13.412.000</td><td></td></tr><tr><td>2937</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
350*350</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.336.000</td><td></td></tr><tr><td>2938</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
400*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>13.130.000</td><td></td></tr><tr><td>2939</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
400*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.520.000</td><td></td></tr><tr><td>2940</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
400*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>15.234.000</td><td></td></tr></tbody></table>

|<image_38>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2941</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
400*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>16.489.000</td><td></td></tr><tr><td>2942</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
400*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>16.612.000</td><td></td></tr><tr><td>2943</td><td>Thiết bị
ngành nước</td><td>Tê gang FFF DN
400*400</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>18.027.000</td><td></td></tr><tr><td>2944</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN80*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.354.000</td><td></td></tr><tr><td>2945</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN100*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.477.000</td><td></td></tr><tr><td>2946</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
100*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.600.000</td><td></td></tr><tr><td>2947</td><td>Thiết bị
ngành nước</td><td>Tê gang BBBDN
150*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.314.000</td><td></td></tr></tbody></table>

|<image_39>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2948</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
150*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.461.000</td><td></td></tr><tr><td>2949</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
150*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.199.000</td><td></td></tr><tr><td>2950</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
200x80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.199.000</td><td></td></tr><tr><td>2951</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN200*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.508.000</td><td></td></tr><tr><td>2952</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN200*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.692.000</td><td></td></tr><tr><td>2953</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN200*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.938.000</td><td></td></tr><tr><td>2954</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN225*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.380.000</td><td></td></tr></tbody></table>

|<image_40>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2955</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN225*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.615.000</td><td></td></tr><tr><td>2956</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN225*225</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.922.000</td><td></td></tr><tr><td>2957</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN250*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.088.000</td><td></td></tr><tr><td>2958</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
250*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.045.000</td><td></td></tr><tr><td>2959</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
250*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.291.000</td><td></td></tr><tr><td>2960</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
250*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.414.000</td><td></td></tr><tr><td>2961</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN280*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.906.000</td><td></td></tr></tbody></table>

|<image_41>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2962</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB
DN280*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.014.000</td><td></td></tr><tr><td>2963</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
280*280</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.752.000</td><td></td></tr><tr><td>2964</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
300*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>6.276.000</td><td></td></tr><tr><td>2965</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
300*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.260.000</td><td></td></tr><tr><td>2966</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
300*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>7.998.000</td><td></td></tr><tr><td>2967</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
300*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.598.000</td><td></td></tr><tr><td>2968</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
300*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.183.000</td><td></td></tr></tbody></table>

|<image_42>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2969</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
350*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>8.183.000</td><td></td></tr><tr><td>2970</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
350*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.106.000</td><td></td></tr><tr><td>2971</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
350 * 200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>9.844.000</td><td></td></tr><tr><td>2972</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
350*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>10.951.000</td><td></td></tr><tr><td>2973</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
350*350</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>11.567.000</td><td></td></tr><tr><td>2974</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
400*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>10.459.000</td><td></td></tr><tr><td>2975</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
400*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>11.752.000</td><td></td></tr></tbody></table>

|<image_43>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2976</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
400*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>12.308.000</td><td></td></tr><tr><td>2977</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
400*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>12.825.000</td><td></td></tr><tr><td>2978</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
400*300</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.028.000</td><td></td></tr><tr><td>2979</td><td>Thiết bị
ngành nước</td><td>Tê gang BBB DN
400*400</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>14.213.000</td><td></td></tr><tr><td>2980</td><td>Thiết bị
ngành nước</td><td>Côn gang BB
DN100*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>738.000</td><td></td></tr><tr><td>2981</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
150*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.539.000</td><td></td></tr><tr><td>2982</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
150*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.642.000</td><td></td></tr></tbody></table>

|<image_44>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2983</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
180 x 80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.662.000</td><td></td></tr><tr><td>2984</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
180 x 100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.785.000</td><td></td></tr><tr><td>2985</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
200x80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.846.000</td><td></td></tr><tr><td>2986</td><td>Thiết bị
ngành nước</td><td>Côn gang
BBĐDN200*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.969.000</td><td></td></tr><tr><td>2987</td><td>Thiết bị
ngành nước</td><td>Côn gang BB
DN200*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.375.000</td><td></td></tr><tr><td>2988</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
250*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.707.000</td><td></td></tr><tr><td>2989</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
250*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.076.000</td><td></td></tr></tbody></table>

|<image_45>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2990</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
300*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.482.000</td><td></td></tr><tr><td>2991</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
300*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.815.000</td><td></td></tr><tr><td>2992</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
300*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.307.000</td><td></td></tr><tr><td>2993</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
350*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.482.000</td><td></td></tr><tr><td>2994</td><td>Thiết bị
ngành nước</td><td>Côn gang BB DN
350*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.815.000</td><td></td></tr><tr><td>2995</td><td>Thiết bị
ngành nước</td><td>Côn gang FF
DN100*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>984.000</td><td></td></tr><tr><td>2996</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
150*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.662.000</td><td></td></tr></tbody></table>

|<image_46>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>2997</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
150*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.846.000</td><td></td></tr><tr><td>2998</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
180x80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.846.000</td><td></td></tr><tr><td>2999</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
180x100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.031.000</td><td></td></tr><tr><td>3000</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
200x80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.154.000</td><td></td></tr><tr><td>3001</td><td>Thiết bị
ngành nước</td><td>Côn gang FF
DN200*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.400.000</td><td></td></tr><tr><td>3002</td><td>Thiết bị
ngành nước</td><td>Côn gang FF
DN200*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.830.000</td><td></td></tr><tr><td>3003</td><td>Thiết bị
ngành nước</td><td>Côn gang FF
DN225*80</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.769.000</td><td></td></tr></tbody></table>

|<image_47>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>3004</td><td>Thiết bị
ngành nước</td><td>Côn gang FF
DN225*100</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.015.000</td><td></td></tr><tr><td>3005</td><td>Thiết bị
ngành nước</td><td>Côn gang FF
DN225*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.537.000</td><td></td></tr><tr><td>3006</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
250*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.372.000</td><td></td></tr><tr><td>3007</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
250*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.754.000</td><td></td></tr><tr><td>3008</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
300*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.877.000</td><td></td></tr><tr><td>3009</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
300*200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.331.000</td><td></td></tr><tr><td>3010</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
300*250</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>5.107.000</td><td></td></tr></tbody></table>

|<image_48>|


## VIETTEL AI RACE

## TD646

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD646</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH NƯỚC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại
vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu
chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>3011</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
350*150</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.872.000</td><td></td></tr><tr><td>3012</td><td>Thiết bị
ngành nước</td><td>Côn gang FF DN
350 * 200</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>4.307.000</td><td></td></tr><tr><td>3013</td><td>Thiết bị
ngành nước</td><td>Nắp chụp hố van
gang/Chụp van
gang cầu ( DN 150)</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>530.000</td><td></td></tr><tr><td>3014</td><td>Thiết bị
ngành nước</td><td>Nắp chụp hố van
gang/Chụp van
gang cầu ( DN 100)</td><td>cái</td><td>ISO
2531:2009</td><td>Bằng gang cầu</td><td>Công ty CP Đầu
tư và Sản xuất
HCL</td><td>Đã bao
gồm
VC</td><td>Giá bán đến chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>410.000</td><td></td></tr></tbody></table>

|<image_49>|


