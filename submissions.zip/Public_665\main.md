# Public_665

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD665</th></tr></thead><tbody><tr><td></td><td>GHÉP BẰNG REN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Phân
loại</th><th>Tên gọi</th><th>Hình dạng</th><th>Hình chiếu</th><th>Ký hiệu</th></tr></thead><tbody><tr><td>Bulông</td><td>Bulông
tinh đầu
Sáu cạnh</td><td></td><td></td><td>Bulông
M12 x 50
TCVN
1892-76</td></tr><tr><td>Vít</td><td>Vít cấy</td><td></td><td></td><td>Vít cấy A1-
M12 x45
TCVN
3608-81</td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD665</th></tr></thead><tbody><tr><td></td><td>GHÉP BẰNG REN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Phân
loại</th><th>Tên gọi</th><th>Hình dạng</th><th>Hình chiếu</th><th>Ký hiệu</th></tr></thead><tbody><tr><td></td><td>Vít đầu
trụ</td><td></td><td></td><td>Vít đầu trụ
M10 x 45
TCVN52-86</td></tr><tr><td></td><td>Vít đầu
chìm</td><td></td><td></td><td>Vít đầu chìm
M10 x45
TCVN58-86</td></tr><tr><td></td><td>Vít định vị</td><td></td><td></td><td>Vít đuôi thẳng
hìnhnón
M5x20
TCVN 1905-
76</td></tr><tr><td>Đai</td><td>Đai ốc</td><td></td><td></td><td>Đai ốc 1-M16
TCVN 1905-
76</td></tr></tbody></table>

|<image_6>|

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD665</th></tr></thead><tbody><tr><td></td><td>GHÉP BẰNG REN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Phân
loại</th><th>Tên gọi</th><th>Hình dạng</th><th>Hình chiếu</th><th>Ký hiệu</th></tr></thead><tbody><tr><td></td><td>Đai ốc xẻ
rãnh</td><td></td><td></td><td>Đai ốc xẻ
rãnh 1-
M16
TCVN
1911-76</td></tr><tr><td></td><td>Vòng đệm</td><td></td><td></td><td>Vòng đệm 16
TCVN 2061-
77</td></tr></tbody></table>

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|

|<image_21>|

|<image_22>|

|<image_23>|

|<image_24>|

|<image_25>|

|<image_26>|

|<image_27>|

|<image_28>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD665</th></tr></thead><tbody><tr><td></td><td>GHÉP BẰNG REN</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_29>|

|<image_30>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD665</th></tr></thead><tbody><tr><td></td><td>GHÉP BẰNG REN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_31>|

|<image_32>|

|<image_33>|

|<image_34>|

|<image_35>|

|<image_36>|


