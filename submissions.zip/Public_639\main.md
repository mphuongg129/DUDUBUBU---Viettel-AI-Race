# Public_639

### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố
Cao Bằng</td></tr><tr><td>&lt;1&gt;</td><td>&lt;2&gt;</td><td>&lt;3&gt;</td><td></td><td></td><td>&lt;4&gt;</td><td>&lt;5&gt;</td><td>&lt;6&gt;</td><td>&lt;7&gt;</td><td>&lt;8&gt;</td><td>&lt;9&gt;</td><td>&lt;10&gt;</td><td>&lt;11&gt;</td></tr><tr><td></td><td>Vật tư
ngành
điện</td><td>Đèn LED chiếu sáng đường
phố - VihaLighting</td><td></td><td></td><td></td><td>TCVN 7722-
1:2017
TCVN 7722-2-
3:2019
TCVN 4255:2008
ISO 9001:2015</td><td></td><td>Công ty
TNHH TM và
sản xuất Việt
Hải</td><td>Việt
Nam</td><td>Giá bán trên
địa bàn tỉnh
Cao Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL1-
60W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;
120lm/w, chống xung sét
10kA)</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.000.000</td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL1-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.500.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>VHL1-60W ( (Dim 5 cấp</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.000.000</td></tr><tr><td></td><td></td><td></td><td>công suất, kết nối 1-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL2-
80W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;
120lm/w, chống xung sét
10kA)</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.200.000</td></tr></tbody></table>

|<image_1>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL2-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.500.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL2-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.200.000</td></tr><tr><td></td><td></td><td></td><td>120W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL2-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.500.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL3-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.700.000</td></tr><tr><td></td><td></td><td></td><td>80W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL3-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.000.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL3-
120W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.500.000</td></tr></tbody></table>

<table><thead><tr><th>Đèn LED đường phố VHL3-</th></tr></thead><tbody><tr><td>120W (Dim 5 cấp công suất,</td></tr><tr><td>kết nối 1-10V/DALI, lumen &gt;</td></tr></tbody></table>

|<image_2>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>120lm/w, chống xung sét
10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL3-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.000.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL4-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.500.000</td></tr><tr><td></td><td></td><td></td><td>50W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL4-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.000.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL4-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.500.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL16-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.000.000</td></tr><tr><td></td><td></td><td></td><td>50W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>120lm/w, chống xung sét</th></tr></thead><tbody><tr><td>10kA)</td></tr></tbody></table>

|<image_3>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL16-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.500.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL16-
150W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;
120lm/w, chống xung sét
10kA)</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.000.000</td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL26-
80W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;
120lm/w, chống xung sét
10kA)</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.000.000</td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL26-
100W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;
120lm/w, chống xung sét
10kA)</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.200.000</td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL26-
120W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;
120lm/w, chống xung sét
10kA)</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.500.000</td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL26-
150W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.800.000</td></tr></tbody></table>

<table><thead><tr><th>Đèn LED đường phố VHL26-</th></tr></thead><tbody><tr><td>150W (Dim 5 cấp công suất,</td></tr><tr><td>kết nối 1-10V/DALI, lumen &gt;</td></tr></tbody></table>

|<image_4>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>120lm/w, chống xung sét
10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL39-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.500.000</td></tr><tr><td></td><td></td><td></td><td>80W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL39-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.000.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL39-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.600.000</td></tr><tr><td></td><td></td><td></td><td>120W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL39-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.200.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL55-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.500.000</td></tr><tr><td></td><td></td><td></td><td>80W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>120lm/w, chống xung sét</th></tr></thead><tbody><tr><td>10kA)</td></tr></tbody></table>

|<image_5>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL55-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.000.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL55-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.200.000</td></tr><tr><td></td><td></td><td></td><td>120W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL55-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.500.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL86-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.000.000</td></tr><tr><td></td><td></td><td></td><td>80W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL86-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.200.000</td></tr><tr><td></td><td></td><td></td><td>99W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL86-
100W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.000.000</td></tr></tbody></table>

|<image_6>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>120lm/w, chống xung sét
10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL86-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.600.000</td></tr><tr><td></td><td></td><td></td><td>120W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL86-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.300.000</td></tr><tr><td></td><td></td><td></td><td>140W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL86-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.500.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL88-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.000.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL88-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.600.000</td></tr><tr><td></td><td></td><td></td><td>125W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_7>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL88-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.500.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL98-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.950.000</td></tr><tr><td></td><td></td><td></td><td>80W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL98-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.100.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL98-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.500.000</td></tr><tr><td></td><td></td><td></td><td>120W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL98-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.600.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Đèn LED đường phố VHL99-
80W (Dim 5 cấp công suất,
kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.800.000</td></tr></tbody></table>

<table><thead><tr><th>Đèn LED đường phố VHL99-</th></tr></thead><tbody><tr><td>80W (Dim 5 cấp công suất,</td></tr><tr><td>kết nối 1-10V/DALI, lumen &gt;</td></tr></tbody></table>

|<image_8>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>120lm/w, chống xung sét
10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL99-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.000.000</td></tr><tr><td></td><td></td><td></td><td>100W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL99-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.500.000</td></tr><tr><td></td><td></td><td></td><td>120W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL99-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.000.000</td></tr><tr><td></td><td></td><td></td><td>150W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL99-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.450.000</td></tr><tr><td></td><td></td><td></td><td>180W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn LED đường phố VHL99-</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.950.000</td></tr><tr><td></td><td></td><td></td><td>200W (Dim 5 cấp công suất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kết nối 1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>120lm/w, chống xung sét</th></tr></thead><tbody><tr><td>10kA)</td></tr></tbody></table>

|<image_9>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Đèn pha LED -</td><td></td><td></td><td>TCVN 7722-
1:2017
TCVN 7722-2-
3:2019
TCVN 4255:2008
ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>VihaLighting</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn pha LED VHFL4-150W</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.000.000</td></tr><tr><td></td><td></td><td></td><td>(Dim 5 cấp công suất, kết nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn pha LED VHFL4-200W</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.500.000</td></tr><tr><td></td><td></td><td></td><td>(Dim 5 cấp công suất, kết nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn pha LED VHFL4-300W</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.300.000</td></tr><tr><td></td><td></td><td></td><td>(Dim 5 cấp công suất, kết nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn pha LED VHFL4-400W</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.500.000</td></tr><tr><td></td><td></td><td></td><td>(Dim 5 cấp công suất, kết nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Đèn pha LED VHFL4-500W</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>13.000.000</td></tr><tr><td></td><td></td><td></td><td>(Dim 5 cấp công suất, kết nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1-10V/DALI, lumen &gt;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>120lm/w, chống xung sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10kA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Bộ đèn LED chiếu sáng sử</td><td></td><td></td><td>TCVN 7722-
1:2017</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>dụng năng lượng mặt trời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_10>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bộ đèn LED 50W sử dụng</td><td></td><td>Bộ</td><td>TCVN 7722-2-
3:2019
TCVN 4255:2008
ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td>14.200.000</td></tr><tr><td></td><td></td><td></td><td>Năng Lượng Mặt Trời bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>gồm:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Đèn LED đường phố</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>VHL16-50W</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Pin lưu trữ lithium LiFePO4</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>12,8V-36Ah</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Tấm pin NLMT đơn tinh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>thể, công suất 100Wp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Bộ điều khiển LED Solar</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Street Light Controller</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Bộ đèn LED 80W sử dụng</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1Ccapcaôô6.50
0.000</td></tr><tr><td></td><td></td><td></td><td>Năng Lượng Mặt Trời bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>gồm:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Đèn LED đường phố</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>VHL16-80W</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Pin lưu trữ lithium LiFePO4</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>12,8V-42Ah</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Tấm pin NLMT đơn tinh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>thể, công suất 120Wp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Bộ điều khiển LED Solar</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Street Light Controller</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_11>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bộ đèn LED 100W sử dụng</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>19.300.000</td></tr><tr><td></td><td></td><td></td><td>Năng Lượng Mặt Trời bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>gồm:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Đèn LED đường phố</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>VHL16-100W</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Pin lưu trữ lithium LiFePO4</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>12,8V-72Ah</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Tấm pin NLMT đơn tinh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>thể, công suất 2x120Wp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Bộ điều khiển LED Solar</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Street Light Controller</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép liền cần đơn mạ</td><td></td><td></td><td>TCCS
01:2018/VIETHAI
ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td>2.870.000</td></tr><tr><td></td><td></td><td></td><td>kẽm nhúng nóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BGC, TC liền cần</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.275.000</td></tr><tr><td></td><td></td><td></td><td>đơn, H=7m, tôn dày 3mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BGC, TC liền cần</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.920.000</td></tr><tr><td></td><td></td><td></td><td>đơn, H=8m, tôn dày 3mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BGC, TC liền cần</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.580.000</td></tr><tr><td></td><td></td><td></td><td>đơn, H=8m, tôn dày 3,5mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BGC, TC liền cần</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.970.000</td></tr><tr><td></td><td></td><td></td><td>đơn, H=9m, tôn dày 3,5mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BGC, TC liền cần</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>đơn, H=10m, tôn dày 4mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép đầu ngọn D78 mạ</td><td></td><td></td><td>TCCS
01:2018/VIETHAI
ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kẽm nhúng nóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BG, TC 6m D78-</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.860.000</td></tr><tr><td></td><td></td><td></td><td>3mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_12>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Cột thép BG, TC 7m D78-</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.650.000</td></tr><tr><td></td><td></td><td></td><td>3,5mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BG, TC 8m D78-</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.120.000</td></tr><tr><td></td><td></td><td></td><td>3,5mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BG, TC 9m D78-</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.230.000</td></tr><tr><td></td><td></td><td></td><td>3,5mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cột thép BG, TC 10m D78-</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.350.000</td></tr><tr><td></td><td></td><td></td><td>4mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cần đèn rời mạ kẽm nhúng</td><td></td><td></td><td>TCCS
01:2018/VIETHAI
ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cần đèn đơn VH D01, VH</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>965.200</td></tr><tr><td></td><td></td><td></td><td>D03, VH D04, VH D05, VH</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>D06 cao 2m, vươn 1,5m</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cần đèn đôi VH K01, VH</td><td></td><td>Chiếc</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.555.400</td></tr><tr><td></td><td></td><td></td><td>K03, VH K04, VH K05, VH</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>K06 cao 2m, vươn 1,5m</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Khung móng cột đèn</td><td></td><td></td><td>ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Khung móng</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>485.000</td></tr><tr><td></td><td></td><td></td><td>M24x300x300x(675-750)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Khung móng</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>285.000</td></tr><tr><td></td><td></td><td></td><td>M16x240x240x(500-600)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Khung móng</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>310.000</td></tr><tr><td></td><td></td><td></td><td>M16x260x260x(500-600)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Khung móng</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>325.000</td></tr><tr><td></td><td></td><td></td><td>M16x340x340x(500-600)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_13>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th></th><th></th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Cọc tiếp địa mạ kẽm nhúng</td><td></td><td></td><td>ISO 9001:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>L63x63x6, L=1500mm, râu</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.000</td></tr><tr><td></td><td></td><td></td><td>thép D10 kèm tai bắt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>L63x63x6, L=2000mm, râu</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>490.000</td></tr><tr><td></td><td></td><td></td><td>thép D10 kèm tai bắt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>L63x63x6, L=2500mm, râu</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>525.000</td></tr><tr><td></td><td></td><td></td><td>thép D10 kèm tai bắt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>35</td><td>Vật tư
ngành
điện</td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D130/58mm,
H=6m tôn dày 3mm</td><td></td><td></td><td>Cột</td><td>ISO 9001:2015;
ISO 14001:2015;
TCVN 7722-2-
3:2019; AWS
D1.1M và JIS
G3101, mác
SS400; ASTM A
123/A 123M; JIS
G 3101 mác
SS400.</td><td></td><td>Công ty cổ
phần WINCO
Việt Nam</td><td>Việt
Nam</td><td>Giá bán trên
địa bàn tỉnh
Cao Bằng</td><td></td><td>3.320.200</td></tr><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D140/58mm,
H=7m tôn dày 3mm</td><td></td><td></td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.785.350</td></tr><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D150/58mm,
H=8m tôn dày 3mm</td><td></td><td></td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.712.500</td></tr><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D151/58mm,
H=8m tôn dày 3,5 mm</td><td></td><td></td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.625.500</td></tr><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D161/58mm,
H=9m tôn dày 3,5mm</td><td></td><td></td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.657.500</td></tr><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D171/58mm,
H=10m tôn dày 3,5mm</td><td></td><td></td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.972.500</td></tr></tbody></table>

|<image_14>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D182/58mm,
H=11m tôn dày 4mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.497.500</td></tr><tr><td></td><td></td><td>Cột thép bát giác, Tròn côn
liền cần đơn, D192/58mm,
H=11m tôn dày 4mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.054.000</td></tr><tr><td></td><td></td><td>Cột thép Bát giác, Tròn côn
6m D150/78-3mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.752.800</td></tr><tr><td></td><td></td><td>Cột thép Bát giác, Tròn côn
7m D160/78-3mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.670.500</td></tr><tr><td></td><td></td><td>Cột thép Bát giác, Tròn côn
8m D171/78-3,5mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.574.550</td></tr><tr><td></td><td></td><td>Cột thép Bát giác, Tròn côn
9m D182/78-4mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.463.900</td></tr><tr><td></td><td></td><td>Cột thép Bát giác, Tròn côn
10m D192/78-4mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.296.550</td></tr><tr><td></td><td></td><td>Cột thép Bát giác, Tròn côn
11m D202/78-4mm</td><td>Cột</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.156.500</td></tr><tr><td></td><td></td><td>Cần đèn Cánh Hạc Đơn cao
2m, vươn 1,5m, dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.853.350</td></tr><tr><td></td><td></td><td>Cần đèn Cánh Hạc Đôi cao
2m, vươn 1,5m, dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.318.500</td></tr><tr><td></td><td></td><td>Cần đèn Cánh Hạc Ba cao
2m, vươn 1,5m, dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.200.000</td></tr><tr><td></td><td></td><td>Cần đèn CD-04 cao 2m, vươn
1,5m, dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.951.000</td></tr></tbody></table>

|<image_15>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Cần đèm CK04 cao 2m vươn
1,5m dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.749.000</td></tr><tr><td></td><td></td><td>Cần đèn CD-01 cao 2m,
vươn 1,5m, dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.898.500</td></tr><tr><td></td><td></td><td>Cần đèn CK-01 cao 2m,
vươn 1,5m, dày 3mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.539.000</td></tr><tr><td></td><td></td><td>Đế gang DP01 cao 1,38m
thân cột thép cao 8m ngọn
D78-3.5</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.347.850</td></tr><tr><td></td><td></td><td>Đế gang DP01 cao 1,38m
thân cột thép cao 8m ngọn
D78-4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.079.700</td></tr><tr><td></td><td></td><td>Đế gang DP01 cao 1,38m
thân cột thép cao 9m ngọn
D78-4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.518.600</td></tr><tr><td></td><td></td><td>Đế gang DP01 cao 1,38m
thân cột thép cao 10m ngọn
D78-4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>12.103.450</td></tr><tr><td></td><td></td><td>Đế gang DC05B cao 1,58m
thân cột thép cao 8m ngọn
D78-3.5</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.639.750</td></tr><tr><td></td><td></td><td>Đế gang DC05Bcao 1,58m
thân cột thép cao 8m ngọn
D78-4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.371.600</td></tr><tr><td></td><td></td><td>Đế gang DC05B cao 1,58m
thân cột thép cao 9m ngọn
D78-4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.957.500</td></tr></tbody></table>

|<image_16>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đế gang DC05B cao 1,58m
thân cột thép cao 10m ngọn
D78-4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>12.396.400</td></tr><tr><td></td><td></td><td>Đế gang sư tử cao 2,9m thân
cột thép cao 9m ngọn D78-
4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>17.920.000</td></tr><tr><td></td><td></td><td>Đế gang sư tử cao 2,9m thân
cột thép cao 10m ngọn D78-
4.0</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>20.050.000</td></tr><tr><td></td><td></td><td>Cột đa giác 14m-130-5mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>21.292.000</td></tr><tr><td></td><td></td><td>Cột đa giác 17m-150-5mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>28.845.322</td></tr><tr><td></td><td></td><td>Cột đa giác 20m-180-5mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>41.767.000</td></tr><tr><td></td><td></td><td>Lọng bắt pha không đèn 8
cạnh</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.282.000</td></tr><tr><td></td><td></td><td>Cột đa giác nâng hạ 20-25m-
ngọn D260/600-5/6/6mm, bắt
8-16 đèn</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>185.250.000</td></tr><tr><td></td><td></td><td>Cột đa giác nâng hạ 30-35m-
ngọn D260/728-6/6/8/8mm,
bắt 8-16đèn</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>350.250.000</td></tr><tr><td></td><td></td><td>Cột đa giác SVĐ 30M + Dàn
thao tác và Giá lắp đèn 24 -
32 đèn pha, có thang trèo -
ngọn D950/450- 9/9/9/6mm
dày 10/8/8/8mm</td><td>Cái</td><td></td><td></td><td></td><td></td><td></td><td></td><td>550.250.000</td></tr></tbody></table>

|<image_17>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 90W
DIMMING 5-6 cấp</td><td>Bộ</td><td>TCVN
10885:2015,
TCVN
10485:2015,
TCVN
11843:2017,
TCVN 7722-
1:2017, TCVN
7722-2-3:2019,
TCVN 4255:2008,
IEC 62262:2002,
IEC 61643-
11:2011</td><td></td><td></td><td></td><td></td><td></td><td>6.984.250</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 100W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.500.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 120W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.856.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 150W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.265.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 160W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.567.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 180W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.704.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 200W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.859.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 220W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.012.000</td></tr></tbody></table>

|<image_18>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 240W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.189.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MAX công suất 250W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.368.000</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 90W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.984.250</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 100W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.093.150</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 120W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.746.550</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 150W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.672.200</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 160W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.979.000</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 180W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>12.686.850</td></tr></tbody></table>

|<image_19>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 200W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>13.993.650</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 220W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>14.701.500</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 240W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>16.879.500</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN
MAX công suất 250W
DIMMING 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>17.968.500</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 40W
DIMMING</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.381.540</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 50W
DIMMING</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.588.450</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 60W
DIMMING</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.806.250</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 70W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.024.050</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 80W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.241.850</td></tr></tbody></table>

|<image_20>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 90W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.568.550</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 100W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.805.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 110W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.945.000</td></tr><tr><td></td><td></td><td>Đèn đường Led A-WIN
MINI công suất 120W
DIMMING 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.056.000</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 40W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.381.540</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 50 W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.588.450</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 60W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.806.250</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 70W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.024.050</td></tr></tbody></table>

|<image_21>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 80W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.241.850</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 90W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.568.550</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 100W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.167.500</td></tr><tr><td></td><td></td><td>Đèn đường Led C-WIN MINI
công suất 120W DIMMING 6
cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.093.150</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN ông
suất 30-40W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.746.000</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 50W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.221.650</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 60W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.940.900</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 70W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.210.750</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 80W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.483.750</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 90W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.161.000</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 100W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.472.850</td></tr></tbody></table>

|<image_22>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 120W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.785.750</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 150W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.351.700</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 160W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.699.250</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 170W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.307.200</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 180W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.695.700</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 200W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.179.750</td></tr><tr><td></td><td></td><td>Đèn đường Led D-WIN công
suất 240W DIM 5-6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.198.250</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 200w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.750.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 250w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.680.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 300w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.400.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 400w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>12.500.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 500w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>15.500.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 600w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>19.500.000</td></tr></tbody></table>

|<image_23>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 700w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>22.500.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 800w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>23.500.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 900w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>25.500.000</td></tr><tr><td></td><td></td><td>Đèn pha led ANDES công
suất 1000w DIM 5 - 6 cấp</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>27.500.000</td></tr><tr><td></td><td></td><td>Phần mềm điều khiển giám
sát và quản lý chiếu
sáng trên bản đồ GIS</td><td>Phần
mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>450.000.000</td></tr><tr><td></td><td></td><td>Hệ điều hành máy chủ Sever
(Window
sever License)</td><td>Phần
mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>28.200.000</td></tr><tr><td></td><td></td><td>Hệ điều hành máy tính vận
hành (Window
license)</td><td>Phần
mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.850.000</td></tr><tr><td></td><td></td><td>Phần mềm diệt virut cho 5
PCs (Scurity
license)</td><td>Phần
mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.000.000</td></tr><tr><td></td><td></td><td>Modem kết nối truyền thông
GSM/GPRS
và nhắn tin cảnh báo sự cố</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.000.000</td></tr><tr><td></td><td></td><td>Thiết bị điều khiển và giám
sát từ trung tâm lắp đặt tại tủ</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>60.000.000</td></tr></tbody></table>

|<image_24>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Bộ điều khiển truyền thông
ISEVER Lora-Mesh lắp đặt
tại tủ</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.000.000</td></tr><tr><td></td><td></td><td>Bộ chống sét lan chuyền
3P+N, 40KVA</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.500.000</td></tr><tr><td></td><td></td><td>Bộ điều khiển thông minh
W'LCU cho đèn đường LED
công suất từ 40-200W</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.500.000</td></tr><tr><td></td><td></td><td>Bộ điều khiển thông minh
W'LCU cho đèn pha LED
công suất từ 250W-400W</td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.500.000</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
32/25</td><td>Mét</td><td>TCVN 7434:04;
KSM 3413: 93;
TCVN 7997:
2009;
TCVN 7997:
2009;
TCVN 7997:
2009;
ISO 3127</td><td></td><td></td><td></td><td></td><td></td><td>12.800</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
40/30</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>14.900</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
50/40</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>21.400</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
65/50</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>29.300</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
85/65</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>42.500</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
90/72</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>52.400</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
105/80</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>55.300</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
110/90</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>63.600</td></tr></tbody></table>

|<image_25>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD639</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu
xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển (*)</th><th>Ghi chú</th><th>Giá bán chưa
bao gồm thuế
giá trị gia
tăng) (*)</th></tr></thead><tbody><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
130/100</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>78.100</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
160/125</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>121.400</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
195/150</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>165.800</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
230/175</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>247.200</td></tr><tr><td></td><td></td><td>Ống nhựa gân xoắn HDPE
260/200</td><td>Mét</td><td></td><td></td><td></td><td></td><td></td><td></td><td>295.500</td></tr></tbody></table>

|<image_26>|


