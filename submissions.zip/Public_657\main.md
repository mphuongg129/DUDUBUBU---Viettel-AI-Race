# Public_657

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD657</th></tr></thead><tbody><tr><td></td><td>GIAO DIỆN MÀN HÌNH CẢM ỨNG
E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Thanh trên cùng – Hiển thị trạng thái</th><th></th></tr></thead><tbody><tr><td></td><td></td></tr><tr><td></td><td>Lệnh in
Hữu ích để có ảnh màn hình hoặc bản in
thông tin và cài đặt sản xuất, hoặc để liên
lạc với người bảo dưỡng.</td></tr><tr><td></td><td>Thông báo cảnh báo/trạng thái lỗi
Nếu có một báo động, hộp này sẽ hiển thị màu
đỏ kèm theo mô tả về báo động đó.
Nếu có hai hoặc nhiều báo động, thì số lượng
báo động sẽ hiển thị ở bên phải. Trong ví dụ
này là 6 báo động.
Để xem tất cả các báo động hiện hoạt, hãy
nhấn vào thanh thông báo màu đỏ hoặc nút
[Alarm] (Báo động).</td></tr><tr><td></td><td>Trạng thái trực tiếp hiện tại
Trạng thái trực tiếp về tốc độ và vị trí của
trục vít, áp suất phun.</td></tr><tr><td></td><td>Cấp độ người dùng
Hiển thị người dùng hiện tại và cấp độ truy
cập của người dùng hiện tại.</td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD657</th></tr></thead><tbody><tr><td></td><td>GIAO DIỆN MÀN HÌNH CẢM ỨNG
E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Cửa sổ chế độ và trạng thái
Cho biết hệ thống nào đang hoạt động, trạng
thái của hệ thống đó và có bất kỳ báo động
nào hay không.</th></tr></thead><tbody></tbody></table>

<table><thead><tr><th>Các biểu tượng chuyển động hiện hoạt</th><th></th></tr></thead><tbody><tr><td></td><td>Lắp trục vít</td></tr><tr><td></td><td>Giữ trục vít</td></tr><tr><td></td><td>Xoay trục vít (dẻo hóa)</td></tr><tr><td></td><td>Lùi trục vít</td></tr><tr><td></td><td>Tiến trục vít</td></tr><tr><td></td><td>Tiến giá trượt</td></tr></tbody></table>

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|

|<image_15>|


### Trạng thái gia nhiệt khoang chứa – màu xám (hiển thị)

### Chỉ báo chế độ – Một biểu tượng cho biết chế độ hiện tại

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD657</th></tr></thead><tbody><tr><td></td><td>GIAO DIỆN MÀN HÌNH CẢM ỨNG
E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Lùi giá trượt</th></tr></thead><tbody></tbody></table>

<table><thead><tr><th>Biểu tượng trạng thái</th><th></th><th></th></tr></thead><tbody><tr><td></td><td>Trạng thái gia nhiệt khoang chứa – màu xám (hiển thị)
khi bộ gia nhiệt khoang chứa tắt và màu lục khi bộ gia nhiệt
khoang chứa bật. Giống như đèn LED nút [F8].</td><td></td></tr><tr><td></td><td>Hoạt động của động cơ servo – màu xám (hiển thị) khi
động cơ servo tắt và màu lục nếu động cơ bật</td><td></td></tr><tr><td></td><td>Chỉ báo chế độ – Một biểu tượng cho biết chế độ hiện tại
của máy</td><td></td></tr><tr><td></td><td></td><td>Chế độ thủ công. Máy chạy ở tốc độ tối
đa.</td></tr><tr><td></td><td></td><td>Chế độ thiết lập. Máy chạy ở tốc độ
thiết lập.</td></tr><tr><td></td><td></td><td>Chế độ tự động. Máy sẽ vận hành tự
động khi máy ép phun khởi động đúng
cách và kết nối EuroMap giữa máy ép
phun và rô-bốt là chính xác.</td></tr></tbody></table>

<table><thead><tr><th>Các nút điều hướng màn hình</th><th></th></tr></thead><tbody><tr><td></td><td>Màn hình Tổng quan (Màn hình chính)</td></tr></tbody></table>

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|

|<image_21>|

|<image_22>|

|<image_23>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD657</th></tr></thead><tbody><tr><td></td><td>GIAO DIỆN MÀN HÌNH CẢM ỨNG
E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Màn hình này là "trang chủ" của hệ thống. Màn hình này
cung cấp thông tin tổng quan về hoạt động của E-Multi.</th></tr></thead><tbody><tr><td></td><td>Màn hình cài đặt phun
Màn hình này dùng để điều chỉnh các mục cài đặt cho
giai đoạn phun của chu trình ép phun E-Multi.</td></tr><tr><td></td><td>Màn hình cài đặt giữ
Màn hình này dùng để điều chỉnh các mục cài đặt cho
giai đoạn giữ của chu trình ép phun E-Multi.</td></tr><tr><td></td><td>Màn hình cài đặt phục hồi
Màn hình này dùng để điều chỉnh các mục cài đặt cho
giai đoạn phục hồi hoặc dẻo hóa của chu trình phun E-
Multi.</td></tr><tr><td></td><td>Màn hình cài đặt nhiệt độ khoang chứa
Màn hình này dùng để điều chỉnh các mục cài đặt cho bộ
gia nhiệt khoang chứa E-Multi.</td></tr><tr><td></td><td>Màn hình kiểm soát nhiệt độ kênh dẫn nóng
Màn hình này dùng để điều chỉnh các thông số kiểm soát
nhiệt độ kênh dẫn nóng của những hệ thống tích hợp tùy
chọn này. Nếu không có tùy chọn này, thì nút sẽ có màu
xám như minh họa ở trên.</td></tr><tr><td></td><td>Màn hình E-Drive
Màn hình này dùng để điều chỉnh các thông số E-Drive
cho những hệ thống tích hợp E-Drive. Nếu không có tùy
chọn này thì nút sẽ có màu xám.</td></tr><tr><td></td><td>Màn hình cửa van</td></tr></tbody></table>

|<image_24>|

|<image_25>|

|<image_26>|

|<image_27>|

|<image_28>|

|<image_29>|

|<image_30>|

|<image_31>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD657</th></tr></thead><tbody><tr><td></td><td>GIAO DIỆN MÀN HÌNH CẢM ỨNG
E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Màn hình này dùng để điều chỉnh hoạt động của các đầu
ra kích hoạt cửa van kỹ thuật số.</th></tr></thead><tbody><tr><td></td><td>Màn hình biểu đồ sản xuất
Màn hình Biểu đồ sản xuất dùng để hiển thị thông tin sản
xuất theo thời gian thực dựa trên các biến đặt sẵn của hệ
thống.</td></tr><tr><td></td><td>Màn hình thông số kỹ thuật máy (Tổng quan về bảo
dưỡng)
Màn hình này đóng vai trò là một điểm truy cập trung
tâm dành cho tất cả các màn hình cấu hình, cũng như
màn hình bảo dưỡng và bảo trì.</td></tr><tr><td></td><td>Hiển thị báo động
Đưa người dùng đến màn hình hiển thị báo động có danh
sách báo động do hệ thống điều khiển kích hoạt.</td></tr><tr><td></td><td>Nút quay lại
Quay lại màn hình đã hiển thị trước đó.</td></tr></tbody></table>

|<image_32>|

|<image_33>|

|<image_34>|

|<image_35>|

|<image_36>|

|<image_37>|


