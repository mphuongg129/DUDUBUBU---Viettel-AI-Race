# Public_671

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD671</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC TRONG BẢN VẼ SƠ ĐỒ HỆ
THỐNG ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên các phần tử trên sơ đồ</th><th>Kí hiệu</th></tr></thead><tbody><tr><td>Máy phát điện (F)</td><td></td></tr><tr><td>Trạm biến áp (TBA)</td><td></td></tr><tr><td>Trạm phân phối, trạm cắt (TPP)</td><td></td></tr><tr><td>Máy biến áp (BA)</td><td></td></tr><tr><td>Máy cắt điện (MC)</td><td></td></tr><tr><td>Máy biến áp đo lường (BU)</td><td></td></tr><tr><td>Máy biến dòng điện (BI)</td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|

|<image_7>|

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD671</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC TRONG BẢN VẼ SƠ ĐỒ HỆ
THỐNG ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Máy cắt phụ tải (MCPT)
Dao cắt phụ tải (DCPT)</th><th></th></tr></thead><tbody><tr><td>Dao cách ly (DCL)</td><td></td></tr><tr><td>Cầu dao (CD)</td><td></td></tr><tr><td>Cầu chì (CC)</td><td></td></tr><tr><td>Cầu chì tự rơi</td><td></td></tr><tr><td>Tụ bù</td><td></td></tr><tr><td>Áp tô mát (A)</td><td></td></tr><tr><td>Khởi động từ (KĐT)
Công tắc tơ (CT)</td><td></td></tr><tr><td>Động cơ điện (Đ)</td><td></td></tr><tr><td>Thanh góp (thanh cái) (TG)</td><td></td></tr><tr><td>Dây trung tính</td><td></td></tr><tr><td>Dây dẫn</td><td></td></tr><tr><td>Đèn sợi đốt</td><td></td></tr><tr><td>Đèn túyp</td><td></td></tr><tr><td>Chuông</td><td></td></tr><tr><td>Ổ và phích cắm</td><td></td></tr><tr><td>Công tắc (đơn, kép)</td><td></td></tr></tbody></table>

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|

|<image_21>|

|<image_22>|

|<image_23>|

|<image_24>|

|<image_25>|

|<image_26>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD671</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC TRONG BẢN VẼ SƠ ĐỒ HỆ
THỐNG ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Bảng điện</th><th></th></tr></thead><tbody><tr><td>Đồng hồ vôn, Ampe, cos</td><td></td></tr><tr><td>Công tơ hữu công, công tơ vô công</td><td></td></tr><tr><td>Nối đất</td><td></td></tr><tr><td>Quạt điện</td><td></td></tr><tr><td>Tiếp điểm thường mở</td><td></td></tr><tr><td>Tiếp điểm thường đóng</td><td></td></tr><tr><td>Nút ấn thường mở</td><td></td></tr><tr><td>Nút ấn thường đóng</td><td></td></tr></tbody></table>

|<image_27>|

|<image_28>|

|<image_29>|

|<image_30>|

|<image_31>|

|<image_32>|

|<image_33>|

|<image_34>|

|<image_35>|

|<image_36>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD671</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC TRONG BẢN VẼ SƠ ĐỒ HỆ
THỐNG ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_37>|

|<image_38>|

|<image_39>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD671</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC TRONG BẢN VẼ SƠ ĐỒ HỆ
THỐNG ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_40>|

|<image_41>|


