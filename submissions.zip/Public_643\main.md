# Public_643

## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>IX</td><td>Hệ thống trần</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9,1</td><td>Trần nhôm (Công ty Cổ phần FOSTER Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Số 10, LK 398, Khu A, phường Yên Nghĩa, quận Hà Đông, Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>C- Shaped, sơn tĩnh điện gia nhiệt PE; phụ kiện: khung xương thép tiêu chuẩn 1,2m/m², móc treo..</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>621</td><td>Vật liệu
hoàn
thiện</td><td>C100 phẳng- Shaped, chiều
dày 0,6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, màu
đen, ghi tiêu</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>450,000</td></tr><tr><td>622</td><td>Vật liệu
hoàn
thiện</td><td>C150 phẳng- Shaped, chiều
dày 0,6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, màu
đen, ghi tiêu</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>410,000</td></tr><tr><td>623</td><td>Vật liệu
hoàn
thiện</td><td>C300 phẳng- Shaped, chiều
dày 0,8mm
C300 phẳng- Shaped, chiều
dày 0,9mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, màu
đen, ghi tiêu</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>570,000</td></tr><tr><td>624</td><td>Vật liệu
hoàn
thiện</td><td></td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, màu
đen, ghi tiêu</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư</td><td></td><td>630,000</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td></td></tr><tr><td>*</td><td>Clip- In, bề mặt đục lỗ D1,8mm, sơn tĩnh điện gia nhiệt PE. Phụ kiện: Khung tam giác 1,8m, 02 móc treo, 0,4 nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>625</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,6) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>440,000</td></tr><tr><td>626</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,7) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>480,000</td></tr><tr><td>627</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,8) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>530,000</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>628</td><td>Vật liệu
hoàn
thiện</td><td>(300x300x0,5) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>370,000</td></tr><tr><td>*</td><td>Lay- In bề mặt đục lỗ D1,8mm, sơn tĩnh điện gia nhiệt PE. Không bao gồm khung và phụ kiện.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>629</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,6) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>430,000</td></tr><tr><td>630</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,7) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>470,000</td></tr><tr><td>631</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,8) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>510,000</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Lay- In T-Black bề mặt đục lỗ D1,8mm, sơn tĩnh điện gia nhiệt PE. Phụ kiện: Khung T chính, T phụ 1,62m, 02 móc treo, 0,5 nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>632</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,6)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>510,000</td></tr><tr><td>633</td><td>Vật liệu
hoàn
thiện</td><td>(300x300x0,5) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>550,000</td></tr><tr><td>634</td><td>Vật liệu
hoàn
thiện</td><td>(600x600x0,8) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng tiêu
chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>590,000</td></tr><tr><td>*</td><td>Cell (Caro) dày 0,5mm, sơn tĩnh điện gia nhiệt PE. Phụ kiện: móc treo 1,5 chiếc.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>635</td><td>Vật liệu
hoàn
thiện</td><td>Caro vuông
(50x50x50x15x1950) mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí</td><td></td><td>1.240.000</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhân công lắp
đặt)</td><td></td><td></td></tr><tr><td>636</td><td>Vật liệu
hoàn
thiện</td><td>Caro vuông
(75x75x50x15x1950)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>690,000</td></tr><tr><td>637</td><td>Vật liệu
hoàn
thiện</td><td>Caro vuông
(100x100x50x15x2000)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>640,000</td></tr><tr><td>638</td><td>Vật liệu
hoàn
thiện</td><td>Caro vuông
(150x150x50x15x1950)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>480,000</td></tr><tr><td>639</td><td>Vật liệu
hoàn
thiện</td><td>Caro vuông
(200x200x50x15 x
2000)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không</td><td></td><td>420,000</td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td></td></tr><tr><td>640</td><td>Vật liệu
hoàn
thiện</td><td>Caro tam giác
(150x150x50x15x1950)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>870,000</td></tr><tr><td>641</td><td>Vật liệu
hoàn
thiện</td><td>Caro tam giác
(200x200x50x15x2000)mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>670,000</td></tr><tr><td>*</td><td>Hệ lam chắn nắng Foster Sun Louver hợp kim nhôm; mặt sơn tĩnh điện cao cấp Akzo Nobel (sơn tĩnh điện gia nhiệt PE ngoài trời). Khung xương và
phụ kiện hoàn chỉnh, chiều dài theo yêu cầu.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>642</td><td>Vật liệu
hoàn
thiện</td><td>85C (0,6mm), lam 11,5m/m²,
rộng 85, phụ kiện khung thép
1m</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>480,000</td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>643</td><td>Vật liệu
hoàn
thiện</td><td>85R (0,6mm), lam
13,5m/m², rộng 85, phụ
kiện khung thép 1m</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>540,000</td></tr><tr><td>644</td><td>Vật liệu
hoàn
thiện</td><td>132S(0,6mm), lam 5m/m²,
rộng 132, phụ kiện móc
treo 6 chiếc/m²</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>460,000</td></tr><tr><td>645</td><td>Vật liệu
hoàn
thiện</td><td>FT - HT (150x24x1,3)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>390,000</td></tr><tr><td>646</td><td>Vật liệu
hoàn
thiện</td><td>FT - HT (200x25x1,)5mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>460,000</td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>647</td><td>Vật liệu
hoàn
thiện</td><td>FT-HT (250x50x1,3)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>630,000</td></tr><tr><td>648</td><td>Vật liệu
hoàn
thiện</td><td>FT-LL (120 x 1,2)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>310,000</td></tr><tr><td>649</td><td>Vật liệu
hoàn
thiện</td><td>FT-LL (150 x 1,4)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>390,000</td></tr><tr><td>650</td><td>Vật liệu
hoàn
thiện</td><td>FT-LL (170 x 1,3)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>410,000</td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>651</td><td>Vật liệu
hoàn
thiện</td><td>FT-DD (150x52x1,3)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>450,000</td></tr><tr><td>652</td><td>Vật liệu
hoàn
thiện</td><td>FT-DD (200x52x1,5)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>610,000</td></tr><tr><td>653</td><td>Vật liệu
hoàn
thiện</td><td>FT-DD (250x52x1,5)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>770,000</td></tr><tr><td>654</td><td>Vật liệu
hoàn
thiện</td><td>FT - HH (150x30x2,1)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>510,000</td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>655</td><td>Vật liệu
hoàn
thiện</td><td>FT-HH (150x50x1.5)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>550,000</td></tr><tr><td>656</td><td>Vật liệu
hoàn
thiện</td><td>FT-HH (150x50x1,2)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu đạn,
thoi, hộp CN</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>650,000</td></tr><tr><td>657</td><td>Vật liệu
hoàn
thiện</td><td>FT-HH (200 x 100 x
1.4)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu dạn,
thoi, hộp CN</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>730,000</td></tr><tr><td>658</td><td>Vật liệu
hoàn
thiện</td><td>FT-HH (250x100x1.4)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu dạn,
thoi, hộp CN</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>850,000</td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>659</td><td>Vật liệu
hoàn
thiện</td><td>FT-HH (300x100x1.5)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu dạn,
thoi, hộp CN</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>1,018,000</td></tr><tr><td>660</td><td>Vật liệu
hoàn
thiện</td><td>FT-HH (400x100x1.5)mm</td><td>m2</td><td>ASTM B209M</td><td>Hình: C, S, lá
liễu, đầu dạn,
thoi, hộp CN</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>1,360,000</td></tr><tr><td>*</td><td>(B-Shaped, màu trắng, màu đen. Sơn tĩnh điện gia nhiệt PE, phụ kiện: khung xương thép tiêu chuẩn, 1.2m/m², móc treo...)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>661</td><td>Vật liệu
hoàn
thiện</td><td>Multi B230 dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>440,000</td></tr><tr><td>662</td><td>Vật liệu
hoàn
thiện</td><td>Multi B230 dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí</td><td></td><td>480,000</td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhân công lắp
đặt)</td><td></td><td></td></tr><tr><td>663</td><td>Vật liệu
hoàn
thiện</td><td>Multi B130 dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>530,000</td></tr><tr><td>664</td><td>Vật liệu
hoàn
thiện</td><td>Multi B80 dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>580,000</td></tr><tr><td>665</td><td>Vật liệu
hoàn
thiện</td><td>Multi B30 dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>640,000</td></tr><tr><td>*</td><td>(G-Shaped, sơn tĩnh điện gia nhiệt PE, phụ kiện: khung xương thép tiêu chuẩn, 1.2m/m², móc treo...)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>666</td><td>Vật liệu
hoàn
thiện</td><td>G100 chịu gió</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng,
đen, ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>600,000</td></tr><tr><td>667</td><td>Vật liệu
hoàn
thiện</td><td>G150 chịu gió</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng,
đen, ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>550,000</td></tr><tr><td>668</td><td>Vật liệu
hoàn
thiện</td><td>G200 chịu gió</td><td>m3</td><td>ASTM B209M</td><td>Màu trắng,
đen, ghi tiêu
chuẩn</td><td>Công ty Cổ
phần
POSTER Việt
Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chính, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>500,000</td></tr><tr><td>669</td><td>Vật liệu
hoàn
thiện</td><td></td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>440,000</td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>U - Shaped, Sơn tĩnh điện gia nhiệt PE, phụ kiện: khung xương thép tiêu chuẩn. 1,2m/m², móc treo</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>670</td><td>Vật liệu
hoàn
thiện</td><td>(30 x 50)mm, dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>Màu trắng, đen,
ghi tiêu chuẩn</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>530,000</td></tr><tr><td>671</td><td>Vật liệu
hoàn
thiện</td><td>(30 x 100)mm, dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>(30 x 100)mm,
dày 0.6mm</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>830,000</td></tr><tr><td>672</td><td>Vật liệu
hoàn
thiện</td><td>(50 x 100)mm, dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>(50 x 100)mm,
dày 0.6mm</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>840,000</td></tr><tr><td>673</td><td>Vật liệu
hoàn
thiện</td><td>(50 x150)mm, dày 0.6mm</td><td>m2</td><td>ASTM B209M</td><td>(50 x150)mm,
dày 0.6mm</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>1.160.000</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Trần Sợi khoáng Foster - FTS615, FTS91, Vật tư phụ kiện hoàn chỉnh.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>674</td><td>Vật liệu
hoàn
thiện</td><td>FTS915V, cạnh vuông
FTS615V, cạnh vuông
FTS615G, cạnh gờ</td><td>m2</td><td>ASTM B209M</td><td>900x600x15mm</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>460,000</td></tr><tr><td>675</td><td>Vật liệu
hoàn
thiện</td><td></td><td>m2</td><td>ASTM B209M</td><td>600x600x15mm</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>420,000</td></tr><tr><td>676</td><td>Vật liệu
hoàn
thiện</td><td></td><td>m2</td><td>ASTM B209M</td><td>600x600x15mm</td><td>Công ty Cổ
phần POSTER
Việt Nam</td><td>Không</td><td>Giá bán tại
thành phố Lạng
Sơn (Đã bao
gồm vật tư
chúnh, không
bao gồm chi phí
nhân công lắp
đặt)</td><td></td><td>490,000</td></tr><tr><td>X</td><td>Sơn các loại</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10,1</td><td>Sơn
KOVA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn nước
trong nhà</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>677</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm loại
K109 - Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa</td><td></td><td>100,364</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>678</td><td>Vật liệu
hoàn
thiện</td><td>Sơn tráng trần loại K10 -
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>104,318</td></tr><tr><td>679</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng cao cấp loại K871
-
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>203,091</td></tr><tr><td>680</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng cao cấp loại
K5500
- Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>157,182</td></tr><tr><td>681</td><td>Vật liệu
hoàn
thiện</td><td>Sơn không bóng loại K260 -
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>67,682</td></tr><tr><td>682</td><td>Vật liệu
hoàn
thiện</td><td>Sơn không bóng loại K771 -
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>56,136</td></tr><tr><td>*</td><td>Sơn nước ngoài trời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>683</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm loại
K209 - Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>164,909</td></tr><tr><td>684</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng cao cấp loại K360
-
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>269,318</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>685</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bán bóng cáo cấp
K5800-
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>189,545</td></tr><tr><td>686</td><td>Vật liệu
hoàn
thiện</td><td>Sơn trang trí, chống thấm
loại
CT04T- Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>211,273</td></tr><tr><td>687</td><td>Vật liệu
hoàn
thiện</td><td>Sơn không bóng loại K5501
-
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>137,955</td></tr><tr><td>688</td><td>Vật liệu
hoàn
thiện</td><td>Sơn không bóng loại K261 -
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>88,000</td></tr><tr><td>*</td><td>Sơn màu pha sẵn trong và ngoài nhà</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>689</td><td>Vật liệu
hoàn
thiện</td><td>Sơn trong nhà loại K-180</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>55,409</td></tr><tr><td>690</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoài trời loại K-280
Màu nhạt</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>81,273</td></tr><tr><td>691</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoài trời loại K-280
Màu đậm</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>106,000</td></tr><tr><td>692</td><td>Vật liệu
hoàn
thiện</td><td>Sơn sân tenis, sàn thể thao đa
năng (trắng, xanh, đỏ) CT08-
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>276,136</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Sơn màu pha sẵn trong và ngoài nhà</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>693</td><td>Vật liệu
hoàn
thiện</td><td>Sơn sân tenis, sàn thể thao đa
năng màu khác CT08-Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>317,727</td></tr><tr><td>694</td><td>Vật liệu
hoàn
thiện</td><td>Sơn men bán bóng phủ sàn
trong nhà KL5T-Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>260,000</td></tr><tr><td>695</td><td>Vật liệu
hoàn
thiện</td><td>Sơn men bóng phủ sàn trong
nhà KL5T-Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>299,500</td></tr><tr><td>696</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót chịu mài mòn KL5T
Aqua - Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>150,409</td></tr><tr><td>697</td><td>Vật liệu
hoàn
thiện</td><td>Matit MT KL5T Aqua -
Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>119,364</td></tr><tr><td>*</td><td>Sơn phủ bóng không màu trong suốt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>698</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ bóng clear ngoài
trời
Clear N- Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>235,227</td></tr><tr><td>699</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ bóng clear chống
thấm, chịu mài mòn Clear
KL5 - Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>460,682</td></tr><tr><td>700</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hạt KGP</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa</td><td></td><td>113,182</td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>701</td><td>Vật liệu
hoàn
thiện</td><td>Sơn giả đá KSP - Gold</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>200,682</td></tr><tr><td>702</td><td>Vật liệu
hoàn
thiện</td><td>Sơn giao thông hệ nước
K426</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>120,000</td></tr><tr><td>*</td><td>Mầu sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>703</td><td>Vật liệu
hoàn
thiện</td><td>Mầu có đuôi OW</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>7,955</td></tr><tr><td>704</td><td>Vật liệu
hoàn
thiện</td><td>Mầu có đuôi P</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>9,091</td></tr><tr><td>705</td><td>Vật liệu
hoàn
thiện</td><td>Mầu có đuôi T</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>28,182</td></tr><tr><td>706</td><td>Vật liệu
hoàn
thiện</td><td>Mầu có đuôi D</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>34,091</td></tr><tr><td>707</td><td>Vật liệu
hoàn
thiện</td><td>Màu có đuôi A</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>43,182</td></tr><tr><td>*</td><td>Ma tít</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>708</td><td>Vật liệu
hoàn
thiện</td><td>Ma tít trong nhà loại MTT -
Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>25,124</td></tr><tr><td>709</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả trong nhà loại MBT -
Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>14,036</td></tr><tr><td>710</td><td>Vật liệu
hoàn
thiện</td><td>Matít ngoài trời loại MTN -
Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>27,818</td></tr><tr><td>711</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoài trời loại MBN -
Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>18,109</td></tr><tr><td>712</td><td>Vật liệu
hoàn
thiện</td><td>Matít KL-5T hai thành phần
chịu mài mòn loại mịn</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>83,455</td></tr><tr><td>713</td><td>Vật liệu
hoàn
thiện</td><td>Matít KL-5T hai thành phần
chịu mài mòn loại thô</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>77,636</td></tr><tr><td>714</td><td>Vật liệu
hoàn
thiện</td><td>Chất phủ đệm sân thể thao,
sân Tennis loại TNA</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 25kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>53,745</td></tr><tr><td>715</td><td>Vật liệu
hoàn
thiện</td><td>Matít chịu ẩm cho sân
Tennis, chân tường SK-6</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>67,091</td></tr><tr><td>*</td><td>Chống thấm, chống nóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>716</td><td>Chất
chống
thấm
nóng</td><td>Chống thấm xi măng, bê
tông
CT-11A Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>179,773</td></tr><tr><td>717</td><td>Chất
chống
thấm
nóng</td><td>Phụ gia trộn vữa xi măng, bê
tông CT-11B Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>117,656</td></tr><tr><td>718</td><td>Chất
chống
thấm
nóng</td><td>Co giãn, chống áp lực cho xi
măng, bê tông CT-14 Gold</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>170,227</td></tr><tr><td>719</td><td>Chất
chống
thấm
nóng</td><td>Sơn chống nóng hệ nước
CN-
05</td><td>kg</td><td>TCVN
7239:2014</td><td>Thùng 20kg</td><td>Tập đoàn Sơn
KOVA</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>158,182</td></tr><tr><td>10,2</td><td>Sơn LOTVICNANO (Công ty CP tập đoàn Thành Thắng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Thôn Chi Lễ, xã Mỹ Thái, Huyện Lang Giang, tỉnh Bắc Giang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn nội Thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>720</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 24kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>41,566</td><td></td></tr><tr><td>721</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn cao cấp nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 24kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>24,394</td><td></td></tr><tr><td>722</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng ngọc trai nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>85,748</td><td></td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>723</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lau chùi hiệu quả</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>53,157</td><td></td></tr><tr><td>724</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>97,146</td><td></td></tr><tr><td>*</td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>725</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn ngoại thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>53,359</td><td></td></tr><tr><td>726</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng nano</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>110,101</td><td></td></tr><tr><td>727</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>116,616</td><td></td></tr><tr><td>*</td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>728</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm nội thất
Nano</td><td>kg</td><td>TCVN
8652:2020</td><td>Thùng 22kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>39,268</td><td></td></tr><tr><td>729</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót siêu kháng kiềm nội
thất nano</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>53,485</td><td></td></tr><tr><td>730</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót siêu kháng kiềm
ngoại thất nano</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>69,217</td><td></td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>*</td><td>Sơn chống thấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>731</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm pha xi măng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>77,651</td><td></td></tr><tr><td>732</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm mầu</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>95,151</td><td></td></tr><tr><td>*</td><td>Sơn đặc biệt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>733</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng men sứ 5 lít</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 5 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>170,545</td><td></td></tr><tr><td>734</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ bóng 5kg</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 5 kg</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>196,860</td><td></td></tr><tr><td>735</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nhũ vàng 1 lít</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 1 lít</td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>450,000</td><td></td></tr><tr><td>*</td><td>Bột bả tường gốc xi măng Pooc Lăng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Vật liệu
hoàn
thiện</td><td>Bột bả nội - ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td></td><td>Công ty CP tập
đoàn Thành
Thắng)</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>5,455</td><td></td></tr><tr><td></td><td>Giá trên chỉ áp dụng cho sơn trắng, nếu pha màu thì tính thêm tiền màu như
sau:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td>Những mã màu đuôi T trong quạt màu được tính màu đậm bậc 1 giá cộng thêm
10%</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Những mã màu đuôi D trong quạt màu được tính màu đậm bậc 1 giá cộng thêm
20%</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Những mã màu đuôi C trong quạt màu được tính màu đậm bậc 1 giá cộng thêm
30%</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10,3</td><td>Sơn Japan Việt Nam</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>736</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>45,181</td><td></td></tr><tr><td>737</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>59,627</td><td></td></tr><tr><td>738</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kiềm nội thất cao
cấp.</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>81,770</td><td></td></tr><tr><td>739</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kiềm ngoại thất cao
cấp</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>112,569</td><td></td></tr><tr><td>*</td><td>Sơn nội
thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>740</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn nội thất cao cấp.</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>34,433</td><td></td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>741</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất lau chùi hiệu
quả cao cấp.</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>58,862</td><td></td></tr><tr><td>742</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Siêu Trắng Trần Nội
Thất Cao Cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>5,968</td><td></td></tr><tr><td>743</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng ngọc trai nội thất
cao cấp.</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>98,439</td><td></td></tr><tr><td>744</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng men sứ nội
thất cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>123,157</td><td></td></tr><tr><td>*</td><td>Sơn
Ngoại
thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>745</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn ngoại thất cao cấp.</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>69,186</td><td></td></tr><tr><td>746</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng ngọc trai ngoại
thất cao cấp.</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>132,957</td><td></td></tr><tr><td>747</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng men sứ ngoại
thất cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>164,178</td><td></td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>748</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm đa năng pha
xi măng</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>96,856</td><td></td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>749</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả cao cấp nội thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>3,840</td><td></td></tr><tr><td>750</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả cao cấp ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
Sơn Japan Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>5,733</td><td></td></tr><tr><td>10,5</td><td>Sơn Fancol (Công ty Cổ phần FALCON Coatings Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: 67 Tô Ngọc Vân, quận Tây Hồ, Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn Lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>751</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót chống kiềm ngoại
thất</td><td>kg</td><td>TCVN
8652:2020</td><td>Thùng 18kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>172,944</td><td></td></tr><tr><td>752</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót chống kiềm nội thất</td><td>kg</td><td>TCVN
8652:2020</td><td>Thùng 19kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>131,947</td><td></td></tr><tr><td>753</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót đa năng nội và ngoại
thất</td><td>kg</td><td>TCVN
8652:2020</td><td>Thùng 20kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>107,600</td><td></td></tr><tr><td>*</td><td>Sơn nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>754</td><td>Vật liệu
hoàn
thiện</td><td>Sơn không lót</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP
FALCON</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>221,700</td><td></td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Coatings Việt
Nam</td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>755</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Lon 5,1kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>267,843</td><td></td></tr><tr><td>756</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng ngọc trai</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20,4kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>190,196</td><td></td></tr><tr><td>757</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lau chùi hiệu quả</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 23,6kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>83,136</td><td></td></tr><tr><td>758</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng, sáng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 23,5kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>69,702</td><td></td></tr><tr><td>759</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 24kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>38,417</td><td></td></tr><tr><td>*</td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>760</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ men sứ</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>371,222</td><td></td></tr><tr><td>761</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Lon 5,1kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>393,725</td><td></td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>762</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng ngọc trai</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20,4kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>278,382</td><td></td></tr><tr><td>763</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng mờ</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 23,2kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>132,672</td><td></td></tr><tr><td>764</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 24kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>102,875</td><td></td></tr><tr><td>*</td><td>Sơn chống thấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>765</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm pha mầu</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>242,800</td><td></td></tr><tr><td>766</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm polyme</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>171,150</td><td></td></tr><tr><td>767</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm pha xi măng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>160,700</td><td></td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>768</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>14,800</td><td></td></tr><tr><td>769</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty CP
FALCON</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>11,850</td><td></td></tr></tbody></table>

|<image_28>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Coatings Việt
Nam</td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>770</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả nội và ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty CP
FALCON
Coatings Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>8,150</td><td></td></tr><tr><td>10,6</td><td>Sơn LuxShield (Công ty TNHH DV&amp;TM Green QNT)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: sô 22, tổ 80, khu 8, phường Hà Khẩu, thành phố Hạ Long</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn phủ nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>771</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng men sứ nội
thất cao cấp S-63</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>350,000</td><td></td></tr><tr><td>772</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng nội thất cao
cấp S-62</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>270,000</td><td></td></tr><tr><td>773</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng mờ nội thất cao
cấp B-622</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>190,000</td><td></td></tr><tr><td>774</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn nội thất cao cấp S-
61</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>64,000</td><td></td></tr><tr><td>775</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn nội thất N-01</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>29,545</td><td></td></tr><tr><td>776</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng nội thất cao
cấp S-60</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>90,000</td><td></td></tr></tbody></table>

|<image_29>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>DV&amp;TM
Green QNT</td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>*</td><td>Sơn phủ ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>777</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siếu bóng ngoại thất
men sứ cao cấp S-93</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>390,000</td><td></td></tr><tr><td>778</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng ngoại thất cao
cấp S-92</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>298,000</td><td></td></tr><tr><td>779</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn ngoại thất cao cấp
S- 91</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>128,000</td><td></td></tr><tr><td>780</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm đa năng S-
99</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>190,000</td><td></td></tr><tr><td>781</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm mầu cao cấp
S-88</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>240,000</td><td></td></tr><tr><td></td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>782</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả nội thất cao cấp</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>9,750</td><td></td></tr><tr><td>783</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngọai thất cao cấp</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
DV&amp;TM
Green QNT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>12,375</td><td></td></tr></tbody></table>

|<image_30>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>10,7</td><td>Sơn Lebus (Công ty Cổ phần liên doanh Lebus Group)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Đ/c: số 10, đường Lý Thường Kiệt, tổ 1, thị trấn Thắng, Hiệp Hòa, Bắc Giang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>784</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm nội thất
LA</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>65,686</td><td></td></tr><tr><td>785</td><td>Vật liệu
hoàn
thiện</td><td>S</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>86,605</td><td></td></tr><tr><td>*</td><td>Sơn nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>786</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng trần chống ố
vàng W-09</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>56,591</td><td></td></tr><tr><td>787</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn không độc hại Q-1</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>33,764</td><td></td></tr><tr><td>788</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng mờ lau chùi Q-2</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>77,813</td><td></td></tr><tr><td>789</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng cao cấp diệt khuẩn
Q-3</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>107,785</td><td></td></tr><tr><td>790</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng đặc biệt Q-4</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>120,771</td><td></td></tr></tbody></table>

|<image_31>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>791</td><td>Vật liệu
hoàn
thiện</td><td>Son siêu bóng cao cấp 5
trong 1 diệt khuẩn Q-1</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>170,170</td><td></td></tr><tr><td>*</td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>792</td><td>Vật liệu
hoàn
thiện</td><td>Son mịn S-22</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>74,670</td><td></td></tr><tr><td>793</td><td>Vật liệu
hoàn
thiện</td><td>Son bóng S-33</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>108,670</td><td></td></tr><tr><td>794</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng cao cấp S-66</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>131,160</td><td></td></tr><tr><td>795</td><td>Vật liệu
hoàn
thiện</td><td>Sơn đặc biệt S-88</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>190,740</td><td></td></tr><tr><td></td><td>Sơn chống thấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>796</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm đa năng phi
xi măng cao cấp CT-366</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>76,171</td><td></td></tr><tr><td>797</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất chống thấm
một thành phần CTM-388</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty Cổ
phần
liên doanh
Lebus Group</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>97,013</td><td></td></tr><tr><td>10,8</td><td>Sơn MyLand (Công ty TNHH MyLands Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Đ/c: Cụm công nghiệp Hạ Thái, xa Duyên Thái, huyện Thường Tín, Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_32>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>798</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm cao cấp</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>111,111</td><td></td></tr><tr><td>799</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất kháng
kiềm cao cấp</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>138,888</td><td></td></tr><tr><td>*</td><td>Sơn ngoài trời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>800</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất mịn cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>97,727</td><td></td></tr><tr><td>801</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất bóng chống
bám bẩn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>169,696</td><td></td></tr><tr><td>802</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất siêu bóng cao
cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Lon 5 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>262,727</td><td></td></tr><tr><td>803</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nhũ đồng</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Lon 5 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>400,000</td><td></td></tr><tr><td>804</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nhũ vàng</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Lon 5 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>400,000</td><td></td></tr><tr><td>*</td><td>Sơn trong nhà</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_33>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>805</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>46,969</td><td></td></tr><tr><td>806</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất siêu mịn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>47,979</td><td></td></tr><tr><td>807</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất siêu trắng, lau
chùi</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>80,807</td><td></td></tr><tr><td>808</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất bóng ngọc trai
cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>140,909</td><td></td></tr><tr><td>809</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất diêu bóng cao
cấp ánh ngọc</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Lon 5 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>244,545</td><td></td></tr><tr><td>*</td><td>Sơn chống thấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>810</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm màu cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>150,505</td><td></td></tr><tr><td>811</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm trộn xi
măng</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>139,141</td><td></td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>812</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả nội thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>8,636</td><td></td></tr></tbody></table>

|<image_34>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>MyLands Việt
Nam</td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>813</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả chống thấm ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
MyLands Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>11,591</td><td></td></tr><tr><td>10,9</td><td>Sơn Dulux (Công ty TNHH AKZONOBEL Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Tầng 12, Toà nhà VinCom Center Đồng Khởi - Số 72 Lê Thánh Tôn, phuòng Bến nghé, Quận 1, Thành phố HCM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>814</td><td>Vật liệu
hoàn
thiện</td><td>Weathershield E1000 plus</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>14,375</td><td></td></tr><tr><td>815</td><td>Vật liệu
hoàn
thiện</td><td>Bả nội thất Diamon A1000</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>13,919</td><td></td></tr><tr><td>816</td><td>Vật liệu
hoàn
thiện</td><td>Bả nội thất A500</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>10,057</td><td></td></tr><tr><td>817</td><td>Vật liệu
hoàn
thiện</td><td>Bả ngoại thất E700</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>12,578</td><td></td></tr><tr><td></td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>818</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất chống
kiềm E1000</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>184,688</td><td></td></tr></tbody></table>

|<image_35>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>819</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất E700</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>151,612</td><td></td></tr><tr><td>820</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất E500</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>114,961</td><td></td></tr><tr><td>821</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất chống kiềm
A1000</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>183,019</td><td></td></tr><tr><td>822</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất A500</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>105,306</td><td></td></tr><tr><td>823</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất A300</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>67,820</td><td></td></tr><tr><td>*</td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>824</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất mờ</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>368,839</td><td></td></tr><tr><td>825</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất bóng</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>368,839</td><td></td></tr><tr><td>826</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất OceanGuard</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>358,351</td><td></td></tr></tbody></table>

|<image_36>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>827</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất mờ E1000</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>328,255</td><td></td></tr><tr><td>828</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất bóng E1000</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>328,255</td><td></td></tr><tr><td>829</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất Express</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>309,409</td><td></td></tr><tr><td>830</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất mờ E700</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>179,682</td><td></td></tr><tr><td>831</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất mờ E500</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>105,068</td><td></td></tr><tr><td>832</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hiệu ứng StoneTex</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>140,570</td><td></td></tr><tr><td>833</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hiệu ứng SandTex</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>144,775</td><td></td></tr><tr><td>834</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hiệu ứng AcrylTex</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>68,311</td><td></td></tr><tr><td>*</td><td>Sơn nội thât</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_37>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>835</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất Diamon
Care</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>277,121</td><td></td></tr><tr><td>836</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất Diamon
A1000</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>268,599</td><td></td></tr><tr><td>837</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất, lau chùi
hiệu quả</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>127,893</td><td></td></tr><tr><td>838</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất kháng
khuẩn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>113,352</td><td></td></tr><tr><td>839</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất, lau chùi</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>98,631</td><td></td></tr><tr><td>840</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất A500</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>76,104</td><td></td></tr><tr><td>841</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất A390</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
AKZONOBEL
VN</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>55,305</td><td></td></tr><tr><td>10,10</td><td>Sơn Joton (Công ty Cổ phần L.Q Joton Hà Nội)
Địa chỉ: KCN Vĩnh Tuy, phường Vĩnh Hưng, Hoàng Mai, HN</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn giao thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_38>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>842</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Joline vàng phẳng
AASHTO M249-12</td><td>kg</td><td>AASHTO
M249- 12</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>39,500</td></tr><tr><td>843</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Joline trắng phẳng
AASHTO M249-12</td><td>kg</td><td>AASHTO
M249- 12</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>39,000</td></tr><tr><td>844</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Joline trắng phẳng
TCVN 8791-2011</td><td>kg</td><td>TCVN 8791-
2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>36,500</td></tr><tr><td>845</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Joline vàng phẳng
TCVN 8791-2011</td><td>kg</td><td>TCVN
8791:2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>37,500</td></tr><tr><td>846</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Joline Primer lót cho hệ
nhiệt dẻo</td><td>kg</td><td>TCVN
8791:2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>94,800</td></tr><tr><td>847</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hệ dung môi Joway
trắng</td><td>kg</td><td>TCVN
8787:2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>153,900</td></tr><tr><td>848</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hệ dung môi Joway đen</td><td>kg</td><td>TCVN
8787:2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>153,900</td></tr><tr><td>849</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hệ dung môi Joway
vàng</td><td>kg</td><td>TCVN
8787:2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>191,800</td></tr></tbody></table>

|<image_39>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>850</td><td>Vật liệu
hoàn
thiện</td><td>Sơn hệ dung môi Joway đỏ</td><td>kg</td><td>TCVN
8787:2011</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>191,700</td></tr><tr><td>851</td><td>Vật liệu
hoàn
thiện</td><td>Hạt phản quang loại A</td><td>kg</td><td>TCCS
02:2018/JBG</td><td>Thùng 25kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>32,700</td></tr><tr><td>*</td><td>Sơn sàn công nghiệp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>852</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót epoxy gốc nước
jones WEPO</td><td>kg</td><td>TCCS
CN24:2022</td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>250,000</td></tr><tr><td>853</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ epoxy gốc nước
jona WEPO màu thường</td><td>kg</td><td>TCCS
CN07:2023</td><td>Thùng 19,5kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>299,000</td></tr><tr><td>854</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót hệ dung môi Jones
Epo Clear</td><td>kg</td><td>TCCS
CN09:2023</td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>219,000</td></tr><tr><td>855</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ Jona Epo màu cơ
bản</td><td>kg</td><td>JISSK
5659:2018</td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>290,000</td></tr><tr><td>856</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót Jones Sealer EC</td><td>kg</td><td></td><td>Thùng 10kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>210,000</td></tr><tr><td>857</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót jona Level New màu
thường</td><td>kg</td><td>TCCS
CN05:2023</td><td>Thùng 19,5kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>208,000</td></tr></tbody></table>

|<image_40>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>858</td><td>Vật liệu
hoàn
thiện</td><td>Dung môi TN 305 (dùng cho
epoxy hệ dung môi)</td><td>kg</td><td></td><td>Lon 5L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>72,600</td></tr><tr><td>859</td><td>Vật liệu
hoàn
thiện</td><td>Dung môi TN 401</td><td>kg</td><td></td><td>Lon 5L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>66,000</td></tr><tr><td>860</td><td>Vật liệu
hoàn
thiện</td><td>Dung môi TN 304 (dùng cho
PU hệ dụng môi)</td><td>kg</td><td></td><td>Lon 5L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>77,000</td></tr><tr><td></td><td>Sơn kết cấu thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>861</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống gỉ Sp Primer</td><td>kg</td><td></td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>107,250</td></tr><tr><td>862</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Alkyd Jimmy</td><td>kg</td><td>JIS K
5962:1993</td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>157,400</td></tr><tr><td>863</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống gỉ 2 tahnfh phần
Jones Epo</td><td></td><td>JIS K
5962:1993</td><td>Bộ 20kg, bộ
4kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>219,450</td></tr><tr><td>864</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ 2 thành phần Jona
Epo màu thông thường</td><td></td><td>JIS K
5962:1993</td><td>Bộ 20kg, bộ
4kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>246,900</td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>865</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả cao cấp</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>bao 40kg</td><td>Công ty Cổ
phần</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,</td><td></td><td>18,400</td></tr></tbody></table>

|<image_41>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>L.Q Joton Hà
Nội</td><td></td><td>chưa bao gồm
vận chuyển</td><td></td><td></td></tr><tr><td>866</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả Sp Filler nội thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>bao 40kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>10,400</td></tr><tr><td>867</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất J-plus</td><td></td><td>QCVN
16:2019/BXD</td><td>bao 40kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>17,900</td></tr><tr><td>868</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả Jolia nội thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>bao 40kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>9,100</td></tr><tr><td>*</td><td>Sơn tường</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>869</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm ngoại
thất Joton Altex</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>148,600</td></tr><tr><td>870</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm nội thất
Altin</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>94,700</td></tr><tr><td></td><td></td><td>Sơn lót kháng kiềm ngoại
thất Fotex</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>148,600</td></tr><tr><td></td><td></td><td>Sơn lót kháng kiềm nội thất
Fotin</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>94,700</td></tr></tbody></table>

|<image_42>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>871</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Fa ngoại thất bóng</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>323,529</td></tr><tr><td>872</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Fa nội thất</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>109,833</td></tr><tr><td>873</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất siêu mịn
Nova</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>161,000</td></tr><tr><td>874</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất mịn Bella</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>66,400</td></tr><tr><td>875</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Jony ngoại thất mịn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>161,000</td></tr><tr><td>876</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Jony nội thất mịn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>66,400</td></tr><tr><td>877</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất JOTON
ALTEX DA</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>94,200</td></tr><tr><td>878</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất JOTON
ALTIN DA</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>61,600</td></tr></tbody></table>

|<image_43>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>879</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ ngoại thất JOTON
JONY EXT DA</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>86,300</td></tr><tr><td>880</td><td>Vật liệu
hoàn
thiện</td><td>Sơn phủ nội thất JOTON
JONY INT DA</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>39,600</td></tr><tr><td>881</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội BENTIN LT</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>61,600</td></tr><tr><td>882</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại BENTIN LE</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 17L</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>94,200</td></tr><tr><td>883</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất BENTIN INT</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>39,600</td></tr><tr><td>884</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất BENTIN
EXT</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 20kg</td><td>Công ty Cổ
phần
L.Q Joton Hà
Nội</td><td>không</td><td>giá bán tại thành
phố Lạng Sơn,
chưa bao gồm
vận chuyển</td><td></td><td>86,300</td></tr><tr><td>10,11</td><td>Sơn OPTEX (Công ty CP Công nghệ ASAP PAINT Quốc tế)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Nơi sản xuất: Cụm công nghiệp Thanh Oai, xã Bích Hoà, huyện Thanh Oai, Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>885</td><td>Vật liệu
hoàn
thiện</td><td>Kháng kiềm ngoại thất K-30</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>119,253</td><td></td></tr></tbody></table>

|<image_44>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>886</td><td>Vật liệu
hoàn
thiện</td><td>Kháng kiềm nội thất cao cấp
K10</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>163,540</td><td></td></tr><tr><td>887</td><td>Vật liệu
hoàn
thiện</td><td>Kháng kiềm ngoại thất cao
cấp K-36</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>225,137</td><td></td></tr><tr><td>*</td><td>Sơn nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>888</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu mịn cao cấp M-01</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>68,865</td><td></td></tr><tr><td>889</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất lau chùi hiệu
quả E-04</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>117,723</td><td></td></tr><tr><td>890</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng cao cấp T-02</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>119,359</td><td></td></tr><tr><td>891</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng mờ cao cấp PS-03</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>196,877</td><td></td></tr><tr><td>892</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng cao cấp P-05</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>246,313</td><td></td></tr><tr><td>893</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng cao cấp 7in1
P-06</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>312,536</td><td></td></tr></tbody></table>

|<image_45>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>894</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu mịn cao cấp M-07</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>138,372</td><td></td></tr><tr><td>895</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng cao cấp P-08</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>265,914</td><td></td></tr><tr><td>896</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng cao cấp 8in1
P- 09</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>328,356</td><td></td></tr><tr><td>897</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm xi măng cao
cấp TC-11A</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>193,712</td><td></td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>898</td><td>Vật liệu
hoàn
thiện</td><td>Bả nội thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>7,679</td><td></td></tr><tr><td>899</td><td>Vật liệu
hoàn
thiện</td><td>Bả ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty CP
Công nghệ
ASAP PAINT</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>11,465</td><td></td></tr><tr><td>10,12</td><td>Sơn ANOTEX (Công ty CP Amson Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Nơi sản xuất: Lô CN-3.1, Khu công nghiệp Phú Nghĩa, xã Phú Nghĩa, huyện Chương Mỹ, thành phố Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Sơn lót</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>900</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất kháng kiềm
cao cấp</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>110,567</td><td></td></tr></tbody></table>

|<image_46>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>901</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất kháng
kiềm cao cấp</td><td>lít</td><td>TCVN
8652:2021</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>136,938</td><td></td></tr><tr><td>*</td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>902</td><td>Vật liệu
hoàn
thiện</td><td>Sơn min ngoại thất cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>95,279</td><td></td></tr><tr><td>903</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng ngoại thất chống
bám bẩn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Lon 5 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>167,796</td><td></td></tr><tr><td>904</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng ngoại thất cao
cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>260,327</td><td></td></tr><tr><td>*</td><td>Sơn chống thấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>905</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm màu</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>148,585</td><td></td></tr><tr><td>906</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm đa năng</td><td>lít</td><td>TCVN
8652:2021</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>137,341</td><td></td></tr><tr><td>*</td><td>Sơn nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>907</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất siêu mịn</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>45,869</td><td></td></tr></tbody></table>

|<image_47>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>908</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng trần</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>46,979</td><td></td></tr><tr><td>909</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất lau chùi</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>79,307</td><td></td></tr><tr><td>910</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất bóng cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>139,609</td><td></td></tr><tr><td>911</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất siêu bóng cao
cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>242,345</td><td></td></tr><tr><td>*</td><td>Bột bả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>912</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả nội thất cao cấp</td><td>kg</td><td>TCVN
7239:2014</td><td>Bao 40kg</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>8,136</td><td></td></tr><tr><td>913</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất cao cấp</td><td>kg</td><td>TCVN
7239:2015</td><td>Bao 40kg</td><td>Công ty CP
AMSON Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>10,791</td><td></td></tr><tr><td>10,13</td><td>Sơn JYMEX (Công ty CP Sơn JYMEC Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Nơi sản xuất: Lô 03 điểm công nghiệp Di Trạch, xã Di Trạch, huyện Hoài Đức, thành phố Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>914</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót chống kiềm nội thất</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
Ssown</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình</td><td>2.675.000</td><td></td></tr></tbody></table>

|<image_48>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>JYMEC Việt
Nam</td><td></td><td>trên địa bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>915</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót chống kiềm ngoại
thất cao cấp</td><td>lít</td><td>TCVN
8652:2020</td><td>Thùng 18 lít</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>3.789.000</td><td></td></tr><tr><td>916</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất cao cấp dễ lau
chùi</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>2.252.000</td><td></td></tr><tr><td>917</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nước siêu trắng nội thất
cao cấp</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>1.962.000</td><td></td></tr><tr><td>918</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nước nội thất 3 in 1</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>1.015.000</td><td></td></tr><tr><td>919</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nước ngoại thất</td><td>lít</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>2.909.000</td><td></td></tr><tr><td>920</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất cao cấp</td><td>kg</td><td>TCVN
7239:2015</td><td>Bao 40kg</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>520,000</td><td></td></tr><tr><td>921</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả nội thất và ngoại thất
cao cấp</td><td>kg</td><td>TCVN
7239:2016</td><td>Bao 40kg</td><td>Công ty CP
Ssown
JYMEC Việt
Nam</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>462,000</td><td></td></tr><tr><td>10,13</td><td>Sơn KANZEN (Công ty TNHH MTV Xây dựng Tường Anh)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Đại chỉ trụ sở: Ngõ 7 đường Lê Đại Hành, phường Đông Kinh, thành phố Lạng Sơn.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_49>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td>Nơi sản xuất: KM số 8 quốc lộ 21B - Bình Minh - Thanh Oai - Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>922</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm nội thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>98,000</td><td></td></tr><tr><td>923</td><td>Vật liệu
hoàn
thiện</td><td>sơn lót kháng kiềm nội thất
Nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>124,000</td><td></td></tr><tr><td>924</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng trong nhà</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>87,500</td><td></td></tr><tr><td>925</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu mịn nội thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>44,545</td><td></td></tr><tr><td>926</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lau chùi cao cấp nội thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>102,000</td><td></td></tr><tr><td>927</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng nội thất</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>167,000</td><td></td></tr></tbody></table>

|<image_50>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>928</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm ngoại
thất đặc biệt nano</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>125,000</td><td></td></tr><tr><td>929</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn bền màu kháng UV</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>106,000</td><td></td></tr><tr><td>930</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bóng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>257,000</td><td></td></tr><tr><td>931</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu bóng cao cấp 8in1</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>268,000</td><td></td></tr><tr><td>932</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm trộn xi
măng</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>184,000</td><td></td></tr><tr><td>933</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm màu cao cấp</td><td>kg</td><td>QCVN
16:2019/BXD</td><td>Thùng 18 lít</td><td>Công ty
TNHH
MTV Xây
dựng Tường
Anh</td><td>Đã bao
gồm
VC</td><td>Giá bán đến
chân công trình
trên địa bàn tỉnh
Lạng Sơn</td><td>216,000</td><td></td></tr><tr><td>10,14</td><td>Sơn KANTECH, TITAN (Công ty Cổ phần Tây Bắc - BQP)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Đại chỉ trụ sở: Số 23, phố Lê Văn Hưu, phường Tứ Minh, thành phố Hải Dương, tỉnh Hải Dương.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_51>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>934</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót KK nội thất cao cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/21kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>98,000</td><td></td></tr><tr><td>935</td><td>Vật liệu
hoàn
thiện</td><td>Sơn siêu trắng phủ trần cao
cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>105,000</td><td></td></tr><tr><td>936</td><td>Vật liệu
hoàn
thiện</td><td>Sơn nội thất mặt mờ cao cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>95,000</td><td></td></tr><tr><td>937</td><td>Vật liệu
hoàn
thiện</td><td>Sơn bán bóng nội thất cao
cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>150,000</td><td></td></tr><tr><td>938</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Bóng nội thất cao cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>200,000</td><td></td></tr><tr><td>939</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót kháng kiềm ngoại
thất cao cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>160,000</td><td></td></tr><tr><td>940</td><td>Vật liệu
hoàn
thiện</td><td>Sơn ngoại thất cao cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>135,000</td><td></td></tr><tr><td>941</td><td>Vật liệu
hoàn
thiện</td><td>Sơn Bóng ngoại thất cao cấp</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>260,000</td><td></td></tr></tbody></table>

|<image_52>|


## VIETTEL AI RACE

## TD643

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG TRẦN & SƠN CÁC LOẠI

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD643</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG TRẦN &amp; SƠN CÁC LOẠI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>942</td><td>Vật liệu
hoàn
thiện</td><td>Sơn chống thấm đa năng cao
cấp KT-11A</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/20kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>180,000</td><td></td></tr><tr><td>943</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót nội thất kinh tế</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/21kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>38,000</td><td></td></tr><tr><td>944</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn nội thất kinh tế</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/21kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>45,000</td><td></td></tr><tr><td>945</td><td>Vật liệu
hoàn
thiện</td><td>Sơn lót ngoại thất kinh tế</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/21kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>74,000</td><td></td></tr><tr><td>946</td><td>Vật liệu
hoàn
thiện</td><td>Sơn mịn ngoại thất kinh tế</td><td>kg</td><td>QCVN:16:2019/
BXD</td><td>Thùng/21kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>80,000</td><td></td></tr><tr><td>947</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất kinh tế</td><td>kg</td><td>TCVN ISO:
9001:2015</td><td>Bao/25kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>13,000</td><td></td></tr><tr><td>948</td><td>Vật liệu
hoàn
thiện</td><td>Bột bả ngoại thất Kantech
cao cấp</td><td>kg</td><td>TCVN ISO:
9001:2015</td><td>Bao/25kg</td><td>Công ty CP
Tây Bắc - BQP</td><td>Đã bao
gồm
VC</td><td>Giá đến chân
công trình trên
địa bàn tỉnh
Lạng Sơn</td><td>12,000</td><td></td></tr></tbody></table>

|<image_53>|


