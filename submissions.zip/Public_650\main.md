# Public_650

## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>1</td><td></td><td></td><td>Decal void camera</td><td></td><td></td><td>4821</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td>Kích thước 2,5 x 1,1 cm.</td><td></td></tr><tr><td>2</td><td></td><td></td><td>Phụ tùng, linh kiện
điện thoại di động</td><td></td><td></td><td></td><td>3919</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: Bảng mạch FPCB, nắp che pin điện thoại di động, băng dính cách điện và
dẫn điện, băng dính đánh dấu, miếng bảo vệ bằng nhựa, miếng xốp bảo vệ, màng
mylar, lá đồng loại có dính và không có dính, tấm hút sóng, phim bảo vệ kính cường
lực mặt trước và sau, màng mặt trước và sau, màng bảo vệ, màng ly hình (màng
phim), các loại nhựa cho sản xuất linh kiện, phụ tùng điện thoại.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3920</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3921</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>5911</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7222</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7419</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8517</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8547</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td></td><td></td><td>Tay nối truyền tín
hiệu</td><td></td><td></td><td>7419</td><td></td><td></td><td>99</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td>Ký hiệu FS26-D0 R0 STRIP ANT1.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bằng đồng mạ bạc, dùng trong sản xuất bộ lọc tín hiệu.</td><td></td></tr><tr><td>4</td><td></td><td></td><td>Tấm phản xạ
chính dùng trong
sản xuất ăng ten</td><td></td><td></td><td>7606</td><td></td><td></td><td>12</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Ký hiệu MAIN REFLECTOR.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Kích thước: 2.387 x 515,8 mm và 1.023 x 445 mm; dày 1,5 mm.Vật liệu bằng nhôm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hợp kim.</td><td></td></tr><tr><td>5</td><td></td><td></td><td></td><td>Nắp đậy bộ lọc</td><td></td><td>7616</td><td></td><td></td><td>99</td><td></td><td></td><td>90</td><td></td><td></td><td>Kích thước 304,6 x 384,5 x 2,5 mm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>bằng nhôm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>6</td><td></td><td></td><td>Máy tính xách tay</td><td></td><td></td><td>8471</td><td></td><td></td><td>30</td><td></td><td></td><td>20</td><td></td><td></td><td>Core I5/14”/Ram 4GB, HDD 500GB.</td><td></td></tr><tr><td>7</td><td></td><td></td><td>Máy tính cá nhân</td><td></td><td></td><td>8471</td><td></td><td></td><td>41</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>– Celeron, Core I/H81, H110/RAM 4GB/HDD 500GB/PSU 300W Case tower.- TCCS</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QC/SMS-PC01:2020 ban hành tháng 10/2020.</td><td></td></tr><tr><td>8</td><td></td><td></td><td>Máy tính bảng</td><td></td><td></td><td>8471</td><td></td><td></td><td>30</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td>– Hệ điều hành Android 11;- Bộ xử lý MT8765 Quad coreA53;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Tốc độ xử lý 1,3 GHz;- Màn hình đến 8 inches, công nghệ IPS LCD 1.280 x 800
px;- RAM 3GB;- Bộ nhớ trong 32GB;- Camera trước 5MP;</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Bao gồm: Bảng mạch FPCB, nắp che pin điện thoại di động, băng dính cách điện và</th></tr></thead><tbody><tr><td>dẫn điện, băng dính đánh dấu, miếng bảo vệ bằng nhựa, miếng xốp bảo vệ, màng</td></tr><tr><td>mylar, lá đồng loại có dính và không có dính, tấm hút sóng, phim bảo vệ kính cường</td></tr><tr><td>lực mặt trước và sau, màng mặt trước và sau, màng bảo vệ, màng ly hình (màng</td></tr><tr><td>phim), các loại nhựa cho sản xuất linh kiện, phụ tùng điện thoại.</td></tr></tbody></table>

<table><thead><tr><th>– Tốc độ xử lý 1,3 GHz;- Màn hình đến 8 inches, công nghệ IPS LCD 1.280 x 800</th></tr></thead><tbody><tr><td>px;- RAM 3GB;- Bộ nhớ trong 32GB;- Camera trước 5MP;</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>– Camera sau 2MP;</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Mạng di động 4G LTE;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Bluetooth 4.0;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Pin 5.000mAh.</td><td></td></tr><tr><td></td><td>9</td><td></td><td></td><td>Máy chủ</td><td></td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td>Xeon E5/C612/RAM 16GB/HDD 1TB/PSU 600W Rack 1U.</td><td></td></tr><tr><td>10</td><td></td><td></td><td></td><td>Hệ thống chuyển</td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td>– Chuyển mạch gói cung cấp dịch vụ (cả thoại và dữ liệu) trên nền tảng mạng di
động 4G LTE (Long Term Evolution);- Độ tin cậy: 99,999%.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>mạch gói cung cấp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dịch vụ (cả thoại</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>và dữ liệu) trên</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nền tảng mạng di</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>động 4G LTE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>(EPC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td></td><td></td><td>Hệ thống tính
cước thời gian
thực (OCS)</td><td></td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td>– Tính cước ADSL, VoIP, Mobile (2G, 3G và 4G, 5G), IPTV; trả trước, trả sau cho
các dịch vụ: thoại, tin nhắn, data;- Tính sẵn sàng của hệ thống 99,99%;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Độ trễ nhỏ hơn 10 ms.</td><td></td></tr><tr><td>12</td><td></td><td></td><td></td><td>Hệ thống chuyển</td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>– Quản lý thông tin di động (Mobility Management).- Cung cấp các dịch vụ cơ bản</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>mạch cho mạng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(thoại, tin nhắn) cũng như các dịch vụ nâng cao (chặn, chuyển tiếp cuộc gọi, dấu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>viễn thông (MSC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>số).- Độ tin cậy lên đến 99,999%.</td><td></td></tr><tr><td>13</td><td></td><td></td><td>Hệ thống tổng đài
tin nhắn (SMSC)</td><td></td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>– Có chức năng gửi nhận và lưu trữ tin nhắn; chặn tin nhắn spam.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Độ tin cậy: 99,99%.</td><td></td></tr><tr><td>14</td><td></td><td></td><td></td><td>Hệ thống nhạc</td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>– Cung cấp tính năng nhạc chờ cơ bản, giới thiệu, nhạc chờ cho thuê bao chủ gọi.-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>chuông chờ cho</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Độ tin cậy và sẵn sàng 99,99%.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>phép lựa chọn và</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Độ trễ tối đa của 1 cuộc gọi 500 ms.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thay đổi nhạc chờ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>của cuộc gọi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>(CRBT)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>– Chuyển mạch gói cung cấp dịch vụ (cả thoại và dữ liệu) trên nền tảng mạng di</th></tr></thead><tbody><tr><td>động 4G LTE (Long Term Evolution);- Độ tin cậy: 99,999%.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống tính</th></tr></thead><tbody><tr><td>cước thời gian</td></tr><tr><td>thực (OCS)</td></tr></tbody></table>

<table><thead><tr><th>– Tính cước ADSL, VoIP, Mobile (2G, 3G và 4G, 5G), IPTV; trả trước, trả sau cho</th></tr></thead><tbody><tr><td>các dịch vụ: thoại, tin nhắn, data;- Tính sẵn sàng của hệ thống 99,99%;</td></tr></tbody></table>

<table><thead><tr><th>11</th></tr></thead><tbody><tr><td></td></tr></tbody></table>

<table><thead><tr><th>8471</th></tr></thead><tbody><tr><td></td></tr></tbody></table>

<table><thead><tr><th>49</th></tr></thead><tbody><tr><td></td></tr></tbody></table>

<table><thead><tr><th>90</th></tr></thead><tbody><tr><td></td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>15</th><th>Phân trạm phát
thanh an toàn tia
lửa</th><th></th><th></th><th>8471</th><th>80</th><th>90</th><th>Ký hiệu: VIELINA-PTM.AT.Truyền thông trao đổi thông tin với trung tâm điều hành
và giữa các phân trạm với nhau; kết nối với các thùng loa âm ly phòng nổ; tín hiệu
truyền thông ethernet bằng cáp quang hoặc cáp đồng; phát tín hiệu âm thanh; công
suất loa 20W; đầu ra audio U = 3,6V; I = 36mA; nguồn cung cấp 12VDC/900mA an
o o
toàn tia lửa; độ ẩm môi trường không khí 0 – 95%; nhiệt độ môi trường 0 – 40oC;
dạng bảo vệ nổ Ex[ia]I; kích thước 380 x 331 x 142 mm; trọng lượng 10 kg.</th></tr></thead><tbody><tr><td>16</td><td>Bộ thu thập dữ
liệu Datalogger
Centic CT-D3</td><td></td><td></td><td>8471</td><td>80</td><td></td><td>Tự động thu thập, xử lý, định dạng dữ liệu thu được từ các cảm biến đo thông số
môi trường, thời tiết và gửi về server. Được ứng dụng trong các hệ thống quan trắc
thời tiết, môi trường tại Việt Nam.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thông số kỹ thuật: core 32 bit M4 MPU, truyền dẫn GSM/GPRS/3G. Thay đổi tần số
đo từ xa, không cần thao tác trực tiếp, thay đổi ngưỡng cảnh báo từ xa và các chức
năng điều khiển từ xa khác theo yêu cầu. Hoạt động bằng pin mặt trời, bộ lưu điện
đủ cho thiết bị hoạt động 15 ngày mà không có nắng. Môi trường hoạt động nhiệt độ
từ -10 đến 60oC, hoạt động trong khu vực có sóng GSM/GPRS/3G.</td></tr><tr><td>17</td><td>Ổ cứng SSD</td><td></td><td></td><td>8471</td><td>70</td><td>20</td><td>Dung lượng đến 3,84 TB; tốc độ đến 3.200 MBps (đọc)/1.400 MBps (ghi).</td></tr><tr><td>18</td><td></td><td>Hệ thống cung cấp</td><td></td><td>8471</td><td>49</td><td>90</td><td>– Hỗ trợ mạng di động (4G, 5G), cố định.- Cung cấp các dịch vụ VoLTE, ViLTE,
VoWifi.- Độ tin cậy 99,999%.</td></tr><tr><td></td><td></td><td>các dịch vụ đa</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>phương tiện trên</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>mạng IP (IMS)</td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Ký hiệu: VIELINA-PTM.AT.Truyền thông trao đổi thông tin với trung tâm điều hành</th></tr></thead><tbody><tr><td>và giữa các phân trạm với nhau; kết nối với các thùng loa âm ly phòng nổ; tín hiệu</td></tr><tr><td>truyền thông ethernet bằng cáp quang hoặc cáp đồng; phát tín hiệu âm thanh; công</td></tr><tr><td>suất loa 20W; đầu ra audio U = 3,6V; I = 36mA; nguồn cung cấp 12VDC/900mA an
o o</td></tr><tr><td>toàn tia lửa; độ ẩm môi trường không khí 0 – 95%; nhiệt độ môi trường 0 – 40oC;</td></tr><tr><td>dạng bảo vệ nổ Ex[ia]I; kích thước 380 x 331 x 142 mm; trọng lượng 10 kg.</td></tr></tbody></table>

<table><thead><tr><th>Phân trạm phát</th></tr></thead><tbody><tr><td>thanh an toàn tia</td></tr><tr><td>lửa</td></tr></tbody></table>

<table><thead><tr><th>Tự động thu thập, xử lý, định dạng dữ liệu thu được từ các cảm biến đo thông số</th></tr></thead><tbody><tr><td>môi trường, thời tiết và gửi về server. Được ứng dụng trong các hệ thống quan trắc</td></tr><tr><td>thời tiết, môi trường tại Việt Nam.</td></tr></tbody></table>

<table><thead><tr><th>Bộ thu thập dữ</th></tr></thead><tbody><tr><td>liệu Datalogger</td></tr><tr><td>Centic CT-D3</td></tr></tbody></table>

<table><thead><tr><th>Thông số kỹ thuật: core 32 bit M4 MPU, truyền dẫn GSM/GPRS/3G. Thay đổi tần số</th></tr></thead><tbody><tr><td>đo từ xa, không cần thao tác trực tiếp, thay đổi ngưỡng cảnh báo từ xa và các chức</td></tr><tr><td>năng điều khiển từ xa khác theo yêu cầu. Hoạt động bằng pin mặt trời, bộ lưu điện</td></tr><tr><td>đủ cho thiết bị hoạt động 15 ngày mà không có nắng. Môi trường hoạt động nhiệt độ</td></tr><tr><td>từ -10 đến 60oC, hoạt động trong khu vực có sóng GSM/GPRS/3G.</td></tr></tbody></table>

<table><thead><tr><th>– Hỗ trợ mạng di động (4G, 5G), cố định.- Cung cấp các dịch vụ VoLTE, ViLTE,</th></tr></thead><tbody><tr><td>VoWifi.- Độ tin cậy 99,999%.</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>19</th><th>Thùng loa âm ly
phòng nổ</th><th></th><th></th><th>8471</th><th>80</th><th>90</th><th>Nhận thông tin từ trung tâm điều hành hoặc từ phân trạm phát thanh. Kết nối với các
thùng loa âm ly phòng nổ. Tín hiệu truyền thông Ethernet bằng cáp quang hoặc cáp
đồng. Phát tín hiệu âm thanh công suất loa 20W. Đầu ra audio U = 3,6V; I = 36mA;
o o
nguồn cung cấp 127/380/660VAC; độ ẩm môi trường không khí 0 – 95%; nguồn dự
phòng Pin NiMH 12V/400mAh; nhiệt độ môi trường 0 – 40oC; dạng bảo vệ nổ
Exd[ia]I; kích thước 440 x 430 x 180 mm; trọng lượng 35kg.</th><th></th><th></th></tr></thead><tbody><tr><td>20</td><td></td><td>Bộ nhớ trong</td><td></td><td>8473</td><td>30</td><td>90</td><td>Dung lượng đến 64 GB; tốc độ đến 3.200 Mbps; loại DDR4.</td><td></td><td></td></tr><tr><td></td><td></td><td>DRAM của máy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>tính (thanh ram)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>21</td><td>Tản nhiệt điện
thoại di động</td><td></td><td></td><td>8473</td><td></td><td></td><td></td><td>Mã hiệu: M30S, A30S-6G, Camvas.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: Tấm tản nhiệt Nano Tim, Slicon, Acril, CF Tim.</td><td></td></tr><tr><td>22</td><td></td><td>Bộ dây cáp tiếp</td><td></td><td>8486</td><td>20</td><td></td><td>Gồm dây cắm và đầu cắm.</td><td></td><td></td></tr><tr><td></td><td></td><td>nối của máy tính</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>các loại</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>23</td><td>Robot tự hành
dịch vụ VOR</td><td></td><td></td><td>8479</td><td></td><td></td><td></td><td>– Kính thước (500 x 500 x 1.230) mm;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Trọng lượng 62 kg, chất liệu ABS;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nguồn pin Lithium ion, thời gian sạc 4h, thời gian sử dụng đến 24 giờ, phương</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thức sạc tự động, nguồn và dòng sạc 24 V, 10 A;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Khả năng tải tối đa 40 kg (10 kg/tầng);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Môi trường nhiệt độ từ 5 đến 40°C, độ ẩm 5 – 90% (không đọng sương);</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Góc nghiêng tối đa có thể hoạt động 5°, vượt qua bậc có chiều cao tối đa 15 mm;-
Tốc độ tối đa đến 1,2 m/s, gia tốc đến 0,2 m/s2;- Định vị và lập bản đồ Laser SLAM;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Phương pháp dẫn đường: Computer vision navigation + Laser navigation;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Phạm vi phát hiện vật cản 30 m;</td><td></td></tr></tbody></table>

<table><thead><tr><th>Nhận thông tin từ trung tâm điều hành hoặc từ phân trạm phát thanh. Kết nối với các</th></tr></thead><tbody><tr><td>thùng loa âm ly phòng nổ. Tín hiệu truyền thông Ethernet bằng cáp quang hoặc cáp</td></tr><tr><td>đồng. Phát tín hiệu âm thanh công suất loa 20W. Đầu ra audio U = 3,6V; I = 36mA;
o o</td></tr><tr><td>nguồn cung cấp 127/380/660VAC; độ ẩm môi trường không khí 0 – 95%; nguồn dự</td></tr><tr><td>phòng Pin NiMH 12V/400mAh; nhiệt độ môi trường 0 – 40oC; dạng bảo vệ nổ</td></tr><tr><td>Exd[ia]I; kích thước 440 x 430 x 180 mm; trọng lượng 35kg.</td></tr></tbody></table>

<table><thead><tr><th>Thùng loa âm ly</th></tr></thead><tbody><tr><td>phòng nổ</td></tr></tbody></table>

<table><thead><tr><th>Robot tự hành</th></tr></thead><tbody><tr><td>dịch vụ VOR</td></tr></tbody></table>

<table><thead><tr><th>– Góc nghiêng tối đa có thể hoạt động 5°, vượt qua bậc có chiều cao tối đa 15 mm;-</th></tr></thead><tbody><tr><td>Tốc độ tối đa đến 1,2 m/s, gia tốc đến 0,2 m/s2;- Định vị và lập bản đồ Laser SLAM;</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>– Chiều cao tối thiểu để phát hiện đối tượng 50 mm;- Điều khiển robot bằng giọng</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nói, tự động bám theo đối tượng, tương tác người dùng bằng giọng nói, tự động</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đưa đồ, chấm công, giám sát an ninh cháy nổ, giám sát tác phong làm việc, trợ lý</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ảo.</td><td></td></tr><tr><td>24</td><td>Bộ nắn điện
Rectifier</td><td></td><td></td><td>8504</td><td>40</td><td>40</td><td>Điện áp đầu vào từ 90 đến 290 VAC; điện áp ra danh định: 48VDC; công suất:
2.900W/3.100W; hiệu suất: ≥ 91%/95%; khởi động mềm: có; khả năng chia dòng tải:
có; Hot-swap: có; truyền thông: CAN.</td><td></td><td></td></tr><tr><td>25</td><td></td><td>Adapter AC-DC</td><td></td><td>8504</td><td>40</td><td>30</td><td></td><td>– Chuyển đổi điện áp xoay chiều đến 240 VAC thành điện áp một chiều 19 – 20</td><td></td></tr><tr><td></td><td></td><td>(19,5V)</td><td></td><td></td><td></td><td></td><td></td><td>VDC;- Dòng điện cực đại đến 3,5 A.</td><td></td></tr><tr><td>26</td><td></td><td>Cuộn dây (Choke</td><td></td><td>8504</td><td>40</td><td>90</td><td>Gồm: cuộn lọc tín hiệu; cuộn băng thông.</td><td></td><td></td></tr><tr><td></td><td></td><td>Coil)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>27</td><td>Robot tự hành
công nghiệp VMR</td><td></td><td></td><td>8479</td><td></td><td></td><td>Kích thước 1.300 x 600 x 600 mm, mặt để tải (load surface) 1.100 x 500 mm; trọng
lượng 150 kg; loại tải các loại thùng hàng, pallet và các xe lưới sử dụng trong
thương mại điện tử. Hệ thống truyền động: độ nghiêng tối đa 5 %; tốc độ tối đa 1
m/s (có thể tùy chỉnh); gia tốc tối đa 0,4 m/s2 (đối với cả không tải và có tải). Hệ
thống nâng: tốc độ nâng (0 – 100%) 15s; tải tối đa 300 kg; chạy bằng pin Lithium
ion, thời gian sử dụng 5 năm hoặc 20 nghìn giờ, thời gian hoạt động 9 h (với tải tối
đa) và 12 h (không tải); kết nối: Wifi, Bluetooth, USB/Audio interface, RF interface;
trang bị cơ cấu dừng khẩn cấp; nhiệt độ 5 – 45°C, độ ẩm 5 – 95% (không đọng
sương); Hệ thống phanh bằng điện; phát hiện, nhận diện được con người và các đối
tượng khác; tránh quá tốc độ: ngăn không cho robot vượt tốc độ an toàn đặt trước.</td><td></td><td></td></tr><tr><td>28</td><td></td><td>Thiết bị chuyển đổi</td><td></td><td>8504</td><td>40</td><td>90</td><td>Đầu vào DC:- Công suất cực đại 6kW, dòng điện cực đại 20A;- Điện áp 100 –
600VDC, điện áp khởi động 120VDC, số lượng MPPT/string 2/2;Đầu ra AC:- Công
suất danh định 5kW;- Điện áp danh định 220VAC/50Hz;</td><td></td><td></td></tr><tr><td></td><td></td><td>dòng điện một</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>chiều do tấm pin</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>năng lượng mặt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Điện áp đầu vào từ 90 đến 290 VAC; điện áp ra danh định: 48VDC; công suất:</th></tr></thead><tbody><tr><td>2.900W/3.100W; hiệu suất: ≥ 91%/95%; khởi động mềm: có; khả năng chia dòng tải:</td></tr><tr><td>có; Hot-swap: có; truyền thông: CAN.</td></tr></tbody></table>

<table><thead><tr><th>Bộ nắn điện</th></tr></thead><tbody><tr><td>Rectifier</td></tr></tbody></table>

<table><thead><tr><th>Kích thước 1.300 x 600 x 600 mm, mặt để tải (load surface) 1.100 x 500 mm; trọng</th></tr></thead><tbody><tr><td>lượng 150 kg; loại tải các loại thùng hàng, pallet và các xe lưới sử dụng trong</td></tr><tr><td>thương mại điện tử. Hệ thống truyền động: độ nghiêng tối đa 5 %; tốc độ tối đa 1</td></tr><tr><td>m/s (có thể tùy chỉnh); gia tốc tối đa 0,4 m/s2 (đối với cả không tải và có tải). Hệ</td></tr><tr><td>thống nâng: tốc độ nâng (0 – 100%) 15s; tải tối đa 300 kg; chạy bằng pin Lithium</td></tr><tr><td>ion, thời gian sử dụng 5 năm hoặc 20 nghìn giờ, thời gian hoạt động 9 h (với tải tối</td></tr><tr><td>đa) và 12 h (không tải); kết nối: Wifi, Bluetooth, USB/Audio interface, RF interface;</td></tr><tr><td>trang bị cơ cấu dừng khẩn cấp; nhiệt độ 5 – 45°C, độ ẩm 5 – 95% (không đọng</td></tr><tr><td>sương); Hệ thống phanh bằng điện; phát hiện, nhận diện được con người và các đối</td></tr><tr><td>tượng khác; tránh quá tốc độ: ngăn không cho robot vượt tốc độ an toàn đặt trước.</td></tr></tbody></table>

<table><thead><tr><th>Robot tự hành</th></tr></thead><tbody><tr><td>công nghiệp VMR</td></tr></tbody></table>

<table><thead><tr><th>Đầu vào DC:- Công suất cực đại 6kW, dòng điện cực đại 20A;- Điện áp 100 –</th></tr></thead><tbody><tr><td>600VDC, điện áp khởi động 120VDC, số lượng MPPT/string 2/2;Đầu ra AC:- Công</td></tr><tr><td>suất danh định 5kW;- Điện áp danh định 220VAC/50Hz;</td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>trời sinh ra thành</th><th></th><th></th><th></th><th></th><th>– Dòng ra cực đại 24A;- Hiệu suất chuyển đổi cực đại trên 98%;Tiêu chuẩn chống
xâm nhập bụi, nước IP65.Hỗ trợ phần mềm giám sát trên điện thoại cho người sử
dụng và hệ thống server quản lý tập trung cho nhà cung cấp.</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td>dòng điện xoay</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>chiều và hòa lưới</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>(Solar Inverter</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>5kW) 1 pha hòa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>lưới</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>29</td><td>Bộ sạc năng
lượng mặt trời
(solar charger)</td><td></td><td></td><td>8504</td><td>40</td><td>90</td><td></td><td>– Chuyển đổi năng lượng điện từ tấm pin năng lượng mặt trời nạp cho ắc quy và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cấp nguồn cho thiết bị viễn thông.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Dải điện áp đầu vào 60V DC đến 150V DC;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Công suất 3kW;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Hiệu suất chuyển đổi đến 97%;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Có chức năng MPPT (lấy công suất cực đại từ tấm pin mặt trời);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Có khả năng lắp lẫn và tích hợp vào hệ thống nguồn DC.</td><td></td></tr><tr><td>30</td><td>Thiết bị nguồn –
48VDC dùng cho
hệ thống viễn
thông</td><td></td><td></td><td>8504</td><td>40</td><td>30</td><td></td><td>– Từ nguồn AC sang nguồn DC; điện áp AC vào 70 – 300 VAC; tần số làm việc 45-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>66 Hz; hiệu suất đầu vào ≥0,99 (50-100% tải); điện áp DC đầu ra 53,5 VDC (dải điện</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>áp điều chỉnh 41,5 – 58,5V);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Công suất đầu ra 15kW, dòng điện đầu ra đến 300A, hiệu suất ≥ 95,5%;- Bộ chỉnh
lưu 5 bộ ZDX3000, nguồn vào (70-300)VAC, nguồn ra (41,5 – 58,5) VDC, công suất
lớn nhất 3.000W/bộ.- Bộ giám sát tập trung CSU501B:</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Giám sát và điều khiển các thiết bị ắc quy, bộ chỉnh lưu, nguồn điện, môi trường
làm việc.+ Cài đặt các thông số;+ Hiện thị các thông số, lỗi, chế độ làm việc tại chỗ
hoặc từ xa qua trình duyệt WEB;- Trọng lượng khung ≤ 30 kg; trọng</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lượng khối chỉnh lưu 2 kg/bộ;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nhiệt độ làm việc -40 đến 65oC;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nhiệt độ lưu kho -40 đến 85oC;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Độ ẩm 10 – 95%.</td><td></td></tr><tr><td>31</td><td>Ắc quy Lithium</td><td></td><td></td><td>8507</td><td>60</td><td>90</td><td></td><td>Dùng cho trạm viễn thông;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Điện áp 48 V, dung lượng đến 100 Ah.</td><td></td></tr></tbody></table>

<table><thead><tr><th>– Dòng ra cực đại 24A;- Hiệu suất chuyển đổi cực đại trên 98%;Tiêu chuẩn chống</th></tr></thead><tbody><tr><td>xâm nhập bụi, nước IP65.Hỗ trợ phần mềm giám sát trên điện thoại cho người sử</td></tr><tr><td>dụng và hệ thống server quản lý tập trung cho nhà cung cấp.</td></tr></tbody></table>

<table><thead><tr><th>Bộ sạc năng</th></tr></thead><tbody><tr><td>lượng mặt trời</td></tr><tr><td>(solar charger)</td></tr></tbody></table>

<table><thead><tr><th>– Công suất đầu ra 15kW, dòng điện đầu ra đến 300A, hiệu suất ≥ 95,5%;- Bộ chỉnh</th></tr></thead><tbody><tr><td>lưu 5 bộ ZDX3000, nguồn vào (70-300)VAC, nguồn ra (41,5 – 58,5) VDC, công suất</td></tr><tr><td>lớn nhất 3.000W/bộ.- Bộ giám sát tập trung CSU501B:</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị nguồn –</th></tr></thead><tbody><tr><td>48VDC dùng cho</td></tr><tr><td>hệ thống viễn</td></tr><tr><td>thông</td></tr></tbody></table>

<table><thead><tr><th>+ Giám sát và điều khiển các thiết bị ắc quy, bộ chỉnh lưu, nguồn điện, môi trường</th></tr></thead><tbody><tr><td>làm việc.+ Cài đặt các thông số;+ Hiện thị các thông số, lỗi, chế độ làm việc tại chỗ</td></tr><tr><td>hoặc từ xa qua trình duyệt WEB;- Trọng lượng khung ≤ 30 kg; trọng</td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>32</th><th></th><th></th><th>Ắc qui Lithium
POSTEF 48V50Ah</th><th>8507</th><th></th><th></th><th>60</th><th></th><th></th><th>90</th><th></th><th></th><th></th><th>– Ký hiệu SDA10-4850;</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Công nghệ Cell pin LiFePO
4;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Điện áp danh định 48V;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Dải điện áp làm việc 40,5 – 54V;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Điện áp ngắt thấp nhất 40,5V;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Dòng nạp 0,2C;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nội trở £40 mW;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cell PIN 15 Cell;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Điện áp 3,2V;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Dung lượng 50Ah;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nhiệt độ hoạt động:</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Ở chế độ nạp 0 đến 60°C;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Ở chế độ xả -20 đến 60°C;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Kích thước 441 x 410 x 131 mm (rộng x sâu x cao);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Trọng lượng 30 kg.</td><td></td></tr><tr><td>33</td><td></td><td></td><td>Điện thoại phổ
thông 2G</td><td>8517</td><td></td><td></td><td>12</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>– Hỗ trợ các băng tần 900GSM và 1.800 DCS.- Có các tính năng chính như: 2 SIM,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>màn hình hiển thị LCD, thẻ nhớ, đèn Flash, loa ngoài, tai nghe headphone. Đáp ứng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tiêu chuẩn 3GPP.</td><td></td></tr><tr><td>34</td><td></td><td></td><td>Điện thoại di động
thông minh</td><td>8517</td><td></td><td></td><td>12</td><td></td><td></td><td>0</td><td></td><td></td><td>QCVN 12:2010/BTTTT,QCVN 15:2010/BTTTT,QCVN 54:2011/BTTTT,QCVN
18:2010/BTTTT.Loại dùng hệ điều hành Android, sử dụng bộ ứng dụng độc quyền
của VNPT Technology.Chứng nhận hợp quy của Việt Nam (số
A0966291118AE01A2) &amp; Chứng nhận tiêu chuẩn châu Âu (CE) RED 2014/53/EU.</td><td></td><td></td></tr><tr><td>35</td><td></td><td></td><td>Điện thoại cao cấp
bảo mật (VIP
Phone)</td><td>8517</td><td></td><td></td><td>12</td><td></td><td></td><td>0</td><td></td><td></td><td>Có chức năng liên lạc của điện thoại thông thường. Gọi thoại và nhắn tin bảo mật.
Tất cả dữ liệu trên máy được mã hóa riêng. Có chip bảo mật riêng để chống hack
dữ liệu. Không cài được phần mềm của bên thứ 3.</td><td></td><td></td></tr><tr><td></td><td>36</td><td></td><td></td><td></td><td>8517</td><td></td><td></td><td>12</td><td></td><td></td><td></td><td></td><td></td><td>Ký hiệu: Vivas Lotus S3 LTE;</td><td></td></tr></tbody></table>

<table><thead><tr><th>Ắc qui Lithium</th></tr></thead><tbody><tr><td>POSTEF 48V50Ah</td></tr></tbody></table>

<table><thead><tr><th>Điện thoại phổ</th></tr></thead><tbody><tr><td>thông 2G</td></tr></tbody></table>

<table><thead><tr><th>QCVN 12:2010/BTTTT,QCVN 15:2010/BTTTT,QCVN 54:2011/BTTTT,QCVN</th></tr></thead><tbody><tr><td>18:2010/BTTTT.Loại dùng hệ điều hành Android, sử dụng bộ ứng dụng độc quyền</td></tr><tr><td>của VNPT Technology.Chứng nhận hợp quy của Việt Nam (số</td></tr><tr><td>A0966291118AE01A2) &amp; Chứng nhận tiêu chuẩn châu Âu (CE) RED 2014/53/EU.</td></tr></tbody></table>

<table><thead><tr><th>Điện thoại di động</th></tr></thead><tbody><tr><td>thông minh</td></tr></tbody></table>

<table><thead><tr><th>Điện thoại cao cấp</th></tr></thead><tbody><tr><td>bảo mật (VIP</td></tr><tr><td>Phone)</td></tr></tbody></table>

<table><thead><tr><th>Có chức năng liên lạc của điện thoại thông thường. Gọi thoại và nhắn tin bảo mật.</th></tr></thead><tbody><tr><td>Tất cả dữ liệu trên máy được mã hóa riêng. Có chip bảo mật riêng để chống hack</td></tr><tr><td>dữ liệu. Không cài được phần mềm của bên thứ 3.</td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Thiết bị đầu cuối di
động thông minh
thế hệ mới</th><th></th><th></th><th></th><th></th><th></th><th></th><th>+ Wifi Single band 2,4GHz;</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Ram đến 3GB;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Bộ nhớ đến 32GB;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Cổng 1 Mini USB + Headset 3.5;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Nguồn cấp 5V-1A;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đạt QCVN 12:2015/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 15:2015/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 54:2011/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 65:2013/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 18:2014/BTTTT.</td><td></td></tr><tr><td>37</td><td>IP Phone</td><td></td><td></td><td>8517</td><td>18</td><td></td><td></td><td>Điện thoại có khả năng gọi video theo chuẩn SIP, đàm thoại hai chiều chất lượng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cao, hỗ trợ bảo mật.</td><td></td></tr><tr><td>38</td><td>Điện thoại cố định
ấn phím có màn
hình LCD</td><td></td><td></td><td>8517</td><td>18</td><td>0</td><td></td><td>– Dùng để liên lạc thoại qua giao diện 2 dây theo chuẩn RJ11.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cự ly liên lạc đến 5 km trên đôi dây dã chiến 0,5 mm x 2 hoặc tương đương trong
điều kiện kết nối tổng đài tiêu chuẩn.- Có màn hình LCD hiển thị những thông tin
như giờ, ngày, tháng, số gọi đến, số gọi đi.- Có đèn báo (cuộc gọi đến, khi đang sử
dụng), chế độ loa ngoài, quay số tắt, nhạc chờ giữ cuộc gọi.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nhớ đến 30 cuộc gọi gần nhất.</td><td></td></tr><tr><td>39</td><td></td><td>Thiết bị trạm gốc</td><td></td><td>8517</td><td>61</td><td>0</td><td>QCVN 18:2014/BTTTT,QCVN 47:2011/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td>công nghệ LTE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>40</td><td>Hệ thống trạm thu
phát gốc 4G
veNodeB</td><td></td><td></td><td>8517</td><td>61</td><td>0</td><td>Sản phẩm eNodeB được phát triển dựa trên các công nghệ tiên tiến nhất của thế
giới: Software defined radio (SDR); Self-Organizing network (SON); Simulation auto
testing system; Suppots C-RAN (Centralized-RAN); Auto tilt azimuth (Electrical).</td><td></td><td></td></tr><tr><td>41</td><td>Trạm thu phát vô
tuyến thế hệ thứ 4
– eNodeB 4G</td><td></td><td></td><td>8517</td><td>61</td><td>0</td><td></td><td>Thực hiện việc truyền và nhận tín hiệu trong mạng di động thế hệ thứ 4 (4G);- MIMO</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2T2R/4T4R;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Băng thông rộng: 20 MHz.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Thiết bị đầu cuối di</th></tr></thead><tbody><tr><td>động thông minh</td></tr><tr><td>thế hệ mới</td></tr></tbody></table>

<table><thead><tr><th>– Cự ly liên lạc đến 5 km trên đôi dây dã chiến 0,5 mm x 2 hoặc tương đương trong</th></tr></thead><tbody><tr><td>điều kiện kết nối tổng đài tiêu chuẩn.- Có màn hình LCD hiển thị những thông tin</td></tr><tr><td>như giờ, ngày, tháng, số gọi đến, số gọi đi.- Có đèn báo (cuộc gọi đến, khi đang sử</td></tr><tr><td>dụng), chế độ loa ngoài, quay số tắt, nhạc chờ giữ cuộc gọi.</td></tr></tbody></table>

<table><thead><tr><th>Điện thoại cố định</th></tr></thead><tbody><tr><td>ấn phím có màn</td></tr><tr><td>hình LCD</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống trạm thu</th></tr></thead><tbody><tr><td>phát gốc 4G</td></tr><tr><td>veNodeB</td></tr></tbody></table>

<table><thead><tr><th>Sản phẩm eNodeB được phát triển dựa trên các công nghệ tiên tiến nhất của thế</th></tr></thead><tbody><tr><td>giới: Software defined radio (SDR); Self-Organizing network (SON); Simulation auto</td></tr><tr><td>testing system; Suppots C-RAN (Centralized-RAN); Auto tilt azimuth (Electrical).</td></tr></tbody></table>

<table><thead><tr><th>tuyến thế hệ thứ 4</th></tr></thead><tbody><tr><td>– eNodeB 4G</td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>42</th><th></th><th></th><th></th><th>Trạm thu phát vô</th><th></th><th>8517</th><th></th><th></th><th>61</th><th></th><th></th><th>0</th><th></th><th></th><th>Thực hiện việc truyền và nhận tín hiệu trong mạng di động thế hệ thứ 5 (5G)- Độ
rộng băng thông 100 MHz</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td>tuyến thế hệ thứ 5</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>– gNodeB 5G</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Tiêu chuẩn đáp ứng 3GPP Release 15.</td><td></td></tr><tr><td>43</td><td></td><td></td><td></td><td>Thiết bị đầu cuối</td><td></td><td>8517</td><td></td><td></td><td>62</td><td></td><td></td><td>21</td><td></td><td></td><td>Thiết bị thu phát vô tuyến sử dụng kỹ thuật điều chế trải phổ trong băng tần 2,4 và
5GHz.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>ONT iGATE</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>GW040-H</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>44</td><td></td><td></td><td>Tổng đài nhân
công 10/20/40 số</td><td></td><td></td><td>8517</td><td></td><td></td><td>62</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>– Kết nối với các điện thoại dã chiến (ở chế độ dùng điện riêng).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Liên lạc hội nghị tối đa đến 40 máy, liên lạc mạng tối đa 4 nhóm.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nguồn pin trực tiếp 6 ± 0,5 VDC.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Báo hiệu cuộc gọi đến bằng chuông và đèn led báo.- Có 01 trung kế CO (nhận tín
hiệu từ 01 thuê bao của tổng đài kỹ thuật số) cho phép các thuê bao nội bộ (từ
thạch) của tổng đài có thể liên lạc với các thuê bao của tổng đài kỹ thuật số thông
qua đấu chuyển của điện thoại viên.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Có chức năng mở rộng dung lượng bằng cách kết nối 2 tổng đài qua cáp nối tầng.</td><td></td><td></td></tr><tr><td>45</td><td></td><td></td><td></td><td>Thiết bị thu phát</td><td></td><td>8517</td><td></td><td></td><td>62</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>QCVN 2014/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>vô tuyến sử dụng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 65:2013/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>kỹ thuật điều chế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 47:2015/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>trải phổ trong băng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tần 2,4 và 5GHz</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>(AP1101IH; Home</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Gateway)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Thực hiện việc truyền và nhận tín hiệu trong mạng di động thế hệ thứ 5 (5G)- Độ</th></tr></thead><tbody><tr><td>rộng băng thông 100 MHz</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị thu phát vô tuyến sử dụng kỹ thuật điều chế trải phổ trong băng tần 2,4 và</th></tr></thead><tbody><tr><td>5GHz.</td></tr></tbody></table>

<table><thead><tr><th>Tổng đài nhân</th></tr></thead><tbody><tr><td>công 10/20/40 số</td></tr></tbody></table>

<table><thead><tr><th>– Báo hiệu cuộc gọi đến bằng chuông và đèn led báo.- Có 01 trung kế CO (nhận tín</th></tr></thead><tbody><tr><td>hiệu từ 01 thuê bao của tổng đài kỹ thuật số) cho phép các thuê bao nội bộ (từ</td></tr><tr><td>thạch) của tổng đài có thể liên lạc với các thuê bao của tổng đài kỹ thuật số thông</td></tr><tr><td>qua đấu chuyển của điện thoại viên.</td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>46</th><th>Thiết bị thu phát
lặp không dây</th><th></th><th></th><th>8517</th><th>62</th><th>51</th><th>Dùng để lặp tín hiệu wifi, thu phát tín hiệu với thiết bị đầu cuối đa phương tiện
(camera không dây). Truyền dữ liệu không dây Wifi 2,4GHz, IEEE 802.11a/b/g,
khoảng cách lặp giữa 2 trạm lên đến 1.000m; bán kính thu phát với các camera
không dây 150m không có vật cản, tầm nhìn thẳng; kết nối quang hoặc không dây;
sử dụng nguồn pin sạc Lithium 12VDC/6.000mAh; độ ẩm môi trường không khí 0 –
95%; nhiệt độ môi trường 0 – 40oC; dạng bảo vệ nổ ExmiaI; kích thước (240 x 200 x
100) mm; trọng lượng 2.5kg.</th><th></th><th></th></tr></thead><tbody><tr><td>47</td><td></td><td>Thiết bị phát lặp</td><td></td><td>8517</td><td>62</td><td>29</td><td></td><td>QCVN 18:2014/BTTTT,</td><td></td></tr><tr><td></td><td></td><td>vô tuyến lưu động</td><td></td><td></td><td></td><td></td><td>QCVN47:2015/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td>mặt đất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>48</td><td></td><td>Thiết bị đầu cuối</td><td></td><td>8517</td><td>62</td><td></td><td></td><td>QCVN 22:2010/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>ADSL có định</td><td></td><td></td><td></td><td></td><td></td><td>TCVN 7189:2009 ;</td><td></td></tr><tr><td></td><td></td><td>tuyến và thu phát
vô tuyến sử dụng</td><td></td><td></td><td></td><td></td><td></td><td>QCVN 18:2010/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>kỹ thuật điều chế</td><td></td><td></td><td></td><td></td><td>QCVN 54:2011/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td>trải phổ trong băng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>tần2,4 GHz (iGate</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>AW300N)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>49</td><td></td><td>Thiết bị định tuyến</td><td></td><td>8517</td><td>62</td><td></td><td></td><td>QCVN 47:2015/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>có thu phát vô</td><td></td><td></td><td></td><td></td><td></td><td>QCVN 18:2014/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>tuyến sử dụng kỹ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 54:2011/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td>thuật điều chế trải</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>phổ trong băng tần</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2,4 GHz</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>50</td><td></td><td>Thiết bị thu phát</td><td></td><td>8517</td><td>62</td><td>59</td><td></td><td>QCVN 18:2014/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>vô tuyến, sử dụng</td><td></td><td></td><td></td><td></td><td>Tên khác: Smart Box 2, iGate IP001HD, SmartBox 3, Universal IoT GW.</td><td></td><td></td></tr><tr><td></td><td></td><td>kỹ thuật điều chế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>trải phổ trong băng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>tần 2,4 GHz</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Dùng để lặp tín hiệu wifi, thu phát tín hiệu với thiết bị đầu cuối đa phương tiện</th></tr></thead><tbody><tr><td>(camera không dây). Truyền dữ liệu không dây Wifi 2,4GHz, IEEE 802.11a/b/g,</td></tr><tr><td>khoảng cách lặp giữa 2 trạm lên đến 1.000m; bán kính thu phát với các camera</td></tr><tr><td>không dây 150m không có vật cản, tầm nhìn thẳng; kết nối quang hoặc không dây;</td></tr><tr><td>sử dụng nguồn pin sạc Lithium 12VDC/6.000mAh; độ ẩm môi trường không khí 0 –</td></tr><tr><td>95%; nhiệt độ môi trường 0 – 40oC; dạng bảo vệ nổ ExmiaI; kích thước (240 x 200 x</td></tr><tr><td>100) mm; trọng lượng 2.5kg.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị thu phát</th></tr></thead><tbody><tr><td>lặp không dây</td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>51</th><th>Hệ thống tổng đài
4G vEPC</th><th></th><th></th><th>8517</th><th>62</th><th>30</th><th>EPC (Evolved packet core) là hệ thống mạng lõi chuyển mạch gói cung cấp dịch vụ
(cả thoại và dữ liệu) trên nền tảng mạng di động 4G LTE (Long term evolution). Hệ
thống EPC bao gồm các node mạng chính như sau: mobility management entity
(MME); serving gateway (SGW); packet data node gateway (PGW); element
management system (EMS); self-organizing network (SON).</th><th></th><th></th></tr></thead><tbody><tr><td>52</td><td></td><td>Thiết bị định tuyến</td><td></td><td>8517</td><td>62</td><td>59</td><td></td><td>QCVN 18:2014/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>có thu phát vô</td><td></td><td></td><td></td><td></td><td></td><td>QCVN 47:2015/BTTTT;</td><td></td></tr><tr><td></td><td></td><td>tuyến sử dụng kỹ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 65:2013/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td>thuật điều chế trải</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>phổ trong băng tần</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2,4 và 5GHz</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>(iGate AP02010H)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>53</td><td>Hệ thống đa
phương tiện IP hỗ
trợ 4G IMS</td><td></td><td></td><td>8517</td><td>62</td><td></td><td>MS (IP Multimedia Subsystem) là một kiến trúc mạng hội tụ được xây dựng nhằm
tạo sự thuận tiện cho sự phát triển và phần phối tập trung các dịch vụ truyền thông
đa phương tiện đến người dùng thông qua giao thức SIP và trên nền tảng mạng IP.
IMS cho phép nhiều mạng truy nhập công nghệ khác nhau (di động, cố định, wifi…)
có thể kết nối với nhau để cùng cung cấp dịch vụ. IMS đã được chuẩn hóa, hướng
đến mô hình cung cấp dịch vụ có tính bền vững trong tương lai. Hội tụ dịch vụ
(Service Convergence); Hội tụ công nghệ truy nhập (Network Convergence); Hội tụ
thiết bị (Device Convergence). Do khả năng “hội tụ” các dịch vụ và công nghệ mạng
truy nhập, IMS giúp nhà mạng tập trung hóa trong công tác vận hành, triển khai các
dịch vụ mới.</td><td></td><td></td></tr><tr><td>54</td><td>Camera giám sát
hành trình</td><td></td><td></td><td>8517</td><td>62</td><td></td><td></td><td>– Ký hiệu: BK10 – camera;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– 2 hệ thống thu tín hiệu: GPS, GLONASS;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Đạt QCVN 31:2014/BGTVT.</td><td></td></tr><tr><td>55</td><td>Thiết bị giám sát
hành trình tàu cá</td><td></td><td></td><td>8517</td><td>62</td><td></td><td></td><td>– Ký hiệu quy cách BK88VN;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Sử dụng module EC21 của Quectel;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– 2 hệ thống thu tín hiệu GPS, GLONASS.</td><td></td></tr></tbody></table>

<table><thead><tr><th>EPC (Evolved packet core) là hệ thống mạng lõi chuyển mạch gói cung cấp dịch vụ</th></tr></thead><tbody><tr><td>(cả thoại và dữ liệu) trên nền tảng mạng di động 4G LTE (Long term evolution). Hệ</td></tr><tr><td>thống EPC bao gồm các node mạng chính như sau: mobility management entity</td></tr><tr><td>(MME); serving gateway (SGW); packet data node gateway (PGW); element</td></tr><tr><td>management system (EMS); self-organizing network (SON).</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống tổng đài</th></tr></thead><tbody><tr><td>4G vEPC</td></tr></tbody></table>

<table><thead><tr><th>MS (IP Multimedia Subsystem) là một kiến trúc mạng hội tụ được xây dựng nhằm</th></tr></thead><tbody><tr><td>tạo sự thuận tiện cho sự phát triển và phần phối tập trung các dịch vụ truyền thông</td></tr><tr><td>đa phương tiện đến người dùng thông qua giao thức SIP và trên nền tảng mạng IP.</td></tr><tr><td>IMS cho phép nhiều mạng truy nhập công nghệ khác nhau (di động, cố định, wifi…)</td></tr><tr><td>có thể kết nối với nhau để cùng cung cấp dịch vụ. IMS đã được chuẩn hóa, hướng</td></tr><tr><td>đến mô hình cung cấp dịch vụ có tính bền vững trong tương lai. Hội tụ dịch vụ</td></tr><tr><td>(Service Convergence); Hội tụ công nghệ truy nhập (Network Convergence); Hội tụ</td></tr><tr><td>thiết bị (Device Convergence). Do khả năng “hội tụ” các dịch vụ và công nghệ mạng</td></tr><tr><td>truy nhập, IMS giúp nhà mạng tập trung hóa trong công tác vận hành, triển khai các</td></tr><tr><td>dịch vụ mới.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống đa</th></tr></thead><tbody><tr><td>phương tiện IP hỗ</td></tr><tr><td>trợ 4G IMS</td></tr></tbody></table>

<table><thead><tr><th>Camera giám sát</th></tr></thead><tbody><tr><td>hành trình</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>hành trình tàu cá</td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>56</th><th>Thiết bị giám sát
hành trình ô tô</th><th>8517</th><th>69</th><th>0</th><th></th><th>Thu thập, giám sát hành trình và các thông số của xe ô tô gồm: vị trí, vận tốc; cảm</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>biến: cửa, khóa điện, điều hòa, vận tốc xung.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Hỗ trợ giao tiếp với các thiết bị ngoại vi: camera, cảm biến xăng dầu, taxi meter; hỗ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>trợ quản lý lái xe thông qua đầu đọc thẻ RFID.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Hỗ trợ cảnh báo khi lái xe vượt quá thời gian, quá tốc độ.Giao tiếp với người sử</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>dụng qua SMS.</td><td></td></tr><tr><td>57</td><td>Thiết bị giám sát
hành trình</td><td>8517</td><td>69</td><td>0</td><td>– Có khả năng kết nối với mạng viễn thông (2G, 3G, 4G, NB-IoT) hoặc kết nối vô
tuyến với mạng nội bộ (Wifi, bluetooth), gửi thông tin tọa độ thiết bị về ứng dụng
người dùng.- Ký hiệu quy cách: BK10; 2 hệ thống thu tín hiệu: GPS, GLONASS;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Đạt QCVN 31:2014/BGTVT.</td><td></td></tr><tr><td>58</td><td>Thiết bị giám sát
hành trình cho xe
máy</td><td>8521</td><td>90</td><td>99</td><td></td><td>Tính năng:- Giám sát vị trí thời gian thực.- Cảnh báo chống trộm.- Cảnh báo di</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>chuyển quá tốc độ quy định.- Kiểm tra điện áp nguồn điện của xe.- Điểu khiển thiết</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>bị qua SMS.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>– Thiết bị giám sát MTR-01 kết hợp với: SIM + Hệ thống định vị GPS + Hệ thống
theo dõi giám sát của Công ty M1 (qua Website hoặc ứng dụng trên smartphone).</td><td></td><td></td></tr><tr><td>59</td><td>Thiết bị ONT</td><td>8517</td><td>62</td><td></td><td></td><td>Ký hiệu: iGate; Optical Network Terminal.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>Thiết bị truyền dữ liệu băng rộng (thiết bị đầu cuối mạng quang thụ động PON) hoạt
động trong băng tần 2,4GHz và truy nhập vô tuyến băng tần 5GHz (hoặc chỉ ở băng
tần 2,4GHz)Tiêu chuẩn:- WAN: GPON ITU-T G.984.1, ITU-T G.988;- Ethernet IEEE
802.3;- Wireless: IEEE 802.11b/g/n hoặc IEEE 802.11a/b/g/n/ac (single band hoặc
dual-band).</td><td></td><td></td></tr><tr><td>60</td><td>Thiết bị truy cập
vô tuyến thế hệ
mới (AP)</td><td>8517</td><td>62</td><td></td><td></td><td>QCVN 54:2020/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 65:2013/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 112:2017/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Ký hiệu Mesh AP;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Wifi Dualband (2,4GHz&amp;5GHz);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Ram 256MB DDR2;</td><td></td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>hành trình ô tô</td></tr></tbody></table>

<table><thead><tr><th>– Có khả năng kết nối với mạng viễn thông (2G, 3G, 4G, NB-IoT) hoặc kết nối vô</th></tr></thead><tbody><tr><td>tuyến với mạng nội bộ (Wifi, bluetooth), gửi thông tin tọa độ thiết bị về ứng dụng</td></tr><tr><td>người dùng.- Ký hiệu quy cách: BK10; 2 hệ thống thu tín hiệu: GPS, GLONASS;</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>hành trình</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>hành trình cho xe</td></tr><tr><td>máy</td></tr></tbody></table>

<table><thead><tr><th>– Thiết bị giám sát MTR-01 kết hợp với: SIM + Hệ thống định vị GPS + Hệ thống</th></tr></thead><tbody><tr><td>theo dõi giám sát của Công ty M1 (qua Website hoặc ứng dụng trên smartphone).</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị truyền dữ liệu băng rộng (thiết bị đầu cuối mạng quang thụ động PON) hoạt</th></tr></thead><tbody><tr><td>động trong băng tần 2,4GHz và truy nhập vô tuyến băng tần 5GHz (hoặc chỉ ở băng</td></tr><tr><td>tần 2,4GHz)Tiêu chuẩn:- WAN: GPON ITU-T G.984.1, ITU-T G.988;- Ethernet IEEE</td></tr><tr><td>802.3;- Wireless: IEEE 802.11b/g/n hoặc IEEE 802.11a/b/g/n/ac (single band hoặc</td></tr><tr><td>dual-band).</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị truy cập</th></tr></thead><tbody><tr><td>vô tuyến thế hệ</td></tr><tr><td>mới (AP)</td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>+ Flash 32MB NOR;</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Tiêu chuẩn IEEE 802.11a/b/g/n/ac/ax;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Concurrent user 100;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Cổng: 1 WAN + 1 LAN port GE;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Nguồn cấp 12V-1,5A.</td><td></td></tr><tr><td>61</td><td></td><td>Thiết bị thu phát</td><td></td><td>8517</td><td>62</td><td></td><td>Dải tần đến 30 MHz;Công suất đến 400 W;Tính năng: thoại, truyền số liệu, tin nhắn,
định vị.</td><td></td><td></td></tr><tr><td></td><td></td><td>vô tuyến điện sóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>ngắn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>62</td><td></td><td>Thiết bị thu phát</td><td></td><td>8517</td><td>62</td><td></td><td>Dải tần đến 450 MHz;Công suất: 2 W;Tính năng: thoại, truyền số liệu, định vị.</td><td></td><td></td></tr><tr><td></td><td></td><td>vô tuyến điện cầm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>tay băng tần UHF</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>63</td><td></td><td>Thiết bị định tuyến</td><td></td><td>8517</td><td>62</td><td>21</td><td></td><td>Thực hiện định tuyến biên giữa đầu cuối dịch vụ và nhà mạng cung cấp hạ tầng.-</td><td></td></tr><tr><td></td><td></td><td>lớp truy nhập hỗ</td><td></td><td></td><td></td><td></td><td></td><td>Năng lực chuyển mạch 300 Gbps;</td><td></td></tr><tr><td></td><td></td><td>trợ công nghệ</td><td></td><td></td><td></td><td></td><td>– Năng lực chuyển tiếp 140 Mpps.</td><td></td><td></td></tr><tr><td></td><td></td><td>IP/MPLS trong</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>mạng truyền dẫn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Metro (Site</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Router)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>64</td><td>Thiết bị thu phát
Wifi ONT</td><td></td><td></td><td>8517</td><td>62</td><td></td><td>Thực hiện kết nối với hạ tầng cáp quang cố định băng rộng để cung cấp dịch vụ
internet, IPTV, VoIP cho khách hàng.- Đáp ứng chuẩn WiFi mới nhất IEEE802.11ax.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Hỗ trợ tính năng dualband, hoạt động trên cả 2 tần số thu phát là 2,4 GHz và 5</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>GHz.</td><td></td></tr><tr><td>65</td><td>Thiết bị đầu cuối
mạng quang
GPON, cung cấp
trực tiếp dịch vụ
(Wifi, LAN, IPTV,
VoIP…) cho người
dùng cuối (Single
band ONT)</td><td></td><td></td><td>8517</td><td>62</td><td>21</td><td>– Chỉ tiêu đầu vào quang GPON:</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Tương thích: ITU-T G.984.2. Công suất phát trung bình tại bước sóng 1.310 (nm)</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đạt từ 0,5 đến 5 dBm. Độ nhạy thu trung bình tại bước sóng 1.490 (nm) trong</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khoảng -28 đến -8 dBm.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Loại connector quang SC/APC.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Wifi: tương thích các chuẩn IEEE 802.11b/g/n tại băng tần 2,4GHz; hỗ trợ MIMO 2</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>x 2 và 4 SSID.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– LAN: 1 cổng Gigabit Ethernet, 3 cổng 10/100 base-TX Ethernet.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Dải tần đến 30 MHz;Công suất đến 400 W;Tính năng: thoại, truyền số liệu, tin nhắn,</th></tr></thead><tbody><tr><td>định vị.</td></tr></tbody></table>

<table><thead><tr><th>Thực hiện kết nối với hạ tầng cáp quang cố định băng rộng để cung cấp dịch vụ</th></tr></thead><tbody><tr><td>internet, IPTV, VoIP cho khách hàng.- Đáp ứng chuẩn WiFi mới nhất IEEE802.11ax.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị thu phát</th></tr></thead><tbody><tr><td>Wifi ONT</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị đầu cuối</th></tr></thead><tbody><tr><td>mạng quang</td></tr><tr><td>GPON, cung cấp</td></tr><tr><td>trực tiếp dịch vụ</td></tr><tr><td>(Wifi, LAN, IPTV,</td></tr><tr><td>VoIP…) cho người</td></tr><tr><td>dùng cuối (Single</td></tr><tr><td>band ONT)</td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>– Hỗ trợ tính năng IoP.- Hỗ trợ IPv4/v6.</th><th></th></tr></thead><tbody><tr><td>66</td><td></td><td>Tai nghe không</td><td></td><td>8517</td><td>62</td><td>59</td><td></td><td>Máy thu, đổi và truyền hoặc tái tạo âm thanh, hình ảnh hoặc dạng dữ liệu khác, kể</td><td></td></tr><tr><td></td><td></td><td>dây bluetooth</td><td></td><td></td><td></td><td></td><td></td><td>cả thiết bị chuyển mạch và thiết bị định tuyến.</td><td></td></tr><tr><td>67</td><td>Thiết bị thu phát
Wifi AP</td><td></td><td></td><td>8517</td><td>62</td><td></td><td></td><td>Thực hiện thu phát tín hiệu internet không dây (wifi) cho khách hàng.- Đáp ứng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuẩn WiFi mới nhất IEEE802.11ax.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Hỗ trợ tính năng dualband, hoạt động trên cả 2 tần số thu phát là 2,4 GHz và 5</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>GHz.</td><td></td></tr><tr><td>68</td><td>Bộ giám sát tủ
nguồn DAQ</td><td></td><td></td><td>8517</td><td>62</td><td></td><td>– Thu thập dữ liệu từ tủ nguồn và các thiết bị hỗ trợ giao thức Modbus RTU (ắc quy
LIB, máy phát điện, công tơ điện tử), chuyển về máy chủ;- Đẩy cảnh báo qua
SNMP;- Có cổng kết nối với máy tính, tủ nguồn và thiết bị hỗ trợ giao thức Mobus
RTU;- Hỗ trợ giao diện Web nhúng;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cho phép nâng cấp firmware từ xa cho thiết bị DAQ hoặc thiết bị khác mà DAQ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>quản lý (ví dụ: thiết bị thông gió).</td><td></td></tr><tr><td>69</td><td></td><td>Thiết bị xử lý hình</td><td></td><td>8517</td><td>62</td><td>59</td><td></td><td>Máy thu, đổi và truyền hoặc tái tạo âm thanh, hình ảnh hoặc dạng dữ liệu khác, kể</td><td></td></tr><tr><td></td><td></td><td>ảnh AI box</td><td></td><td></td><td></td><td></td><td></td><td>cả thiết bị chuyển mạch và thiết bị định tuyến.</td><td></td></tr><tr><td>70</td><td>Thiết bị giám sát
sức khỏe cá nhân</td><td></td><td></td><td>8517</td><td>69</td><td>0</td><td>Kết nối: Có khả năng kết nối với với mạng viễn thông (2G, 3G, 4G, NB-IoT) hoặc kết
nối vô tuyến với mạng nội bộ (Wifi, bluetooth, zigbee) gửi thông tin tham số đo
được, tọa độ thiết bị về ứng dụng người dùng.Các tham số đo lường, giám sát: các
tham số sức khỏe (nhịp tim, nhiệt độ cơ thể, huyết áp tương đối, nồng độ Oxy trong
máu).</td><td></td><td></td></tr><tr><td>71</td><td>Thiết bị giám sát
tham số môi
trường</td><td></td><td></td><td>8517</td><td>69</td><td>0</td><td>Kết nối: Có khả năng kết nối với với mạng viễn thông (2G, 3G, 4G, NB-IoT) hoặc kết
nối vô tuyến với mạng nội bộ (Wifi, bluetooth, zigbee), gửi thông tin tham số đo
được, tọa độ thiết bị về ứng dụng người dùng.Các tham số đo lường, giám sát: các
tham số vật lý nhiệt độ, độ ẩm, nồng độ bụi mịn, tốc độ gió, tia UV, nồng độ khí CO,
khí CO , nồng độ khí ga, báo khói, báo cháy, đo dòng điện, đo điện áp, đo thông số
2
của đất, của nước.</td><td></td><td></td></tr><tr><td>72</td><td></td><td>Thiết bị báo hiệu</td><td></td><td>8517</td><td>69</td><td>0</td><td>Dải tần: 121,5 MHz và 406,040 MHz;Công suất 5W;Tính năng định vị toàn cầu.</td><td></td><td></td></tr><tr><td></td><td></td><td>cứu nạn cá nhân</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Thiết bị thu phát</th></tr></thead><tbody><tr><td>Wifi AP</td></tr></tbody></table>

<table><thead><tr><th>– Thu thập dữ liệu từ tủ nguồn và các thiết bị hỗ trợ giao thức Modbus RTU (ắc quy</th></tr></thead><tbody><tr><td>LIB, máy phát điện, công tơ điện tử), chuyển về máy chủ;- Đẩy cảnh báo qua</td></tr><tr><td>SNMP;- Có cổng kết nối với máy tính, tủ nguồn và thiết bị hỗ trợ giao thức Mobus</td></tr><tr><td>RTU;- Hỗ trợ giao diện Web nhúng;</td></tr></tbody></table>

<table><thead><tr><th>Bộ giám sát tủ</th></tr></thead><tbody><tr><td>nguồn DAQ</td></tr></tbody></table>

<table><thead><tr><th>Kết nối: Có khả năng kết nối với với mạng viễn thông (2G, 3G, 4G, NB-IoT) hoặc kết</th></tr></thead><tbody><tr><td>nối vô tuyến với mạng nội bộ (Wifi, bluetooth, zigbee) gửi thông tin tham số đo</td></tr><tr><td>được, tọa độ thiết bị về ứng dụng người dùng.Các tham số đo lường, giám sát: các</td></tr><tr><td>tham số sức khỏe (nhịp tim, nhiệt độ cơ thể, huyết áp tương đối, nồng độ Oxy trong</td></tr><tr><td>máu).</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>sức khỏe cá nhân</td></tr></tbody></table>

<table><thead><tr><th>Kết nối: Có khả năng kết nối với với mạng viễn thông (2G, 3G, 4G, NB-IoT) hoặc kết</th></tr></thead><tbody><tr><td>nối vô tuyến với mạng nội bộ (Wifi, bluetooth, zigbee), gửi thông tin tham số đo</td></tr><tr><td>được, tọa độ thiết bị về ứng dụng người dùng.Các tham số đo lường, giám sát: các</td></tr><tr><td>tham số vật lý nhiệt độ, độ ẩm, nồng độ bụi mịn, tốc độ gió, tia UV, nồng độ khí CO,</td></tr><tr><td>khí CO , nồng độ khí ga, báo khói, báo cháy, đo dòng điện, đo điện áp, đo thông số
2</td></tr><tr><td>của đất, của nước.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>tham số môi</td></tr><tr><td>trường</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>73</th><th>Anten 4G</th><th></th><th></th><th>8517</th><th>70</th><th></th><th>Dùng cho hệ thống trạm eNodeB 4G.- Dải tần 1.710 – 2.690 MHz;- VSWR &lt; 1,5;-
Công suất tối đa cho mỗi đầu vào 250 W;- Trở kháng 50 Ω (ohm);- Phân cực Anten
45o;- Độ cách ly giữa các cổng &gt; 30o;- Tilt điện 2 – 10o;- IMD &lt; -150 dBc;- Vỏ làm
bằng nhựa ASA và PC;</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Vật liệu phần tử phát xạ, phản xạ nhôm.</td><td></td></tr><tr><td>74</td><td>Tủ đấu cáp, hộp
cáp điện thoại</td><td></td><td></td><td>8517</td><td>70</td><td></td><td>– Dùng để quản lý, bảo vệ mối nối và phân phối đường chuyền tín hiệu.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Dung lượng đến 600 x 2 (đầu dây thuê bao).- Nhiệt độ môi trường từ -10°C đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>60°C.</td><td></td></tr><tr><td>75</td><td></td><td>Thiết bị đầu cuối</td><td></td><td>8517</td><td></td><td></td><td>IU pizza box OLT, 8/16 cổng PON, 1024 ONT, switching capacity 60/128 Gbps.</td><td></td><td></td></tr><tr><td></td><td></td><td>OLT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>76</td><td></td><td>Thiết bị âm thanh</td><td></td><td>8518</td><td>10</td><td>19</td><td></td><td>– Ký hiệu: Arirang WMU 3600.+ Số kênh: 600;+ Khoảng cách thu phát tối đa: 60m;+</td><td></td></tr><tr><td></td><td></td><td>không dây</td><td></td><td></td><td></td><td></td><td></td><td>Độ nhạy: -105dBm.+ Dải tần 50Hz đến 18 kHz.</td><td></td></tr><tr><td>77</td><td>Đầu ghi hình</td><td></td><td></td><td>8521</td><td>90</td><td>99</td><td>Model: XRN-1610A. Dùng cho camera quan sát Wisenet- Hanwha Techwin.</td><td></td><td></td></tr><tr><td>78</td><td>Hệ thống mô
phỏng đào tạo lái
xe</td><td></td><td></td><td>8523</td><td></td><td></td><td>Đáp ứng quy chuẩn QCVN 106:2020/BGTVT;- Số lượng bài tập: Tối thiểu 08 bài tập
lái: sa hình, đồi núi, cao tốc, thành phố, lên xuống phà, đường lầy, ngập nước,
sương mù;- Cho phép đào tạo các hạng xe B, C, D, E, FB, FC, FD, FE;- Mô phỏng
các điều kiện thời gian (ngày/đêm), thời tiết (mưa, nắng, sương mù, tuyết);- Cơ cấu
mô phỏng chuyển động: tối thiểu 3 bậc tự do;- Mô phỏng các tình huống giao thông
bất ngờ.</td><td></td><td></td></tr><tr><td>79</td><td>Camera số và
camera ghi hình
(IP Camera)</td><td></td><td></td><td>8525</td><td>80</td><td></td><td>Camera số và camera ghi hình có gắn thiết bị ghi. Thiết bị Camera giám sát trong
nhà/ngoài trời, full HD, tính năng an ninh, bảo mật cao</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nằm trong bộ giải pháp IP Camera của VNPT Technology</td><td></td></tr><tr><td>80</td><td></td><td></td><td></td><td>8525</td><td>80</td><td></td><td></td><td>– Dải sóng làm việc: 380 nm – 760 nm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Kết nối: 10/100 Ethernet và Wifi</td><td></td></tr></tbody></table>

<table><thead><tr><th>Dùng cho hệ thống trạm eNodeB 4G.- Dải tần 1.710 – 2.690 MHz;- VSWR &lt; 1,5;-</th></tr></thead><tbody><tr><td>Công suất tối đa cho mỗi đầu vào 250 W;- Trở kháng 50 Ω (ohm);- Phân cực Anten</td></tr><tr><td>45o;- Độ cách ly giữa các cổng &gt; 30o;- Tilt điện 2 – 10o;- IMD &lt; -150 dBc;- Vỏ làm</td></tr><tr><td>bằng nhựa ASA và PC;</td></tr></tbody></table>

<table><thead><tr><th>Tủ đấu cáp, hộp</th></tr></thead><tbody><tr><td>cáp điện thoại</td></tr></tbody></table>

<table><thead><tr><th>Đáp ứng quy chuẩn QCVN 106:2020/BGTVT;- Số lượng bài tập: Tối thiểu 08 bài tập</th></tr></thead><tbody><tr><td>lái: sa hình, đồi núi, cao tốc, thành phố, lên xuống phà, đường lầy, ngập nước,</td></tr><tr><td>sương mù;- Cho phép đào tạo các hạng xe B, C, D, E, FB, FC, FD, FE;- Mô phỏng</td></tr><tr><td>các điều kiện thời gian (ngày/đêm), thời tiết (mưa, nắng, sương mù, tuyết);- Cơ cấu</td></tr><tr><td>mô phỏng chuyển động: tối thiểu 3 bậc tự do;- Mô phỏng các tình huống giao thông</td></tr><tr><td>bất ngờ.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống mô</th></tr></thead><tbody><tr><td>phỏng đào tạo lái</td></tr><tr><td>xe</td></tr></tbody></table>

<table><thead><tr><th>Camera số và</th></tr></thead><tbody><tr><td>camera ghi hình</td></tr><tr><td>(IP Camera)</td></tr></tbody></table>

<table><thead><tr><th>Camera số và camera ghi hình có gắn thiết bị ghi. Thiết bị Camera giám sát trong</th></tr></thead><tbody><tr><td>nhà/ngoài trời, full HD, tính năng an ninh, bảo mật cao</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>Camera thông</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>– Nhận diện khuôn mặt, đếm người, phát hiện xâm nhập vùng cấm, phát hiện hành</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td>minh (sử dụng trí</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>vi bất thường, ứng dụng cho smarthome, an ninh tòa nhà văn phòng; giao thông</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tuệ nhân tạo)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thông minh; quản lý đô thị.</td><td></td></tr><tr><td>81</td><td></td><td></td><td>Camera giám sát</td><td></td><td></td><td>8525</td><td></td><td></td><td>80</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td>Thiết bị phát dùng cho phát thanh sóng vô tuyến hoặc truyền hình, có hoặc không</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>gắn với thiết bị thu hoặc ghi hoặc tái tạo âm thanh; camera truyền hình, camera kỹ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thuật số và camera ghi hình ảnh.</td><td></td></tr><tr><td>82</td><td></td><td></td><td>Thiết bị Home Hub
(sử dụng trí tuệ
nhân tạo)</td><td></td><td></td><td>8525</td><td></td><td></td><td>81</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>– Năng lực xử lý AI: 2.1 TOPS;- Kết nối: 100/1.000Mbps Ethernet;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Khả năng kết nối tối đa: 4 camera IP;- Tính năng chính: Phát hiện đột nhập; nhận</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>diện khuôn mặt; mã hóa video đầu cuối.</td><td></td></tr><tr><td>83</td><td></td><td></td><td>Camera Wifi</td><td></td><td></td><td>8525</td><td></td><td></td><td>81</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>– Kết nối: Wifi 2,4 GHz; 100 Mbps Ethernet.- Tính năng chính: Xem trực tuyến; xem</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lại lịch sử; thoại 2 chiều; phát hiện chuyển động; bám chuyển động; lưu thẻ nhớ và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cloud.</td><td></td></tr><tr><td>84</td><td></td><td></td><td></td><td>Thiết bị phát sóng</td><td></td><td>8526</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td>QCVN 18:2014/BTTTT;QCVN 55:2011/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>vô tuyến cự lý</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>ngắn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>85</td><td></td><td></td><td></td><td>Thiết bị giám sát</td><td></td><td>8526</td><td></td><td></td><td>91</td><td></td><td></td><td>10</td><td></td><td></td><td>– Sử dụng năng lượng mặt trời kết hợp PIN;- Chống nước tiêu chuẩn IP67;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hành trình tàu,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>truyền/nhận thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Trao đổi tin nhắn 2 chiều tàu – bờ.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tin cảnh báo giữa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tàu – bờ, tàu – tàu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>(S-tracking)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>86</td><td></td><td></td><td>Thiết bị định vị
thông minh vTag</td><td></td><td></td><td>8526</td><td></td><td></td><td>91</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Thiết bị định vị thông minh vTag, dùng công nghệ định vị GPS/Cell Wifi, giao tiếp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2G/NB IoT, có tích hợp cảm biến chuyển động để tối ưu năng lượng tiêu thụ. Sản</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phẩm phù hợp với các mục đích giám sát, định vị cho người, thú cưng, đồ vật và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phương tiện.</td><td></td></tr><tr><td>87</td><td></td><td></td><td></td><td>Thiết bị thu phát</td><td></td><td>8526</td><td></td><td></td><td>92</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>QCVN 73:2013/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>sóng vô tuyến cự</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 18:2014/BTTTT.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lý ngắn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>88</td><td></td><td></td><td>Màn hình máy tính</td><td></td><td></td><td>8528</td><td></td><td></td><td>51</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Độ phân giải: 1.920 X 1.080 pixel; độ sáng (typ.): 300cd/m2; góc nhìn: H (176) – V</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(176); cổng vào: D-sub và HDMI.</td><td></td></tr><tr><td></td><td>89</td><td></td><td></td><td>Màn hình</td><td></td><td></td><td>8528</td><td></td><td></td><td>59</td><td></td><td></td><td>20</td><td></td><td></td><td>Loại đơn sắc, kích thước 12 inch, dùng điện AC 220V.</td><td></td></tr><tr><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>8528</td><td></td><td></td><td>71</td><td></td><td></td><td></td><td></td><td></td><td>QCVN 54:2020/BTTTT;</td><td></td></tr></tbody></table>

<table><thead><tr><th>Thiết bị định vị</th></tr></thead><tbody><tr><td>thông minh vTag</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Thiết bị kỹ thuật số
xử lý và truyền dữ
liệu tự động (IP
set top box)</th><th></th><th></th><th></th><th></th><th></th><th></th><th>QCVN 65:2013/BTTTT;</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 112:2017/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 118:2018/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Ký hiệu SmartBox; Wifi Single/Dual band (2,4GHz&amp;5GHz); Ram: 1GB DDR3/2GB</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>DDR4; e MMC: 8GB; Cổng: 2 USB + 1 LAN + 1 HDMI + 1 AV3.5 + 1 S/PDIF; nguồn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cấp: 5V-2A/12V -1A.</td><td></td></tr><tr><td>91</td><td></td><td>Thiết bị giải mã tín</td><td></td><td>8528</td><td></td><td></td><td>QCVN 63:2012/BTTTT.Set Top Box DVB T2: iGate T201-HD, iGate T202-HD.</td><td></td><td></td></tr><tr><td></td><td></td><td>hiệu truyền hình</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>số mặt đất DVB</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>T2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>92</td><td>Hệ thống cảnh
báo cháy không
dây (FA-01)</td><td></td><td></td><td>8531</td><td>10</td><td>20</td><td>Bao gồm: Server quản lý, khối Gateway và các đầu cảm biến khói kết nối không dây
thông qua chuẩn kết nối Zigbee.- Tính năng: cảnh báo khẩn cấp (bấm nút trên
Gateway để phát cảnh báo khẩn cấp), tự động điều chỉnh (calib) Sensor, tự động
kiểm tra hoạt động của Sensor, cảnh báo pin yếu (dưới ngưỡng 3.3VDC).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Thời gian tác động đầu báo cháy nhiệt ≤ 120s;- Thời gian tác động đầu báo cháy</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khói ≤ 30s;- Tác động đầu báo cháy nhiệt khi nhiệt độ tăng &gt; 5oC/phút;- Cự ly giao</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tiếp với Sensor: tối đa 30m.</td><td></td></tr><tr><td>93</td><td>Thiết bị bảo an
ATM</td><td></td><td></td><td>8531</td><td>10</td><td></td><td>ATM.ONE là thiết bị giám sát các trạng thái đóng mở cửa, quá nhiệt, rung lắc, dịch
chuyển… tại cây ATM của các ngân hàng, báo động qua 3 phương thức:- Tại chỗ
hú loa đèn;- Nhắn tin gọi điện;- Gửi bản tin lên Server.</td><td></td><td></td></tr><tr><td>94</td><td>Thiết bị giám sát
không dâyS-
Wireless</td><td></td><td></td><td>8531</td><td>10</td><td></td><td>Là bộ sản phẩm không dây bao gồm thiết bị S-Wireless Gateway và thiết bị S-
Wireless Node cảm biến, giám sát các trạng thái đóng mở cửa, quá nhiệt, nút bấm
khẩn cấp, báo khói… cho các cửa hàng, siêu thị, phòng giao dịch…, báo động qua 3
phương thức: tại chỗ hú loa đèn; nhắn tin gọi điện; gửi bản tin lên server.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>xử lý và truyền dữ</th></tr></thead><tbody><tr><td>liệu tự động (IP</td></tr><tr><td>set top box)</td></tr></tbody></table>

<table><thead><tr><th>Bao gồm: Server quản lý, khối Gateway và các đầu cảm biến khói kết nối không dây</th></tr></thead><tbody><tr><td>thông qua chuẩn kết nối Zigbee.- Tính năng: cảnh báo khẩn cấp (bấm nút trên</td></tr><tr><td>Gateway để phát cảnh báo khẩn cấp), tự động điều chỉnh (calib) Sensor, tự động</td></tr><tr><td>kiểm tra hoạt động của Sensor, cảnh báo pin yếu (dưới ngưỡng 3.3VDC).</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống cảnh</th></tr></thead><tbody><tr><td>báo cháy không</td></tr><tr><td>dây (FA-01)</td></tr></tbody></table>

<table><thead><tr><th>ATM.ONE là thiết bị giám sát các trạng thái đóng mở cửa, quá nhiệt, rung lắc, dịch</th></tr></thead><tbody><tr><td>chuyển… tại cây ATM của các ngân hàng, báo động qua 3 phương thức:- Tại chỗ</td></tr><tr><td>hú loa đèn;- Nhắn tin gọi điện;- Gửi bản tin lên Server.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị bảo an</th></tr></thead><tbody><tr><td>ATM</td></tr></tbody></table>

<table><thead><tr><th>Là bộ sản phẩm không dây bao gồm thiết bị S-Wireless Gateway và thiết bị S-</th></tr></thead><tbody><tr><td>Wireless Node cảm biến, giám sát các trạng thái đóng mở cửa, quá nhiệt, nút bấm</td></tr><tr><td>khẩn cấp, báo khói… cho các cửa hàng, siêu thị, phòng giao dịch…, báo động qua 3</td></tr><tr><td>phương thức: tại chỗ hú loa đèn; nhắn tin gọi điện; gửi bản tin lên server.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị giám sát</th></tr></thead><tbody><tr><td>không dâyS-</td></tr><tr><td>Wireless</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>95</th><th></th><th></th><th>Thiết bị Cảnh báo
thiên tai đa mục
tiêu</th><th></th><th></th><th>8531</th><th></th><th></th><th>80</th><th></th><th></th><th></th><th></th><th></th><th>Cảnh báo khẩn cấp đến người dân khi có thiên tai xảy ra như động đất, sóng thần,
lũ lụt… thông qua hệ thống loa, đèn, công suất lớn bán kính tác động rộng lớn.
Được điều khiển trực tiếp từ Viện Vật lý địa cầu, Cục Phòng chống thiên tai tại Bộ,
Sở ban ngành. Sử dụng phần mềm quản lý tập trung trên nền tảng Web.</th><th></th><th></th></tr></thead><tbody><tr><td>96</td><td></td><td></td><td>Bản mạch điện tử</td><td></td><td></td><td>8534</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>10</td><td></td><td>PCB Camera module.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>97</td><td></td><td></td><td>Bản mạch FPCB</td><td></td><td></td><td>8534</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Dùng trong lắp ráp điện thoại di động.</td><td></td></tr><tr><td>98</td><td></td><td></td><td>Hệ thống tủ nguồn
DC cho trạm viễn
thông</td><td></td><td></td><td>8537</td><td></td><td></td><td>10</td><td></td><td></td><td>12</td><td></td><td></td><td>Chuyển đổi từ điện xoay chiều 220V-50Hz thành một chiều 48VDC, cấp nguồn cho
thiết bị viễn thông và nạp ắc quy. Hiệu suất chuyển đổi đến 98%. Công suất đến
27kW. Hệ số công suất: 0,99. Độ méo hài dòng điện nhỏ hơn 5%. Cho phép tích
hợp bộ sạc năng lượng mặt trời và điều khiển máy phát điện. Giám sát điều khiển từ
xa toàn bộ các thông số.</td><td></td><td></td></tr><tr><td>99</td><td></td><td></td><td>Thiết bị chuyển đổi
nguồn tự động
ATS</td><td></td><td></td><td>8537</td><td></td><td></td><td>10</td><td></td><td></td><td>99</td><td></td><td></td><td>Chuyển đổi từ điện xoay chiều 220VAC-50 Hz thành một chiều 48VDC, cấp nguồn
cho thiết bị viễn thông và nạp ắc quy. Hiệu suất chuyển đổi đến 98%. Công suất đến
27 kW. Hệ số công suất 99%. Độ méo hài dòng điện đến 5%. Cho phép tích hợp bộ
sạc năng lượng mặt trời và điều khiển máy phát điện. Giám sát điều khiển từ xa
toàn bộ các thông số.</td><td></td><td></td></tr><tr><td></td><td>100</td><td></td><td></td><td>Chip LED</td><td></td><td></td><td>8541</td><td></td><td></td><td>40</td><td></td><td></td><td>10</td><td></td><td></td><td>Loại chip led 2835.</td><td></td></tr><tr><td>101</td><td></td><td></td><td></td><td>Thẻ nhớ ZMU-03</td><td></td><td>8542</td><td></td><td></td><td>32</td><td></td><td></td><td>0</td><td></td><td></td><td>Sử dụng cho biến tần ACS880-01-14A2-7+E200.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>kèm firmware</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>102</td><td></td><td></td><td>Thiết bị thu, phát
và chuyển đổi tín
hiệu sử dụng trong
truyền hình số thế
hệ thứ 2 và các</td><td></td><td></td><td>8543</td><td></td><td></td><td>70</td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 63:2012/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 118:2018/BTTTT;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Ký hiệu: iGate T201-HD/iGate T202-HD/iGate T203-HD;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Ram: 64MB;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Bộ nhớ: 8MB;</td><td></td></tr></tbody></table>

<table><thead><tr><th>Cảnh báo khẩn cấp đến người dân khi có thiên tai xảy ra như động đất, sóng thần,</th></tr></thead><tbody><tr><td>lũ lụt… thông qua hệ thống loa, đèn, công suất lớn bán kính tác động rộng lớn.</td></tr><tr><td>Được điều khiển trực tiếp từ Viện Vật lý địa cầu, Cục Phòng chống thiên tai tại Bộ,</td></tr><tr><td>Sở ban ngành. Sử dụng phần mềm quản lý tập trung trên nền tảng Web.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị Cảnh báo</th></tr></thead><tbody><tr><td>thiên tai đa mục</td></tr><tr><td>tiêu</td></tr></tbody></table>

<table><thead><tr><th>Chuyển đổi từ điện xoay chiều 220V-50Hz thành một chiều 48VDC, cấp nguồn cho</th></tr></thead><tbody><tr><td>thiết bị viễn thông và nạp ắc quy. Hiệu suất chuyển đổi đến 98%. Công suất đến</td></tr><tr><td>27kW. Hệ số công suất: 0,99. Độ méo hài dòng điện nhỏ hơn 5%. Cho phép tích</td></tr><tr><td>hợp bộ sạc năng lượng mặt trời và điều khiển máy phát điện. Giám sát điều khiển từ</td></tr><tr><td>xa toàn bộ các thông số.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống tủ nguồn</th></tr></thead><tbody><tr><td>DC cho trạm viễn</td></tr><tr><td>thông</td></tr></tbody></table>

<table><thead><tr><th>Chuyển đổi từ điện xoay chiều 220VAC-50 Hz thành một chiều 48VDC, cấp nguồn</th></tr></thead><tbody><tr><td>cho thiết bị viễn thông và nạp ắc quy. Hiệu suất chuyển đổi đến 98%. Công suất đến</td></tr><tr><td>27 kW. Hệ số công suất 99%. Độ méo hài dòng điện đến 5%. Cho phép tích hợp bộ</td></tr><tr><td>sạc năng lượng mặt trời và điều khiển máy phát điện. Giám sát điều khiển từ xa</td></tr><tr><td>toàn bộ các thông số.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyển đổi</th></tr></thead><tbody><tr><td>nguồn tự động</td></tr><tr><td>ATS</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị thu, phát</th></tr></thead><tbody><tr><td>và chuyển đổi tín</td></tr><tr><td>hiệu sử dụng trong</td></tr><tr><td>truyền hình số thế</td></tr><tr><td>hệ thứ 2 và các</td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>thế hệ sau
(DVBT2)</th><th></th><th></th><th></th><th></th><th>+ Cổng: 1 RF in + 1 RF out + 1 RCA + 1 Audio + 1 HDMI + 1 USB;</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>+Nguồn cấp: 12V -1,5A.</td><td></td></tr><tr><td>103</td><td>Cáp đồng thông
tin</td><td>8544</td><td>49</td><td></td><td></td><td>TCVN 8238: 2009;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 8697: 2011 ;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>TCN 68 – 132: 1998;+ Ruột dẫn là dây đồng đường kính từ 0,4 mm đến 1,2 mm;
cách điện ruột dẫn là lớp nhựa PE hoặc PVC; các ruột dẫn đã bọc cách điện được
xoắn lại với nhau thành nhóm đôi hoặc nhóm bốn (quad); các nhóm đôi (bốn) được
bện đối xứng với nhau thành lõi cáp; lõi cáp được chống nhiễu bởi lớp băng nhôm;
thành phần gia cường là băng thép hoặc dây thép bện; vỏ bảo vệ ngoài là lớp nhựa
HDPE.</td><td></td><td></td></tr><tr><td>104</td><td>Máy bay không
người lái hạng nhẹ</td><td>8806</td><td>94</td><td>0</td><td></td><td>– Khối lượng cất cánh tối đa &lt; 150 kg;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Thời gian hoạt động liên tục tối đa 03 giờ;- Vận tốc tối đa 120 km/h;- Bán kính hoạt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>động tối đa 50 km;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Trần bay 3.000 m;- Tải trọng hữu ích tối đa 4 kg;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Phương pháp cất/hạ cánh bằng đường băng hoặc máy phóng/ống phóng, lưới</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>thu/dù.</td><td></td></tr><tr><td>105</td><td>Máy bay không
người lái hạng
nhẹ, cất hạ cánh
thẳng đứng</td><td>8806</td><td>94</td><td>0</td><td></td><td>– Khối lượng cất cánh tối đa &lt; 150 kg;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Thời gian hoạt động liên tục tối đa đến 06 giờ;- Vận tốc tối đa 120 km/h;- Bán kính</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoạt động tối đa 70 km;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Trần bay 3.000 m;- Tải trọng hữu ích tối đa 4 kg;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Phương pháp cất/hạ cánh thẳng đứng.</td><td></td></tr><tr><td>106</td><td>Máy bay không
người lái hạng
siêu nhẹ</td><td>8806</td><td>93</td><td>0</td><td></td><td>– Khối lượng cất cánh tối đa &lt; 25 kg;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Thời gian hoạt động liên tục tối đa đến 02 giờ;- Vận tốc tối đa 120 km/h;- Bán kính</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoạt động tối đa 30 km;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Trần bay 3.000 m;- Tải trọng hữu ích tối đa 2 kg.</td><td></td></tr></tbody></table>

<table><thead><tr><th>thế hệ sau</th></tr></thead><tbody><tr><td>(DVBT2)</td></tr></tbody></table>

<table><thead><tr><th>TCN 68 – 132: 1998;+ Ruột dẫn là dây đồng đường kính từ 0,4 mm đến 1,2 mm;</th></tr></thead><tbody><tr><td>cách điện ruột dẫn là lớp nhựa PE hoặc PVC; các ruột dẫn đã bọc cách điện được</td></tr><tr><td>xoắn lại với nhau thành nhóm đôi hoặc nhóm bốn (quad); các nhóm đôi (bốn) được</td></tr><tr><td>bện đối xứng với nhau thành lõi cáp; lõi cáp được chống nhiễu bởi lớp băng nhôm;</td></tr><tr><td>thành phần gia cường là băng thép hoặc dây thép bện; vỏ bảo vệ ngoài là lớp nhựa</td></tr><tr><td>HDPE.</td></tr></tbody></table>

<table><thead><tr><th>Cáp đồng thông</th></tr></thead><tbody><tr><td>tin</td></tr></tbody></table>

<table><thead><tr><th>Máy bay không</th></tr></thead><tbody><tr><td>người lái hạng nhẹ</td></tr></tbody></table>

<table><thead><tr><th>Máy bay không</th></tr></thead><tbody><tr><td>người lái hạng</td></tr><tr><td>nhẹ, cất hạ cánh</td></tr><tr><td>thẳng đứng</td></tr></tbody></table>

<table><thead><tr><th>Máy bay không</th></tr></thead><tbody><tr><td>người lái hạng</td></tr><tr><td>siêu nhẹ</td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>107</th><th>Sợi quang G652D</th><th></th><th></th><th>9001</th><th>10</th><th>10</th><th>TCVN 8665: 2011;- Sợi quang học trong suốt, linh hoạt được làm từ thủy tinh (silica)
hoặc chất dẻo chất lượng cao, kích thước tượng tự sợi tóc người. Sợi quang có
chức năng truyền tín hiệu trong cáp quang.- Cấu tạo: sợi quang học bao gồm 3 lớp
thành phần chính:(1) Lõi: là sợi thủy tinh quang mỏng, nới tín hiệu ánh sáng truyền
đi; (2) Lớp phủ: lớp nhựa bảo vệ các sợi quang khỏi tác động vật lý và hóa học; (3)
Lớp màu: Lớp nhựa màu giúp phân biệt các sợi quang với nhau trong một bó sợi
trong cáp.</th><th></th><th></th></tr></thead><tbody><tr><td>108</td><td>Cáp quang các
loại</td><td></td><td></td><td>9001</td><td>10</td><td></td><td></td><td>TCVN 9665: 2011; TCVN 8696: 2011 ;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCN 68-160-1996.- Số sợi quang: Từ 1 sợi đến 144 sợi quang.- Bước sóng ánh</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sáng hoạt động: 1.310 nm, 1.550 nm, 1.625 nm.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Môi trường sử dụng: Treo, chôn ngầm hoặc luồn cống, luồn ống.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cấu trúc cáp gồm từ tâm đến vỏ ngoài tối thiểu gồm các thành phần sau:+ Phần
tử chịu lực trung tâm làm bằng sợi thủy tinh hoặc vật liệu phi kim loại có khả năng
chịu lực kéo cao.+ Ống lỏng có chứa sợi quang làm bằng nhựa PBT hoặc tương
đương. Hợp chất điền đầy ống lỏng (dầu nhồi) không độc hại, có khả năng bảo vệ
sợi quang tránh sự thâm nhập của nước và rung động, cho phép sợi quang dễ dàng
dịch chuyển trong ống.+ Các sợi độn có kích thước tương đương ống lỏng, và có
màu sắc dễ phân biệt với ống lỏng chứa sợi quang.+ Lớp vỏ trong (lần 1): Làm từ
nhựa HDPE hoặc tương đương bảo vệ lõi cáp, tăng khả năng chịu nén cho cáp.+
Lớp gia cường: Lớp sợi aramid có cường độ chịu lực cao quấn gia cường ngoài lớp
vỏ trong để tăng khả năng chịu kéo cho cáp.+ Lớp vỏ ngoài (lần 2): Làm từ nhựa
HDPE hoặc vật liệu tương đương bảo vệ cáp chống lại tác động của thời tiết, tia cực
tím (UV) và ngoại lực tác động lên cáp.</td><td></td><td></td></tr><tr><td>109</td><td></td><td>Sợi thủy tinh dùng</td><td></td><td>9001</td><td></td><td></td><td></td><td>TCVN – 8665:2011;</td><td></td></tr><tr><td></td><td></td><td>trong thông tin</td><td></td><td></td><td></td><td></td><td>Tiêu chuẩn quốc tế ITU – T G.652.D.</td><td></td><td></td></tr><tr><td></td><td></td><td>quang G.652D</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TCVN 8665: 2011;- Sợi quang học trong suốt, linh hoạt được làm từ thủy tinh (silica)</th></tr></thead><tbody><tr><td>hoặc chất dẻo chất lượng cao, kích thước tượng tự sợi tóc người. Sợi quang có</td></tr><tr><td>chức năng truyền tín hiệu trong cáp quang.- Cấu tạo: sợi quang học bao gồm 3 lớp</td></tr><tr><td>thành phần chính:(1) Lõi: là sợi thủy tinh quang mỏng, nới tín hiệu ánh sáng truyền</td></tr><tr><td>đi; (2) Lớp phủ: lớp nhựa bảo vệ các sợi quang khỏi tác động vật lý và hóa học; (3)</td></tr><tr><td>Lớp màu: Lớp nhựa màu giúp phân biệt các sợi quang với nhau trong một bó sợi</td></tr><tr><td>trong cáp.</td></tr></tbody></table>

<table><thead><tr><th>– Cấu trúc cáp gồm từ tâm đến vỏ ngoài tối thiểu gồm các thành phần sau:+ Phần</th></tr></thead><tbody><tr><td>tử chịu lực trung tâm làm bằng sợi thủy tinh hoặc vật liệu phi kim loại có khả năng</td></tr><tr><td>chịu lực kéo cao.+ Ống lỏng có chứa sợi quang làm bằng nhựa PBT hoặc tương</td></tr><tr><td>đương. Hợp chất điền đầy ống lỏng (dầu nhồi) không độc hại, có khả năng bảo vệ</td></tr><tr><td>sợi quang tránh sự thâm nhập của nước và rung động, cho phép sợi quang dễ dàng</td></tr><tr><td>dịch chuyển trong ống.+ Các sợi độn có kích thước tương đương ống lỏng, và có</td></tr><tr><td>màu sắc dễ phân biệt với ống lỏng chứa sợi quang.+ Lớp vỏ trong (lần 1): Làm từ</td></tr><tr><td>nhựa HDPE hoặc tương đương bảo vệ lõi cáp, tăng khả năng chịu nén cho cáp.+</td></tr><tr><td>Lớp gia cường: Lớp sợi aramid có cường độ chịu lực cao quấn gia cường ngoài lớp</td></tr><tr><td>vỏ trong để tăng khả năng chịu kéo cho cáp.+ Lớp vỏ ngoài (lần 2): Làm từ nhựa</td></tr><tr><td>HDPE hoặc vật liệu tương đương bảo vệ cáp chống lại tác động của thời tiết, tia cực</td></tr><tr><td>tím (UV) và ngoại lực tác động lên cáp.</td></tr></tbody></table>

<table><thead><tr><th>Cáp quang các</th></tr></thead><tbody><tr><td>loại</td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>110</th><th>Công tơ điện tử và
hệ thống thu thập
dữ liệu</th><th>9028</th><th>30</th><th>10</th><th>Công tơ điện tử cấp chính xác 1% phù hợp cho hộ gia đình. Có khả năng truyền dữ
liệu đi xa qua giao thức PLC hoặc RF. Hệ thống thu thập dữ liệu: lấy dữ liệu tối đã
lên đến 1.000 công tơ (qua PLC hoặc RF), gửi dữ liệu về server qua SIM.</th><th></th><th></th></tr></thead><tbody><tr><td>111</td><td>Thiết bị tự động
đo, giám sát áp
suất chênh lệch</td><td>9026</td><td>20</td><td></td><td>Đo lường và hiển thị chênh lệch áp suất tại khu vực giám sát. Truyền dữ liệu về tủ
điều khiển trung tâm bằng tần số. Dải đo: 0 – 10kPa, sai số: ± 2%FS. Hiển thị dữ
liệu trên LCD 2×8. Tần số phát toàn dải đo 5 – 12kHz. Nguồn cung cấp lớn nhất
12VDC/150mA; pin dự phòng NiMH 12VDC/400mA; dạng bảo vệ nổ ExiaI. Kích
thước 160 mm x 110 mm x 80 mm; trọng lượng 1,5kg.</td><td></td><td></td></tr><tr><td>112</td><td>Hệ thống giám sát
phổ dải rộng</td><td>9030</td><td></td><td></td><td></td><td>Dải tần đến 6.000 MHz;Băng thông 40 MHz;Tính năng: phát hiện giám sát tín hiệu;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>phân loại tín hiệu AM, FM, SSB, 2-FSK; giải điều chế tín hiệu AM, FM, LSB, USB,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>CW.</td><td></td></tr><tr><td>113</td><td>Bộ giám sát và đo
lường tự động độ
nghiêng (Tilt), góc
phương vị
(Azimuth)</td><td>9031</td><td>80</td><td>90</td><td></td><td>– Anten tự động và trả kết quả đo về theo ngày; kết quả hiển thị lên thiết bị và trả về</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>server qua GPRS hoặc SMS nếu server bị lỗi.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Sử dụng nguồn điện danh định 24 VDC, dải hoạt động tối thiểu 10 – 48 VDC.-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị có khả năng chống ngược cực tới điện áp 60 VDC trong thời gian tối thiểu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>30 giây.</td><td></td></tr><tr><td>114</td><td>Hệ thống thông
gió lọc bụi</td><td>9032</td><td>89</td><td>39</td><td>– Điều khiển tốc độ quạt thông gió theo nhiệt độ bên trong, giám sát và điều khiển từ
xa;- Bộ lọc tinh lọc hơn 50% các hạt bụi có kích thước từ 10µm trở lên;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Bộ lọc thô lọc vật thể có đường kính từ 2cm trở lên.</td><td></td></tr><tr><td>115</td><td>Cảnh báo nguồn
AC-V1</td><td>9032</td><td>89</td><td>39</td><td>Kích thước ≤ 135 x 55 x 35 mm. Phù hợp lắp đặt khi khoan bắt trên tường, trạm
dùng tủ cầu dao đảo chiều hoặc lắp trong tủ tích hợp.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Công tơ điện tử và</th></tr></thead><tbody><tr><td>hệ thống thu thập</td></tr><tr><td>dữ liệu</td></tr></tbody></table>

<table><thead><tr><th>Công tơ điện tử cấp chính xác 1% phù hợp cho hộ gia đình. Có khả năng truyền dữ</th></tr></thead><tbody><tr><td>liệu đi xa qua giao thức PLC hoặc RF. Hệ thống thu thập dữ liệu: lấy dữ liệu tối đã</td></tr><tr><td>lên đến 1.000 công tơ (qua PLC hoặc RF), gửi dữ liệu về server qua SIM.</td></tr></tbody></table>

<table><thead><tr><th>Đo lường và hiển thị chênh lệch áp suất tại khu vực giám sát. Truyền dữ liệu về tủ</th></tr></thead><tbody><tr><td>điều khiển trung tâm bằng tần số. Dải đo: 0 – 10kPa, sai số: ± 2%FS. Hiển thị dữ</td></tr><tr><td>liệu trên LCD 2×8. Tần số phát toàn dải đo 5 – 12kHz. Nguồn cung cấp lớn nhất</td></tr><tr><td>12VDC/150mA; pin dự phòng NiMH 12VDC/400mA; dạng bảo vệ nổ ExiaI. Kích</td></tr><tr><td>thước 160 mm x 110 mm x 80 mm; trọng lượng 1,5kg.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị tự động</th></tr></thead><tbody><tr><td>đo, giám sát áp</td></tr><tr><td>suất chênh lệch</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống giám sát</th></tr></thead><tbody><tr><td>phổ dải rộng</td></tr></tbody></table>

<table><thead><tr><th>lường tự động độ</th></tr></thead><tbody><tr><td>nghiêng (Tilt), góc</td></tr><tr><td>phương vị</td></tr></tbody></table>

<table><thead><tr><th>– Điều khiển tốc độ quạt thông gió theo nhiệt độ bên trong, giám sát và điều khiển từ</th></tr></thead><tbody><tr><td>xa;- Bộ lọc tinh lọc hơn 50% các hạt bụi có kích thước từ 10µm trở lên;</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống thông</th></tr></thead><tbody><tr><td>gió lọc bụi</td></tr></tbody></table>

<table><thead><tr><th>Cảnh báo nguồn</th></tr></thead><tbody><tr><td>AC-V1</td></tr></tbody></table>

<table><thead><tr><th>Kích thước ≤ 135 x 55 x 35 mm. Phù hợp lắp đặt khi khoan bắt trên tường, trạm</th></tr></thead><tbody><tr><td>dùng tủ cầu dao đảo chiều hoặc lắp trong tủ tích hợp.</td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>116</th><th>Bộ chuyển nguồn
tự động ATS</th><th>9032</th><th>89</th><th>39</th><th>ATS 1 PHA/3 PHA. Điện áp đầu vào: 90-250 VAC. ATS là thiết bị tự động lựa chọn
nguồn điện lưới hoặc nguồn điện máy phát để cấp điện cho trạm BTS. Tự động điều
khiển và sử dụng nguồn từ máy phát điện khi phát hiện có tín hiệu DC LOW từ tủ
nguồn DC của trạm BTS, hoặc điều khiển tự động 2 máy phát điện hoạt động luân
phiên. Dòng tải tối đa 60A. Điện áp nguồn nuôi 48VDC. Đo đạc điện áp AC/DC. Chế
độ vận hành: AUTO/OFF/MANUAL. Chế độ hoạt động: GRID+GEN; GEN1+GEN2.
Giao diện: LCD/ Keyboard/LED/Switch. Có khả năng hoạt động độc lập.</th><th></th><th></th></tr></thead><tbody><tr><td>117</td><td>Bộ điều khiển
nhận tín hiệu DC
low</td><td>9032</td><td>89</td><td>39</td><td>– Chuyển đổi điện áp 12 VDC (ắc quy đề của máy phát điện) thành 48 VDC cấp
nguồn cho ATS tại trạm BTS có khoảng cách giữa máy nổ và nhà trạm &gt; 50m;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Chuyển đổi nguồn 220 VAC thành nguồn 12 VDC cấp cho bộ chuyển đổi (ưu tiên</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>sử dụng nguồn AC khi có điện AC);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Chuyển tiếp tín hiệu DClow từ NOCPro qua GSM đến ATS để điều khiển máy phát</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>điện;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>– Gửi tin nhắn cho nhân viên vận hành trạm.</td><td></td></tr><tr><td>118</td><td>Phần mềm trợ lý
ảo tương tác
khách hàng tự
động (Cyberbot)</td><td></td><td></td><td></td><td>Phần mềm cho phép tự động tương tác với khách hàng nhằm giải đáp, hỗ trợ, thông
báo, xác nhận thông tin.- Giao diện tương tác tin nhắn văn bản (Webchat, Facebook
messenger) hoặc qua tổng đài thoại (VoIP).- Công nghệ: nhận dạng tiếng nói, tổng
hợp tiếng nói, xử lý ngôn ngữ tự nhiên tiếng Việt.</td><td></td><td></td></tr><tr><td>119</td><td>Phần mềm giám
sát thông tin trên
Internet (Reputa)</td><td></td><td></td><td></td><td></td><td>Phần mềm cho phép thu thập, phân tích và cảnh báo các thông tin theo chủ đề trên</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>mạng Internet.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>– Nguồn thông tin đa dạng: có thể thu thập từ 65 triệu tài khoản Facebook, 8 triệu
nhóm/trang Facebook, 2 triệu kênh Youtube Việt Nam, 3 nghìn báo và trang tin điện
tử, diễn đàn.- Số lượng tin quét trên ngày khoảng 12 triệu tin/ngày.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>ATS 1 PHA/3 PHA. Điện áp đầu vào: 90-250 VAC. ATS là thiết bị tự động lựa chọn</th></tr></thead><tbody><tr><td>nguồn điện lưới hoặc nguồn điện máy phát để cấp điện cho trạm BTS. Tự động điều</td></tr><tr><td>khiển và sử dụng nguồn từ máy phát điện khi phát hiện có tín hiệu DC LOW từ tủ</td></tr><tr><td>nguồn DC của trạm BTS, hoặc điều khiển tự động 2 máy phát điện hoạt động luân</td></tr><tr><td>phiên. Dòng tải tối đa 60A. Điện áp nguồn nuôi 48VDC. Đo đạc điện áp AC/DC. Chế</td></tr><tr><td>độ vận hành: AUTO/OFF/MANUAL. Chế độ hoạt động: GRID+GEN; GEN1+GEN2.</td></tr><tr><td>Giao diện: LCD/ Keyboard/LED/Switch. Có khả năng hoạt động độc lập.</td></tr></tbody></table>

<table><thead><tr><th>Bộ chuyển nguồn</th></tr></thead><tbody><tr><td>tự động ATS</td></tr></tbody></table>

<table><thead><tr><th>– Chuyển đổi điện áp 12 VDC (ắc quy đề của máy phát điện) thành 48 VDC cấp</th></tr></thead><tbody><tr><td>nguồn cho ATS tại trạm BTS có khoảng cách giữa máy nổ và nhà trạm &gt; 50m;</td></tr></tbody></table>

<table><thead><tr><th>Bộ điều khiển</th></tr></thead><tbody><tr><td>nhận tín hiệu DC</td></tr><tr><td>low</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm trợ lý</th></tr></thead><tbody><tr><td>ảo tương tác</td></tr><tr><td>khách hàng tự</td></tr><tr><td>động (Cyberbot)</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm cho phép tự động tương tác với khách hàng nhằm giải đáp, hỗ trợ, thông</th></tr></thead><tbody><tr><td>báo, xác nhận thông tin.- Giao diện tương tác tin nhắn văn bản (Webchat, Facebook</td></tr><tr><td>messenger) hoặc qua tổng đài thoại (VoIP).- Công nghệ: nhận dạng tiếng nói, tổng</td></tr><tr><td>hợp tiếng nói, xử lý ngôn ngữ tự nhiên tiếng Việt.</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm giám</th></tr></thead><tbody><tr><td>sát thông tin trên</td></tr><tr><td>Internet (Reputa)</td></tr></tbody></table>

<table><thead><tr><th>– Nguồn thông tin đa dạng: có thể thu thập từ 65 triệu tài khoản Facebook, 8 triệu</th></tr></thead><tbody><tr><td>nhóm/trang Facebook, 2 triệu kênh Youtube Việt Nam, 3 nghìn báo và trang tin điện</td></tr><tr><td>tử, diễn đàn.- Số lượng tin quét trên ngày khoảng 12 triệu tin/ngày.</td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>120</th><th></th><th>Phần mềm chuyển</th><th></th><th></th><th></th><th></th><th>Điểm MOS về độ tự nhiên giọng nói nhân tạo: 4.25/5.0. Số lượng giọng nói nhân tạo
hỗ trợ 12 giọng nam/nữ 3 miền Bắc/ Trung/Nam. Ứng dụng: báo nói, sách nói, tổng
đài tự động.</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td>đổi văn bản thành</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>giọng nói tiếng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Việt (Text to</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Speech)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>121</td><td>Phần mềm hệ điều
hành bảo mật
(CyOS)</td><td></td><td></td><td></td><td></td><td></td><td>Phần mềm hệ điều hành cho phép cài đặt trên các máy tính trạm, cung cấp các tính
năng như duyệt file, duyệt web, soạn thảo cho người dùng cuối cũng như các tính
năng quản lý tập trung và đảm bảo an toàn thông tin cho 1 đơn vị, tổ chức.+ Tính
năng quản lý an toàn thông tin: xác thực người dùng tập trung, quản lý chính sách
tập trung, hỗ trợ người dùng từ xa, mã hóa bảo mật dữ liệu.+ Tính năng người
dùng: giao diện thuận tiện, hỗ trợ bộ gõ tiếng Việt, MS Office, mã hóa dữ liệu, tối ưu
bộ nhớ.</td><td></td><td></td></tr><tr><td>122</td><td>Phần mềm chuyển
đổi giọng nói
thành văn bản
tiếng Việt(Speech
to Text)</td><td></td><td></td><td></td><td></td><td></td><td>Độ chính xác nhận diện trung bình mức 90%.Giọng hỗ trợ nhận dạng: nam/nữ, 3
miền Bắc/Trung/Nam.Ứng dụng: ghi chú cuộc họp, bóc băng phỏng vấn, công cụ
nhập liệu bằng giọng nói, tổng đài tự động, ra lệnh bằng giọng nói.</td><td></td><td></td></tr><tr><td>123</td><td></td><td>Phần mềm trích</td><td></td><td></td><td></td><td></td><td></td><td>Tự động trích xuất thông tin trong từ ảnh có chứa các văn bản, biểu mẫu, giấy tờ</td><td></td></tr><tr><td></td><td></td><td>xuất thông tin từ</td><td></td><td></td><td></td><td></td><td></td><td>tiếng Việt. Ảnh văn bản hỗ trợ: chứng minh nhân dân, căn cước công dân, văn bản</td><td></td></tr><tr><td></td><td></td><td>ảnh văn bản tiếng</td><td></td><td></td><td></td><td></td><td></td><td>hành chính, hóa đơn. Độ chính xác nhận diện mức ký tự 98%. Tốc độ xử lý</td><td></td></tr><tr><td></td><td></td><td>Việt</td><td></td><td></td><td></td><td></td><td></td><td>1,2s/ảnh.</td><td></td></tr><tr><td>124</td><td>Phần mềm nhận
dạng phương tiện
giao thông và biển
số xe</td><td></td><td></td><td></td><td></td><td></td><td>Tự động nhận diện phương tiện giao thông và biển số xe trong ảnh hoặc video.- Độ
chính xác nhận diện phương tiện đến 98%;- Độ chính xác nhận diện biển số đến
98%;- Các loại phương tiện hỗ trợ: xe tải, xe con, xe khách, xe máy, xe đạp, người
đi bộ;- Tốc độ xử lý: 16 hình/giây/ luồng video.</td><td></td><td></td></tr><tr><td>125</td><td></td><td>Phần mềm nhận</td><td></td><td></td><td></td><td></td><td>Tự động nhận dạng khuôn mặt người và so khớp với ảnh trong hồ sơ sẵn có của
người dùng.- Độ chính xác nhận diện và so khớp: 98%;- Độ chính xác phân biệt ảnh
giả mạo: 95%;- Tốc độ xử lý: 1,5s/ảnh.</td><td></td><td></td></tr><tr><td></td><td></td><td>dạng và so khớp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>hình ảnh khuôn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>mặt người (Face</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Matching)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Điểm MOS về độ tự nhiên giọng nói nhân tạo: 4.25/5.0. Số lượng giọng nói nhân tạo</th></tr></thead><tbody><tr><td>hỗ trợ 12 giọng nam/nữ 3 miền Bắc/ Trung/Nam. Ứng dụng: báo nói, sách nói, tổng</td></tr><tr><td>đài tự động.</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm hệ điều hành cho phép cài đặt trên các máy tính trạm, cung cấp các tính</th></tr></thead><tbody><tr><td>năng như duyệt file, duyệt web, soạn thảo cho người dùng cuối cũng như các tính</td></tr><tr><td>năng quản lý tập trung và đảm bảo an toàn thông tin cho 1 đơn vị, tổ chức.+ Tính</td></tr><tr><td>năng quản lý an toàn thông tin: xác thực người dùng tập trung, quản lý chính sách</td></tr><tr><td>tập trung, hỗ trợ người dùng từ xa, mã hóa bảo mật dữ liệu.+ Tính năng người</td></tr><tr><td>dùng: giao diện thuận tiện, hỗ trợ bộ gõ tiếng Việt, MS Office, mã hóa dữ liệu, tối ưu</td></tr><tr><td>bộ nhớ.</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm hệ điều</th></tr></thead><tbody><tr><td>hành bảo mật</td></tr><tr><td>(CyOS)</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm chuyển</th></tr></thead><tbody><tr><td>đổi giọng nói</td></tr><tr><td>thành văn bản</td></tr><tr><td>tiếng Việt(Speech</td></tr></tbody></table>

<table><thead><tr><th>Độ chính xác nhận diện trung bình mức 90%.Giọng hỗ trợ nhận dạng: nam/nữ, 3</th></tr></thead><tbody><tr><td>miền Bắc/Trung/Nam.Ứng dụng: ghi chú cuộc họp, bóc băng phỏng vấn, công cụ</td></tr><tr><td>nhập liệu bằng giọng nói, tổng đài tự động, ra lệnh bằng giọng nói.</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm nhận</th></tr></thead><tbody><tr><td>dạng phương tiện</td></tr><tr><td>giao thông và biển</td></tr><tr><td>số xe</td></tr></tbody></table>

<table><thead><tr><th>Tự động nhận diện phương tiện giao thông và biển số xe trong ảnh hoặc video.- Độ</th></tr></thead><tbody><tr><td>chính xác nhận diện phương tiện đến 98%;- Độ chính xác nhận diện biển số đến</td></tr><tr><td>98%;- Các loại phương tiện hỗ trợ: xe tải, xe con, xe khách, xe máy, xe đạp, người</td></tr><tr><td>đi bộ;- Tốc độ xử lý: 16 hình/giây/ luồng video.</td></tr></tbody></table>

<table><thead><tr><th>Tự động nhận dạng khuôn mặt người và so khớp với ảnh trong hồ sơ sẵn có của</th></tr></thead><tbody><tr><td>người dùng.- Độ chính xác nhận diện và so khớp: 98%;- Độ chính xác phân biệt ảnh</td></tr><tr><td>giả mạo: 95%;- Tốc độ xử lý: 1,5s/ảnh.</td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD650

## DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH

## KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG

## SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD650</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, NGUYÊN LIỆU, VẬT TƯ, LINH
KIỆN NGÀNH VIỄN THÔNG - CÔNG NGHỆ THÔNG TIN, NỘI DUNG
SỐ, PHẦN MỀM TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>126</th><th></th><th></th><th>Phần mềm quản lý
tin nhắn rác và
cuộc gọi rác
(Antispam)</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Cho phép quản lý và xử lý các tin nhắn rác và cuộc gọi rác trên mạng viễn thông.-
Công nghệ áp dụng: Big Data, Machine Learning;- Năng lực xử lý: 10 nghìn tin
nhắn/giây, 20 nghìn cuộc gọi/ giây, thời gian xử lý ra quyết định &lt; 1s;- Tỷ lệ chặn
thiếu SMS &lt; 1%;</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Độ chính xác dự đoán cuộc gọi spam 83%.</td><td></td></tr><tr><td>127</td><td></td><td></td><td></td><td>Hệ thống điều</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO Annex 14.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>khiển đèn hiệu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>128</td><td></td><td></td><td>Hệ thống chuyển
tiếp điện văn tự
động – AMSS</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO Annex 10;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Sử dụng chuyển điện văn tự động trong lĩnh vực không lưu.</td><td></td><td></td></tr><tr><td></td><td>129</td><td></td><td></td><td>Máy điều dòng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO doc 9157;Điều dòng hỗ trợ hệ thống đèn hiệu sân bay.</td><td></td></tr><tr><td>130</td><td></td><td></td><td></td><td>Thiết bị ghi âm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO Annex 10.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>chuyên dụng hàng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>không</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>131</td><td></td><td></td><td></td><td>Phần mềm Hệ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO doc 9880;Hệ thống chuyển đổi điện văn theo TC về AMHS.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thống AMHS cơ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>bản</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>132</td><td></td><td></td><td>Đèn chữ X</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO Annex 14; ICAO doc 9157;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dùng báo hiệu đóng cửa đường cất hạ cánh máy bay tạm thời.</td><td></td></tr><tr><td>133</td><td></td><td></td><td></td><td>Hệ thống quan</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICAO Annex 3.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>trắc thời tiết tự</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>động hàng không</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>134</td><td></td><td></td><td></td><td>Hệ thống điều</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ED 137- tiêu chuẩn về khả năng tương tác cho các thành phần của VoIP ATM. Sử
dụng liên lạc thông tin đối không và mặt đất.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>khiển thông tin</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thoại</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Cho phép quản lý và xử lý các tin nhắn rác và cuộc gọi rác trên mạng viễn thông.-</th></tr></thead><tbody><tr><td>Công nghệ áp dụng: Big Data, Machine Learning;- Năng lực xử lý: 10 nghìn tin</td></tr><tr><td>nhắn/giây, 20 nghìn cuộc gọi/ giây, thời gian xử lý ra quyết định &lt; 1s;- Tỷ lệ chặn</td></tr><tr><td>thiếu SMS &lt; 1%;</td></tr></tbody></table>

<table><thead><tr><th>Phần mềm quản lý</th></tr></thead><tbody><tr><td>tin nhắn rác và</td></tr><tr><td>cuộc gọi rác</td></tr><tr><td>(Antispam)</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống chuyển</th></tr></thead><tbody><tr><td>tiếp điện văn tự</td></tr><tr><td>động – AMSS</td></tr></tbody></table>

<table><thead><tr><th>ED 137- tiêu chuẩn về khả năng tương tác cho các thành phần của VoIP ATM. Sử</th></tr></thead><tbody><tr><td>dụng liên lạc thông tin đối không và mặt đất.</td></tr></tbody></table>

|<image_24>|


