# Public_675

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD675</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: VÁCH NGĂN VÀ
BỘ PHẬN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Vách ngăn, ký hiệu
chung trên mặt bằng</td><td></td><td></td></tr><tr><td>Vách ngăn lưới kim
loại</td><td></td><td></td></tr><tr><td>Vách ngăn bằng các
tấm đúc sẵn</td><td></td><td></td></tr><tr><td>Vách ngăn bằng kính
hay vật liệu trong, vật
liệu trổ hoa rỗng</td><td></td><td></td></tr><tr><td>Vách ngăn bằng vật
liệu phổ thông: tre, gỗ,
cốt phê, tấm sợi ép…</td><td></td><td>Để vách có thể làm bằng gỗ, tre, mai,
vầu, lồ ô. Tấm vách có thể làm bằng
gỗ dán, gỗ ván, phên, da, cốt… (Vật
liệu vách có thể chú thích trên trên
đường dẫn).</td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD675</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: VÁCH NGĂN VÀ
BỘ PHẬN</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD675</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: VÁCH NGĂN VÀ
BỘ PHẬN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Tường</td><td>Tường hiện có cần
sửa chữa</td><td></td><td></td></tr><tr><td></td><td>Tường mới thiết
kế khi sửa chữa
hay xây mới</td><td></td><td></td></tr><tr><td></td><td>Tường cần phá
bỏ khi sửa chữa</td><td></td><td></td></tr><tr><td>Lỗ trống</td><td>Lỗ trống hiện có
cần được mở rộng
trên tường</td><td></td><td>Thể hiện trên mặt
đứng và mặt cắt.</td></tr><tr><td></td><td>Lỗ trống hiện có
trên tường cần
được thu hẹp</td><td></td><td>Thể hiện trên mặt
đứng và mặt cắt.</td></tr><tr><td></td><td>Lỗ trống mới thiết
kế trên tường hay
sàn hiện có</td><td></td><td>Có thể chú thích
trên trên đường
dẫn</td></tr></tbody></table>

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD675</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: VÁCH NGĂN VÀ
BỘ PHẬN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Lỗ trống cần bít
lại trên sàn hay
tường hiện có</th><th></th><th>Có thể chú thích
trên trên đường
dẫn.</th></tr></thead><tbody></tbody></table>

|<image_15>|

|<image_16>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD675</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: VÁCH NGĂN VÀ
BỘ PHẬN</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_17>|


