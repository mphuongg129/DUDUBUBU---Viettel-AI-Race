# Public_649

## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI CHUYÊN DÙNG TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td></td><td></td><td></td><td>Xe nâng người làm việc</td><td></td><td>8428</td><td></td><td></td><td>10</td><td></td><td></td><td>31</td><td></td><td></td><td>Nâng đến độ cao 21m, làm việc trong nhà xưởng.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>trên cao</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td></td><td></td><td></td><td>Tàu điện ắc quy phòng</td><td></td><td>8601</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 02:2016/CĐUB. Đầu máy di chuyển trên đường ray chạy bằng ắc quy</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nổ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>điện, tự trọng đến 12 tấn.</td><td></td></tr><tr><td>3</td><td></td><td></td><td>Tàu điện 8 tấn 2 cabin
chạy bằng ắc quy điện</td><td></td><td></td><td>8601</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 19:2022/CĐUB. Cỡ đường ray đến 900 mm, tự trọng 8,9 tấn, khoảng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cách trục 1.150 mm, tốc độ 7 đến 10 km/h, điện áp 140 V, dung lượng 440</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Ah.</td><td></td></tr><tr><td>4</td><td></td><td></td><td></td><td>Đầu máy diesel truyền</td><td></td><td>8602</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>QCVN 15: 2018/BGTVT. Đầu máy D19E, chạy trên đường ray, công suất kéo</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>động điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.455 kW.</td><td></td></tr><tr><td>5</td><td></td><td></td><td>Toa xe</td><td></td><td></td><td>8605</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 18:2018/BGTVT. Bao gồm toa xe: nằm mềm (An), nằm cứng (Bn), ghế
mềm (A), ghế cứng (B), ghế dọc (C), hàng cơm (HC), chở công vụ phát điện,
tự đổ đến 12 m3, chở ô tô, chở container, chở xi măng rời, chở hành lý, thùng
(xi téc) composite chở chất lỏng đến 30 m3.</td><td></td><td></td></tr><tr><td>6</td><td></td><td></td><td>Toa xe chở người lò dốc</td><td></td><td></td><td>8605</td><td></td><td></td><td>0</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Phương tiện vận tải người trong hầm lò, số chỗ ngồi: 28 chỗ, góc dốc đường</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lò 10°-30°. Bán kính cong đi qua nhỏ nhất 25 m, khoảng cách hoãn xung 1,5</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>m.</td><td></td></tr><tr><td>7</td><td></td><td></td><td>Toa xe chở người có giá
chuyển hướng</td><td></td><td></td><td>8605</td><td></td><td></td><td>0</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCN.GCH.18(8).900(600), TCCS 15:2018/CĐUB, vận chuyển đến 18 người,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>02 cụm giá chuyển hướng, số lượng bánh xe/cụm 04 cái, vận tốc trên đường</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thẳng đến 7 km/h, vận tốc qua đường cong đến 3 km/h, trọng lượng ≥ 2.300</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kg.</td><td></td></tr><tr><td>8</td><td></td><td></td><td>Toa xe lò bằng có giá
chuyển TXGC</td><td></td><td></td><td>8605</td><td></td><td></td><td>0</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Vận tốc lớn nhất trên đường thẳng 7 km/h, trên đường cong 3 km/h, bán kính</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đường cong nhỏ nhất 8.000 mm, số người vận chuyển 18 người, số lượng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuyển giá 02 giá.</td><td></td></tr><tr><td>9</td><td></td><td></td><td>Xe goòng chở vật liệu nổ
công nghiệp</td><td></td><td></td><td>8606</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 13:2018/CKMK. Dùng chở vật liệu nổ công nghiệp trong hầm lò, cỡ
đường ray 900 mm, chiều dài trục cơ sở 1.100 mm, số ngăn chứa 14 ngăn.</td><td></td><td></td></tr><tr><td></td><td>10</td><td></td><td></td><td>Toa xe xitec (P)</td><td></td><td></td><td>8606</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 9983:2013. Dung tích đến 12 m3.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Tàu điện 8 tấn 2 cabin</th></tr></thead><tbody><tr><td>chạy bằng ắc quy điện</td></tr></tbody></table>

<table><thead><tr><th>QCVN 18:2018/BGTVT. Bao gồm toa xe: nằm mềm (An), nằm cứng (Bn), ghế</th></tr></thead><tbody><tr><td>mềm (A), ghế cứng (B), ghế dọc (C), hàng cơm (HC), chở công vụ phát điện,</td></tr><tr><td>tự đổ đến 12 m3, chở ô tô, chở container, chở xi măng rời, chở hành lý, thùng</td></tr><tr><td>(xi téc) composite chở chất lỏng đến 30 m3.</td></tr></tbody></table>

<table><thead><tr><th>Toa xe chở người có giá</th></tr></thead><tbody><tr><td>chuyển hướng</td></tr></tbody></table>

<table><thead><tr><th>Toa xe lò bằng có giá</th></tr></thead><tbody><tr><td>chuyển TXGC</td></tr></tbody></table>

<table><thead><tr><th>Xe goòng chở vật liệu nổ</th></tr></thead><tbody><tr><td>công nghiệp</td></tr></tbody></table>

<table><thead><tr><th>TCCS 13:2018/CKMK. Dùng chở vật liệu nổ công nghiệp trong hầm lò, cỡ</th></tr></thead><tbody><tr><td>đường ray 900 mm, chiều dài trục cơ sở 1.100 mm, số ngăn chứa 14 ngăn.</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>11</td><td></td><td></td><td>Ô tô kéo rơ moóc</td><td></td><td></td><td>8701</td><td></td><td></td><td>95</td><td></td><td></td><td>90</td><td></td><td></td><td>Công suất máy đến 294 kW. Khối lượng kéo lớn nhất là 44 tấn.</td><td></td></tr><tr><td></td><td>12</td><td></td><td></td><td>Ô tô khách</td><td></td><td></td><td>8702</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT, QCVN 10:2015/BGTVT. Chở đến 52 chỗ.</td><td></td></tr><tr><td>13</td><td></td><td></td><td>Ô tô khách đào tạo lái xe</td><td></td><td></td><td>8702</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Xe có cơ cấu phanh phụ bố trí chân phanh phụ bên ghế phụ của xe, thiết bị
chấm điểm, để sát hạch lái xe, tập lái, sử dụng động cơ xăng hoặc diesel.</td><td></td><td></td></tr><tr><td></td><td>14</td><td></td><td></td><td>Ô tô buýt</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Chở đến 80 chỗ ngồi.</td><td></td></tr><tr><td></td><td>15</td><td></td><td></td><td>Xe minibus</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>89</td><td></td><td></td><td>QCVN 86:2015/BGTVT. Chở đến 19 chỗ.</td><td></td></tr><tr><td>16</td><td></td><td></td><td></td><td>Ô tô khách có giường</td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>81</td><td></td><td></td><td>Chở đến 38 người (36 giường nằm, 02 ghế ngồi).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nằm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>17</td><td></td><td></td><td>Ô tô khách thành phố</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>81</td><td></td><td></td><td>Chở đến 80 người (bao gồm cả chỗ ngồi và chỗ đứng), có hoặc không bố trí
ghế ưu tiên, khu vực để xe lăn để người khuyết tật có thể tiếp cận sử dụng.</td><td></td><td></td></tr><tr><td>18</td><td></td><td></td><td>Ô tô khách thành phố,
một tầng, không có nóc</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>81</td><td></td><td></td><td></td><td>Số người chở đến 80 người. Có 2 khoang: kín và không có nóc, có hoặc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>không bố trí ghế ưu tiên, khu vực để xe lăn để người khuyết tật có thể tiếp cận</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sử dụng.</td><td></td></tr><tr><td>19</td><td></td><td></td><td>Ô tô khách thành phố,
hai tầng, không có nóc</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>81</td><td></td><td></td><td></td><td>Chở đến 80 người, có 2 tầng, không có nóc che toàn bộ sàn tầng 2, có hoặc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>không bố trí ghế ưu tiên, khu vực để xe lăn để người khuyết tật có thể tiếp cận</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sử dụng.</td><td></td></tr><tr><td>20</td><td></td><td></td><td></td><td>Ô tô khách thành phố</td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>81</td><td></td><td></td><td>Chở đến 90 người (bao gồm cả chỗ ngồi và chỗ đứng).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>BRT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>21</td><td></td><td></td><td>Ô tô tang lễ</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>81</td><td></td><td></td><td>Chở đến 19 người và 01 quan tài.</td><td></td></tr><tr><td>22</td><td></td><td></td><td>Ô tô chở người trong sân
bay</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>71</td><td></td><td></td><td>TCCS 18:2015/CHK. Phương tiện tự hành vận chuyển hành khách giữa nhà
ga và máy bay. Chở đến 90 người (bao gồm cả chỗ ngồi và chỗ đứng).</td><td></td><td></td></tr><tr><td>23</td><td></td><td></td><td>Xe chuyên dùng chở
người người nghiện ma
túy, đối tượng tệ nạn xã
hội</td><td></td><td></td><td>8702</td><td></td><td></td><td>10</td><td></td><td></td><td>10</td><td></td><td></td><td>Tổng trọng tải 6.500 kg. Dung tích xi lanh 2.977 cc. Lái xe và cán bộ áp giải
03 người, đối tượng tệ nạn xã hội 20 người, có trang bị còi hụ và đèn quay
tròn, thùng có vách ngăn theo chiều dọc bằng tôn và lưới thép, có lắp 01 cửa
hông thùng bên phụ. Đạt tiêu chuẩn khí thải Euro 4.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Xe có cơ cấu phanh phụ bố trí chân phanh phụ bên ghế phụ của xe, thiết bị</th></tr></thead><tbody><tr><td>chấm điểm, để sát hạch lái xe, tập lái, sử dụng động cơ xăng hoặc diesel.</td></tr></tbody></table>

<table><thead><tr><th>Chở đến 80 người (bao gồm cả chỗ ngồi và chỗ đứng), có hoặc không bố trí</th></tr></thead><tbody><tr><td>ghế ưu tiên, khu vực để xe lăn để người khuyết tật có thể tiếp cận sử dụng.</td></tr></tbody></table>

<table><thead><tr><th>Ô tô khách thành phố,</th></tr></thead><tbody><tr><td>một tầng, không có nóc</td></tr></tbody></table>

<table><thead><tr><th>Ô tô khách thành phố,</th></tr></thead><tbody><tr><td>hai tầng, không có nóc</td></tr></tbody></table>

<table><thead><tr><th>Ô tô chở người trong sân</th></tr></thead><tbody><tr><td>bay</td></tr></tbody></table>

<table><thead><tr><th>TCCS 18:2015/CHK. Phương tiện tự hành vận chuyển hành khách giữa nhà</th></tr></thead><tbody><tr><td>ga và máy bay. Chở đến 90 người (bao gồm cả chỗ ngồi và chỗ đứng).</td></tr></tbody></table>

<table><thead><tr><th>Xe chuyên dùng chở</th></tr></thead><tbody><tr><td>người người nghiện ma</td></tr><tr><td>túy, đối tượng tệ nạn xã</td></tr><tr><td>hội</td></tr></tbody></table>

<table><thead><tr><th>Tổng trọng tải 6.500 kg. Dung tích xi lanh 2.977 cc. Lái xe và cán bộ áp giải</th></tr></thead><tbody><tr><td>03 người, đối tượng tệ nạn xã hội 20 người, có trang bị còi hụ và đèn quay</td></tr><tr><td>tròn, thùng có vách ngăn theo chiều dọc bằng tôn và lưới thép, có lắp 01 cửa</td></tr><tr><td>hông thùng bên phụ. Đạt tiêu chuẩn khí thải Euro 4.</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>24</td><td></td><td></td><td>Ô tô con</td><td></td><td></td><td>8703</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Chở đến 9 chỗ ngồi (kể cả lái xe), không gồm xe ô tô
chống đạn, đặc chủng chuyên dùng an ninh quốc phòng.</td><td></td><td></td></tr><tr><td>25</td><td></td><td></td><td>Ô tô con đào tạo lái xe</td><td></td><td></td><td>8703</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chở đến 9 chỗ ngồi (kể cả lái xe), xe có cơ cấu phanh phụ bố trí chân phanh</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phụ bên ghế phụ của xe, thiết bị chấm điểm, để tập lái, sát hạch lái xe. Sử</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dụng động cơ xăng hoặc diesel.</td><td></td></tr><tr><td>26</td><td></td><td></td><td>Xe chở người bốn bánh
có gắn động cơ</td><td></td><td></td><td>8703</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Số chỗ ngồi tối đa 15 chỗ (kể cả chỗ ngồi của người lái). Sử dụng động cơ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>điện, xăng hoặc diesel, bao gồm cả xe chơi golf (golf car, golf buggies), ô tô</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>điện.</td><td></td></tr><tr><td>27</td><td></td><td></td><td>Xe chuyên dùng chở lực
lượng vũ trang</td><td></td><td></td><td>8703</td><td></td><td></td><td>22</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Xe ô tô tải chuyên dùng chở lực lượng vũ trang 08 chỗ. Dung tích xi lanh</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.462 cc. Tổng tải trọng 2.010 kg. Hai bên thùng có hai dãy băng ghế nệm,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kèo mui, dãy cơ động. Amly, đèn quay dài 1,2 m.</td><td></td></tr><tr><td>28</td><td></td><td></td><td>Ô tô cứu thương</td><td></td><td></td><td>8703</td><td></td><td></td><td>23</td><td></td><td></td><td>51</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Khối lượng toàn bộ đến 16 tấn. Chở đến 09 chỗ.</td><td></td><td></td></tr><tr><td>29</td><td></td><td></td><td>Ô tô chở phạm nhân</td><td></td><td></td><td>8703</td><td></td><td></td><td>32</td><td></td><td></td><td>53</td><td></td><td></td><td>Số người cho phép chở sau cải tạo kể cả lái xe 9 người. Dung tích xi lanh
2.497 cc, sử dụng hệ thống phun dầu điện tử. Tiêu chuẩn khí thải Euro 4.</td><td></td><td></td></tr><tr><td>30</td><td></td><td></td><td></td><td>Ô tô cứu hộ nâng cầu, ô</td><td></td><td>8704</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Khối lượng toàn bộ đến 34 tấn, tải trọng nâng đến 34 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tô cứu hộ sàn trượt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>31</td><td></td><td></td><td></td><td>Ô tô bồn nhiên liệu lưu</td><td></td><td>8704</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thể tích đến 20 m3, có cơ cấu bơm diesel và lưu lượng kế điện tử.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>động</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>32</td><td></td><td></td><td></td><td>Ô tô tải chở hàng chuyên</td><td></td><td>8704</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Xe có thùng lửng, thùng kín, thùng bạt, thùng gắn cẩu có tổng tải trọng đến 34</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dùng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tấn.</td><td></td></tr><tr><td></td><td>33</td><td></td><td></td><td>Ô tô chở quân</td><td></td><td></td><td>8704</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Loại xe chở quân 01 cầu chủ động 4×2 loại tiểu đội, trung đội.</td><td></td></tr><tr><td>34</td><td></td><td></td><td>Ô tô chở rác</td><td></td><td></td><td>8704</td><td></td><td></td><td>21</td><td></td><td></td><td>22</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng tải trọng đến 24 tấn, thể tích chứa đến 22 m3.</td><td></td><td></td></tr><tr><td>35</td><td></td><td></td><td>Xe ô tô pickup</td><td></td><td></td><td>8704</td><td></td><td></td><td>21</td><td></td><td></td><td>26</td><td></td><td></td><td></td><td>Trọng tải chở hàng tối đa đến 808 kg, cabin kép, nhiên liệu dầu diesel, dung</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tích xi lanh 2,0 L, công thức bánh xe 4×2 và 4×4.</td><td></td></tr><tr><td></td><td>36</td><td></td><td></td><td>Ô tô chở kính</td><td></td><td></td><td>8704</td><td></td><td></td><td>21</td><td></td><td></td><td>29</td><td></td><td></td><td>Tải trọng chuyên chở đến 13 tấn, trang bị giá chữ A để chở kính.</td><td></td></tr></tbody></table>

<table><thead><tr><th>QCVN 09:2015/BGTVT. Chở đến 9 chỗ ngồi (kể cả lái xe), không gồm xe ô tô</th></tr></thead><tbody><tr><td>chống đạn, đặc chủng chuyên dùng an ninh quốc phòng.</td></tr></tbody></table>

<table><thead><tr><th>Xe chở người bốn bánh</th></tr></thead><tbody><tr><td>có gắn động cơ</td></tr></tbody></table>

<table><thead><tr><th>Xe chuyên dùng chở lực</th></tr></thead><tbody><tr><td>lượng vũ trang</td></tr></tbody></table>

<table><thead><tr><th>Số người cho phép chở sau cải tạo kể cả lái xe 9 người. Dung tích xi lanh</th></tr></thead><tbody><tr><td>2.497 cc, sử dụng hệ thống phun dầu điện tử. Tiêu chuẩn khí thải Euro 4.</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>37</td><td></td><td></td><td>Ô tô tải đào tạo lái xe</td><td></td><td></td><td>8704</td><td></td><td></td><td>21</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td>Tải trọng đến 5 tấn, xe có cơ cấu phanh phụ bố trí chân phanh phụ bên ghế</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phụ của xe.</td><td></td></tr><tr><td></td><td>38</td><td></td><td></td><td>Xe thùng tải lắp cẩu</td><td></td><td></td><td>8704</td><td></td><td></td><td>22</td><td></td><td></td><td></td><td></td><td></td><td>QCVN 09: 2015/BGTVT. Tổng tải trọng đến 15,1 tấn.</td><td></td></tr><tr><td></td><td>39</td><td></td><td></td><td>Ô tô chở ô tô</td><td></td><td></td><td>8704</td><td></td><td></td><td>22</td><td></td><td></td><td>51</td><td></td><td></td><td>Tải trọng chuyên chở đến 16 tấn.</td><td></td></tr><tr><td>40</td><td></td><td></td><td></td><td>Ô tô tải chở thùng bảo</td><td></td><td>8704</td><td></td><td></td><td>22</td><td></td><td></td><td>41</td><td></td><td></td><td>Tải trọng đến 20 tấn, thể tích đến 45 m3; độ lạnh đến -25ºC.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>ôn, thùng đông lạnh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>41</td><td></td><td></td><td>Ô tô xi téc</td><td></td><td></td><td>8704</td><td></td><td></td><td>22</td><td></td><td></td><td>43</td><td></td><td></td><td>Trọng lượng toàn bộ đến 34 tấn. Dung tích đến 27.000 lít, chở dầu ăn, dầu ăn
thực vật, nước, sữa, nước mắm; axít (Acetic, H SO , HCl), cồn, dung dịch
2 4
NaOH 4%; xăng, diesel, ethanol, hexane, khí ga hóa lỏng, LPG, methanol,
methyl tertiary butyl ether, toluene, n-butanol, nhiên liệu; mủ cao su, nhựa
đường nóng lỏng, nitơ lỏng, ôxy lỏng, CO lỏng, NH lỏng, cám, thủy tinh lỏng,
2 3
nước thủy tinh silicat, phụ gia bê tông, xi măng rời, chất thải; nhiên liệu cho
máy bay.</td><td></td><td></td></tr><tr><td></td><td>42</td><td></td><td></td><td>Ô tô chở pallet</td><td></td><td></td><td>8704</td><td></td><td></td><td>22</td><td></td><td></td><td>51</td><td></td><td></td><td>Tải trọng chở đến 18 tấn.</td><td></td></tr><tr><td></td><td>43</td><td></td><td></td><td>Xe kéo, chở xe</td><td></td><td></td><td>8704</td><td></td><td></td><td>22</td><td></td><td></td><td>59</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng trọng tải đến 11,2 tấn.</td><td></td></tr><tr><td>44</td><td></td><td></td><td></td><td>Xe Hooklift (tự kéo đẩy,</td><td></td><td>8704</td><td></td><td></td><td>23</td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng tải trọng đến 24 tấn. Thể tích thùng chứa đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nâng, hạ thùng hàng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>22 m3.</td><td></td></tr><tr><td>45</td><td></td><td></td><td></td><td>Xe tải tự đổ có trang bị</td><td></td><td>8704</td><td></td><td></td><td>32</td><td></td><td></td><td>97</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng tải trọng đến 15,1 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cặp đổ bùn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>46</td><td></td><td></td><td>Ô tô sát xi tải</td><td></td><td></td><td>8704</td><td></td><td></td><td>21, 22,
23</td><td></td><td></td><td></td><td>29,</td><td></td><td>QCVN 09:2015/BGTVT. Là ô tô sát xi có buồng lái có khối lượng toàn bộ theo
thiết kế đến 34 tấn. Dung tích xi lanh đến 10,5L. Công thức bánh xe 4×2, 4×4,
6×2, 6×4, 8×4 và 10×4.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>51,</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>59,</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>69</td><td></td><td></td><td></td><td></td></tr><tr><td>47</td><td></td><td></td><td>Ô tô tải tự đổ, xe ben</td><td></td><td></td><td>8704</td><td></td><td></td><td>21, 23</td><td></td><td></td><td>29</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Xe có thùng tự đổ, tổng tải trọng đến 34 tấn.</td><td></td><td></td></tr><tr><td>48</td><td></td><td></td><td>Ô tô đầu kéo</td><td></td><td></td><td>8701</td><td></td><td></td><td>21</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Khối lượng toàn bộ tới 29,23 tấn. Ô tô được thiết kế</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>để kéo sơ mi rơ moóc.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Trọng lượng toàn bộ đến 34 tấn. Dung tích đến 27.000 lít, chở dầu ăn, dầu ăn</th></tr></thead><tbody><tr><td>thực vật, nước, sữa, nước mắm; axít (Acetic, H SO , HCl), cồn, dung dịch
2 4</td></tr><tr><td>NaOH 4%; xăng, diesel, ethanol, hexane, khí ga hóa lỏng, LPG, methanol,</td></tr><tr><td>methyl tertiary butyl ether, toluene, n-butanol, nhiên liệu; mủ cao su, nhựa</td></tr><tr><td>đường nóng lỏng, nitơ lỏng, ôxy lỏng, CO lỏng, NH lỏng, cám, thủy tinh lỏng,
2 3</td></tr><tr><td>nước thủy tinh silicat, phụ gia bê tông, xi măng rời, chất thải; nhiên liệu cho</td></tr><tr><td>máy bay.</td></tr></tbody></table>

<table><thead><tr><th>QCVN 09:2015/BGTVT. Là ô tô sát xi có buồng lái có khối lượng toàn bộ theo</th></tr></thead><tbody><tr><td>thiết kế đến 34 tấn. Dung tích xi lanh đến 10,5L. Công thức bánh xe 4×2, 4×4,</td></tr><tr><td>6×2, 6×4, 8×4 và 10×4.</td></tr></tbody></table>

<table><thead><tr><th>21, 22,</th></tr></thead><tbody><tr><td>23</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>49</td><td></td><td></td><td>Ô tô bán hàng lưu động</td><td></td><td></td><td>8704</td><td></td><td></td><td>21</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Khối lượng toàn bộ tới 3,045 tấn. Kết cấu thùng dạng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hộp kín, trần xe có thể nâng lên khi bán hàng và trên thùng xe có trang bị các</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kệ bán hàng.</td><td></td></tr><tr><td>50</td><td></td><td></td><td>Ô tô tải VAN</td><td></td><td></td><td>8704</td><td></td><td></td><td>31</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Khối lượng toàn bộ tới 2,47 tấn. Ô tô tải thùng kín có</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khoang chở hàng liền với cabin, có bố trí cửa xếp dỡ hàng, có lắp đặt vách</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ngăn cố định giữa khoang chở hàng và cabin.</td><td></td></tr><tr><td>51</td><td></td><td></td><td>Ô tô xi téc phun nước</td><td></td><td></td><td>8704</td><td></td><td></td><td>90</td><td></td><td></td><td>50</td><td></td><td></td><td></td><td>Dung tích đến 15.000 lít, sử dụng bơm bánh răng (60 m3/h), súng phun xa</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đến 50 m (1.800 l/phút).</td><td></td></tr><tr><td>52</td><td></td><td></td><td></td><td>Xe ô tô tải nâng chuyên</td><td></td><td>8705</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Xe ô tô tải mui bạt bửng nâng. Số người cho phép chở kể cả lái 03 người.
Bửng có sửng nâng 600 kg. Dung tích xi lanh 2.999 cc.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dùng tuần tra, kiểm soát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>giao thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>53</td><td></td><td></td><td>Ô tô tải có cần cẩu</td><td></td><td></td><td>8705</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Tải trọng chở lớn nhất 20,5 tấn. Tải trọng nâng lớn nhất đến 15 tấn. Tầm với</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lớn nhất 25,3 m.</td><td></td></tr><tr><td>54</td><td></td><td></td><td>Ô tô chữa cháy</td><td></td><td></td><td>8705</td><td></td><td></td><td>30</td><td></td><td></td><td>0</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Khối lượng toàn bộ đến 24 tấn, xi téc chứa nước đến
12.000 lít, bồn chứa foam đến 1.000 lít (không gồm xe chữa cháy loại nhỏ xi
téc ≤ 2.000 lít, bồn chứa bọt ≤ 200 lít, tính năng chuyên dùng quốc phòng, an
ninh vượt trội so với xe chữa cháy thông thường).</td><td></td><td></td></tr><tr><td>55</td><td></td><td></td><td></td><td>Xe thang cứu hộ, cứu</td><td></td><td>8705</td><td></td><td></td><td>30</td><td></td><td></td><td>0</td><td></td><td></td><td>Độ cao đến 32 m.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nạn chữa cháy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>56</td><td></td><td></td><td>Xe trạm bơm chữa cháy</td><td></td><td></td><td>8705</td><td></td><td></td><td>30</td><td></td><td></td><td>0</td><td></td><td></td><td>Lưu lượng bơm đến 15.000 lít/phút.</td><td></td></tr><tr><td>57</td><td></td><td></td><td></td><td>Ô tô chở nước tiếp nước</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>50</td><td></td><td></td><td>Dung tích đến 13,5 m3.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cho xe chữa cháy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>58</td><td></td><td></td><td></td><td>Ô tô vệ sinh hầm đường</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>50</td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Khối lượng toàn bộ theo thiết kế 24 tấn. Xi téc chứa</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nước và các trang thiết bị vệ sinh hầm đường bộ.</td><td></td></tr><tr><td>59</td><td></td><td></td><td></td><td>Xe quét hút rác đường</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>50</td><td></td><td></td><td>Dung tích thùng chứa rác đến 10 m3.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>phố</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Xe ô tô tải mui bạt bửng nâng. Số người cho phép chở kể cả lái 03 người.</th></tr></thead><tbody><tr><td>Bửng có sửng nâng 600 kg. Dung tích xi lanh 2.999 cc.</td></tr></tbody></table>

<table><thead><tr><th>QCVN 09:2015/BGTVT. Khối lượng toàn bộ đến 24 tấn, xi téc chứa nước đến</th></tr></thead><tbody><tr><td>12.000 lít, bồn chứa foam đến 1.000 lít (không gồm xe chữa cháy loại nhỏ xi</td></tr><tr><td>téc ≤ 2.000 lít, bồn chứa bọt ≤ 200 lít, tính năng chuyên dùng quốc phòng, an</td></tr><tr><td>ninh vượt trội so với xe chữa cháy thông thường).</td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>60</td><td></td><td></td><td>Xe ô tô chuyên dùng
trong lĩnh vực y tế</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>50</td><td></td><td></td><td>Bao gồm: Xe chụp x-quang lưu động, Xe khám chữa mắt lưu động, Xe xét
nghiệm lưu động, Xe phẫu thuật lưu động, Xe lấy máu, Xe vận chuyển vắc
xin, sinh phẩm, Xe phục vụ tiêm chủng lưu động, Xe ô tô y tế lưu động (trang
bị máy siêu âm, x-quang và các thiết bị y tế khác).</td><td></td><td></td></tr><tr><td>61</td><td></td><td></td><td></td><td>Ô tô điều chế vật liệu nổ</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>60</td><td></td><td></td><td>Khối lượng bản thân xe 17.920 kg, tải trọng 17.970 kg.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>công nghiệp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>62</td><td></td><td></td><td>Xe chở nhiên liệu</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Tổng trọng tải đến 15,1 tấn. QCVN 09:2015/BGTVT.</td><td></td></tr><tr><td></td><td>63</td><td></td><td></td><td>Ô tô kéo xe</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Khối lượng hàng chở đến 5,15 tấn.</td><td></td></tr><tr><td>64</td><td></td><td></td><td></td><td>Ô tô tải nâng người làm</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Tổng tải trọng 7,5 tấn. Chiều cao nâng tối đa 28 m. Bán kính làm việc 16,0 m.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>việc trên cao</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>65</td><td></td><td></td><td></td><td>Xe phun nước phòng</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Cải tạo trên xe cơ sở ô tô sát xi tải 6×4, dung tích đến xitec loại 5.000 lít đến
12.000 lít nước, gồm cả xe có hàng rào chắn thép thủy lực.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>chống bạo loạn (xe giải</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tán đám đông)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>66</td><td></td><td></td><td>Xe cứu hộ cứu nạn</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Tổng trọng tải đến 18 tấn, cần cẩu thủy lực 3 tấn và thiết bị đi kèm.</td><td></td></tr><tr><td>67</td><td></td><td></td><td>Xe rải dây thép gai</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Tổng trọng tải đến 24 tấn. Thời gian rải dây tối đa 4 phút, thời gian thu dây tối
đa 25 phút. Chiều dài tối đa của hàng rào khi rải lên tới 250 m. Có hoặc không
có cần cẩu gập thủy lực sức nâng lớn nhất 6.000 kg/m.</td><td></td><td></td></tr><tr><td>68</td><td></td><td></td><td></td><td>Xe thang cứu hộ, cứu</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Độ cao đến 23 m.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nạn phá dỡ tường</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>69</td><td></td><td></td><td>Xe hút khói và thổi ống
khói cứu hộ cứu nạn
chữa cháy</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Bao gồm Xe rô bốt hút khói chuyên dùng cứu hộ cứu nạn chữa cháy lưu
lượng khí danh định đến 200.000 m3/h, lưu lượng khí tối đa 1.000.000 m3/h.</td><td></td><td></td></tr><tr><td></td><td>70</td><td></td><td></td><td>Xe chở xe và cứu hộ</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng trọng tải đến 11,2 tấn.</td><td></td></tr><tr><td>71</td><td></td><td></td><td>Xe sân khấu lưu động</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>QCVN 09:2015/BGTVT. Diện tích sàn từ 45 m2 đến 82,5 m2. Tổng trọng tải từ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8,85 tấn đến 15,1 tấn.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Bao gồm: Xe chụp x-quang lưu động, Xe khám chữa mắt lưu động, Xe xét</th></tr></thead><tbody><tr><td>nghiệm lưu động, Xe phẫu thuật lưu động, Xe lấy máu, Xe vận chuyển vắc</td></tr><tr><td>xin, sinh phẩm, Xe phục vụ tiêm chủng lưu động, Xe ô tô y tế lưu động (trang</td></tr><tr><td>bị máy siêu âm, x-quang và các thiết bị y tế khác).</td></tr></tbody></table>

<table><thead><tr><th>Xe ô tô chuyên dùng</th></tr></thead><tbody><tr><td>trong lĩnh vực y tế</td></tr></tbody></table>

<table><thead><tr><th>Cải tạo trên xe cơ sở ô tô sát xi tải 6×4, dung tích đến xitec loại 5.000 lít đến</th></tr></thead><tbody><tr><td>12.000 lít nước, gồm cả xe có hàng rào chắn thép thủy lực.</td></tr></tbody></table>

<table><thead><tr><th>Tổng trọng tải đến 24 tấn. Thời gian rải dây tối đa 4 phút, thời gian thu dây tối</th></tr></thead><tbody><tr><td>đa 25 phút. Chiều dài tối đa của hàng rào khi rải lên tới 250 m. Có hoặc không</td></tr><tr><td>có cần cẩu gập thủy lực sức nâng lớn nhất 6.000 kg/m.</td></tr></tbody></table>

<table><thead><tr><th>Xe hút khói và thổi ống</th></tr></thead><tbody><tr><td>khói cứu hộ cứu nạn</td></tr><tr><td>chữa cháy</td></tr></tbody></table>

<table><thead><tr><th>Bao gồm Xe rô bốt hút khói chuyên dùng cứu hộ cứu nạn chữa cháy lưu</th></tr></thead><tbody><tr><td>lượng khí danh định đến 200.000 m3/h, lưu lượng khí tối đa 1.000.000 m3/h.</td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>72</td><td>Xe hút bùn thông cống</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td>50</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng tải trọng đến 24 tấn. Thể tích bồn chứa bùn đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>11m3.</td><td></td></tr><tr><td>73</td><td>Xe hút chất thải</td><td></td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td>50</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng tải trọng đến 15,1 tấn. Thể tích thùng chứa bùn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đến 8 m3.</td><td></td></tr><tr><td>74</td><td></td><td>Xe tưới cây và rửa</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td>50</td><td></td><td></td><td>QCVN 09:2015/BGTVT. Tổng tải trọng đến 24 tấn. Thể tích bồn chứa bùn đến</td><td></td></tr><tr><td></td><td></td><td>đường</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>14 m3.</td><td></td></tr><tr><td>75</td><td></td><td>Xe nấu ăn di động dã</td><td></td><td>8705</td><td></td><td></td><td>90</td><td></td><td>90</td><td></td><td>Tổng trọng tải của xe đến 24 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td>chiến</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>76</td><td>Xe gắn máy</td><td></td><td></td><td>8711</td><td></td><td></td><td>10</td><td></td><td>19</td><td></td><td>QCVN 41:2016/BGTVT. Động cơ dung tích đến 50 cm3, tốc độ tối đa 50 km/h.</td><td></td><td></td></tr><tr><td>77</td><td>Xe mô tô</td><td></td><td></td><td>8711</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td>QCVN 41:2016/BGTVT. Động cơ có dung tích xi lanh từ 50 đến 250 cm3.</td><td></td><td></td></tr><tr><td>78</td><td>Xe đạp điện</td><td></td><td></td><td>8711</td><td></td><td></td><td>60</td><td></td><td>94</td><td></td><td>QCVN 68:2013/BGTVT. Động cơ điện, công suất lớn nhất 250 W, vận tốc lớn
nhất 25 km/h và khối lượng bản thân (cả ắc quy) tối đa 40 kg.</td><td></td><td></td></tr><tr><td>79</td><td>Dolly (10ft và 20ft)</td><td></td><td></td><td>8716</td><td></td><td></td><td>39</td><td></td><td>99</td><td></td><td></td><td>TCCS 18:2015/CHK. Phương tiện không tự hành, chuyên dùng vận chuyển</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ULD (Unit Load Devices – Phương tiện chở hàng đường không), hàng hóa,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hành lý, bưu kiện tại sân bay.</td><td></td></tr><tr><td>80</td><td>Moóc chứa hàng hóa rời</td><td></td><td></td><td>8716</td><td></td><td></td><td>39</td><td></td><td>99</td><td></td><td></td><td>TCCS 18:2015/CHK. Phương tiện không tự hành, chuyên dùng vận chuyển</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hàng hóa rời, hành lý, bưu kiện tại sân bay.</td><td></td></tr><tr><td>81</td><td>Sơ mi rơ moóc</td><td></td><td></td><td>8716</td><td></td><td></td><td>39</td><td></td><td>99</td><td></td><td>QCVN 11:2015/BGTVT. Khối lượng toàn bộ đến 48 tấn, phanh khí nén 2
dòng. Gồm loại chở hàng, ô tô, xe công trình, máy chuyên dụng, container;
chở ô tô du lịch (tối đa chở được 08 ô tô), chở nhiên liệu, chở xi măng rời,
chở LPG, chở gia súc; loại có mui, tự đổ, đông lạnh.</td><td></td><td></td></tr><tr><td>82</td><td>Rơ moóc</td><td></td><td></td><td>8716</td><td></td><td></td><td>39</td><td></td><td>91
99</td><td></td><td></td><td>QCVN 11:2015/BGTVT. Chở máy phát điện, thiết bị phát sóng di động, hàng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>siêu trường, siêu trọng, xe và máy chuyên dùng, phục vụ tập lái. Khối lượng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>toàn bộ đến 57.340 kg.</td><td></td></tr></tbody></table>

<table><thead><tr><th>QCVN 68:2013/BGTVT. Động cơ điện, công suất lớn nhất 250 W, vận tốc lớn</th></tr></thead><tbody><tr><td>nhất 25 km/h và khối lượng bản thân (cả ắc quy) tối đa 40 kg.</td></tr></tbody></table>

<table><thead><tr><th>QCVN 11:2015/BGTVT. Khối lượng toàn bộ đến 48 tấn, phanh khí nén 2</th></tr></thead><tbody><tr><td>dòng. Gồm loại chở hàng, ô tô, xe công trình, máy chuyên dụng, container;</td></tr><tr><td>chở ô tô du lịch (tối đa chở được 08 ô tô), chở nhiên liệu, chở xi măng rời,</td></tr><tr><td>chở LPG, chở gia súc; loại có mui, tự đổ, đông lạnh.</td></tr></tbody></table>

<table><thead><tr><th>91</th></tr></thead><tbody><tr><td>99</td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>83</td><td></td><td></td><td>Xe băng chuyền</td><td></td><td></td><td>8716</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>TCCS 18:2015/CHK. Phương tiện không tự hành, vận chuyển hàng hóa từ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dưới đất lên máy bay.</td><td></td></tr><tr><td>84</td><td></td><td></td><td>Thang kéo đẩy tay</td><td></td><td></td><td>8716</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td>TCCS 18:2015/CHK. Vận chuyển hàng hóa từ dưới đất lên máy bay.</td><td></td><td></td></tr><tr><td>85</td><td></td><td></td><td>Xe gom rác đẩy tay</td><td></td><td></td><td>8716</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td>Khung xe được làm từ ống tuýp Ø34 sơn chống gỉ chịu cường lực. 02 bánh
xe chịu tải Ф550mm, 01 bánh xe dẫn hướng Ф250 mm. Dung tích 400 lít.</td><td></td><td></td></tr><tr><td>86</td><td></td><td></td><td></td><td>Tàu khách đường thủy</td><td></td><td>8901</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Sức chở đến 500 khách.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nội địa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>87</td><td></td><td></td><td></td><td>Tàu khách đường biển</td><td></td><td>8901</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Sức chở đến 500 khách. Tàu cao tốc vỏ nhôm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>(tàu hàng hải)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>88</td><td></td><td></td><td>Tàu chở xi măng rời</td><td></td><td></td><td>8901</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải 14.600 DWT</td><td></td></tr><tr><td></td><td>89</td><td></td><td></td><td>Tàu chở công nhân</td><td></td><td></td><td>8901</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Sức chở đến 100 người.</td><td></td></tr><tr><td>90</td><td></td><td></td><td>Phà</td><td></td><td></td><td>8901</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phà vận tải biển chở khách/các xe trọng tải đến 255 tấn. Phà vận tải thủy nội</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>địa trọng tải đến 268 tấn.</td><td></td></tr><tr><td></td><td>91</td><td></td><td></td><td>Xà lan</td><td></td><td></td><td>8901</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td>Trọng tải đến 18.000 tấn.</td><td></td></tr><tr><td>92</td><td></td><td></td><td></td><td>Tàu chở khí hóa lỏng</td><td></td><td>8901</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải đến 5.000 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>(LPG)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>93</td><td></td><td></td><td>Tàu chở hóa chất</td><td></td><td></td><td>8901</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải đến 6.500 tấn.</td><td></td></tr><tr><td>94</td><td></td><td></td><td></td><td>Tàu chở hóa chất nguy</td><td></td><td>8901</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Trọng tải đến 2.580 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hiểm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>95</td><td></td><td></td><td>Tàu chở dầu/hóa chất</td><td></td><td></td><td>8901</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải đến 50.000 tấn.</td><td></td></tr><tr><td>96</td><td></td><td></td><td>Tàu chở dầu</td><td></td><td></td><td>8901</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tàu hàng hải trọng tải đến 105.000 DWT, tốc độ khai thác 15 hải lý/h. Tàu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đường thủy nội địa trọng tải đến 4.880 tấn</td><td></td></tr><tr><td>97</td><td></td><td></td><td></td><td>Tàu chở khí hóa lỏng</td><td></td><td>8901</td><td></td><td></td><td>20</td><td></td><td></td><td>50</td><td></td><td></td><td>Khả năng chuyên chở 4.500 m3</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Ethylene</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>98</td><td></td><td></td><td></td><td>Tàu tự hành pha sông</td><td></td><td>8901</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải đến 100 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>biển</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>99</td><td></td><td></td><td>Xà lan nhà ở</td><td></td><td></td><td>8901</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải 9.500 tấn, sức chở 150 người.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Khung xe được làm từ ống tuýp Ø34 sơn chống gỉ chịu cường lực. 02 bánh</th></tr></thead><tbody><tr><td>xe chịu tải Ф550mm, 01 bánh xe dẫn hướng Ф250 mm. Dung tích 400 lít.</td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>100</td><td></td><td></td><td></td><td>Xà lan chuyên dùng lắp</td><td></td><td>8901</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Sức nâng đến 4.200 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>101</td><td></td><td></td><td>Tàu cần cẩu</td><td></td><td></td><td>8901</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Sức nâng đến 240 tấn.</td><td></td></tr><tr><td>102</td><td></td><td></td><td>Tàu chở hàng</td><td></td><td></td><td>8901</td><td></td><td></td><td>10, 90</td><td></td><td></td><td>36,
37</td><td></td><td></td><td>Trọng tải đến 56.000 tấn, bao gồm cả loại tàu chở ô tô, chở container (sức
chứa đến 2.410 TEU), tàu chở hàng rời đến 54.000 DWT. Đối với tàu chở
hàng đa năng (trọng tải đến 17.500 tấn) và tàu chở hàng khô tổng hợp trọng
tải đến 25000T. Pha sông biển/ Quốc tế.</td><td></td><td></td></tr><tr><td>103</td><td></td><td></td><td>Xà lan tự nâng 90M phục
vụ công trình điện gió
ngoài khơi</td><td></td><td></td><td>8901</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Chiều dài lớn nhất 95,63 m, chiều rộng 40 m, chiều cao mạn 6,8 m, mớn
nước thiết kế 2,9 m. Trọng tải toàn phần 1400 tấn. Cẩu chính có chiều dài 120
m, khai thác ở tầm với xa nhất 10 m với sức nâng không quá 98 tấn, khai thác
ở tầm với nhỏ nhất 15 m với sức nâng không quá 419 tấn.</td><td></td><td></td></tr><tr><td>104</td><td></td><td></td><td>Tàu đánh bắt hải sản</td><td></td><td></td><td>8902</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chiều dài lớn nhất 31,8 m, chiều rộng tàu 7 m, chiều cao mạn 5 m. Công suất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>máy chính 749 Kw, 1350 v/ph.</td><td></td></tr><tr><td>105</td><td></td><td></td><td></td><td>Tàu đánh bắt cua biển</td><td></td><td>8902</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chiều dài lớn nhất 19 m, chiều rộng tàu 7 m, chiều cao mạn 3,4 m. Công suất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>chuyên dụng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>máy chính 360 Kw, 1840 v/ph.</td><td></td></tr><tr><td></td><td>106</td><td></td><td></td><td>Tàu cá</td><td></td><td></td><td>8902</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Loại tàu cá vỏ gỗ, thép, composite.</td><td></td></tr><tr><td></td><td>107</td><td></td><td></td><td>Cano</td><td></td><td></td><td>8903</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Công suất đến 200 HP, sức chở 6 người.</td><td></td></tr><tr><td>108</td><td></td><td></td><td>Cano nhôm</td><td></td><td></td><td>8903</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tốc độ lớn nhất khi đủ tải đến 51 km/h, sức chứa 12 người cả lái, công suất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>máy chính đến 150 HP (lắp máy đồng bộ).</td><td></td></tr><tr><td></td><td>109</td><td></td><td></td><td>Tàu kéo biển</td><td></td><td></td><td>8904</td><td></td><td></td><td>0</td><td></td><td></td><td>39</td><td></td><td></td><td>Công suất 6.500 HP, sức kéo 85 tấn, tốc độ đến 14,5 hải lý/giờ.</td><td></td></tr><tr><td></td><td>110</td><td></td><td></td><td>Tàu kéo</td><td></td><td></td><td>8904</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Công suất máy chính đến 5.810 HP.</td><td></td></tr><tr><td></td><td>111</td><td></td><td></td><td>Tàu đẩy</td><td></td><td></td><td>8904</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Công suất máy chính đến 7.200 HP.</td><td></td></tr><tr><td></td><td>112</td><td></td><td></td><td>Tàu kéo đẩy</td><td></td><td></td><td>8904</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Công suất máy chính đến 3.040 HP.</td><td></td></tr><tr><td></td><td>113</td><td></td><td></td><td>Tàu kéo – đẩy biển</td><td></td><td></td><td>8904</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td></td><td>Công suất đến 7.000 HP.</td><td></td></tr><tr><td>114</td><td></td><td></td><td>Tàu lai dắt</td><td></td><td></td><td>8904</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chiều dài 25.76 m, rộng 10.80 m, chiều cao mạn 4.60 m, công suất 2 x 1902</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>KW, tấn đăng ký 299 GT.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Trọng tải đến 56.000 tấn, bao gồm cả loại tàu chở ô tô, chở container (sức</th></tr></thead><tbody><tr><td>chứa đến 2.410 TEU), tàu chở hàng rời đến 54.000 DWT. Đối với tàu chở</td></tr><tr><td>hàng đa năng (trọng tải đến 17.500 tấn) và tàu chở hàng khô tổng hợp trọng</td></tr><tr><td>tải đến 25000T. Pha sông biển/ Quốc tế.</td></tr></tbody></table>

<table><thead><tr><th>36,</th></tr></thead><tbody><tr><td>37</td></tr></tbody></table>

<table><thead><tr><th>Chiều dài lớn nhất 95,63 m, chiều rộng 40 m, chiều cao mạn 6,8 m, mớn</th></tr></thead><tbody><tr><td>nước thiết kế 2,9 m. Trọng tải toàn phần 1400 tấn. Cẩu chính có chiều dài 120</td></tr><tr><td>m, khai thác ở tầm với xa nhất 10 m với sức nâng không quá 98 tấn, khai thác</td></tr><tr><td>ở tầm với nhỏ nhất 15 m với sức nâng không quá 419 tấn.</td></tr></tbody></table>

<table><thead><tr><th>Xà lan tự nâng 90M phục</th></tr></thead><tbody><tr><td>vụ công trình điện gió</td></tr><tr><td>ngoài khơi</td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>115</td><td></td><td></td><td>Tàu hút</td><td></td><td></td><td>8905</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Phương tiện thủy nội địa. Công suất hút đến 20.000 m3/h.</td><td></td></tr><tr><td></td><td>116</td><td></td><td></td><td>Tàu cuốc</td><td></td><td></td><td>8905</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Phương tiện thủy nội địa. Công suất cuốc đến 300 m3/h.</td><td></td></tr><tr><td>117</td><td></td><td></td><td>Tàu cuốc sông và biển</td><td></td><td></td><td>8905</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Phương tiện hàng hải. Chiều sâu cuốc đến 20m. Công suất đến 3.000 HP.</td><td></td><td></td></tr><tr><td></td><td>118</td><td></td><td></td><td>Tàu hút bùn</td><td></td><td></td><td>8905</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Công suất động cơ đến 4.170 HP (5.000 m3/h).</td><td></td></tr><tr><td></td><td>119</td><td></td><td></td><td>Tàu thủy văn</td><td></td><td></td><td>8906</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Trọng tải đến 287 tấn.</td><td></td></tr><tr><td></td><td>120</td><td></td><td></td><td>Tàu cứu hộ</td><td></td><td></td><td>8906</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Trọng tải đến 114 tấn.</td><td></td></tr><tr><td></td><td>121</td><td></td><td></td><td>Tàu huấn luyện</td><td></td><td></td><td>8906</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phương tiện thủy nội địa. Sức chở đến 20 người.</td><td></td></tr><tr><td></td><td>122</td><td></td><td></td><td>Tàu kiểm ngư</td><td></td><td></td><td>8906</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Công suất đến 600 CV.</td><td></td></tr><tr><td></td><td>123</td><td></td><td></td><td>Tàu thả phao</td><td></td><td></td><td>8906</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Công suất đến 3.000 HP.</td><td></td></tr><tr><td></td><td>124</td><td></td><td></td><td>Ụ nổi</td><td></td><td></td><td>8905</td><td></td><td></td><td>90</td><td></td><td></td><td>10</td><td></td><td></td><td>Sức nâng đến 20.000 tấn.</td><td></td></tr><tr><td>125</td><td></td><td></td><td></td><td>Tàu tìm kiếm, cứu hộ –</td><td></td><td>8906</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Công suất đến 6.300 HP.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cứu nạn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>126</td><td></td><td></td><td>Xuồng cứu sinh mạn kín</td><td></td><td></td><td>8906</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Công suất đến 29 HP, sức chở 28 người.</td><td></td></tr><tr><td></td><td>127</td><td></td><td></td><td>Pontoon Công trình</td><td></td><td></td><td>8907</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải đến 840 DWT</td><td></td></tr><tr><td></td><td>128</td><td></td><td></td><td>Bến nổi</td><td></td><td></td><td>8907</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Phương tiện thủy nội địa. Sức chở đến 500 khách.</td><td></td></tr><tr><td>DANH MỤC VẬT TƯ XÂY DỰNG TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td></td><td></td><td>Cát, cát nghiền</td><td></td><td></td><td>2505</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN16: 2019,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 16:2019/BXD. Cát hạt mịn và hạt thô làm cốt liệu nhỏ cho bê tông và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>vữa.</td><td></td></tr><tr><td>2</td><td></td><td></td><td>Cao lanh</td><td></td><td></td><td>2507</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Al O từ 30% đến 52%, Fe O &lt; 1%. Chịu lửa 1.750oC. Độ ẩm từ 32% đến
2 3 2 3</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>35%.</td><td></td></tr><tr><td>3</td><td></td><td></td><td>Đá xây dựng</td><td></td><td></td><td>2517</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 7572-2006, QCVN 16:2022. Đá hộc, đá dăm làm cốt liệu lớn cho bê
tông và vữa. Diện tích chịu lực 1.600 mm2, tải trọng phá hoại 190 kN, cường
độ chịu nén 119,96 N/mm2.</td><td></td><td></td></tr><tr><td></td><td>4</td><td></td><td></td><td>Đôlômít</td><td></td><td></td><td>2518</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dùng để luyện kim, hàm lượng MgO ≥ 28%.</td><td></td></tr></tbody></table>

<table><thead><tr><th>TCVN 7572-2006, QCVN 16:2022. Đá hộc, đá dăm làm cốt liệu lớn cho bê</th></tr></thead><tbody><tr><td>tông và vữa. Diện tích chịu lực 1.600 mm2, tải trọng phá hoại 190 kN, cường</td></tr><tr><td>độ chịu nén 119,96 N/mm2.</td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td></td><td></td><td>Tấm tường, tấm trần
thạch cao</td><td></td><td></td><td>2520</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 16:2019/BXD. Trọng lượng 18 ± 0,5 kg. Cường độ chịu uốn: theo</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phương ngang ≥ 322N, theo phương dọc ≥ 109N. Độ biến dạng ẩm ≤ 48mm.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Độ ẩm ≤ 0,9%. Độ hút nước ≤ 5%.</td><td></td></tr><tr><td></td><td>6</td><td></td><td></td><td>Clinker xi măng</td><td></td><td></td><td>2523</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>TCVN 7024:2013.</td><td></td></tr><tr><td>7</td><td></td><td></td><td></td><td>Xi măng portland, xi</td><td></td><td>2523</td><td></td><td></td><td>29</td><td></td><td></td><td>90</td><td></td><td></td><td>QCVN 16:2019/BXD, TCVN 6017:2015 , TCVN 6016:2011, TCVN 141:2008 .</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>măng portland hỗn hợp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td></td><td></td><td></td><td>Xỉ hạt (xỉ cát) từ công</td><td></td><td>2618</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td></td><td>TCVN 4315:2017, TCVN 11586:2016 .</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nghiệp luyện sắt hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td></td><td></td><td>Xỉ, xỉ luyện kim, vụn xỉ</td><td></td><td></td><td>2619</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 4315:2017, TCVN 11586:2016 . Xỉ, xỉ luyện kim (trừ xỉ hạt), vụn xỉ và các phế thải</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khác từ công nghiệp luyện sắt hoặc thép.</td><td></td></tr><tr><td></td><td>10</td><td></td><td></td><td>Tro xỉ nhiệt điện</td><td></td><td></td><td>2621</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>TCVN 12249:2018, TCVN 10302:2014 , TCVN 12660:2019.</td><td></td></tr><tr><td></td><td>11</td><td></td><td></td><td>Sơn bảo vệ kết cấu thép</td><td></td><td></td><td>3209</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 8789 : 2011.</td><td></td></tr><tr><td>12</td><td></td><td></td><td></td><td>Sơn tường dạng nhũ</td><td></td><td>3209</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 8652:2012.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tương</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td></td><td></td><td>Hỗn hợp chịu lửa đầm lò</td><td></td><td></td><td>3816</td><td></td><td></td><td>0</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>MgO ≤ 90%, Al O ≤ 95%,
2 3</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>SiC ≤ 85%, C ≤ 30%.</td><td></td></tr><tr><td></td><td>14</td><td></td><td></td><td>Hỗn hợp chịu lửa dẻo</td><td></td><td></td><td>3816</td><td></td><td></td><td>0</td><td></td><td></td><td>90</td><td></td><td></td><td>Al O ≤ 90%, Al O ≤ 90%.
2 3 2 3</td><td></td></tr><tr><td></td><td>15</td><td></td><td></td><td>Bùn bịt lô gang lò cao</td><td></td><td></td><td>3816</td><td></td><td></td><td>0</td><td></td><td></td><td>90</td><td></td><td></td><td>Al O ≤ 50%, SiC ≤ 30%, C ≤ 30%.
2 3</td><td></td></tr><tr><td>16</td><td></td><td></td><td></td><td>Hỗn hợp chịu lửa để</td><td></td><td>3816</td><td></td><td></td><td>0</td><td></td><td></td><td>90</td><td></td><td></td><td>Al O ≤ 95%, Ca ≤ 30%.
2 3</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>phun</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>17</td><td></td><td></td><td>Vữa chịu nhiệt</td><td></td><td></td><td>3816</td><td></td><td></td><td>0</td><td></td><td></td><td>90</td><td></td><td></td><td>Al O ≤ 20%, SiO ≤ 70%, CaO ≤ 40%. Độ chịu nhiệt 1450oC.
2 3 2</td><td></td></tr><tr><td>18</td><td></td><td></td><td>Bê tông chịu nhiệt</td><td></td><td></td><td>3816</td><td></td><td></td><td>0</td><td></td><td></td><td>90</td><td></td><td></td><td>Đầm trong các lò công nghiệp chịu được môi trường kiềm và môi trường axit.
Hàm lượng Al O ≥ 45%, Fe O ≤ 2,5%. Độ chịu nhiệt 1.700oC.
2 3 2 3</td><td></td><td></td></tr><tr><td>19</td><td></td><td></td><td></td><td>Phụ gia đã điều chế</td><td></td><td>3824</td><td></td><td></td><td>40</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 8826:2011.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dùng cho xi măng, vữa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>và bê tông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Tấm tường, tấm trần</th></tr></thead><tbody><tr><td>thạch cao</td></tr></tbody></table>

<table><thead><tr><th>Đầm trong các lò công nghiệp chịu được môi trường kiềm và môi trường axit.</th></tr></thead><tbody><tr><td>Hàm lượng Al O ≥ 45%, Fe O ≤ 2,5%. Độ chịu nhiệt 1.700oC.
2 3 2 3</td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>20</td><td></td><td></td><td></td><td>Vữa xi măng khô trộn</td><td></td><td>3824</td><td></td><td></td><td>50</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 9204:2012.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>sẵn không co</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>21</td><td></td><td></td><td>Vữa tăng cứng sàn trộn
sẵn</td><td></td><td></td><td>3824</td><td></td><td></td><td>50</td><td></td><td></td><td>0</td><td></td><td></td><td>Chế biến từ xi măng, cốt liệu chọn lọc, phụ gia. Dùng để tăng khả năng chịu
mài mòn của mặt sàn nhà công nghiệp, sàn tầng hầm đỗ xe, bãi đỗ xe.</td><td></td><td></td></tr><tr><td>22</td><td></td><td></td><td></td><td>Ống nhựa xoắn HDPE</td><td></td><td>3917</td><td></td><td></td><td>21</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Đường kính ngoài: 32 ± 2 ÷ 320 ± 5 mm. Độ dày thành ống: 1,5 ± 0,3 ÷ 4,5 ±</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>loại cứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1,5 mm. Bước ren: 8 ± 0,5 ÷ 70 ± 1,0.</td><td></td></tr><tr><td>23</td><td></td><td></td><td>Sàn composite</td><td></td><td></td><td>3918</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 11352: 2016, ISO 9001-2015. Vật liệu SPC (Stone plastic composite)</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>với chất nền là bột nhựa nguyên sinh PVC kết hợp bột đá canxi carbonate và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>các phụ gia chống giãn nở.</td><td></td></tr><tr><td></td><td>24</td><td></td><td></td><td>Bộ thông gió cho cửa sổ</td><td></td><td></td><td>3926</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chất liệu nhựa.</td><td></td></tr><tr><td></td><td>25</td><td></td><td></td><td>Đá granite ốp lát tự nhiên</td><td></td><td></td><td>6801</td><td></td><td></td><td>0</td><td></td><td></td><td>0</td><td></td><td></td><td>Trừ đá phiến.</td><td></td></tr><tr><td></td><td>26</td><td></td><td></td><td>Tấm thạch cao</td><td></td><td></td><td>6809</td><td></td><td></td><td>11</td><td></td><td></td><td>0</td><td></td><td></td><td>ASTM C 473-17(d), ASTM C471M-16a.</td><td></td></tr><tr><td>27</td><td></td><td></td><td>Đá ốp lát nhân tạo</td><td></td><td></td><td>6810</td><td></td><td></td><td>19</td><td></td><td></td><td>10</td><td></td><td></td><td>TCVN 8057:2009. Thành phần chính là thạch anh (silica, quartz, granite).</td><td></td><td></td></tr><tr><td>28</td><td></td><td></td><td></td><td>Ống cống bê tông cốt</td><td></td><td>6810</td><td></td><td></td><td>91</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 9113:2012. Đường kính đến 1.500 mm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thép ly tâm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>29</td><td></td><td></td><td></td><td>Gạch bê tông (xi măng</td><td></td><td>6810</td><td></td><td></td><td>11</td><td></td><td></td><td>0</td><td></td><td></td><td>QCVN 16:2019/BXD, TCVN 6477:2016 , TCVN 6355:2009.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cốt liệu), gạch xi măng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>30</td><td></td><td></td><td>Cột điện bê tông ly tâm</td><td></td><td></td><td>6810</td><td></td><td></td><td>91</td><td></td><td></td><td>0</td><td></td><td></td><td>Cho đường dây truyền tải có điện áp đến 35kV.</td><td></td></tr><tr><td></td><td>31</td><td></td><td></td><td>Gạch AAC bê tông khí</td><td></td><td></td><td>6810</td><td></td><td></td><td>10</td><td></td><td></td><td>11</td><td></td><td></td><td>TCVN 7959:2017</td><td></td></tr><tr><td>32</td><td></td><td></td><td>Panel bê tông khí</td><td></td><td></td><td>6810</td><td></td><td></td><td>10</td><td></td><td></td><td>11</td><td></td><td></td><td>TCVN 12867:2020, 12868:2020, 12869:2020. Panel khí chưng áp, cấu trúc có
nhiều lỗ khí, bên trong có lõi thép gia công tăng khả năng chịu lực.</td><td></td><td></td></tr><tr><td>33</td><td></td><td></td><td></td><td>Tấm tường nhẹ 3 lớp</td><td></td><td>6810</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 12302:2018.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>xen kẹp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>34</td><td></td><td></td><td></td><td>Tấm tường rỗng bê tông</td><td></td><td>6810</td><td></td><td></td><td>91</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 11524:2016.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>đúc sẵn theo công nghệ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>đùn ép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Vữa tăng cứng sàn trộn</th></tr></thead><tbody><tr><td>sẵn</td></tr></tbody></table>

<table><thead><tr><th>Chế biến từ xi măng, cốt liệu chọn lọc, phụ gia. Dùng để tăng khả năng chịu</th></tr></thead><tbody><tr><td>mài mòn của mặt sàn nhà công nghiệp, sàn tầng hầm đỗ xe, bãi đỗ xe.</td></tr></tbody></table>

<table><thead><tr><th>TCVN 12867:2020, 12868:2020, 12869:2020. Panel khí chưng áp, cấu trúc có</th></tr></thead><tbody><tr><td>nhiều lỗ khí, bên trong có lõi thép gia công tăng khả năng chịu lực.</td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td></tr><tr><td>35</td><td>Gạch chịu lửa ma nhê
(MgO)</td><td>6902</td><td></td><td></td><td>10</td><td></td><td>0</td><td></td><td>Sử dụng xây lót lò công nghiệp chịu được môi trường kiềm như lò luyện thép,
luyện kẽm. Có hàm lượng MgO ≥ 87%, CaO ≤ 3%, SiO ≤ 1,5%. Độ xốp ≤
2
20%. Độ chịu lửa 2.000oC.</td></tr><tr><td>36</td><td>Gạch chịu lửa ma nhê –
cácbon (MgO-C)</td><td>6902</td><td></td><td></td><td>10</td><td></td><td>0</td><td></td><td>Sử dụng xây lót trong lò luyện thép và các lò công nghiệp chịu được môi
trường kiềm. Có hàm lượng MgO ≥ 76%, C = 10 – 18%. Độ xốp ≤ 5%.</td></tr><tr><td>37</td><td>Gạch chịu lửa kiềm tính
– ma nhê crôm (MgO –
Cr O )
2 3</td><td>6902</td><td></td><td></td><td>10</td><td></td><td>0</td><td></td><td>Sử dụng xây lót trong lò công nghiệp chịu được môi trường kiềm như lò quay
xi măng, lò luyện kẽm. Có hàm lượng MgO ≥ 55%, Cr O ≤ 22%. Độ xốp ≤
2 3
18%. Độ chịu lửa 2.000oC.</td></tr><tr><td>38</td><td>Gạch chịu lửa kiềm tính
– ma nhê – spinel (MgO-
Al O )
2 3</td><td>6902</td><td></td><td></td><td>10</td><td></td><td>0</td><td></td><td>Sử dụng xây lót lò công nghiệp chịu được môi trường kiềm như lò quay xi
măng, lò luyện thép, lò luyện kẽm. Hàm lượng MgO ≥ 76%, Al O = 5 – 20%,
2 3
Fe O ≤ 0,8%, SiO ≤ 0,9%. Độ xốp ≤ 18%. Độ chịu lửa 1.790oC.
2 3 2</td></tr><tr><td>39</td><td>Gạch chịu axít</td><td>6902</td><td></td><td></td><td>20</td><td></td><td>0</td><td></td><td>Sử dụng xây lót lò công nghiệp chịu được môi trường axít. Có hàm lượng
Al O ≤ 22%, Fe O ≤ 3%, SiO ≤ 65%. Độ xốp ≤ 8%. Độ chịu axít ≥ 96%. Độ
2 3 2 3 2
chịu lửa 1.580oC.</td></tr><tr><td>40</td><td>Gạch chịu lửa nhôm –
các bon – SiC (Al O -C-
2 3
SiC)</td><td>6902</td><td></td><td></td><td>20</td><td></td><td>0</td><td></td><td>Sử dụng xây lót lò luyện gang và các lò công nghiệp chịu được môi trường
kiềm và axít. Có hàm lượng Al O ≥ 50%, C = 8 – 10%, SiC ≥ 5%. Độ xốp ≤
2 3
13%. Độ chịu lửa 1.750oC.</td></tr><tr><td>41</td><td>Gạch chịu lửa nhôm –
các bon (Al O -C)
2 3</td><td>6902</td><td></td><td></td><td>20</td><td></td><td>0</td><td></td><td>Sử dụng xây lót lò luyện gang và các lò công nghiệp chịu được môi trường
kiềm và axít. Có hàm lượng Al O ≥ 60%, C = 10 – 16%. Độ xốp ≤ 13%.
2 3</td></tr><tr><td>42</td><td>Gạch chịu lửa cao nhôm
– SiC (Al O -SiC)
2 3</td><td>6902</td><td></td><td></td><td>20</td><td></td><td>0</td><td></td><td>Sử dụng xây lót trong các lò quay sản xuất clinker xi măng và các lò công
nghiệp có môi trường trung tính. Có hàm lượng Al O ≥ 50%, Fe O ≤ 2,5%,
2 3 2 3
SiC = 5 – 18%. Độ xốp ≤ 18%. Độ chịu lửa 1.790oC.</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót lò công nghiệp chịu được môi trường kiềm như lò luyện thép,</th></tr></thead><tbody><tr><td>luyện kẽm. Có hàm lượng MgO ≥ 87%, CaO ≤ 3%, SiO ≤ 1,5%. Độ xốp ≤
2</td></tr><tr><td>20%. Độ chịu lửa 2.000oC.</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa ma nhê</th></tr></thead><tbody><tr><td>(MgO)</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa ma nhê –</th></tr></thead><tbody><tr><td>cácbon (MgO-C)</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót trong lò luyện thép và các lò công nghiệp chịu được môi</th></tr></thead><tbody><tr><td>trường kiềm. Có hàm lượng MgO ≥ 76%, C = 10 – 18%. Độ xốp ≤ 5%.</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa kiềm tính</th></tr></thead><tbody><tr><td>– ma nhê crôm (MgO –</td></tr><tr><td>Cr O )
2 3</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót trong lò công nghiệp chịu được môi trường kiềm như lò quay</th></tr></thead><tbody><tr><td>xi măng, lò luyện kẽm. Có hàm lượng MgO ≥ 55%, Cr O ≤ 22%. Độ xốp ≤
2 3</td></tr><tr><td>18%. Độ chịu lửa 2.000oC.</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa kiềm tính</th></tr></thead><tbody><tr><td>– ma nhê – spinel (MgO-</td></tr><tr><td>Al O )
2 3</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót lò công nghiệp chịu được môi trường kiềm như lò quay xi</th></tr></thead><tbody><tr><td>măng, lò luyện thép, lò luyện kẽm. Hàm lượng MgO ≥ 76%, Al O = 5 – 20%,
2 3</td></tr><tr><td>Fe O ≤ 0,8%, SiO ≤ 0,9%. Độ xốp ≤ 18%. Độ chịu lửa 1.790oC.
2 3 2</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót lò công nghiệp chịu được môi trường axít. Có hàm lượng</th></tr></thead><tbody><tr><td>Al O ≤ 22%, Fe O ≤ 3%, SiO ≤ 65%. Độ xốp ≤ 8%. Độ chịu axít ≥ 96%. Độ
2 3 2 3 2</td></tr><tr><td>chịu lửa 1.580oC.</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa nhôm –</th></tr></thead><tbody><tr><td>các bon – SiC (Al O -C-
2 3</td></tr><tr><td>SiC)</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót lò luyện gang và các lò công nghiệp chịu được môi trường</th></tr></thead><tbody><tr><td>kiềm và axít. Có hàm lượng Al O ≥ 50%, C = 8 – 10%, SiC ≥ 5%. Độ xốp ≤
2 3</td></tr><tr><td>13%. Độ chịu lửa 1.750oC.</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa nhôm –</th></tr></thead><tbody><tr><td>các bon (Al O -C)
2 3</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót lò luyện gang và các lò công nghiệp chịu được môi trường</th></tr></thead><tbody><tr><td>kiềm và axít. Có hàm lượng Al O ≥ 60%, C = 10 – 16%. Độ xốp ≤ 13%.
2 3</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót trong các lò quay sản xuất clinker xi măng và các lò công</th></tr></thead><tbody><tr><td>nghiệp có môi trường trung tính. Có hàm lượng Al O ≥ 50%, Fe O ≤ 2,5%,
2 3 2 3</td></tr><tr><td>SiC = 5 – 18%. Độ xốp ≤ 18%. Độ chịu lửa 1.790oC.</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa cao nhôm</th></tr></thead><tbody><tr><td>– SiC (Al O -SiC)
2 3</td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>43</td><td></td><td></td><td>Gạch chịu lửa cao nhôm
(Al O )
2 3</td><td></td><td></td><td>6902</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Sử dụng xây lót trong các lò quay, lò đứng sản xuất clinker xi măng, lò luyện
thép và các lò công nghiệp có môi trường trung tính. Có hàm lượng Al O =
2 3
46% – 95%, Fe O ≤ 2,5%. Độ xốp ≤ 20%. Độ chịu lửa 1.790oC.
2 3</td><td></td><td></td></tr><tr><td>44</td><td></td><td></td><td>Gạch chịu lửa Silic (Đi
nát)</td><td></td><td></td><td>6902</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Sử dụng xây lót trong các lò công nghiệp có môi trường axít như lò nấu thủy
tinh, lò luyện cốc. Hàm lượng SiO ≥ 95%, Fe O ≤ 1%. Độ xốp &lt; 24%.
2 2 3</td><td></td><td></td></tr><tr><td></td><td>45</td><td></td><td></td><td>Sericit</td><td></td><td></td><td>6902</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Hàm lượng Al O ≥ 10%.
2 3</td><td></td></tr><tr><td>46</td><td></td><td></td><td>Gạch chịu lửa Zircon
(ZrO )
2</td><td></td><td></td><td>6902</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>Làm viên dẫn dòng luyện thép. Có hàm lượng ZrO ≥ 90%, Fe O ≤ 0,8%. Độ
2 2 3
chịu lửa 2.000oC.</td><td></td><td></td></tr><tr><td>47</td><td></td><td></td><td>Gạch chịu lửa sa mốt</td><td></td><td></td><td>6902</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>Bao gồm: SMA, SMB. Xây lót trong các lò công nghiệp có môi trường trung
tính như lò nung tuynel nung gạch đỏ, lò đốt rác. Hàm lượng Al O ≥ 30%,
2 3
Fe O ≤ 3%. Độ xốp ≤ 23%. Độ chịu lửa 1.710oC.
2 3</td><td></td><td></td></tr><tr><td></td><td>48</td><td></td><td></td><td>Gạch xốp cách nhiệt</td><td></td><td></td><td>6902</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>Khối lượng thể tích đến 1,23 g/cm3. Độ chịu lửa 1.700oC.</td><td></td></tr><tr><td>49</td><td></td><td></td><td>Ống sứ chịu lửa</td><td></td><td></td><td>6903</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>Ống sứ dạng Co, dạng T, dạng thập, dạng thẳng từ Ø16 đến Ø190 mm. Độ
chịu lửa 1.750oC, Al O ≥ 37%, SiO ≤ 50%, Fe O ≤ 1,8%.
2 3 2 2 3</td><td></td><td></td></tr><tr><td>50</td><td></td><td></td><td>Ống sứ</td><td></td><td></td><td>6903</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Độ chịu lửa 1750oC, Al O ≥ 37%, SiO ≤ 50%, Fe O ≤ 1,8%. Tiết diện ≤
2 3 2 2 3
Ø190 mm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Ø190 mm.</td><td></td></tr><tr><td>51</td><td></td><td></td><td>Gạch đất sét nung</td><td></td><td></td><td>6904</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>QCVN 16:2019/BXD, TCVN 1450:2009 , TCVN 6355-2:2009, TCVN 6355-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3:2009 . Bao gồm gạch tuynel, gạch đặc.</td><td></td></tr><tr><td></td><td>52</td><td></td><td></td><td>Ngói gốm tráng men</td><td></td><td></td><td>6905</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 9133:2011.</td><td></td></tr><tr><td></td><td>53</td><td></td><td></td><td>Gạch gốm ốp lát</td><td></td><td></td><td>6907</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: ceramic, granite, cotto.</td><td></td></tr><tr><td>54</td><td></td><td></td><td>Gạch ốp, lát không nung</td><td></td><td></td><td>6908</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: Terrazo, Brestonstone, Terastone; kích thước viên đến 800mm x</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>800mm.</td><td></td></tr><tr><td></td><td>55</td><td></td><td></td><td>Kính phủ bức xạ thấp</td><td></td><td></td><td>7005</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td>TCVN 9808:2013.</td><td></td></tr><tr><td></td><td>56</td><td></td><td></td><td>Kính phủ phản quang</td><td></td><td></td><td>7005</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td>TCVN 7528:2005.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót trong các lò quay, lò đứng sản xuất clinker xi măng, lò luyện</th></tr></thead><tbody><tr><td>thép và các lò công nghiệp có môi trường trung tính. Có hàm lượng Al O =
2 3</td></tr><tr><td>46% – 95%, Fe O ≤ 2,5%. Độ xốp ≤ 20%. Độ chịu lửa 1.790oC.
2 3</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa cao nhôm</th></tr></thead><tbody><tr><td>(Al O )
2 3</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa Silic (Đi</th></tr></thead><tbody><tr><td>nát)</td></tr></tbody></table>

<table><thead><tr><th>Sử dụng xây lót trong các lò công nghiệp có môi trường axít như lò nấu thủy</th></tr></thead><tbody><tr><td>tinh, lò luyện cốc. Hàm lượng SiO ≥ 95%, Fe O ≤ 1%. Độ xốp &lt; 24%.
2 2 3</td></tr></tbody></table>

<table><thead><tr><th>Gạch chịu lửa Zircon</th></tr></thead><tbody><tr><td>(ZrO )
2</td></tr></tbody></table>

<table><thead><tr><th>Làm viên dẫn dòng luyện thép. Có hàm lượng ZrO ≥ 90%, Fe O ≤ 0,8%. Độ
2 2 3</th></tr></thead><tbody><tr><td>chịu lửa 2.000oC.</td></tr></tbody></table>

<table><thead><tr><th>Bao gồm: SMA, SMB. Xây lót trong các lò công nghiệp có môi trường trung</th></tr></thead><tbody><tr><td>tính như lò nung tuynel nung gạch đỏ, lò đốt rác. Hàm lượng Al O ≥ 30%,
2 3</td></tr><tr><td>Fe O ≤ 3%. Độ xốp ≤ 23%. Độ chịu lửa 1.710oC.
2 3</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>57</td><td></td><td></td><td>Kính màu hấp thụ nhiệt</td><td></td><td></td><td>7005</td><td></td><td></td><td>21</td><td></td><td></td><td>90</td><td></td><td></td><td>QCVN 16:2019/BXD.</td><td></td></tr><tr><td></td><td>58</td><td></td><td></td><td>Kính nổi</td><td></td><td></td><td>7005</td><td></td><td></td><td>29</td><td></td><td></td><td>90</td><td></td><td></td><td>TCVN 7219:2018, TCVN 7737:2007 .</td><td></td></tr><tr><td></td><td>59</td><td></td><td></td><td>Kính tôi nhiệt an toàn</td><td></td><td></td><td>7007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 7364-2004</td><td></td></tr><tr><td></td><td>60</td><td></td><td></td><td>Kính phẳng tôi nhiệt</td><td></td><td></td><td>7007</td><td></td><td></td><td>19</td><td></td><td></td><td>90</td><td></td><td></td><td>TCVN 7455:2013.</td><td></td></tr><tr><td>61</td><td></td><td></td><td></td><td>Kính dán an toàn nhiều</td><td></td><td>7007</td><td></td><td></td><td>29</td><td></td><td></td><td>90</td><td></td><td></td><td>TCVN 7364:2004.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lớp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>62</td><td></td><td></td><td>Kính gương tráng bạc</td><td></td><td></td><td>7009</td><td></td><td></td><td>91</td><td></td><td></td><td>0</td><td></td><td></td><td>TCVN 7219:2002.</td><td></td></tr><tr><td>63</td><td></td><td></td><td>Phôi thép dẹt (dạng
phiến)</td><td></td><td></td><td>7207</td><td></td><td></td><td>12, 20</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>– Loại có hàm lượng carbon từ 0,03% đến 0,25%.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Loại có hàm lượng carbon từ 0,25% đến 0,28%.</td><td></td></tr><tr><td>64</td><td></td><td></td><td></td><td>Thép không hợp kim,</td><td></td><td>7208</td><td></td><td></td><td>36, 38,
39</td><td></td><td></td><td>0</td><td></td><td></td><td>Chiều dày đến 12 mm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dạng cuộn, chưa được</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>gia công quá mức cán</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>65</td><td></td><td></td><td>Dây thép buộc</td><td></td><td></td><td>7217</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đường kính 1 mm.</td><td></td></tr><tr><td>66</td><td></td><td></td><td></td><td>Thép hợp kim dự ứng</td><td></td><td></td><td>7227,</td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Bằng thép Mangan – Silic, dạng cuộn, cán nóng, mặt cắt ngang tròn, đường</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lực</td><td></td><td></td><td>7229</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kính từ 7,1 mm – 12,6 mm.</td><td></td></tr><tr><td>67</td><td></td><td></td><td>Mặt bích</td><td></td><td></td><td>7307</td><td></td><td></td><td>91</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Dùng để ghép nối cọc ống bê tông bằng thép không hợp kim, vật liệu thép</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Q235.</td><td></td></tr><tr><td></td><td>68</td><td></td><td></td><td>Mặt bích bằng thép</td><td></td><td></td><td>7307</td><td></td><td></td><td>93</td><td></td><td></td><td>90</td><td></td><td></td><td>Dạng tròn đường kính từ 300 mm đến 1.000 mm.</td><td></td></tr><tr><td>69</td><td></td><td></td><td>Các cấu kiện bằng thép</td><td></td><td></td><td>7308</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Loại thông dụng và khung nhà thép, dầm cầu thép đường bộ; Khung giá đỡ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tấm pin quang điện loại cố định.</td><td></td></tr><tr><td>70</td><td></td><td></td><td>Máng cáp</td><td></td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td>60</td><td></td><td></td><td>Chất liệu bằng thép. Dùng cho cáp trung thế. Kích thước 300 x 100 mm.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>36, 38,</th></tr></thead><tbody><tr><td>39</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>71</td><td></td><td></td><td>Tấm Panel</td><td></td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td>99</td><td></td><td></td><td>Các loại Panel: Sandwich PU, sợi thủy tinh (Panel glass glasswool), cách
nhiệt (trong xây dựng).- Lớp tôn bề mặt: Tôn mạ màu hệ sơn Polyester, Tôn
mạ màu hệ sơn PVDF, tôn phủ PVC, Inox;- Lớp giữa cách nhiệt:+ Lớp PU
(POLYURETHANE) đối với tấm Panel Sandwich PU.+ Bông thủy tinh
(glasswool) đối với tấm Panel sợi thủy tinh.</td><td></td><td></td></tr><tr><td>72</td><td></td><td></td><td>Các cấu kiện nhôm định
hình</td><td></td><td></td><td>7610</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Các kết cấu bằng nhôm (trừ nhà lắp ghép thuộc nhóm 94.06) và các bộ phận
của các kết cấu bằng nhôm (ví dụ, cầu và nhịp cầu, tháp, cột lưới, mái nhà,
khung mái, cửa ra vào và cửa sổ và các loại khung cửa và ngưỡng cửa ra
vào, cửa chớp, lan can, cột trụ và các loại cột); tấm, thanh, dạng hình, ống và
các loại tương tự bằng nhôm, đã được gia công để sử dụng làm kết cấu.</td><td></td><td></td></tr><tr><td>73</td><td></td><td></td><td>Cáp thép</td><td></td><td></td><td>7312</td><td></td><td></td><td>10</td><td></td><td></td><td>91</td><td></td><td></td><td>Loại bện tao, sử dụng cho bê tông dự ứng lực, đường kính từ 9mm – 16mm</td><td></td><td></td></tr><tr><td></td><td>74</td><td></td><td></td><td>Sản phẩm sứ vệ sinh</td><td></td><td></td><td>7324</td><td></td><td></td><td>90</td><td></td><td></td><td>10</td><td></td><td></td><td>TCVN 6073:20005</td><td></td></tr><tr><td>75</td><td></td><td></td><td></td><td>Dây truyền tải điện tổn</td><td></td><td>7614</td><td></td><td></td><td>10</td><td></td><td></td><td>11</td><td></td><td></td><td></td><td>Gồm lõi thép bọc nhôm, nhiệt độ ruột dẫn lớn nhất 150oC. Giảm tổn thất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thất thấp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>truyền tải đến 25%.</td><td></td></tr><tr><td></td><td>76</td><td></td><td></td><td>Cáp điện</td><td></td><td></td><td>7614</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 04:2009/BKHCN và sửa đổi 1:2016 QCVN 04:2009/BKHCN</td><td></td></tr><tr><td>77</td><td></td><td></td><td>Khóa điện từ thông minh</td><td></td><td></td><td>8301</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Khóa điện từ có thể sử dụng 4 cơ chế mở cửa: vân tay, thẻ từ, mã số, chìa</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cơ; tay ốp khóa hợp kim kẽm hoặc inox</td><td></td></tr><tr><td></td><td>78</td><td></td><td></td><td>Tay nắm cửa</td><td></td><td></td><td>8302</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bằng kim loại, 1 bộ gồm tay nắm và phụ kiện đồng bộ.</td><td></td></tr><tr><td></td><td>79</td><td></td><td></td><td>Bản lề cửa</td><td></td><td></td><td>8302</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bằng kim loại, 1 bộ gồm bản lề và phụ kiện đồng bộ.</td><td></td></tr><tr><td>80</td><td></td><td></td><td>Thiết bị thuộc hệ thống lò
quay</td><td></td><td></td><td>8417</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: Tháp làm mát, Băng tải gầu, Cấp liệu tấm, cấp liệu tang, Van điện
nhiệt độ cao, Súng bắn khí, Van tấm điện, Xích tải, Khe nhiệt (đường kính đến
1800 mm), Lọc bụi tĩnh điện, Ống gió ba (đường kính đến 2800 mm).</td><td></td><td></td></tr><tr><td>81</td><td></td><td></td><td>Cáp điện một chiều</td><td></td><td></td><td>8544</td><td></td><td></td><td>60</td><td></td><td></td><td>11</td><td></td><td></td><td></td><td>Dây 01 lõi đồng, bọc cách điện bằng nhựa XLPO, tiết diện 4 mm2, điện áp 1,5</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kV DC.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Các loại Panel: Sandwich PU, sợi thủy tinh (Panel glass glasswool), cách</th></tr></thead><tbody><tr><td>nhiệt (trong xây dựng).- Lớp tôn bề mặt: Tôn mạ màu hệ sơn Polyester, Tôn</td></tr><tr><td>mạ màu hệ sơn PVDF, tôn phủ PVC, Inox;- Lớp giữa cách nhiệt:+ Lớp PU</td></tr><tr><td>(POLYURETHANE) đối với tấm Panel Sandwich PU.+ Bông thủy tinh</td></tr><tr><td>(glasswool) đối với tấm Panel sợi thủy tinh.</td></tr></tbody></table>

<table><thead><tr><th>Các kết cấu bằng nhôm (trừ nhà lắp ghép thuộc nhóm 94.06) và các bộ phận</th></tr></thead><tbody><tr><td>của các kết cấu bằng nhôm (ví dụ, cầu và nhịp cầu, tháp, cột lưới, mái nhà,</td></tr><tr><td>khung mái, cửa ra vào và cửa sổ và các loại khung cửa và ngưỡng cửa ra</td></tr><tr><td>vào, cửa chớp, lan can, cột trụ và các loại cột); tấm, thanh, dạng hình, ống và</td></tr><tr><td>các loại tương tự bằng nhôm, đã được gia công để sử dụng làm kết cấu.</td></tr></tbody></table>

<table><thead><tr><th>Các cấu kiện nhôm định</th></tr></thead><tbody><tr><td>hình</td></tr></tbody></table>

<table><thead><tr><th>Bao gồm: Tháp làm mát, Băng tải gầu, Cấp liệu tấm, cấp liệu tang, Van điện</th></tr></thead><tbody><tr><td>nhiệt độ cao, Súng bắn khí, Van tấm điện, Xích tải, Khe nhiệt (đường kính đến</td></tr><tr><td>1800 mm), Lọc bụi tĩnh điện, Ống gió ba (đường kính đến 2800 mm).</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị thuộc hệ thống lò</th></tr></thead><tbody><tr><td>quay</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>82</td><td></td><td></td><td></td><td>Cáp hạ thế, trung thế,</td><td></td><td>8544</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phần lõi cáp có tiết diện lớn nhất cho 1 pha đến 2.000 mm2, điện áp từ 0,6 kV
– 170 kV.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cao thế bọc cách điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>plastic và EPR</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>83</td><td></td><td></td><td>Cáp nguồn lõi đồng</td><td></td><td></td><td>8544</td><td></td><td></td><td>11</td><td></td><td></td><td>20</td><td></td><td></td><td>Dây đơn, dạng cuộn, loại 6 A/220 V, bằng đồng bọc PVC, tiết diện 1,5 mm2.</td><td></td><td></td></tr><tr><td></td><td>84</td><td></td><td></td><td>Cáp tiếp địa nguồn</td><td></td><td></td><td>8544</td><td></td><td></td><td>11</td><td></td><td></td><td>20</td><td></td><td></td><td>Chất liệu bằng đồng, bọc PVC, dây đơn dạng cuộn.</td><td></td></tr><tr><td>85</td><td></td><td></td><td>Nhà kính, nhà màng cho
sản xuất nông nghiệp</td><td></td><td></td><td>9406</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tiêu chuẩn NGMN-1994 của Hiệp hội Nhà màng Hoa Kỳ. Kết cấu khung nhà
chịu sức gió 80 km/h. Màng lợp mái chịu sức gió 70 km/h.</td><td></td><td></td></tr><tr><td>DANH MỤC MÁY MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td></td><td></td><td>Xăng E5 RON 92</td><td></td><td></td><td>2710</td><td></td><td></td><td>12</td><td></td><td></td><td>25</td><td></td><td></td><td></td><td>QCVN 1:2022/BKHCN;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 8063:2015 ;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 11:2019/BSR.</td><td></td></tr><tr><td>2</td><td></td><td></td><td>Xăng không chì RON 92</td><td></td><td></td><td>2710</td><td></td><td></td><td>12</td><td></td><td></td><td>24</td><td></td><td></td><td></td><td>QCVN 1:2022/BKHCN;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 6776:2013 ;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 01:2022/BSR.</td><td></td></tr><tr><td>3</td><td></td><td></td><td>Xăng không chì RON 95</td><td></td><td></td><td>2710</td><td></td><td></td><td>12</td><td></td><td></td><td>24</td><td></td><td></td><td></td><td>QCVN 1:2022/BKHCN;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 01:2022/BSR.</td><td></td></tr><tr><td></td><td>4</td><td></td><td></td><td>Xăng nền RON91</td><td></td><td></td><td>2710</td><td></td><td></td><td>12</td><td></td><td></td><td>12</td><td></td><td></td><td>TCVN 12883:2020.</td><td></td></tr><tr><td>5</td><td></td><td></td><td>Xăng ô tô RON83</td><td></td><td></td><td>2710</td><td></td><td></td><td>12</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td>TCVN/QS 1563:2021;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 18:2022/BSR.</td><td></td></tr><tr><td></td><td>6</td><td></td><td></td><td>Dầu bôi trơn</td><td></td><td></td><td>2710</td><td></td><td></td><td>19</td><td></td><td></td><td>46</td><td></td><td></td><td>Bao gồm: PV Modding OIL/18L và nhiều loại khác.</td><td></td></tr><tr><td>7</td><td></td><td></td><td>Dầu diesel</td><td></td><td></td><td>2710</td><td></td><td></td><td>19</td><td></td><td></td><td>71</td><td></td><td></td><td></td><td>QCVN 01:2022/BKHCN;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 5689:2013 .</td><td></td></tr><tr><td>8</td><td></td><td></td><td>Khí khô thương phẩm</td><td></td><td></td><td>2711</td><td></td><td></td><td>19</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 01:2016/PV GAS;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 08:2022/PV GAS;</td><td></td></tr></tbody></table>

<table><thead><tr><th>Phần lõi cáp có tiết diện lớn nhất cho 1 pha đến 2.000 mm2, điện áp từ 0,6 kV</th></tr></thead><tbody><tr><td>– 170 kV.</td></tr></tbody></table>

<table><thead><tr><th>Nhà kính, nhà màng cho</th></tr></thead><tbody><tr><td>sản xuất nông nghiệp</td></tr></tbody></table>

<table><thead><tr><th>Tiêu chuẩn NGMN-1994 của Hiệp hội Nhà màng Hoa Kỳ. Kết cấu khung nhà</th></tr></thead><tbody><tr><td>chịu sức gió 80 km/h. Màng lợp mái chịu sức gió 70 km/h.</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 09:2022/PV GAS.</td><td></td></tr><tr><td>9</td><td></td><td></td><td></td><td>Chân đế và khối thượng</td><td></td><td>2711</td><td></td><td></td><td>21</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cụm Dịch vụ kinh tế – Khoa học kỹ thuật, với khối lượng chân đế 750 tấn, cọc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tầng cho nhà giàn DK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>900 tấn, khối thượng tầng 700 tấn.</td><td></td></tr><tr><td>10</td><td></td><td></td><td>Hóa chất khử nhũ</td><td></td><td></td><td>3824</td><td></td><td></td><td>99</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td>– Chất lỏng màu trắng sữa; pH4-6; độ nhớt 100-300cP; nhiệt độ đông đặc &lt;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>5oC; nhiệt độ chớp cháy &gt; 150oC.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Loại Deoiler: Tỷ trọng ở 20°C:1 ÷ 1,2 g/mL, hàm lượng khuyến cáo sử dụng
2 – 10 ppm tùy thuộc vào hệ thống xử lý nước thải biển.</td><td></td><td></td></tr><tr><td></td><td>11</td><td></td><td></td><td>Giàn DK</td><td></td><td></td><td>3926</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Công trình nổi nhà ở, khối lượng 800 – 1.200 tấn.</td><td></td></tr><tr><td>12</td><td></td><td></td><td>Hệ thống đường ống
biển</td><td></td><td></td><td></td><td>7304</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Đường kính ngoài 26 inch, dài 362 km.- Gồm các loại ống, ống dẫn và thanh
hình rỗng, bằng sắt hoặc thép.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7305</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7306</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td></td><td></td><td>Ống thép bọc bê tông gia
trọng</td><td></td><td></td><td>7304</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đường kính ngoài từ: 6” (168,3 mm) – 48” (1.219,2 mm); chiều dài ống tối đa
12,7 m; độ dày lớp bọc tối thiểu 35 mm; độ dày lớp bọc tối đa 150 mm; độ bền
nén bê tông với mẫu hình trụ sau 28 ngày 30 – 40 Mpa (4.350 – 5.800 psi); độ
bền nén bê tông với mẫu hình khối sau 28 ngày 40 – 50 Mpa (5.800 – 7.250
psi), bê tông có tỷ trọng từ 2.400 kg/m3 đến 3.040 kg/m3.</td><td></td><td></td></tr><tr><td>14</td><td></td><td></td><td>LPG</td><td></td><td></td><td>7305</td><td></td><td></td><td>11</td><td></td><td></td><td>0</td><td></td><td></td><td>Thành phần chính là propan (C H ), propen (C H ) hoặc butan (C H ), buten
3 8 3 6 4 10
(C H ) hoặc hỗn hợp của các hydrocacbon này.Đáp ứng QCVN
4 8
8:2019/BKHCN; TCCS 01:2020/PV GAS; TCCS 02:2020/PV GAS.</td><td></td><td></td></tr><tr><td>15</td><td></td><td></td><td></td><td>Ống chống bằng thép</td><td></td><td>7305</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Có đầu nối đi kèm, đường kính từ 20 đến 36 inches.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hàn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>16</td><td></td><td></td><td>Ống thép hàn thẳng hồ
quang chìm</td><td></td><td></td><td>7305</td><td></td><td></td><td>31</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Sử dụng cho đường ống dẫn dầu hoặc khí: thép tấm sau khi kiểm tra đầu vào,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>được cuốn tạo hình, hàn bằng công nghệ hàn hồ quang chìm, sau đó nong để</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đạt dung sai kích thước thành phẩm. Đáp ứng tiêu chuẩn API 5L; DNV-OS-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>F101.</td><td></td></tr></tbody></table>

<table><thead><tr><th>– Loại Deoiler: Tỷ trọng ở 20°C:1 ÷ 1,2 g/mL, hàm lượng khuyến cáo sử dụng</th></tr></thead><tbody><tr><td>2 – 10 ppm tùy thuộc vào hệ thống xử lý nước thải biển.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống đường ống</th></tr></thead><tbody><tr><td>biển</td></tr></tbody></table>

<table><thead><tr><th>– Đường kính ngoài 26 inch, dài 362 km.- Gồm các loại ống, ống dẫn và thanh</th></tr></thead><tbody><tr><td>hình rỗng, bằng sắt hoặc thép.</td></tr></tbody></table>

<table><thead><tr><th>Đường kính ngoài từ: 6” (168,3 mm) – 48” (1.219,2 mm); chiều dài ống tối đa</th></tr></thead><tbody><tr><td>12,7 m; độ dày lớp bọc tối thiểu 35 mm; độ dày lớp bọc tối đa 150 mm; độ bền</td></tr><tr><td>nén bê tông với mẫu hình trụ sau 28 ngày 30 – 40 Mpa (4.350 – 5.800 psi); độ</td></tr><tr><td>bền nén bê tông với mẫu hình khối sau 28 ngày 40 – 50 Mpa (5.800 – 7.250</td></tr><tr><td>psi), bê tông có tỷ trọng từ 2.400 kg/m3 đến 3.040 kg/m3.</td></tr></tbody></table>

<table><thead><tr><th>Ống thép bọc bê tông gia</th></tr></thead><tbody><tr><td>trọng</td></tr></tbody></table>

<table><thead><tr><th>Thành phần chính là propan (C H ), propen (C H ) hoặc butan (C H ), buten
3 8 3 6 4 10</th></tr></thead><tbody><tr><td>(C H ) hoặc hỗn hợp của các hydrocacbon này.Đáp ứng QCVN
4 8</td></tr><tr><td>8:2019/BKHCN; TCCS 01:2020/PV GAS; TCCS 02:2020/PV GAS.</td></tr></tbody></table>

<table><thead><tr><th>Ống thép hàn thẳng hồ</th></tr></thead><tbody><tr><td>quang chìm</td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>17</td><td></td><td></td><td>Ống thép bọc cách nhiệt</td><td></td><td></td><td>7305</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Gồm các lớp: FBE (lớp 1); Adhesive (lớp 2); PU Foam (lớp 3); HDPE (lớp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>4);- Đường kính ngoài từ 4” (100 mm) – 24” (600 mm); chiều dài ≤ 12,7 m;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhiệt độ vận hành từ -20°C đến 140°C (-4°F đến 284°F); độ sâu nước biển ≤</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>300 m; OHTC(“U” Value) &lt; 2 W/m2.K(0,352 BTU/hr.ft2.F); K-Value từ 0-42</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>W/m.K.</td><td></td></tr><tr><td>18</td><td></td><td></td><td>Ống thép bọc chống ăn
mòn</td><td></td><td></td><td>7305</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Gồm các loại lớp bọc: 3LPE (FBE + Copolymer Adhesive +Polyethylene);
3LPP (FBE + Copolymer adhesive + Polypropylene); FBE (Funsion Bonded
Epoxy)- Đường kính ngoài từ 2” (60,3 mm) – 48” (1.219,2 mm); chiều dài ống
≤ 12,7 m; nhiệt độ vận hành ≤ 140°C (284°F).</td><td></td><td></td></tr><tr><td>19</td><td></td><td></td><td>Các loại ống thép hàn</td><td></td><td></td><td>7305</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Ống kết cấu điện gió, ống kết cấu giàn khai thác/vận hành, ống các công trình
giao thông, ống dẫn nước trong các dự án xử lý nước; Thép tấm sau khi kiểm
tra đầu vào, được cuốn tạo hình và hàn thẳng, sau đó nong để đạt dung sai
kích thước thành phẩm. Gồm loại hàn thẳng, hàn dọc và chịu áp lực cao.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đáp ứng tiêu chuẩn API 2B; ASTM (A252/A671/A672); EN 10225; EN 10219;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>AWWA C-200; JIS; ASTM; BS EN.</td><td></td></tr><tr><td>20</td><td></td><td></td><td></td><td>Khung đỡ cho bộ khuếch</td><td></td><td>7307</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Kích thước dài 2,684m rộng 6,937m cao 5,5m, vật liệu A36, theo tiêu chuẩn
ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tán khí thải, bộ phận của</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tua bin khí</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>21</td><td></td><td></td><td>Ống xả dạng đứng</td><td></td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Cao 18,6 m, đường kính 4.504 mm kết hợp bộ giảm thanh đầu vào 4.684
mm, chất liệu đạt ASTM A36 &amp; SS, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td>22</td><td></td><td></td><td>Cầu dẫn</td><td></td><td></td><td>7308</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải 1.200 – 2.000 tấn</td><td></td></tr><tr><td>23</td><td></td><td></td><td>Thân chính và phụ kiện
của hệ thống ống khói</td><td></td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Hệ thống ống xả khí đường kính ống lớn 6.900 mm – ống nhỏ 4.546 mm,
chiều cao 60m, bằng thép ASTM A36 &amp; ss, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>– Gồm các loại lớp bọc: 3LPE (FBE + Copolymer Adhesive +Polyethylene);</th></tr></thead><tbody><tr><td>3LPP (FBE + Copolymer adhesive + Polypropylene); FBE (Funsion Bonded</td></tr><tr><td>Epoxy)- Đường kính ngoài từ 2” (60,3 mm) – 48” (1.219,2 mm); chiều dài ống</td></tr><tr><td>≤ 12,7 m; nhiệt độ vận hành ≤ 140°C (284°F).</td></tr></tbody></table>

<table><thead><tr><th>Ống thép bọc chống ăn</th></tr></thead><tbody><tr><td>mòn</td></tr></tbody></table>

<table><thead><tr><th>Ống kết cấu điện gió, ống kết cấu giàn khai thác/vận hành, ống các công trình</th></tr></thead><tbody><tr><td>giao thông, ống dẫn nước trong các dự án xử lý nước; Thép tấm sau khi kiểm</td></tr><tr><td>tra đầu vào, được cuốn tạo hình và hàn thẳng, sau đó nong để đạt dung sai</td></tr><tr><td>kích thước thành phẩm. Gồm loại hàn thẳng, hàn dọc và chịu áp lực cao.</td></tr></tbody></table>

<table><thead><tr><th>Kích thước dài 2,684m rộng 6,937m cao 5,5m, vật liệu A36, theo tiêu chuẩn</th></tr></thead><tbody><tr><td>ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Cao 18,6 m, đường kính 4.504 mm kết hợp bộ giảm thanh đầu vào 4.684</th></tr></thead><tbody><tr><td>mm, chất liệu đạt ASTM A36 &amp; SS, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Thân chính và phụ kiện</th></tr></thead><tbody><tr><td>của hệ thống ống khói</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống ống xả khí đường kính ống lớn 6.900 mm – ống nhỏ 4.546 mm,</th></tr></thead><tbody><tr><td>chiều cao 60m, bằng thép ASTM A36 &amp; ss, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>24</td><td></td><td></td><td>Trạm biến áp điện gió
ngoài khơi (chân đế +
khối thượng tầng)</td><td></td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td>99</td><td></td><td></td><td>Dạng kết cấu thép công trình biển với khối lượng chân đế 500 – 10.000 tấn,
khối lượng khối thượng tầng 500 – 15.000 tấn, thiết bị chính trên khối thượng
tầng là máy biến áp, độ sâu nước 10m – 120m.</td><td></td><td></td></tr><tr><td>25</td><td></td><td></td><td></td><td>Bồn có ống khuếch tán</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Đường kính 650 mm, chiều cao 3,3m, độ dày 8 mm, bằng thép ASTM A36, áp
suất thiết kế ATM, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>và khung kết cấu thép hỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>trợ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>26</td><td></td><td></td><td>Khung sàn thao tác</td><td></td><td></td><td>7308</td><td></td><td></td><td>40</td><td></td><td></td><td></td><td></td><td></td><td>Vật liệu thép SS400/A36, sản xuất theo tiêu chuẩn ASME, EN/ISO.</td><td></td></tr><tr><td>27</td><td></td><td></td><td></td><td>Khung lắp dựng hệ thống</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Rộng 6,1m, dài 33,3m, cao 1,92m, bằng thép A572-50 theo tiêu chuẩn ASME,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lò hơi hồi nhiệt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>EN/ISO.</td><td></td></tr><tr><td>28</td><td></td><td></td><td></td><td>Khung nâng hệ thống lò</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Rộng 0,6m, dài 26,2m, cao 2m, bằng thép A572-50, theo tiêu chuẩn ASME,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hơi hồi nhiệt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>EN/ISO.</td><td></td></tr><tr><td>29</td><td></td><td></td><td></td><td>Hệ thống lắp đặt và tháo</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Vật liệu thép A36, EN 10025-6 S690QL, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lắp động cơ rotor của tua</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>bin khí</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>30</td><td></td><td></td><td></td><td>Mái che cho Hệ thống lò</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Rộng 3,6m, dài 14m, cao 1,5m, vật liệu thép A36, A572-50, SS304, theo tiêu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hơi hồi nhiệt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuẩn ASME, EN/ISO.</td><td></td></tr><tr><td>31</td><td></td><td></td><td></td><td>Lan can, cầu thang, sàn</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Vật liệu thép SS400/A36.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thao tác</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>32</td><td></td><td></td><td></td><td>Dầm thép, thanh dầm</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Vật liệu thép SS400/A36.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thép, giằng đứng, dầm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>liên kết chịu lực, cửa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>chốt bằng thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>33</td><td></td><td></td><td></td><td>Phễu và tấm lọc bằng</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chiều dài 4,48m, rộng 4,48m, chiều cao 3,2m, vật liệu thép SS400/A36,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>SS304, theo tiêu chuẩn ASME, EN/ISO.</td><td></td></tr><tr><td>34</td><td></td><td></td><td></td><td>Thành bồn chứa, đáy</td><td></td><td>7308</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Đường kính 12m, chiều cao 21,3m, độ dày 8 – 12 mm, vật liệu thép
SS400/A36, SS304, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>bồn chứa và vòng tăng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cứng cho bồn bằng thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Trạm biến áp điện gió</th></tr></thead><tbody><tr><td>ngoài khơi (chân đế +</td></tr><tr><td>khối thượng tầng)</td></tr></tbody></table>

<table><thead><tr><th>Dạng kết cấu thép công trình biển với khối lượng chân đế 500 – 10.000 tấn,</th></tr></thead><tbody><tr><td>khối lượng khối thượng tầng 500 – 15.000 tấn, thiết bị chính trên khối thượng</td></tr><tr><td>tầng là máy biến áp, độ sâu nước 10m – 120m.</td></tr></tbody></table>

<table><thead><tr><th>Đường kính 650 mm, chiều cao 3,3m, độ dày 8 mm, bằng thép ASTM A36, áp</th></tr></thead><tbody><tr><td>suất thiết kế ATM, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Đường kính 12m, chiều cao 21,3m, độ dày 8 – 12 mm, vật liệu thép</th></tr></thead><tbody><tr><td>SS400/A36, SS304, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>35</td><td>Bình làm kín bằng chất
lỏng</td><td></td><td></td><td>7309</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td></td><td>Đường kính 3,66m cao 14,4m, vật liệu thép A516-70N, SS304, theo tiêu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuẩn ASME VIII-1.Sử dụng để phân tách khí đầu đốt bằng một lớp chất lỏng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trong bình.</td><td></td></tr><tr><td>36</td><td>Bồn chữa cháy khẩn cấp
với giá đỡ</td><td></td><td></td><td>7309</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Đường kính 250 mm, chiều cao 2m, độ dày 8 mm, vật liệu ASTM A106-
B/A516-70, áp suất thiết kế ATM, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td>37</td><td>Bồn áp lực</td><td></td><td></td><td>7311</td><td></td><td></td><td>0</td><td></td><td>99</td><td></td><td></td><td>Tiêu chuẩn chế tạo ASMEVIII Div.1;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Hình dạng trụ/đứng/nằm ngang; áp suất ≤ 250 bar; nhiệt độ ≤ 400oC; chiều
dài ≤ 50m; đường kính ≤ 4.000 mm; chiều dày &lt; 40 mm.</td><td></td><td></td></tr><tr><td>38</td><td></td><td>Ống dẫn dung môi (phụ</td><td></td><td>7507</td><td></td><td></td><td>12</td><td></td><td></td><td></td><td></td><td>Đường kính 1/2 inch, vật liệu hợp kim HASTELLOY C276, theo tiêu chuẩn</td><td></td></tr><tr><td></td><td></td><td>kiện của bồn chữa cháy)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ASME, EN/ISO.</td><td></td></tr><tr><td>39</td><td></td><td>Anot hy sinh nhôm chống</td><td></td><td>7604</td><td></td><td></td><td>10</td><td></td><td>19</td><td></td><td>Dung lượng điện hóa &gt; 2.500 A.h/kg. Theo tiêu chuẩn ISO 15589-2-2012, tiêu
chuẩn quốc tế DNV RP B401;</td><td></td><td></td></tr><tr><td></td><td></td><td>ăn mòn – dạng tấm, trụ,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>thẳng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>40</td><td></td><td>Hệ thống ống khói cho</td><td></td><td>8404</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td>Ống dẫn khí cao đến 40m, kết hợp bộ diverter (kích thước 7.913 x 6.815 mm,</td><td></td></tr><tr><td></td><td></td><td>tuabin lò hơi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>theo tiêu chuẩn ASME, EN/ISO.</td><td></td></tr><tr><td>41</td><td></td><td>Phụ kiện của hệ thống</td><td></td><td>8404</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Ống dẫn khí cao 40m, kết hợp bộ diverter (7.913 x 6.815 mm), vật
liệu đạt ASTM A36, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td>ống khói cho tuabin lò</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>hơi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>42</td><td>Bộ khuếch tán khí thải</td><td></td><td></td><td>8411</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td></td><td>Là bộ phận của tua bin khí đường kính 7,029m dài 6,513m, vật liệu thép A36,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>SS304, theo tiêu chuẩn ASME, EN/ISO.</td><td></td></tr><tr><td>43</td><td></td><td>Hệ thống giảm thanh</td><td></td><td>8411</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td></td><td>Kích thước 8.500 x 8.500 mm, 3.261 x 3.612 mm, ống dẫn khí cao 40m, kết</td><td></td></tr><tr><td></td><td></td><td>thuộc bộ phận của tuabin</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hợp bộ diverter (8.080 x 9.228 mm) vật liệu đạt ASTM A36, theo tiêu chuẩn</td><td></td></tr><tr><td></td><td></td><td>và phụ kiện kèm theo</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ASME, EN/ISO.</td><td></td></tr><tr><td>44</td><td></td><td>Hệ thống ống dẫn đầu</td><td></td><td>8411</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td></td><td>Hệ thống ống dẫn khí kích thước 4.800 x 6.320 mm, vật liệu đạt ASTM A36,</td><td></td></tr><tr><td></td><td></td><td>vào, phụ kiện cho tuabin</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>theo tiêu chuẩn ASME, EN/ISO.</td><td></td></tr><tr><td>45</td><td></td><td>Bơm điện chìm ly tâm</td><td></td><td>8413</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bộ bơm VMP155/3; công suất (Q)155 m3/h; chiều cao (H) = 95 m nước.</td><td></td><td></td></tr><tr><td></td><td></td><td>bơm nước biển</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Bình làm kín bằng chất</th></tr></thead><tbody><tr><td>lỏng</td></tr></tbody></table>

<table><thead><tr><th>Bồn chữa cháy khẩn cấp</th></tr></thead><tbody><tr><td>với giá đỡ</td></tr></tbody></table>

<table><thead><tr><th>Đường kính 250 mm, chiều cao 2m, độ dày 8 mm, vật liệu ASTM A106-</th></tr></thead><tbody><tr><td>B/A516-70, áp suất thiết kế ATM, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Hình dạng trụ/đứng/nằm ngang; áp suất ≤ 250 bar; nhiệt độ ≤ 400oC; chiều</th></tr></thead><tbody><tr><td>dài ≤ 50m; đường kính ≤ 4.000 mm; chiều dày &lt; 40 mm.</td></tr></tbody></table>

<table><thead><tr><th>Dung lượng điện hóa &gt; 2.500 A.h/kg. Theo tiêu chuẩn ISO 15589-2-2012, tiêu</th></tr></thead><tbody><tr><td>chuẩn quốc tế DNV RP B401;</td></tr></tbody></table>

<table><thead><tr><th>Ống dẫn khí cao 40m, kết hợp bộ diverter (7.913 x 6.815 mm), vật</th></tr></thead><tbody><tr><td>liệu đạt ASTM A36, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>46</td><td>Hệ thống bơm hóa phẩm</td><td></td><td></td><td>8413</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Vật liệu thép không gỉ SUS316L;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Kích thước 5.960 x 4.300 x 2.550 mm và 4.865 x 3.700 x 3.860 mm;- Nhiệt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>độ thiết kế (MIN/MAX): AMB/45 ̊C;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Dung tích đến 30,1 F56;- Khối lượng 9.150 kg;- Khả năng chứa đầy chất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lỏng.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Tiêu chuẩn thiết kế: API 650 + ROAKS &amp; YOUNG;</td><td></td></tr><tr><td>47</td><td></td><td>Các bộ ổ đỡ thủy lực cho</td><td></td><td>8419</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đường kính trong 300 mm, trọng tải tối đa 215KN (khoảng 21,9 tấn), công
suất ≤ 600kW.</td><td></td><td></td></tr><tr><td></td><td></td><td>các động cơ bơm chìm ly</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>tâm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>48</td><td></td><td>Các cấu kiện của hệ</td><td></td><td>8419</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Kích thước dài 6m rộng 0,725m cao 3m, vật liệu thép SS304 sản xuất theo
tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td>thống làm mát bằng bay</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>hơi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>49</td><td></td><td>Thiết bị lọc nước bằng</td><td></td><td>8421</td><td></td><td></td><td>21</td><td></td><td></td><td></td><td></td><td>Đường kính 3.800 mm, dày 25 mm, vật liệu thép A36/A516-70/Q345-B, tiêu</td><td></td></tr><tr><td></td><td></td><td>cát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuẩn sản xuất ASME VIII-1.</td><td></td></tr><tr><td>50</td><td>Hệ thống điều phối khí
xả cho tuabin</td><td></td><td></td><td>8421</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td></td><td>Hệ thống điều phối khí xả kết hợp diverter (3.050 x 3.050 mm), (5.100 x 5.100</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mm), (4.660 x 4.220 mm), vật liệu đạt thép ASTM A36, theo tiêu chuẩn ASME,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>EN/ISO.</td><td></td></tr><tr><td>51</td><td>Hệ thống lọc và xả khí</td><td></td><td></td><td>8421</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td>Hệ thống lọc khí kích thước bao 2.288 mm (dài) x 3.207 mm (cao) x l.570 mm
(rộng), kích thước bao 29.537 mm (dài) x 12.727 mm (cao) x 24.289
mm (rộng), vật liệu đạt thép ASTM A36, tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td>52</td><td>Hệ thống ống xả khí S-
GH1&amp;S-GH2</td><td></td><td></td><td>8421</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td>Hệ thống ống xả khí đường kính ống lớn DN300 mm – ống nhỏ DN80 mm,
chiều dài tối đa 25m, vật liệu thép SS3 16L, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td>53</td><td></td><td>Phụ kiện của Hệ thống</td><td></td><td>8421</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td>Kết hợp diverter (3.050 x 3.050 mm), (5.100 x 5.100 mm), (3.050 x 30.50
mm), vật liệu đạt thép ASTM A36, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td>điều phối khí xả cho</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>tuabin</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>54</td><td></td><td>Giàn khoan dầu khí cố</td><td></td><td>8430</td><td></td><td></td><td>49</td><td></td><td>10</td><td></td><td>Hoạt động ở vùng biển có độ sâu 120m nước.</td><td></td><td></td></tr><tr><td></td><td></td><td>định trên biển</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Đường kính trong 300 mm, trọng tải tối đa 215KN (khoảng 21,9 tấn), công</th></tr></thead><tbody><tr><td>suất ≤ 600kW.</td></tr></tbody></table>

<table><thead><tr><th>Kích thước dài 6m rộng 0,725m cao 3m, vật liệu thép SS304 sản xuất theo</th></tr></thead><tbody><tr><td>tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống điều phối khí</th></tr></thead><tbody><tr><td>xả cho tuabin</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống lọc khí kích thước bao 2.288 mm (dài) x 3.207 mm (cao) x l.570 mm</th></tr></thead><tbody><tr><td>(rộng), kích thước bao 29.537 mm (dài) x 12.727 mm (cao) x 24.289</td></tr><tr><td>mm (rộng), vật liệu đạt thép ASTM A36, tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống ống xả khí S-</th></tr></thead><tbody><tr><td>GH1&amp;S-GH2</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống ống xả khí đường kính ống lớn DN300 mm – ống nhỏ DN80 mm,</th></tr></thead><tbody><tr><td>chiều dài tối đa 25m, vật liệu thép SS3 16L, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Kết hợp diverter (3.050 x 3.050 mm), (5.100 x 5.100 mm), (3.050 x 30.50</th></tr></thead><tbody><tr><td>mm), vật liệu đạt thép ASTM A36, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>55</td><td></td><td></td><td>Cọc (Pile)</td><td></td><td></td><td>8430</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bán kính ngoài OD 1.524 x 50 mm (THK) ÷ OD 2438 x 50 mm (THK); chiều</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dài (L) 68 – 125 m.</td><td></td></tr><tr><td>56</td><td></td><td></td><td></td><td>Cụm mô-đun xử lý công</td><td></td><td>8479</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đặc tính kỹ thuật chi tiết được thiết kế theo yêu cầu của khách hàng.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nghệ trên tàu nổi xử lý và</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>chứa dầu Floating</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Production Storage</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Offloading (FPSO)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>57</td><td></td><td></td><td>Phụ tùng cho bơm ly tâm
vận chuyển dầu khí</td><td></td><td></td><td>8504</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bơm chuyển dầu thô: MSDD 4 x 8 x 10.5B: P = 35 bar; Q = 75 m3/h; CPC C3
x 6 x 9 HMD: P = 19 bar; Q = 120 m3/h; 65-500: P = 40 bar; Q: 65 m3/h;
200/210: P = 20 bar; Q = 120 m3/h. Chế tạo từ các vật liệu duplex, theo tiêu
chuẩn API 610.</td><td></td><td></td></tr><tr><td></td><td>58</td><td></td><td></td><td>Vessel (Tàu)</td><td></td><td></td><td>8901</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải 1.025 tấn.</td><td></td></tr><tr><td>59</td><td></td><td></td><td></td><td>Xà lan</td><td></td><td>8901</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Trọng tải 650 tấn, chiều rộng 10 m, chiều dài 40 m.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Feedbarge</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>60</td><td></td><td></td><td></td><td>Chân đế và khối thượng</td><td></td><td>8905</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Khối lượng chân đế 1.011 tấn, cọc 915 tấn, khối thượng tầng 940 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tầng giàn khai thác dầu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>và khí</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>61</td><td></td><td></td><td></td><td>Giàn khoan dầu khí di</td><td></td><td>8905</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Có khả năng thăm dò, khai thác dầu khí tại các vùng nước có độ sâu 120m.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>động</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>62</td><td></td><td></td><td></td><td>Trạm biến áp cho các</td><td></td><td>8905</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Điện áp 6,3/22 KV, công suất trạm đến 4.000 KVA, đáp ứng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>giàn khai thác dầu khí</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN49:2012/BGTVT; API; ASTM; IEC.</td><td></td></tr><tr><td>63</td><td></td><td></td><td>Giàn chân căng</td><td></td><td></td><td>8905</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cho cụm giàn khai thác dầu khí nước sâu &gt; 1.000 mét. Đặc tính kỹ thuật chi</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tiết được thiết kế theo yêu cầu của khách hàng.</td><td></td></tr><tr><td>64</td><td></td><td></td><td></td><td>Giàn xử lý công nghệ</td><td></td><td>8905</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phục vụ công tác khai thác dầu khí. Đặc tính kỹ thuật chi tiết được thiết kế</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>trung tâm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>theo yêu cầu của khách hàng.</td><td></td></tr><tr><td>65</td><td></td><td></td><td></td><td>Giàn khoan dầu khí tự</td><td></td><td>8905</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Khối lượng 12.500 – 18.000 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nâng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>66</td><td></td><td></td><td>Phao Bouyancy Tank</td><td></td><td></td><td>8907</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Đường kính ngoài OD 2.800 mm – 3.500 mm;- Khối lượng 800 – 1.200 tấn.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Bơm chuyển dầu thô: MSDD 4 x 8 x 10.5B: P = 35 bar; Q = 75 m3/h; CPC C3</th></tr></thead><tbody><tr><td>x 6 x 9 HMD: P = 19 bar; Q = 120 m3/h; 65-500: P = 40 bar; Q: 65 m3/h;</td></tr><tr><td>200/210: P = 20 bar; Q = 120 m3/h. Chế tạo từ các vật liệu duplex, theo tiêu</td></tr><tr><td>chuẩn API 610.</td></tr></tbody></table>

<table><thead><tr><th>Phụ tùng cho bơm ly tâm</th></tr></thead><tbody><tr><td>vận chuyển dầu khí</td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th></th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>67</td><td></td><td>Chân đế giàn khoan</td><td></td><td>8907</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Khối lượng 1.200 – 13.000 tấn.</td><td></td><td></td></tr><tr><td></td><td></td><td>(Jacket)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>68</td><td>Thiết bị áp lực dạng tháp
(Tower)</td><td></td><td></td><td>9026</td><td></td><td></td><td>80</td><td></td><td></td><td>20</td><td></td><td>Áp suất đến 250 bar; nhiệt độ từ -50oC đến 400oC; chiều dài ≤ 50 m; đường
kính ≤ 4.000 mm; độ dày ≤ 40m, chế tạo theo tiêu chuẩn ASME VIII Div.1.</td><td></td><td></td></tr><tr><td>69</td><td>Khối giàn nhà ở trên biển</td><td></td><td></td><td>9406</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Phục vụ công tác khoan và khai thác dầu khí. Đặc tính kỹ thuật chi tiết được</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thiết kế theo yêu cầu của khách hàng.</td><td></td></tr><tr><td>70</td><td>Hệ thống ống khí đốt</td><td></td><td></td><td></td><td>7309</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Bao gồm cả khung đỡ chân rộng 26m x 26m, cao 150m, vật liệu thép
STK400, A36, A516, A672, SS304, theo tiêu chuẩn ASME, EN/ISO.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>7304</td><td></td><td></td><td>11</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>7311</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>71</td><td>Hệ thống điều khiển tích
hợp và giám sát an toàn</td><td></td><td></td><td>8535</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Gồm các tủ điều khiển công nghệ (PCS), các tủ điều khiển hệ thống an toàn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(SSD), các trạm vận hành, số lượng tín hiệu đến 5.000.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đáp ứng QCVN49:2012/BGTVT; API; ASTM; IEC.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8537</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>72</td><td>Tủ điều khiển các đầu
giếng</td><td></td><td></td><td></td><td>8535</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cho các giàn khai thác dầu khí, điều khiển đến 12 module, áp suất làm việc tối
đa 690 bar. Đáp ứng QCVN49:2012/BGTVT; API; ASTM; IEC.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8537</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>73</td><td>Tủ đóng cắt điện áp thấp
và điều khiển động cơ</td><td></td><td></td><td></td><td>8535</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Hệ thống tủ phân phối điện hạ áp cho các giàn khai thác dầu khí, gồm:</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Các tủ phân phối (MCC);</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8537</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Các lộ tủ phân phối đầu vào (Incoming);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Các lộ tủ phân phối đầu ra (OutGoing);</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Số lượng lộ tủ đến 50 lộ vào/ra.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đáp ứng QCVN49:2012/BGTVT; API; ASTM; IEC.</td><td></td></tr><tr><td>74</td><td>Tủ phân phối điện</td><td></td><td></td><td></td><td>8535</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cho các giàn khai thác dầu khí, gồm: tủ phân phối nhỏ (DPs), số lượng dây ra
đến 30 đường vào ra. Đáp ứng QCVN49:2012/BGTVT; API; ASTM; IEC.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Thiết bị áp lực dạng tháp</th></tr></thead><tbody><tr><td>(Tower)</td></tr></tbody></table>

<table><thead><tr><th>Áp suất đến 250 bar; nhiệt độ từ -50oC đến 400oC; chiều dài ≤ 50 m; đường</th></tr></thead><tbody><tr><td>kính ≤ 4.000 mm; độ dày ≤ 40m, chế tạo theo tiêu chuẩn ASME VIII Div.1.</td></tr></tbody></table>

<table><thead><tr><th>Bao gồm cả khung đỡ chân rộng 26m x 26m, cao 150m, vật liệu thép</th></tr></thead><tbody><tr><td>STK400, A36, A516, A672, SS304, theo tiêu chuẩn ASME, EN/ISO.</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống điều khiển tích</th></tr></thead><tbody><tr><td>hợp và giám sát an toàn</td></tr></tbody></table>

<table><thead><tr><th>Tủ điều khiển các đầu</th></tr></thead><tbody><tr><td>giếng</td></tr></tbody></table>

<table><thead><tr><th>Cho các giàn khai thác dầu khí, điều khiển đến 12 module, áp suất làm việc tối</th></tr></thead><tbody><tr><td>đa 690 bar. Đáp ứng QCVN49:2012/BGTVT; API; ASTM; IEC.</td></tr></tbody></table>

<table><thead><tr><th>Tủ đóng cắt điện áp thấp</th></tr></thead><tbody><tr><td>và điều khiển động cơ</td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8537</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>75</td><td>Các hộp nối cáp ngầm
dưới biển cho các công
trình dầu khí và điện gió
gần bờ, ngoài khơi</td><td>8535
8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1. Hộp nối cáp ngầm 22 kV cho điện gió gần bờ, kích thước 450 x 450 x 2.900
mm;2. Hộp nối cáp ngầm 22 kV cho điện gió ngoài khơi, kích thước 300 x 300
x 1.050 mm;Thông số kỹ thuật chung: kích thước cáp 3 x 120 mm2, áp suất
thiết kế 7,4 Mpa.</td><td></td><td></td></tr><tr><td>76</td><td>Khí thiên nhiên nén
(CNG)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Là sản phẩm hydrocabon ở thể khí được nén ở áp suất đến 250 bar, có
nguồn gốc từ khí tự nhiên với thành phần chủ yếu là mêtan (CH ).
4</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đáp ứng TCCS 01:2016/PV GAS; TCCS 08:2022/PV GAS; TCCS 09:2022/PV</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>GAS.</td><td></td></tr><tr><td>77</td><td>Chế phẩm hóa học tăng
cường thu hồi dầu VPI-
SURF</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dạng lỏng; sức căng bề mặt (mN/m) max 1,5; pH (dung dịch 1% trong nước</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cất) 6,5 – 7,5; độ nhớt động học tại 25°C là 220 cSt; nồng độ CMC đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0,07%kl; điểm chớp cháy nhỏ nhất 55°C; tổng chất rắn hòa tan nhỏ nhất 45</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>g/l.</td><td></td></tr><tr><td>78</td><td>Condensate</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Là sản phẩm hydrocarbon lỏng thu được sau quá trình chưng cất phân đoạn
trong nhà máy xử lý khí, thành phần bao gồm chủ yếu là hỗn hợp pentan
(C H ) và các hydrocarbon nặng hơn.Đáp ứng TCCS 03:2020/PV GAS;
5 12
TCCS 04:2017/PV GAS; TCCS 05:2018/PV GAS.</td><td></td><td></td></tr><tr><td>79</td><td>Bộ đo đa pha –
Multiphase flow meter-
MPFM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Kiểu tách hai pha khí/lỏng riêng biệt; nhiệt độ làm việc 35oC; áp suất/nhiệt độ
thiết kế 35 bar/0-80oC; áp suất/nhiệt độ làm việc 10-25 bar/25-64oC; công suất
đo pha khí đến 250.000 m3/ngày; công suất đo pha lỏng đến 850 m3/ngày.</td><td></td><td></td></tr><tr><td>80</td><td>Trạm tạo hơi nước nóng
cao áp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Môi chất: nước ngọt;Nhiên liệu: dầu diesel;Năng suất hơi 1.000 – 1.600
kg/giờ;Áp suất hơi 80 – 100 kgf/cm2;Nhiệt độ hơi 295°C;Tiêu hao nhiên liệu
72 lít/giờ;Năng suất nhiệt chế độ I 940.000 kcal/giờ;Công suất động cơ 7,5 –
11 kW;Điện áp 3 pha – 380V x 50Hz.Theo QCVN 102:2018/BGTVT.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>dưới biển cho các công</th></tr></thead><tbody><tr><td>trình dầu khí và điện gió</td></tr><tr><td>gần bờ, ngoài khơi</td></tr></tbody></table>

<table><thead><tr><th>8535</th></tr></thead><tbody><tr><td>8536</td></tr></tbody></table>

<table><thead><tr><th>mm;2. Hộp nối cáp ngầm 22 kV cho điện gió ngoài khơi, kích thước 300 x 300</th></tr></thead><tbody><tr><td>x 1.050 mm;Thông số kỹ thuật chung: kích thước cáp 3 x 120 mm2, áp suất</td></tr><tr><td>thiết kế 7,4 Mpa.</td></tr></tbody></table>

<table><thead><tr><th>Là sản phẩm hydrocabon ở thể khí được nén ở áp suất đến 250 bar, có</th></tr></thead><tbody><tr><td>nguồn gốc từ khí tự nhiên với thành phần chủ yếu là mêtan (CH ).
4</td></tr></tbody></table>

<table><thead><tr><th>Khí thiên nhiên nén</th></tr></thead><tbody><tr><td>(CNG)</td></tr></tbody></table>

<table><thead><tr><th>Chế phẩm hóa học tăng</th></tr></thead><tbody><tr><td>cường thu hồi dầu VPI-</td></tr><tr><td>SURF</td></tr></tbody></table>

<table><thead><tr><th>Là sản phẩm hydrocarbon lỏng thu được sau quá trình chưng cất phân đoạn</th></tr></thead><tbody><tr><td>trong nhà máy xử lý khí, thành phần bao gồm chủ yếu là hỗn hợp pentan</td></tr><tr><td>(C H ) và các hydrocarbon nặng hơn.Đáp ứng TCCS 03:2020/PV GAS;
5 12</td></tr><tr><td>TCCS 04:2017/PV GAS; TCCS 05:2018/PV GAS.</td></tr></tbody></table>

<table><thead><tr><th>Bộ đo đa pha –</th></tr></thead><tbody><tr><td>Multiphase flow meter-</td></tr><tr><td>MPFM</td></tr></tbody></table>

<table><thead><tr><th>Kiểu tách hai pha khí/lỏng riêng biệt; nhiệt độ làm việc 35oC; áp suất/nhiệt độ</th></tr></thead><tbody><tr><td>thiết kế 35 bar/0-80oC; áp suất/nhiệt độ làm việc 10-25 bar/25-64oC; công suất</td></tr><tr><td>đo pha khí đến 250.000 m3/ngày; công suất đo pha lỏng đến 850 m3/ngày.</td></tr></tbody></table>

<table><thead><tr><th>Môi chất: nước ngọt;Nhiên liệu: dầu diesel;Năng suất hơi 1.000 – 1.600</th></tr></thead><tbody><tr><td>kg/giờ;Áp suất hơi 80 – 100 kgf/cm2;Nhiệt độ hơi 295°C;Tiêu hao nhiên liệu</td></tr><tr><td>72 lít/giờ;Năng suất nhiệt chế độ I 940.000 kcal/giờ;Công suất động cơ 7,5 –</td></tr><tr><td>11 kW;Điện áp 3 pha – 380V x 50Hz.Theo QCVN 102:2018/BGTVT.</td></tr></tbody></table>

<table><thead><tr><th>Trạm tạo hơi nước nóng</th></tr></thead><tbody><tr><td>cao áp</td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD649

## DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY

## MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD649</th></tr></thead><tbody><tr><td></td><td>DANH MỤC PHƯƠNG TIỆN VẬN TẢI, VẬT TƯ XÂY DỰNG, MÁY
MÓC, THIẾT BỊ, VẬT TƯ CẦN THIẾT CHO HOẠT ĐỘNG DẦU KHÍ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số TT</th><th>Tên mặt hàng</th><th></th><th>Mã số theo biểu thuế</th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>nhập khẩu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>81</td><td>Hộp nối cáp điện trung
thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1. Hộp nối 24kV: Model VMED-O24JB 3X50;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2. Hộp nối 6,3kVAC: Model VMED-O6,3JB 3X70;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thông số kỹ thuật chung:</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Điện áp 24kVAC – 50 Hz;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cấp bảo vệ IP56;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Kích thước 1.000 x 1.200 x 5,50 mm;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Vật liệu thép không gỉ SUS316;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Khối lượng 140 kg.</td><td></td></tr><tr><td>82</td><td>Thanh cần cẩu biển dạng
khung, dạng hộp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dạng kết cấu khung giàn/chữ A, hộp, tải trọng làm việc 1 – 50 tấn, tầm với 3 –
36m, ứng dụng cho thiết bị nâng trên các công trình biển.</td><td></td><td></td></tr><tr><td>83</td><td>Các cầu trục trong nhà
tải trọng đến 20 tấn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Tải trọng đến 20 tấn; khẩu độ cầu trục đến 32m; chế độ làm việc trung bình;
điện áp vận hành (V) U 3 pha 380V; điện áp điều khiển (V) U 48; kích thước
dầm chính HD x WD 1.502 mm x 652 mm; kích thước ray cầu trục HR x WR
38 mm x 60 mm;- Tự trọng cầu trục 27.700 kg.</td><td></td><td></td></tr><tr><td>84</td><td>Bình trao đổi nhiệt dạng
ống tròn thẳng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Kiểu loại bình trao đổi nhiệt dạng ống tròn; môi chất: dầu nóng/dầu thô; lắp
đặt nằm ngang; chiều dài toàn bộ bình 7.172,8 mm; đường kính thân bình 470
mm; đường kính ngoài (OD) 19,05 mm; áp suất thiết kế 27,5 bar; nhiệt độ
thiết kế 125oC; áp suất làm việc 16 bar; khối lượng toàn bộ bình 2.450 kg.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Hộp nối cáp điện trung</th></tr></thead><tbody><tr><td>thế</td></tr></tbody></table>

<table><thead><tr><th>Thanh cần cẩu biển dạng</th></tr></thead><tbody><tr><td>khung, dạng hộp</td></tr></tbody></table>

<table><thead><tr><th>Dạng kết cấu khung giàn/chữ A, hộp, tải trọng làm việc 1 – 50 tấn, tầm với 3 –</th></tr></thead><tbody><tr><td>36m, ứng dụng cho thiết bị nâng trên các công trình biển.</td></tr></tbody></table>

<table><thead><tr><th>– Tải trọng đến 20 tấn; khẩu độ cầu trục đến 32m; chế độ làm việc trung bình;</th></tr></thead><tbody><tr><td>điện áp vận hành (V) U 3 pha 380V; điện áp điều khiển (V) U 48; kích thước</td></tr><tr><td>dầm chính HD x WD 1.502 mm x 652 mm; kích thước ray cầu trục HR x WR</td></tr><tr><td>38 mm x 60 mm;- Tự trọng cầu trục 27.700 kg.</td></tr></tbody></table>

<table><thead><tr><th>Các cầu trục trong nhà</th></tr></thead><tbody><tr><td>tải trọng đến 20 tấn</td></tr></tbody></table>

<table><thead><tr><th>Kiểu loại bình trao đổi nhiệt dạng ống tròn; môi chất: dầu nóng/dầu thô; lắp</th></tr></thead><tbody><tr><td>đặt nằm ngang; chiều dài toàn bộ bình 7.172,8 mm; đường kính thân bình 470</td></tr><tr><td>mm; đường kính ngoài (OD) 19,05 mm; áp suất thiết kế 27,5 bar; nhiệt độ</td></tr><tr><td>thiết kế 125oC; áp suất làm việc 16 bar; khối lượng toàn bộ bình 2.450 kg.</td></tr></tbody></table>

<table><thead><tr><th>Bình trao đổi nhiệt dạng</th></tr></thead><tbody><tr><td>ống tròn thẳng</td></tr></tbody></table>

|<image_26>|


