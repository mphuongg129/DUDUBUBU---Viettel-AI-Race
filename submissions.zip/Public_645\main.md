# Public_645

## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>XIV</td><td>Vật liệu ngành điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14,1</td><td>Dây điện Trần Phú (Công ty CP Cơ điện Trần Phú)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Dây đơn
Cu/PVC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1238</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x0,75 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>3,055</td></tr><tr><td>1239</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x1,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>3,909</td></tr><tr><td>1240</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x1,5 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>5,782</td></tr><tr><td>1241</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x2,5 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>9,391</td></tr><tr><td>1242</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x4,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>14,409</td></tr><tr><td>1243</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x6,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>21,409</td></tr><tr><td>1244</td><td>Vật liệu
ngành điện</td><td>VCm - Đơn 1x10 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>35,636</td></tr><tr><td>*</td><td>Dây dẹt Cu/PVC/PVC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1245</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 2x0,75
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>7,000</td></tr><tr><td>1246</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 2x1,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>8,964</td></tr><tr><td>1247</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 2x1,5 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>12,318</td></tr><tr><td>1248</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 2x2,5 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>20,273</td></tr><tr><td>1249</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 2x4,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>30,455</td></tr><tr><td>1250</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 2x6,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>45,091</td></tr><tr><td>1251</td><td>Vật liệu
ngành điện</td><td>VCm-D - Dẹt 3x0,75
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>10,364</td></tr><tr><td>*</td><td>Dây tròn ruột mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1252</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 2x0,75
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>7,973</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1253</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 2x1,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>10,309</td></tr><tr><td>1254</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 2x1,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>13,718</td></tr><tr><td>1255</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 2x2,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>22,636</td></tr><tr><td>1256</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 2x4,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>33,273</td></tr><tr><td>1257</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 2x6,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>49,182</td></tr><tr><td>1258</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 3x0,75
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>11,164</td></tr><tr><td>1259</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 3x1,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>14,455</td></tr><tr><td>1260</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 3x1,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>19,355</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1261</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 3x2,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>31,364</td></tr><tr><td>1262</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 3x4,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>47,436</td></tr><tr><td>1263</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 3x6,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>70,936</td></tr><tr><td>1264</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 4x0,75
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>14,682</td></tr><tr><td>1265</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 4x1,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>18,227</td></tr><tr><td>1266</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 4x1,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>25,273</td></tr><tr><td>1267</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 4x2,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>40,727</td></tr><tr><td>1268</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 4x4,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>62,109</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1269</td><td>Vật liệu
ngành điện</td><td>VCm-T - Tròn 4x6,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>92,182</td></tr><tr><td>*</td><td>Dây dính cách</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1270</td><td>Vật liệu
ngành điện</td><td>VCm-DK - Dính cách
2x1,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>12,545</td></tr><tr><td>1271</td><td>Vật liệu
ngành điện</td><td>VCm-DK - Dính cách
2x2,5
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>20,727</td></tr><tr><td>1272</td><td>Vật liệu
ngành điện</td><td>VCm-DK - Dính cách
2x4,0
mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>30,818</td></tr><tr><td>1273</td><td>Vật liệu
ngành điện</td><td>Dây xúp VCm-X - Xúp
2x0,75 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>6,000</td></tr><tr><td>*</td><td>Dây đơn 7 bọc nhựa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1274</td><td>Vật liệu
ngành điện</td><td>CV - Đơn 1x1,5 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>5,664</td></tr><tr><td>1275</td><td>Vật liệu
ngành điện</td><td>CV - Đơn 1x2,5 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>9,227</td></tr><tr><td>1276</td><td>Vật liệu
ngành điện</td><td>CV - Đơn 1x4,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ</td><td>không</td><td>Giá bán tại
thành phố</td><td></td><td>14,091</td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>điện Trần
Phú</td><td></td><td>Lạng
Sơn</td><td></td><td></td></tr><tr><td>1277</td><td>Vật liệu
ngành điện</td><td>CV - Đơn 1x6,0 mm²</td><td>m</td><td>IEC 60227-
3/60227-5</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>20,982</td></tr><tr><td>*</td><td>Dây đơn hạ thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1278</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x10 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>39,364</td></tr><tr><td>1279</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x16 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>63,273</td></tr><tr><td>1280</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x25 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>101,364</td></tr><tr><td>1281</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x35 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>138,091</td></tr><tr><td>1282</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x50 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>186,364</td></tr><tr><td>1283</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x70 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>263,636</td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1284</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x95 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>368,182</td></tr><tr><td>1285</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x120 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>462,727</td></tr><tr><td>1286</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x150 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>580,909</td></tr><tr><td>1287</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x185 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>729,091</td></tr><tr><td>1288</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x240 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>Cuộn 100m</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>914,182</td></tr><tr><td>*</td><td>Cáp 1 lõi hạ thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1289</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x50 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>186,364</td></tr><tr><td>1290</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x70 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>263,636</td></tr><tr><td>1291</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x95 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>368,182</td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1292</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x120 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>462,727</td></tr><tr><td>1293</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x150 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>580,909</td></tr><tr><td>1294</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x185 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>729,091</td></tr><tr><td>1295</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x240 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>914,182</td></tr><tr><td>1296</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x300 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.206.364</td></tr><tr><td>1297</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(1x400 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.436.364</td></tr><tr><td>1298</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x10 mm²
+1x6
mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>153,455</td></tr><tr><td>1299</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x16mm²
+1x10mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>233,000</td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1300</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x25 mm²
+1x16mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>354,000</td></tr><tr><td>1301</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x35 mm²
+1x16
mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>464,818</td></tr><tr><td>1302</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x35 mm²
+1x25
mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>502,273</td></tr><tr><td>1303</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x50 mm²
+1x25
mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>648,909</td></tr><tr><td>1304</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x50 mm²
+1x35mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>687,545</td></tr><tr><td>1305</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x70mm²
+1x35mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>900,000</td></tr><tr><td>1306</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x70mm²
+1x50mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>954,545</td></tr><tr><td>1307</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x95mm²
+1x50mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.238.636</td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1308</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x95mm²
+1x70mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.312.545</td></tr><tr><td>1309</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x120mm²
+1x70mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.568.182</td></tr><tr><td>1310</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x120mm²
+1x95mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.670.455</td></tr><tr><td>1311</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x150mm²
+1x70mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.886.364</td></tr><tr><td>1312</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(3x150mm²
+1x95mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.994.545</td></tr><tr><td>*</td><td>Cáp 4 lõi hạ thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1313</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x10 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>155,273</td></tr><tr><td>1314</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x16 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>241,273</td></tr><tr><td>1315</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x25 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>379,727</td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1316</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x35 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>503,636</td></tr><tr><td>1317</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x50 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>663,636</td></tr><tr><td>1318</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x70 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>954,545</td></tr><tr><td>1319</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x95 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.335.455</td></tr><tr><td>1320</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x120 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.658.182</td></tr><tr><td>1321</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x150 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.965.455</td></tr><tr><td>1322</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x185 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>2.570.909</td></tr><tr><td>1323</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x240 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>3.220.000</td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1324</td><td>Vật liệu
ngành điện</td><td>Cáp CVV-(4x300 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/PVC/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>4.209.091</td></tr><tr><td>*</td><td>Cáp 1 lõi hạ thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1325</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x10 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>38,818</td></tr><tr><td>1326</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x16 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>62,364</td></tr><tr><td>1327</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x25 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>99,091</td></tr><tr><td>1328</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x35 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>135,455</td></tr><tr><td>1329</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x50 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>186,364</td></tr><tr><td>1330</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x70 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>263,636</td></tr><tr><td>1331</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x95 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>368,091</td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1332</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x120 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>455,455</td></tr><tr><td>1333</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x150 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>570,909</td></tr><tr><td>1334</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x185 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>717,273</td></tr><tr><td>1335</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(1x240 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>900,000</td></tr><tr><td>*</td><td>Cáp (3+1) lõi hạ thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1336</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x16mm²
+1x10mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>227,273</td></tr><tr><td>1337</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x25mm²
+1x10mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>325,000</td></tr><tr><td>1338</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x25mm²
+1x16mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>445,455</td></tr><tr><td>1339</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x35mm²
+1x16mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>470,909</td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1340</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x35mm²
+1x25mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>609,091</td></tr><tr><td>1341</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x50mm²
+1x25mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>700,636</td></tr><tr><td>1342</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x50mm²
+1x35mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>863,636</td></tr><tr><td>1343</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x70mm²
+1x35mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>948,182</td></tr><tr><td>1344</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x70mm²
+1x50mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.227.273</td></tr><tr><td>1345</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x95mm²
+1x50mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.308.182</td></tr><tr><td>1346</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x95mm²
+1x70mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.500.000</td></tr><tr><td>1347</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x120mm²
+1x70mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.640.909</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1348</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x120mm²
+1x95mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.800.000</td></tr><tr><td>1349</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x150mm²
+1x70mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.990.000</td></tr><tr><td>1350</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x150mm²
+1x95mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>2.089.091</td></tr><tr><td>1351</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(3x150mm²
+1x120mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>2.318.182</td></tr><tr><td>*</td><td>Cáp 4 lõi hạ thế</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1352</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x10 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>163,636</td></tr><tr><td>1353</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x16 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>250,000</td></tr><tr><td>1354</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x25 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>400,000</td></tr><tr><td>1355</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x35 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>554,545</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1356</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x50 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>781,818</td></tr><tr><td>1357</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x70 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.081.818</td></tr><tr><td>1358</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x95 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.477.273</td></tr><tr><td>1359</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x120 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>1.827.273</td></tr><tr><td>1360</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x150 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>2.294.545</td></tr><tr><td>1361</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x185 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>2.875.455</td></tr><tr><td>1362</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x240 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>3.610.909</td></tr><tr><td>1363</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x300 mm²)</td><td>s</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>4.585.455</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1364</td><td>Vật liệu
ngành điện</td><td>Cáp CXV-(4x400 mm²)</td><td>m</td><td>IEC 60202-
1/60228</td><td>CU/XLPE/PVC</td><td>Công ty CP
Cơ
điện Trần
Phú</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>5.943.636</td></tr><tr><td>14,2</td><td>Dây cáp điện CADIVI (Công ty TNHH MTV Cadivi Miền Bắc)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 0,6/1kV (1 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1365</td><td>Vật liệu
ngành điện</td><td>CVV-1 (1x7/0.425) –
0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>7,370</td></tr><tr><td>1366</td><td>Vật liệu
ngành điện</td><td>CVV-1.5 (1x7/0,52) –
0,6/1
kV</td><td>m</td><td>TCVN 5935-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>9,460</td></tr><tr><td>1367</td><td>Vật liệu
ngành điện</td><td>CVV-6.0 (1x7/1.04) –
0,6/1
kV</td><td>m</td><td>TCVN 5935-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH
MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>28,010</td></tr><tr><td>1368</td><td>Vật liệu
ngành điện</td><td>CVV-25 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-4</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>100,670</td></tr><tr><td>1369</td><td>Vật liệu
ngành điện</td><td>CVV-50– 0,6/1 kV</td><td>m</td><td>TCVN 5935-5</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>186,500</td></tr><tr><td>1370</td><td>Vật liệu
ngành điện</td><td>CVV-95 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-6</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>364,220</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1371</td><td>Vật liệu
ngành điện</td><td>CVV-150 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-7</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>563,430</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 300/500V (2 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1372</td><td>Vật liệu
ngành điện</td><td>CVV-2x1.5 (2x7/0.52)–
300/500 V</td><td>m</td><td>TCVN 6610-4</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>21,150</td></tr><tr><td>1373</td><td>Vật liệu
ngành điện</td><td>CVV-2x4 (2x7/0.85)–
300/500 V</td><td>m</td><td>TCVN 6610-5</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>45,790</td></tr><tr><td>1374</td><td>Vật liệu
ngành điện</td><td>CVV-2x10 (2x7/1.35)–
300/500 V</td><td>m</td><td>TCVN 6610-6</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>102,130</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 300/500V (3 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1375</td><td>Vật liệu
ngành điện</td><td>CVV-3x1.5 (3x7/0.52) –
300/500 V</td><td>m</td><td>TCVN 6610-4</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>27,900</td></tr><tr><td>1376</td><td>Vật liệu
ngành điện</td><td>CVV-3x2.5 (3x7/0.67) –
300/500 V</td><td>m</td><td>TCVN 6610-5</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>42,160</td></tr><tr><td>1377</td><td>Vật liệu
ngành điện</td><td>CVV-3x6 (3x7/1.04) –
300/500 V</td><td>m</td><td>TCVN 6610-6</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>86,180</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 300/500V (4 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1378</td><td>Vật liệu
ngành điện</td><td>CVV-4x1.5 (4x7/0.52) –
300/500 V</td><td>m</td><td>TCVN 6610-6</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>35,500</td></tr><tr><td>1379</td><td>Vật liệu
ngành điện</td><td>CVV-4x2.5 (4x7/0.67) –
300/500 V</td><td>m</td><td>TCVN 6610-6</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>53,670</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 0,6/1kV (2 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1380</td><td>Vật liệu
ngành điện</td><td>CVV-2x16 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>155,160</td></tr><tr><td>1381</td><td>Vật liệu
ngành điện</td><td>CVV-2x25 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>224,960</td></tr><tr><td>1382</td><td>Vật liệu
ngành điện</td><td>CVV-2x150 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.177.670</td></tr><tr><td>1383</td><td>Vật liệu
ngành điện</td><td>CVV-2x185 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-4</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.465.920</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 0,6/1kV (3 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1384</td><td>Vật liệu
ngành điện</td><td>CVV-3x16 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>219,170</td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1385</td><td>Vật liệu
ngành điện</td><td>CVV-3x50 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>578,620</td></tr><tr><td>1386</td><td>Vật liệu
ngành điện</td><td>CVV-3x95 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.124.600</td></tr><tr><td>1387</td><td>Vật liệu
ngành điện</td><td>CVV-3x120 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.455.830</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 0,6/1kV (4 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1388</td><td>Vật liệu
ngành điện</td><td>CVV-4x16 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>281,320</td></tr><tr><td>1389</td><td>Vật liệu
ngành điện</td><td>CVV-4x25 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>417,050</td></tr><tr><td>1390</td><td>Vật liệu
ngành điện</td><td>CVV-4x50 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>778,040</td></tr><tr><td>1391</td><td>Vật liệu
ngành điện</td><td>CVV-4x120 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.928.790</td></tr><tr><td>1392</td><td>Vật liệu
ngành điện</td><td>CVV-4x185 – 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>2.866.530</td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 0,6/1kV (3 lõi pha + 1 lõi đất, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1393</td><td>Vật liệu
ngành điện</td><td>CVV-3x16+1x10 -
0,6/1kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>264,470</td></tr><tr><td>1394</td><td>Vật liệu
ngành điện</td><td>CVV-3x25+1x16 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>381,680</td></tr><tr><td>1395</td><td>Vật liệu
ngành điện</td><td>CVV-3x50+1x25 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH
MTV
CADIVI</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>678,470</td></tr><tr><td>1396</td><td>Vật liệu
ngành điện</td><td>CVV-3x95+1x50 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.308.730</td></tr><tr><td>1397</td><td>Vật liệu
ngành điện</td><td>CVV-3x120+1x70 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.726.140</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế có giáp bảo vệ- 0,6/1 kV- (1 lõi ruột đồng, cách điện PVC, giáp băng nhôm bảo vệ, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1398</td><td>Vật liệu
ngành điện</td><td>CVV/DATA-25-0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>138,060</td></tr><tr><td>1399</td><td>Vật liệu
ngành điện</td><td>CVV/DATA-50-0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>231,380</td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1400</td><td>Vật liệu
ngành điện</td><td>CVV/DATA-95-0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>413,850</td></tr><tr><td>1401</td><td>Vật liệu
ngành điện</td><td>CVV/DATA-240-0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>990,690</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế có giáp bảo vệ- 0,6/1 kV- (2 lõi ruột đồng, cách điện PVC, giáp băng nhôm bảo vệ, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1402</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-2x4
(2x7/0.85) - 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>71,110</td></tr><tr><td>1403</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-2x10
(2x7/1.35)
-0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>124,530</td></tr><tr><td>1404</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-2x50 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>432,240</td></tr><tr><td>1405</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-2x150-0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.274.540</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế có giáp bảo vệ- 0,6/1 kV- (3 lõi ruột đồng, cách điện PVC, giáp băng nhôm bảo vệ, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1406</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-3x6 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>116,810</td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1407</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-3x16 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>240,040</td></tr><tr><td>1408</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-3x50 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH
MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>615,780</td></tr><tr><td>1409</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-3x185 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>2.282.560</td></tr><tr><td>1410</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-3x4+1x2.5 -
0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>103,290</td></tr><tr><td>1411</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA-3x16+1x10 -
0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>288,830</td></tr><tr><td>1412</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA -3x50+1x25
- 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>724,410</td></tr><tr><td>1413</td><td>Vật liệu
ngành điện</td><td>CVV/DSTA -
3x240+1x120 - 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>3.581.680</td></tr><tr><td>*</td><td>Dây đồng trần xoắn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1414</td><td>Vật liệu
ngành điện</td><td>C-10</td><td>m</td><td>TCVN - 5064</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>36,790</td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>CADIVI
Miền Bắc</td><td></td><td></td><td></td><td></td></tr><tr><td>1415</td><td>Vật liệu
ngành điện</td><td>C-50</td><td>m</td><td>TCVN - 5064</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>183,450</td></tr><tr><td>*</td><td>Cáp điện kế – 0,6/1 kV- (2 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1416</td><td>Vật liệu
ngành điện</td><td>DK-CVV-2x4 -0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>60,430</td></tr><tr><td>1417</td><td>Vật liệu
ngành điện</td><td>DK-CVV-2x10 -0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>121,440</td></tr><tr><td>1418</td><td>Vật liệu
ngành điện</td><td>DK-CVV-2x35 -0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>326,820</td></tr><tr><td>*</td><td>Cáp điều khiển - 0,6/1 kV- (2-&gt;37 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1419</td><td>Vật liệu
ngành điện</td><td>DVV-2x1.5 (2x7/0.52) -
0,6/1
kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>22,330</td></tr><tr><td>1420</td><td>Vật liệu
ngành điện</td><td>DVV-10x2.5 (10x7/0.67)
- 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>120,740</td></tr><tr><td>1421</td><td>Vật liệu
ngành điện</td><td>DVV-19x4 (19x7/0.85) -
0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>345,700</td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>CADIVI
Miền Bắc</td><td></td><td></td><td></td><td></td></tr><tr><td>1422</td><td>Vật liệu
ngành điện</td><td>DVV-37x2.5 (37x7/0.67)
- 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>424,770</td></tr><tr><td>*</td><td>Cáp điều khiển có màn chắn chống nhiễu - 0,6/1 kV- (2-&gt;37 lõi, ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1423</td><td>Vật liệu
ngành điện</td><td>DVV/Sc-3x1.5 (3x7/0.52)
- 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>42,260</td></tr><tr><td>1424</td><td>Vật liệu
ngành điện</td><td>DVV/Sc-8x2.5 (8x7/0.67)
- 0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>118,480</td></tr><tr><td>1425</td><td>Vật liệu
ngành điện</td><td>DVV/Sc-30x2.5
(30x7/0.67)
-0,6/1 kV</td><td>m</td><td>TCVN 5935-1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>374,900</td></tr><tr><td>*</td><td>Cáp trung thế treo-12/20(24) kV hoặc 12.7/22(24) kV - (ruột đồng, có chống thấm, bán dẫn ruột dẫn, cách điện XLPE, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1426</td><td>Vật liệu
ngành điện</td><td>CX1V/WBC-95-
12/20(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>422,630</td></tr><tr><td>1427</td><td>Vật liệu
ngành điện</td><td>CX1V/WBC-240-
12/20(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>994,340</td></tr><tr><td>*</td><td>Dây điện lực (AV)-0,6/1kV</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1428</td><td>Vật liệu
ngành điện</td><td>AV-16-0,6/1 kV</td><td>m</td><td>AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>8,620</td></tr><tr><td>1429</td><td>Vật liệu
ngành điện</td><td>AV-35-0,6/1 kV</td><td>m</td><td>AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>15,810</td></tr><tr><td>1430</td><td>Vật liệu
ngành điện</td><td>AV-120-0,6/1 kV</td><td>m</td><td>AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>49,330</td></tr><tr><td>1431</td><td>Vật liệu
ngành điện</td><td>AV-500-0,6/1 kV</td><td>m</td><td>AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>196,070</td></tr><tr><td>*</td><td>Dây nhôm lõi thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1432</td><td>Vật liệu
ngành điện</td><td>ACSR-50/8 (6/3.2+1/3.2)</td><td>m</td><td>TCVN 5064</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>19,450</td></tr><tr><td>1433</td><td>Vật liệu
ngành điện</td><td>ACSR-95/16
(6/4.5+1/4.5)</td><td>m</td><td>TCVN 5064</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>37,680</td></tr><tr><td>1434</td><td>Vật liệu
ngành điện</td><td>ACSR-240/32
(24/3.6+7/2.4)</td><td>m</td><td>TCVN 5064</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>93,820</td></tr><tr><td>*</td><td>Cáp vặn xoắn hạ thế -0,6/1 kV- (2 lõi, ruột nhôm, cách điện XLPE)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1435</td><td>Vật liệu
ngành điện</td><td>LV-ABC-2x50-0,6/1 kV
(ruột nhôm)</td><td>m</td><td>TCVN
6447/AS 3560</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>44,340</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế chống cháy 0,6/1 kV- (1 lõi, ruột đồng, cách điện FR-PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1436</td><td>Vật liệu
ngành điện</td><td>CV/FR-1x25 -0,6/1 kV</td><td>m</td><td>TCVN 5935-
1/IEC 60331-
21,
IEC 60332-3
CAT C</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>106,740</td></tr><tr><td>1437</td><td>Vật liệu
ngành điện</td><td>CV/FR-1x240 -0,6/1 kV</td><td>m</td><td>TCVN 5935-
1/IEC 60331-
21,
IEC 60332-3
CAT C</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>945,620</td></tr><tr><td>*</td><td>Ống luồn dây điện :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1438</td><td>Vật liệu
ngành điện</td><td>Ống luồn tròn F16 dài
2,9 m</td><td>ống</td><td>BSEN 61386-
21;
BS4607;
TCVN 7417-21</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>26,420</td></tr><tr><td>1439</td><td>Vật liệu
ngành điện</td><td>Ống luồn cứng F16-
1250N- CA16H</td><td>ống</td><td>BSEN 61386-
21;
BS4607;
TCVN 7417-21</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>30,650</td></tr><tr><td>1440</td><td>Vật liệu
ngành điện</td><td>Ống luồn đàn hồi CAF-
16</td><td>cuộn</td><td>BSEN 61386-
21;
BS4607;
TCVN 7417-21</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>246,930</td></tr><tr><td>1441</td><td>Vật liệu
ngành điện</td><td>Ống luồn đàn hồi CAF-
20</td><td>cuộn</td><td>BSEN 61386-
21;
BS4607;
TCVN 7417-21</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>342,930</td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>*</td><td>Dây đồng đơn cứng bọc PVC – 300/500
V</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1442</td><td>Vật liệu
ngành điện</td><td>VC-0,50 (F 0,80)-
300/500 V</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>2,630</td></tr><tr><td>1443</td><td>Vật liệu
ngành điện</td><td>VC-1,00 (F1,13)-
300/500 V</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>4,350</td></tr><tr><td>*</td><td>Dây điện bọc nhựa PVC - 0,6/1 kV (ruột đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1444</td><td>Vật liệu
ngành điện</td><td>VCmd-2x0.5-(2x16/0.2)-
0,6/1 kV</td><td>m</td><td>TC AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>5,040</td></tr><tr><td>1445</td><td>Vật liệu
ngành điện</td><td>VCmd-2x0.75-
(2x24/0.2)- 0,6/1 kV</td><td>m</td><td>TC AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>7,110</td></tr><tr><td>1446</td><td>Vật liệu
ngành điện</td><td>VCmd-2x1-(2x32/0.2)-
0,6/1
kV</td><td>m</td><td>TC AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>9,120</td></tr><tr><td>1447</td><td>Vật liệu
ngành điện</td><td>VCmd-2x1,5-
(2x30/0.25)- 0,6/1 kV</td><td>m</td><td>TC AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>13,000</td></tr><tr><td>1448</td><td>Vật liệu
ngành điện</td><td>VCmd-2x2,5-
(2x50/0.25)- 0,6/1 kV</td><td>m</td><td>TC AS/NZS
5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>21,070</td></tr><tr><td>*</td><td>Dây điện mềm bọc nhựa PVC - 300/500V- (ruột đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_28>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1449</td><td>Vật liệu
ngành điện</td><td>VCmo-2x1-(2x32/0.2)-
300/500 V</td><td>m</td><td>TCVN 6610-5</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>10,480</td></tr><tr><td>1450</td><td>Vật liệu
ngành điện</td><td>VCmo-2x1.5-
(2x30/0.25)- 300/500 V</td><td>m</td><td>TCVN 6610-5</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>14,760</td></tr><tr><td>1451</td><td>Vật liệu
ngành điện</td><td>VCmo-2x6-
(2x7x12/0.30)- 300/500
V</td><td>m</td><td>TCVN 6610-5</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>53,720</td></tr><tr><td>*</td><td>Cáp điện lực hạ thế - 0.6/1kV-(ruột
đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1452</td><td>Vật liệu
ngành điện</td><td>CV-1.5 (7/0.52) -
0.6/1kV</td><td>m</td><td>TC
AS/NZS5000.1</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>6,760</td></tr><tr><td>1453</td><td>Vật liệu
ngành điện</td><td>CV-2.5 (7/0.67) -
0.6/1kV</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>11,030</td></tr><tr><td>1454</td><td>Vật liệu
ngành điện</td><td>CV-10 (7/1.35) -
0.6/1kV</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>40,560</td></tr><tr><td>1455</td><td>Vật liệu
ngành điện</td><td>CV-50 - 0.6/1kV</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>178,670</td></tr><tr><td>1456</td><td>Vật liệu
ngành điện</td><td>CV-240 - 0.6/1kV</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>897,730</td></tr></tbody></table>

|<image_29>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>CADIVI
Miền Bắc</td><td></td><td></td><td></td><td></td></tr><tr><td>1457</td><td>Vật liệu
ngành điện</td><td>CV-300 - 0.6/1kV</td><td>m</td><td>TCVN 6610-3</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.126.030</td></tr><tr><td>*</td><td>Cáp trung thế có màn chắn kim loại - 12/20(24) kV hoặc 12.7/22(24) kV - (3 lõi, ruột đồng, bán dẫn ruột dẫn, cách điện XLPE, bán dẫn cách điện, màn chắn kim
loại cho từng lõi, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1458</td><td>Vật liệu
ngành điện</td><td>CXV/SE-DSTA-3x50-
12/20(24) kV</td><td>m</td><td>TCVN 5935-2/
IEC 60502-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.055.760</td></tr><tr><td>1459</td><td>Vật liệu
ngành điện</td><td>CXV/SE-DSTA-3x400-
12/20(24) kV</td><td>m</td><td>TCVN 5935-2/
IEC 60502-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>5.360.010</td></tr><tr><td>*</td><td>Cáp năng lượng mặt trời</td><td></td><td>m</td><td>TCVN 5935-2/
IEC 60502-2</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td></td></tr><tr><td>1460</td><td>Vật liệu
ngành điện</td><td>H1Z2Z2-K-4-1,5kV DC</td><td>m</td><td>BS EN 50618</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>23,640</td></tr><tr><td>1461</td><td>Vật liệu
ngành điện</td><td>H1Z2Z2-K-6-1,5kV DC</td><td>m</td><td>BS EN 50618</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>33,680</td></tr><tr><td>1462</td><td>Vật liệu
ngành điện</td><td>H1Z2Z2-K-300-1,5kV
DC</td><td>m</td><td>BS EN 50618</td><td>CU/PVC/PVC</td><td>Công ty
TNHH MTV
CADIVI
Miền Bắc</td><td>không</td><td>hàng giao tại
kho người mua</td><td></td><td>1.390.260</td></tr></tbody></table>

|<image_30>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>14,3</td><td>Dây cáp điện CADI-SUN (Công ty CP dây và cáp điện Thượng Đình)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Đại lý: Công ty CP TM đầu tư xây dựng Dũng Linh-156 Bến Bắc, Tam Thanh, tp. Lạng Sơn. Cửa hàng Thiết bị điện Cao Ban - 123, Trần Đăng Ninh, tp Lạng Sơn.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cáp đồng trần</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1463</td><td>Vật liệu
ngành điện</td><td>CF 10</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>416,921</td></tr><tr><td>1464</td><td>Vật liệu
ngành điện</td><td>CF 16</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>412,136</td></tr><tr><td>1465</td><td>Vật liệu
ngành điện</td><td>CF 25</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>412,044</td></tr><tr><td>1466</td><td>Vật liệu
ngành điện</td><td>CF 35</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>411,773</td></tr><tr><td>1467</td><td>Vật liệu
ngành điện</td><td>CF 50</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>412,650</td></tr><tr><td>1468</td><td>Vật liệu
ngành điện</td><td>CF 70</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>412,112</td></tr></tbody></table>

|<image_31>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1469</td><td>Vật liệu
ngành điện</td><td>CF 95</td><td>kg</td><td>TCVN
5604:1994</td><td>Cuộn 8000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>412,019</td></tr><tr><td>*</td><td>Cáp đồng bọc PVC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1470</td><td>Vật liệu
ngành điện</td><td>CV 1x16 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>59,742</td></tr><tr><td>1471</td><td>Vật liệu
ngành điện</td><td>CV 1x25 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>92,409</td></tr><tr><td>1472</td><td>Vật liệu
ngành điện</td><td>CV 1x35 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 2000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>128,734</td></tr><tr><td>1473</td><td>Vật liệu
ngành điện</td><td>CV 1x50 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 2000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>177,021</td></tr><tr><td>1474</td><td>Vật liệu
ngành điện</td><td>CV 1x70 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 2000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>250,957</td></tr></tbody></table>

|<image_32>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1475</td><td>Vật liệu
ngành điện</td><td>CV 1x95 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 2000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>350,221</td></tr><tr><td>1476</td><td>Vật liệu
ngành điện</td><td>CV 1x120 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>438,442</td></tr><tr><td>1477</td><td>Vật liệu
ngành điện</td><td>CV 1x150 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>546,396</td></tr><tr><td>1478</td><td>Vật liệu
ngành điện</td><td>CV 1x185 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>680,175</td></tr><tr><td>1479</td><td>Vật liệu
ngành điện</td><td>CV 1x240 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>895,791</td></tr><tr><td>*</td><td>Cáp đồng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1480</td><td>Vật liệu
ngành điện</td><td>CXV 1x50</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>179,056</td></tr></tbody></table>

|<image_33>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1481</td><td>Vật liệu
ngành điện</td><td>CXV 1x70</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>253,513</td></tr><tr><td>1482</td><td>Vật liệu
ngành điện</td><td>CXV 1x95</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>352,445</td></tr><tr><td>1483</td><td>Vật liệu
ngành điện</td><td>CXV 1x120</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>441,670</td></tr><tr><td>1484</td><td>Vật liệu
ngành điện</td><td>CXV 1x150</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>549,802</td></tr><tr><td>1485</td><td>Vật liệu
ngành điện</td><td>CXV 1x185</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>683,787</td></tr><tr><td>1486</td><td>Vật liệu
ngành điện</td><td>CXV 1x240</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>899,961</td></tr><tr><td>1487</td><td>Vật liệu
ngành điện</td><td>CXV 1x300</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.124.796</td></tr></tbody></table>

|<image_34>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1488</td><td>Vật liệu
ngành điện</td><td>CXV 1x400</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.456.049</td></tr><tr><td>1489</td><td>Vật liệu
ngành điện</td><td>CXV 2x6</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>54,094</td></tr><tr><td>1490</td><td>Vật liệu
ngành điện</td><td>CXV 2x10</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>83,778</td></tr><tr><td>1491</td><td>Vật liệu
ngành điện</td><td>CXV 2x16</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>128,337</td></tr><tr><td>1492</td><td>Vật liệu
ngành điện</td><td>CXV 2x25</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>197,227</td></tr><tr><td>1493</td><td>Vật liệu
ngành điện</td><td>CXV 3x10</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>123,646</td></tr></tbody></table>

|<image_35>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1494</td><td>Vật liệu
ngành điện</td><td>CXV 3x16</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>188,681</td></tr><tr><td>1495</td><td>Vật liệu
ngành điện</td><td>CXV 3x25</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>291,231</td></tr><tr><td>1496</td><td>Vật liệu
ngành điện</td><td>CXV 4x10</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>162,350</td></tr><tr><td>1497</td><td>Vật liệu
ngành điện</td><td>CXV 4x16</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>248,700</td></tr><tr><td>1498</td><td>Vật liệu
ngành điện</td><td>CXV 4x25</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>385,326</td></tr><tr><td>1499</td><td>Vật liệu
ngành điện</td><td>CXV 4x35</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>532,980</td></tr><tr><td>1500</td><td>Vật liệu
ngành điện</td><td>CXV 4x50</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>731,781</td></tr></tbody></table>

|<image_36>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1501</td><td>Vật liệu
ngành điện</td><td>CXV 4x70</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.037.129</td></tr><tr><td>1502</td><td>Vật liệu
ngành điện</td><td>CXV 4x95</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.426.439</td></tr><tr><td>1503</td><td>Vật liệu
ngành điện</td><td>CXV 4x120</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.786.532</td></tr><tr><td>1504</td><td>Vật liệu
ngành điện</td><td>CXV 4x150</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2.224.415</td></tr><tr><td>1505</td><td>Vật liệu
ngành điện</td><td>CXV 4x185</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2.765.613</td></tr><tr><td>1506</td><td>Vật liệu
ngành điện</td><td>CXV 4x240</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Cu/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>3.635.348</td></tr><tr><td>*</td><td>Cáp điện kế Muller</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_37>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1507</td><td>Vật liệu
ngành điện</td><td>MULLER 2x4</td><td>m</td><td>TCVN 5935-1</td><td>Cu(Al)/XLPE/PVC/
ATA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>47,712</td></tr><tr><td>1508</td><td>Vật liệu
ngành điện</td><td>MULLER 2x6</td><td>m</td><td>TCVN 5935-1</td><td>Cu(Al)/XLPE/PVC/
ATA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>64,448</td></tr><tr><td>1509</td><td>Vật liệu
ngành điện</td><td>MULLER 2x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu(Al)/XLPE/PVC/
ATA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>140,541</td></tr><tr><td>*</td><td>Cáp đồng ngầm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1510</td><td>Vật liệu
ngành điện</td><td>DATA 1x120</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DA
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>468,198</td></tr><tr><td>1511</td><td>Vật liệu
ngành điện</td><td>DATA 1x150</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DA
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>578,686</td></tr><tr><td>1512</td><td>Vật liệu
ngành điện</td><td>DATA 1x185</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DA
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>714,810</td></tr></tbody></table>

|<image_38>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1513</td><td>Vật liệu
ngành điện</td><td>DATA 1x240</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DA
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>934,818</td></tr><tr><td>1514</td><td>Vật liệu
ngành điện</td><td>DATA 1x300</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DA
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.165.131</td></tr><tr><td>1515</td><td>Vật liệu
ngành điện</td><td>DATA 1x400</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DA
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.502.527</td></tr><tr><td>1516</td><td>Vật liệu
ngành điện</td><td>DSTA 2x6</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>66,172</td></tr><tr><td>1517</td><td>Vật liệu
ngành điện</td><td>DSTA 2x10</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>97,428</td></tr><tr><td>1518</td><td>Vật liệu
ngành điện</td><td>DSTA 2x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>144,268</td></tr><tr><td>1519</td><td>Vật liệu
ngành điện</td><td>DSTA 4x10</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>176,869</td></tr></tbody></table>

|<image_39>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1520</td><td>Vật liệu
ngành điện</td><td>DSTA 4x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>267,490</td></tr><tr><td>1521</td><td>Vật liệu
ngành điện</td><td>DSTA 4x25</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>403,795</td></tr><tr><td>1522</td><td>Vật liệu
ngành điện</td><td>DSTA 4x35</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>554,534</td></tr><tr><td>1523</td><td>Vật liệu
ngành điện</td><td>DSTA 4x50</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>756,057</td></tr><tr><td>1524</td><td>Vật liệu
ngành điện</td><td>DSTA 4x70</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.076.648</td></tr><tr><td>1525</td><td>Vật liệu
ngành điện</td><td>DSTA 4x95</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.468.772</td></tr></tbody></table>

|<image_40>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1526</td><td>Vật liệu
ngành điện</td><td>DSTA 4x120</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.836.178</td></tr><tr><td>1527</td><td>Vật liệu
ngành điện</td><td>DSTA 4x150</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2.280.783</td></tr><tr><td>1528</td><td>Vật liệu
ngành điện</td><td>DSTA 4x185</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2.831.554</td></tr><tr><td>*</td><td>Dây điện áp bên trong CTr</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1529</td><td>Vật liệu
ngành điện</td><td>VCSF 1x0.5 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2,464</td></tr><tr><td>1530</td><td>Vật liệu
ngành điện</td><td>VCSF 1x0.75 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>3,522</td></tr><tr><td>1531</td><td>Vật liệu
ngành điện</td><td>VCSF 1x1.0 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>4,354</td></tr></tbody></table>

|<image_41>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1532</td><td>Vật liệu
ngành điện</td><td>VCSF 1x1.5 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>6,225</td></tr><tr><td>1533</td><td>Vật liệu
ngành điện</td><td>VCSF 1x2.5 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>10,108</td></tr><tr><td>1534</td><td>Vật liệu
ngành điện</td><td>VCSF 1x4.0 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>16,011</td></tr><tr><td>1535</td><td>Vật liệu
ngành điện</td><td>VCSF 1x6.0 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>24,375</td></tr><tr><td>1536</td><td>Vật liệu
ngành điện</td><td>VCSF 1x10.0 - 300/500V</td><td>m</td><td>TCVN 6610-3</td><td>Cuộn 100m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>43,131</td></tr><tr><td>*</td><td>Cáp đồng đơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1537</td><td>Vật liệu
ngành điện</td><td>CV 1x1.5 (V-75 )</td><td>m</td><td>AS/NZS
5000.1:
2005</td><td>Cuộn 10000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>6,666</td></tr></tbody></table>

|<image_42>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1538</td><td>Vật liệu
ngành điện</td><td>CV 1x2.5 (V-75 )</td><td>m</td><td>AS/NZS
5000.1:
2006</td><td>Cuộn 10000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>10,677</td></tr><tr><td>1539</td><td>Vật liệu
ngành điện</td><td>CV 1x4.0 (V-75 )</td><td>m</td><td>AS/NZS
5000.1:
2007</td><td>Cuộn 10000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>16,786</td></tr><tr><td>1540</td><td>Vật liệu
ngành điện</td><td>CV 1x6.0 (V-75 )</td><td>m</td><td>AS/NZS
5000.1:
2008</td><td>Cuộn 10000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>24,619</td></tr><tr><td>1541</td><td>Vật liệu
ngành điện</td><td>CV 1x10 (V-75 )</td><td>m</td><td>AS/NZS
5000.1:
2009</td><td>Cuộn 10000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>38,891</td></tr><tr><td>*</td><td>Dây ovan 2 ruột mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1542</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x0.75</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>8,266</td></tr><tr><td>1543</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x1.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>10,130</td></tr></tbody></table>

|<image_43>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1544</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x1.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>13,991</td></tr><tr><td>1545</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>22,536</td></tr><tr><td>1546</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x4.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>35,387</td></tr><tr><td>1547</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x6.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>52,863</td></tr><tr><td>*</td><td>Dây tròn đặc 2 ruột mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1548</td><td>Vật liệu
ngành điện</td><td>VCTF 2x0.75</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>9,326</td></tr><tr><td>1549</td><td>Vật liệu
ngành điện</td><td>VCTF 2x1.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>11,274</td></tr></tbody></table>

|<image_44>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1550</td><td>Vật liệu
ngành điện</td><td>VCTF 2x1.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>15,546</td></tr><tr><td>1551</td><td>Vật liệu
ngành điện</td><td>VCTF 2x2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>24,818</td></tr><tr><td>1552</td><td>Vật liệu
ngành điện</td><td>VCTF 4x2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>45,971</td></tr><tr><td>1553</td><td>Vật liệu
ngành điện</td><td>VCTF 4x4.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>71,156</td></tr><tr><td>1554</td><td>Vật liệu
ngành điện</td><td>VCTF 4x6.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>107,021</td></tr><tr><td>*</td><td>Dây đơn cứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1555</td><td>Vật liệu
ngành điện</td><td>VCSH 1x1.5</td><td>m</td><td>TCVN 6610-3</td><td>Cu/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>6,405</td></tr></tbody></table>

|<image_45>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1556</td><td>Vật liệu
ngành điện</td><td>VCSH 1x2.5</td><td>m</td><td>TCVN 6610-3</td><td>Cu/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>10,187</td></tr><tr><td>1557</td><td>Vật liệu
ngành điện</td><td>VCSH 1x4.0</td><td>m</td><td>TCVN 6610-3</td><td>Cu/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>16,490</td></tr><tr><td>1558</td><td>Vật liệu
ngành điện</td><td>VCSH 1x6.0</td><td>m</td><td>TCVN 6610-3</td><td>Cu/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>24,645</td></tr><tr><td>*</td><td>Cáp Mica</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1559</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x16</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>65,587</td></tr><tr><td>1560</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x25</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>99,786</td></tr><tr><td>1561</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x35</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>137,161</td></tr></tbody></table>

|<image_46>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1562</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x50</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>186,342</td></tr><tr><td>1563</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x70</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>261,871</td></tr><tr><td>1564</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x95</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>362,310</td></tr><tr><td>1565</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 1x120</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>452,433</td></tr><tr><td>1566</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 2x1.5 (Đặc)</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>23,479</td></tr><tr><td>1567</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 2x2.5 (Đặc)</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>33,223</td></tr><tr><td>1568</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 2x4.0 (Đặc)</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>46,720</td></tr></tbody></table>

|<image_47>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1569</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 2x6.0</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>62,440</td></tr><tr><td>1570</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 2x10</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>92,209</td></tr><tr><td>1571</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x4.0</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>84,370</td></tr><tr><td>1572</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x6.0</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>117,616</td></tr><tr><td>1573</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x10</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>176,529</td></tr><tr><td>1574</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x16</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>265,306</td></tr></tbody></table>

|<image_48>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1575</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x25</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>407,675</td></tr><tr><td>1576</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x35</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>561,846</td></tr><tr><td>1577</td><td>Vật liệu
ngành điện</td><td>FRN-CXV 4x50</td><td>m</td><td>TCVN 60502-1</td><td>Cu/Mica/XLPE/Fr-
PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>762,468</td></tr><tr><td>*</td><td>Cáp trung thế đồng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1578</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x35
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>225,721</td></tr><tr><td>1579</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x50
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>282,142</td></tr><tr><td>1580</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x70
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>363,108</td></tr></tbody></table>

|<image_49>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1581</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x95
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>470,109</td></tr><tr><td>1582</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x120
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>567,280</td></tr><tr><td>1583</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x150
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>680,524</td></tr><tr><td>1584</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x185
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>829,944</td></tr><tr><td>1585</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x240
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.057.445</td></tr><tr><td>1586</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x35
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>262,007</td></tr><tr><td>1587</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x50
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>318,703</td></tr></tbody></table>

|<image_50>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1588</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x70
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>403,113</td></tr><tr><td>1589</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x95
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>513,796</td></tr><tr><td>1590</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x120
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>614,595</td></tr><tr><td>1591</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x150
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>728,786</td></tr><tr><td>1592</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x185
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>881,509</td></tr><tr><td>1593</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x240
(24)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.112.457</td></tr></tbody></table>

|<image_51>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1594</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x50
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>328,548</td></tr><tr><td>1595</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x70
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>412,683</td></tr><tr><td>1596</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x95
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>522,169</td></tr><tr><td>1597</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x120
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>623,119</td></tr><tr><td>1598</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x150
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>737,069</td></tr><tr><td>1599</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x185
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>888,852</td></tr><tr><td>1600</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x240
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.118.969</td></tr></tbody></table>

|<image_52>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1601</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x300
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.365.102</td></tr><tr><td>1602</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x400
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.717.737</td></tr><tr><td>1603</td><td>Vật liệu
ngành điện</td><td>CXV/CTS-W 1x500
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2.127.966</td></tr><tr><td>1604</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x50
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>376,023</td></tr><tr><td>1605</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x70
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>463,537</td></tr><tr><td>1606</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x95
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>576,149</td></tr></tbody></table>

|<image_53>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1607</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x120
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>676,869</td></tr><tr><td>1608</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x150
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>794,265</td></tr><tr><td>1609</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x185
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>950,540</td></tr><tr><td>1610</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x240
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.185.130</td></tr><tr><td>1611</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x300
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.434.094</td></tr><tr><td>1612</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x400
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.793.449</td></tr><tr><td>1613</td><td>Vật liệu
ngành điện</td><td>DATA/CTS-W 1x500
(40.5)kV</td><td>m</td><td>TCVN 5935-2</td><td>Cuộn 1000m</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>2.210.563</td></tr></tbody></table>

|<image_54>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cáp nhôm đơn cách điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1614</td><td>Vật liệu
ngành điện</td><td>AV 1x95 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>38,383</td></tr><tr><td>1615</td><td>Vật liệu
ngành điện</td><td>AV 1x120 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>47,623</td></tr><tr><td>1616</td><td>Vật liệu
ngành điện</td><td>AV 1x150 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>58,859</td></tr><tr><td>1617</td><td>Vật liệu
ngành điện</td><td>AV 1x185 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>72,829</td></tr><tr><td>1618</td><td>Vật liệu
ngành điện</td><td>AV 1x240 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>93,713</td></tr><tr><td>1619</td><td>Vật liệu
ngành điện</td><td>AV 1x300 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>115,465</td></tr></tbody></table>

|<image_55>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1620</td><td>Vật liệu
ngành điện</td><td>AV 1x400 (V-75)</td><td>m</td><td>AS/NZS
5000.1:2005</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>153,167</td></tr><tr><td>*</td><td>Cáp nhôm ngầm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1621</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/PVC/ADSTA
4x150 - 0.6/1 KV</td><td>m</td><td>TCVN:5935-1</td><td>PVC/DATA</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>335,326</td></tr><tr><td>1622</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/PVC/ADSTA
4x185 - 0.6/1 KV</td><td>m</td><td>TCVN:5935-1</td><td>PVC/DATA</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>406,644</td></tr><tr><td>1623</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/PVC/ADSTA
4x240 - 0.6/1 KV</td><td>m</td><td>TCVN:5935-1</td><td>PVC/DATA</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>510,327</td></tr><tr><td>1624</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/PVC/ADSTA
4x300 - 0.6/1 KV</td><td>m</td><td>TCVN:5935-1</td><td>PVC/DATA</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>611,262</td></tr><tr><td>*</td><td>Cáp nhôm vặn xoắn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1625</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 2x16</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>16,582</td></tr></tbody></table>

|<image_56>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1626</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 2x25</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>22,941</td></tr><tr><td>1627</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 2x35</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>29,487</td></tr><tr><td>1628</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x16</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>31,920</td></tr><tr><td>1629</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x25</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>44,902</td></tr><tr><td>1630</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x35</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>58,151</td></tr><tr><td>1631</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x50</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>79,632</td></tr><tr><td>1632</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x70</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>109,893</td></tr></tbody></table>

|<image_57>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1633</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x95</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>149,734</td></tr><tr><td>1634</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x120</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>184,700</td></tr><tr><td>1635</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x150</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>225,841</td></tr><tr><td>1636</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x185</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>280,753</td></tr><tr><td>1637</td><td>Vật liệu
ngành điện</td><td>AL/XLPE/ABC 4x240</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>358,389</td></tr><tr><td>*</td><td>Cáp nhôm trần lõi thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1638</td><td>Vật liệu
ngành điện</td><td>As 70/11</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>96,643</td></tr></tbody></table>

|<image_58>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1639</td><td>Vật liệu
ngành điện</td><td>As 95/16</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>96,546</td></tr><tr><td>1640</td><td>Vật liệu
ngành điện</td><td>As 120/19</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>101,176</td></tr><tr><td>1641</td><td>Vật liệu
ngành điện</td><td>As 120/27</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>94,881</td></tr><tr><td>1642</td><td>Vật liệu
ngành điện</td><td>As 150/19</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>104,203</td></tr><tr><td>1643</td><td>Vật liệu
ngành điện</td><td>As 150/24</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>100,128</td></tr><tr><td>1644</td><td>Vật liệu
ngành điện</td><td>As 185/24</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>102,825</td></tr><tr><td>1645</td><td>Vật liệu
ngành điện</td><td>As 185/29</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>100,293</td></tr></tbody></table>

|<image_59>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Cáp ruột nhôm lõi thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1646</td><td>Vật liệu
ngành điện</td><td>AsXV 35/6.2-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>32,577</td></tr><tr><td>1647</td><td>Vật liệu
ngành điện</td><td>AsXV 50/8.0-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>38,742</td></tr><tr><td>1648</td><td>Vật liệu
ngành điện</td><td>AsXV 70/11-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>50,180</td></tr><tr><td>1649</td><td>Vật liệu
ngành điện</td><td>AsXV 95/16-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>65,470</td></tr><tr><td>1650</td><td>Vật liệu
ngành điện</td><td>AsXV 120/19-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>75,851</td></tr><tr><td>1651</td><td>Vật liệu
ngành điện</td><td>AsXV 120/27-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>78,367</td></tr></tbody></table>

|<image_60>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1652</td><td>Vật liệu
ngành điện</td><td>AsXV 150/19-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>89,978</td></tr><tr><td>1653</td><td>Vật liệu
ngành điện</td><td>AsXV 150/24-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>92,741</td></tr><tr><td>1654</td><td>Vật liệu
ngành điện</td><td>AsXV 150/34-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>96,421</td></tr><tr><td>1655</td><td>Vật liệu
ngành điện</td><td>AsXV 185/24-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>109,409</td></tr><tr><td>1656</td><td>Vật liệu
ngành điện</td><td>AsXV 185/29-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>108,661</td></tr><tr><td>1657</td><td>Vật liệu
ngành điện</td><td>AsXV 185/43-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>116,766</td></tr><tr><td>1658</td><td>Vật liệu
ngành điện</td><td>AsXV 240/32-2.5 - 24kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>137,301</td></tr></tbody></table>

|<image_61>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1659</td><td>Vật liệu
ngành điện</td><td>AsXV 35/6.2-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>42,331</td></tr><tr><td>1660</td><td>Vật liệu
ngành điện</td><td>AsXV 50/8.0-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>49,240</td></tr><tr><td>1661</td><td>Vật liệu
ngành điện</td><td>AsXV 70/11-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>61,436</td></tr><tr><td>1662</td><td>Vật liệu
ngành điện</td><td>AsXV 95/16-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>78,420</td></tr><tr><td>1663</td><td>Vật liệu
ngành điện</td><td>AsXV 120/19-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>89,581</td></tr><tr><td>1664</td><td>Vật liệu
ngành điện</td><td>AsXV 120/27-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>92,160</td></tr></tbody></table>

|<image_62>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1665</td><td>Vật liệu
ngành điện</td><td>AsXV 150/19-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>104,532</td></tr><tr><td>1666</td><td>Vật liệu
ngành điện</td><td>AsXV 150/24-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>107,491</td></tr><tr><td>1667</td><td>Vật liệu
ngành điện</td><td>AsXV 150/34-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>111,366</td></tr><tr><td>1668</td><td>Vật liệu
ngành điện</td><td>AsXV 185/24-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>125,761</td></tr><tr><td>1669</td><td>Vật liệu
ngành điện</td><td>AsXV 185/29-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>124,961</td></tr><tr><td>1670</td><td>Vật liệu
ngành điện</td><td>AsXV 185/43-4.3 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>132,747</td></tr><tr><td>1671</td><td>Vật liệu
ngành điện</td><td>AsXE/S 50/8.0-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>46,595</td></tr></tbody></table>

|<image_63>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1672</td><td>Vật liệu
ngành điện</td><td>AsXE/S 70/11-2.5 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>57,726</td></tr><tr><td>1673</td><td>Vật liệu
ngành điện</td><td>AsXE/S 95/16-2.5 - 35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>72,362</td></tr><tr><td>1674</td><td>Vật liệu
ngành điện</td><td>AsXE/S 120/19-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>82,465</td></tr><tr><td>1675</td><td>Vật liệu
ngành điện</td><td>AsXE/S 120/27-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>84,319</td></tr><tr><td>1676</td><td>Vật liệu
ngành điện</td><td>AsXE/S 150/19-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>95,914</td></tr><tr><td>1677</td><td>Vật liệu
ngành điện</td><td>AsXE/S 150/24-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>98,676</td></tr></tbody></table>

|<image_64>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1678</td><td>Vật liệu
ngành điện</td><td>AsXE/S 150/34-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>102,338</td></tr><tr><td>1679</td><td>Vật liệu
ngành điện</td><td>AsXE/S 185/24-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>115,729</td></tr><tr><td>1680</td><td>Vật liệu
ngành điện</td><td>AsXE/S 185/29-2.5 -
35kV</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>114,844</td></tr><tr><td></td><td>Trung thế nhôm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1681</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x35
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>446,315</td></tr><tr><td>1682</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x50
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>480,034</td></tr><tr><td>1683</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x70
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>539,376</td></tr></tbody></table>

|<image_65>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1684</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x95
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>606,501</td></tr><tr><td>1685</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x120
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>664,574</td></tr><tr><td>1686</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x150
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>739,189</td></tr><tr><td>1687</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x185
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>816,044</td></tr><tr><td>1688</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x240
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>981,734</td></tr><tr><td>1689</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x300
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.100.922</td></tr><tr><td>1690</td><td>Vật liệu
ngành điện</td><td>ADSTA/CTS-W 3x400
(24)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>1.278.026</td></tr></tbody></table>

|<image_66>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Thượng
Đình</td><td></td><td></td><td></td><td></td></tr><tr><td>1691</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x50
(40.5)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>218,979</td></tr><tr><td>1692</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x70
(40.5)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>241,766</td></tr><tr><td>1693</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x95
(40.5)
kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>266,228</td></tr><tr><td>1694</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x120
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>285,217</td></tr><tr><td>1695</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x150
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>309,169</td></tr><tr><td>1696</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x185
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>338,924</td></tr></tbody></table>

|<image_67>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1697</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x240
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>380,721</td></tr><tr><td>1698</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x300
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>420,406</td></tr><tr><td>1699</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x400
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>479,851</td></tr><tr><td>1700</td><td>Vật liệu
ngành điện</td><td>ADATA/CTS-W 1x500
(40.5) kV</td><td>m</td><td>TCVN 5935-2</td><td>AL/XLPE/CTS/PV
C/DSTA/PVC</td><td>Công ty CP
dây và
cáp điện
Thượng
Đình</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn</td><td></td><td>553,614</td></tr><tr><td>14,4</td><td>Dây cáp điện Vạn Xuân</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>(Địa chỉ: KCN Lai Xá, xã Kim Chung, huyện Hoài Đức, thành phố Hà Nội, Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Dây đơn mềm 450/750V</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1701</td><td>Vật liệu
ngành điện</td><td>VCSF 1x1.5</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>7,000</td><td></td></tr><tr><td>1702</td><td>Vật liệu
ngành điện</td><td>VCSF 1x2.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>9,700</td><td></td></tr></tbody></table>

|<image_68>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1703</td><td>Vật liệu
ngành điện</td><td>VCSF 1x2.5</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>11,250</td><td></td></tr><tr><td>1704</td><td>Vật liệu
ngành điện</td><td>VCSF 1x3.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>14,400</td><td></td></tr><tr><td>1705</td><td>Vật liệu
ngành điện</td><td>VCSF 1x4.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>17,500</td><td></td></tr><tr><td>1706</td><td>Vật liệu
ngành điện</td><td>VCSF 1x6.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>26,900</td><td></td></tr><tr><td>1707</td><td>Vật liệu
ngành điện</td><td>VCSF 1x8.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>37,600</td><td></td></tr><tr><td>1708</td><td>Vật liệu
ngành điện</td><td>VCSF 1x10</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>47,500</td><td></td></tr><tr><td>*</td><td>Dây hạ thế 1 ruột cứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1709</td><td>Vật liệu
ngành điện</td><td>VC 1 x 1.5</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công</td><td>7,200</td><td></td></tr></tbody></table>

|<image_69>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>trình trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1710</td><td>Vật liệu
ngành điện</td><td>VC 1 x 2.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>9,600</td><td></td></tr><tr><td>1711</td><td>Vật liệu
ngành điện</td><td>VC 1 x 2.5</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>11,400</td><td></td></tr><tr><td>1712</td><td>Vật liệu
ngành điện</td><td>VC 1 x 4.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>18,400</td><td></td></tr><tr><td>1713</td><td>Vật liệu
ngành điện</td><td>VC 1 x 6.0</td><td>m</td><td>TCVN 6610-3</td><td>cuộn 100m</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>27,500</td><td></td></tr><tr><td>*</td><td>Dây o van 2 ruột mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1714</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x1.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>15,300</td><td></td></tr><tr><td>1715</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x2.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>21,200</td><td></td></tr></tbody></table>

|<image_70>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1716</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>24,500</td><td></td></tr><tr><td>1717</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x3.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>31,300</td><td></td></tr><tr><td>1718</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x4.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>39,000</td><td></td></tr><tr><td>1719</td><td>Vật liệu
ngành điện</td><td>VCTFK 2x6.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>58,000</td><td></td></tr><tr><td>*</td><td>Dây súp rãnh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1720</td><td>Vật liệu
ngành điện</td><td>CV 2 x 1.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>9,800</td><td></td></tr><tr><td>1721</td><td>Vật liệu
ngành điện</td><td>CV 2 x 1.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>14,000</td><td></td></tr></tbody></table>

|<image_71>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1722</td><td>Vật liệu
ngành điện</td><td>CV 2 x 2.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>19,500</td><td></td></tr><tr><td>1723</td><td>Vật liệu
ngành điện</td><td>CV 2 x 2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>22,000</td><td></td></tr><tr><td>*</td><td>Dây tròn 4 ruột mềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1724</td><td>Vật liệu
ngành điện</td><td>VCTF 4x1.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>31,200</td><td></td></tr><tr><td>1725</td><td>Vật liệu
ngành điện</td><td>VCTF 4x2.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>46,200</td><td></td></tr><tr><td>1726</td><td>Vật liệu
ngành điện</td><td>VCTF 4x2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>50,500</td><td></td></tr><tr><td>1727</td><td>Vật liệu
ngành điện</td><td>VCTF 4x3.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>62,300</td><td></td></tr><tr><td>1728</td><td>Vật liệu
ngành điện</td><td>VCTF 4x4.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công</td><td>78,500</td><td></td></tr></tbody></table>

|<image_72>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>trình trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1729</td><td>Vật liệu
ngành điện</td><td>VCTF 4x6.0</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>117,500</td><td></td></tr><tr><td>1730</td><td>Vật liệu
ngành điện</td><td>CVV 3x4+1x2.5</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>83,000</td><td></td></tr><tr><td>1731</td><td>Vật liệu
ngành điện</td><td>CVV 3x6+1x4</td><td>m</td><td>TCVN 6610-5</td><td>Cu/PVC/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>114,000</td><td></td></tr><tr><td>*</td><td>Cáp đồng 1 ruột 7-37 sợi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1732</td><td>Vật liệu
ngành điện</td><td>CV 1x4</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>19,000</td><td></td></tr><tr><td>1733</td><td>Vật liệu
ngành điện</td><td>CV 1x6</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>27,500</td><td></td></tr><tr><td>1734</td><td>Vật liệu
ngành điện</td><td>CV 1x10</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>44,500</td><td></td></tr></tbody></table>

|<image_73>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1735</td><td>Vật liệu
ngành điện</td><td>CV 1x16</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>68,000</td><td></td></tr><tr><td>1736</td><td>Vật liệu
ngành điện</td><td>CV 1x25</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>106,000</td><td></td></tr><tr><td>1737</td><td>Vật liệu
ngành điện</td><td>CV 1x35</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>145,000</td><td></td></tr><tr><td>1738</td><td>Vật liệu
ngành điện</td><td>CV 1x50</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>198,000</td><td></td></tr><tr><td>1739</td><td>Vật liệu
ngành điện</td><td>CV 1x70</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>285,000</td><td></td></tr><tr><td>1740</td><td>Vật liệu
ngành điện</td><td>CV 1x95</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>392,000</td><td></td></tr></tbody></table>

|<image_74>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1741</td><td>Vật liệu
ngành điện</td><td>CV 1x120</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>495,000</td><td></td></tr><tr><td>1742</td><td>Vật liệu
ngành điện</td><td>CV 1x150</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>620,000</td><td></td></tr><tr><td>1743</td><td>Vật liệu
ngành điện</td><td>CV 1x185</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>770,000</td><td></td></tr><tr><td>*</td><td>Cáp đồng 1 ruột</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1744</td><td>Vật liệu
ngành điện</td><td>CXV 1x4</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>20,800</td><td></td></tr><tr><td>1745</td><td>Vật liệu
ngành điện</td><td>CXV 1x6</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>29,500</td><td></td></tr><tr><td>1746</td><td>Vật liệu
ngành điện</td><td>CXV 1x10</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>45,500</td><td></td></tr><tr><td>1747</td><td>Vật liệu
ngành điện</td><td>CXV 1x16</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công</td><td>71,000</td><td></td></tr></tbody></table>

|<image_75>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>trình trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1748</td><td>Vật liệu
ngành điện</td><td>CXV 1x25</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>108,000</td><td></td></tr><tr><td>1749</td><td>Vật liệu
ngành điện</td><td>CXV 1x35</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>150,000</td><td></td></tr><tr><td>1750</td><td>Vật liệu
ngành điện</td><td>CXV 1x50</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>200,000</td><td></td></tr><tr><td>1751</td><td>Vật liệu
ngành điện</td><td>CXV 1x70</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>287,000</td><td></td></tr><tr><td>1752</td><td>Vật liệu
ngành điện</td><td>CXV 1x95</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>395,000</td><td></td></tr><tr><td>1753</td><td>Vật liệu
ngành điện</td><td>CXV 1x120</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>498,000</td><td></td></tr></tbody></table>

|<image_76>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1754</td><td>Vật liệu
ngành điện</td><td>CXV 1x150</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>630,000</td><td></td></tr><tr><td>1755</td><td>Vật liệu
ngành điện</td><td>CXV 1x185</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>785,000</td><td></td></tr><tr><td>*</td><td>Cáp đồng 4 ruột</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1756</td><td>Vật liệu
ngành điện</td><td>CXV 3x10x1x6</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>170,000</td><td></td></tr><tr><td>1757</td><td>Vật liệu
ngành điện</td><td>CXV 3x16+1x10</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>265,000</td><td></td></tr><tr><td>1758</td><td>Vật liệu
ngành điện</td><td>CXV 3x25+1x16</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>400,000</td><td></td></tr><tr><td>1759</td><td>Vật liệu
ngành điện</td><td>CXV 3x35+1x16</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>522,000</td><td></td></tr><tr><td>1760</td><td>Vật liệu
ngành điện</td><td>CXV 3x50+1x25</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công</td><td>730,000</td><td></td></tr></tbody></table>

|<image_77>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>trình trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1761</td><td>Vật liệu
ngành điện</td><td>CXV 3x70+1x35</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.020.000</td><td></td></tr><tr><td>1762</td><td>Vật liệu
ngành điện</td><td>CXV 3x95+1x50</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.405.000</td><td></td></tr><tr><td>1763</td><td>Vật liệu
ngành điện</td><td>CXV 3x120+1x70</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr><tr><td>1764</td><td>Vật liệu
ngành điện</td><td>CXV 3x150+1x95</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>2.275.000</td><td></td></tr><tr><td>1765</td><td>Vật liệu
ngành điện</td><td>CXV 3x185+1x120</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>2.850.000</td><td></td></tr><tr><td>1766</td><td>Vật liệu
ngành điện</td><td>CXV 4x10</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>185,000</td><td></td></tr></tbody></table>

|<image_78>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1767</td><td>Vật liệu
ngành điện</td><td>CXV 4x16</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>285,000</td><td></td></tr><tr><td>1768</td><td>Vật liệu
ngành điện</td><td>CXV 4x25</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>440,000</td><td></td></tr><tr><td>1769</td><td>Vật liệu
ngành điện</td><td>CXV 4x35</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>605,000</td><td></td></tr><tr><td>1770</td><td>Vật liệu
ngành điện</td><td>CXV 4x50</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>830,000</td><td></td></tr><tr><td>1771</td><td>Vật liệu
ngành điện</td><td>CXV 4x70</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.170.000</td><td></td></tr><tr><td>1772</td><td>Vật liệu
ngành điện</td><td>CXV 4x95</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.602.000</td><td></td></tr><tr><td>1773</td><td>Vật liệu
ngành điện</td><td>CXV 4x120</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>2.010.000</td><td></td></tr></tbody></table>

|<image_79>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1774</td><td>Vật liệu
ngành điện</td><td>CXV 4x150</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>2.495.000</td><td></td></tr><tr><td>1775</td><td>Vật liệu
ngành điện</td><td>CXV 4x185</td><td>m</td><td>TCVN 5935</td><td>Cu/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>3.125.000</td><td></td></tr><tr><td>*</td><td>Cáp đồng ngầm 2 ruột</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1776</td><td>Vật liệu
ngành điện</td><td>DSTA 2x2.5</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>43,000</td><td></td></tr><tr><td>1777</td><td>Vật liệu
ngành điện</td><td>DSTA 2x4</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>58,500</td><td></td></tr><tr><td>1778</td><td>Vật liệu
ngành điện</td><td>DSTA 2x6</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>78,000</td><td></td></tr><tr><td>1779</td><td>Vật liệu
ngành điện</td><td>DSTA 2x10</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>115,000</td><td></td></tr></tbody></table>

|<image_80>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1780</td><td>Vật liệu
ngành điện</td><td>DSTA 2x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>165,000</td><td></td></tr><tr><td>1781</td><td>Vật liệu
ngành điện</td><td>DSTA 2x25</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>248,000</td><td></td></tr><tr><td>1782</td><td>Vật liệu
ngành điện</td><td>DSTA 2x35</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>330,000</td><td></td></tr><tr><td>1783</td><td>Vật liệu
ngành điện</td><td>DSTA 2x50</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>448,000</td><td></td></tr><tr><td>1784</td><td>Vật liệu
ngành điện</td><td>DSTA 2x70</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>635,000</td><td></td></tr><tr><td>1785</td><td>Vật liệu
ngành điện</td><td>DSTA 2x95</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>885,000</td><td></td></tr><tr><td>1786</td><td>Vật liệu
ngành điện</td><td>DSTA 2x120</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>1.100.000</td><td></td></tr></tbody></table>

|<image_81>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1787</td><td>Vật liệu
ngành điện</td><td>DSTA 2x150</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.360.000</td><td></td></tr><tr><td>*</td><td>Cáp đồng ngầm 4 ruột</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1634</td><td>Vật liệu
ngành điện</td><td>DSTA 3x4+1x2.5</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>92,000</td><td></td></tr><tr><td>1635</td><td>Vật liệu
ngành điện</td><td>DSTA 3x6+1x4</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>125,000</td><td></td></tr><tr><td>1636</td><td>Vật liệu
ngành điện</td><td>DSTA 3x10x1x6</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>185,000</td><td></td></tr><tr><td>1637</td><td>Vật liệu
ngành điện</td><td>DSTA 3x16+1x10</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>280,000</td><td></td></tr><tr><td>1638</td><td>Vật liệu
ngành điện</td><td>DSTA 3x25+1x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>425,000</td><td></td></tr></tbody></table>

|<image_82>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1639</td><td>Vật liệu
ngành điện</td><td>DSTA 3x35+1x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>550,000</td><td></td></tr><tr><td>1640</td><td>Vật liệu
ngành điện</td><td>DSTA 3x50+1x25</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>765,000</td><td></td></tr><tr><td>1641</td><td>Vật liệu
ngành điện</td><td>DSTA 3x70+1x35</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.080.000</td><td></td></tr><tr><td>1642</td><td>Vật liệu
ngành điện</td><td>DSTA 3x95+1x50</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.460.000</td><td></td></tr><tr><td>1643</td><td>Vật liệu
ngành điện</td><td>DSTA 3x120+1x70</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.880.000</td><td></td></tr><tr><td>1644</td><td>Vật liệu
ngành điện</td><td>DSTA 3x150+1x95</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>2.350.000</td><td></td></tr><tr><td>1645</td><td>Vật liệu
ngành điện</td><td>DSTA 3x185+1x120</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>2.910.000</td><td></td></tr></tbody></table>

|<image_83>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1646</td><td>Vật liệu
ngành điện</td><td>DSTA 4x2.5</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>70,000</td><td></td></tr><tr><td>1647</td><td>Vật liệu
ngành điện</td><td>DSTA 4x4</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>98,000</td><td></td></tr><tr><td>1648</td><td>Vật liệu
ngành điện</td><td>DSTA 4x6</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>136,000</td><td></td></tr><tr><td>1649</td><td>Vật liệu
ngành điện</td><td>DSTA 4x10</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>203,000</td><td></td></tr><tr><td>1650</td><td>Vật liệu
ngành điện</td><td>DSTA 4x16</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>305,000</td><td></td></tr><tr><td>1651</td><td>Vật liệu
ngành điện</td><td>DSTA 4x25</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>460,000</td><td></td></tr></tbody></table>

|<image_84>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1652</td><td>Vật liệu
ngành điện</td><td>DSTA 4x35</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>625,000</td><td></td></tr><tr><td>1653</td><td>Vật liệu
ngành điện</td><td>DSTA 4x50</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>850,000</td><td></td></tr><tr><td>1654</td><td>Vật liệu
ngành điện</td><td>DSTA 4x70</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.220.000</td><td></td></tr><tr><td>1655</td><td>Vật liệu
ngành điện</td><td>DSTA 4x95</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>1.680.000</td><td></td></tr><tr><td>1656</td><td>Vật liệu
ngành điện</td><td>DSTA 4x120</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>2.120.000</td><td></td></tr><tr><td>1657</td><td>Vật liệu
ngành điện</td><td>DSTA 4x150</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>2.605.000</td><td></td></tr><tr><td>1658</td><td>Vật liệu
ngành điện</td><td>DSTA 4x185</td><td>m</td><td>TCVN 5935-1</td><td>Cu/XLPE/PVC/DS
TA/PVC</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>3.200.000</td><td></td></tr></tbody></table>

|<image_85>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>*</td><td>Cáp nhôm đơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1659</td><td>Vật liệu
ngành điện</td><td>AV 16</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>9,800</td><td></td></tr><tr><td>1660</td><td>Vật liệu
ngành điện</td><td>AV 25</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>14,700</td><td></td></tr><tr><td>1661</td><td>Vật liệu
ngành điện</td><td>AV 35</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>19,200</td><td></td></tr><tr><td>1662</td><td>Vật liệu
ngành điện</td><td>AV 50</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>26,600</td><td></td></tr><tr><td>1663</td><td>Vật liệu
ngành điện</td><td>AV 70</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>37,400</td><td></td></tr><tr><td>1664</td><td>Vật liệu
ngành điện</td><td>AV 95</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>50,300</td><td></td></tr></tbody></table>

|<image_86>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1665</td><td>Vật liệu
ngành điện</td><td>AV 120</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>62,600</td><td></td></tr><tr><td>1666</td><td>Vật liệu
ngành điện</td><td>AV 150</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>78,300</td><td></td></tr><tr><td>1667</td><td>Vật liệu
ngành điện</td><td>AV 185</td><td>m</td><td>TCVN 5935-2</td><td>FE/AL/XLPE/PVC</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>97,500</td><td></td></tr><tr><td>*</td><td>Cáp nhôm vặn xoắn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1668</td><td>Vật liệu
ngành điện</td><td>ABC 2x16</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>21,700</td><td></td></tr><tr><td>1669</td><td>Vật liệu
ngành điện</td><td>ABC 2x25</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>30,200</td><td></td></tr><tr><td>1670</td><td>Vật liệu
ngành điện</td><td>ABC 2x35</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>39,000</td><td></td></tr><tr><td>1671</td><td>Vật liệu
ngành điện</td><td>ABC 2x50</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công</td><td>53,300</td><td></td></tr></tbody></table>

|<image_87>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>trình trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1672</td><td>Vật liệu
ngành điện</td><td>ABC 2x70</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>73,200</td><td></td></tr><tr><td>1673</td><td>Vật liệu
ngành điện</td><td>ABC 2x95</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>100,300</td><td></td></tr><tr><td>1674</td><td>Vật liệu
ngành điện</td><td>ABC 2x120</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>122,700</td><td></td></tr><tr><td>1675</td><td>Vật liệu
ngành điện</td><td>ABC 2x150</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>152,500</td><td></td></tr><tr><td>1676</td><td>Vật liệu
ngành điện</td><td>ABC 2x185</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>190,500</td><td></td></tr><tr><td>1677</td><td>Vật liệu
ngành điện</td><td>ABC 4x16</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>41,600</td><td></td></tr></tbody></table>

|<image_88>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1678</td><td>Vật liệu
ngành điện</td><td>ABC 4x25</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>59,200</td><td></td></tr><tr><td>1679</td><td>Vật liệu
ngành điện</td><td>ABC 4x35</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>75,600</td><td></td></tr><tr><td>1680</td><td>Vật liệu
ngành điện</td><td>ABC 4x50</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>104,200</td><td></td></tr><tr><td>1681</td><td>Vật liệu
ngành điện</td><td>ABC 4x70</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>144,900</td><td></td></tr><tr><td>1682</td><td>Vật liệu
ngành điện</td><td>ABC 4x95</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>197,200</td><td></td></tr><tr><td>1683</td><td>Vật liệu
ngành điện</td><td>ABC 4x120</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>244,100</td><td></td></tr><tr><td>1684</td><td>Vật liệu
ngành điện</td><td>ABC 4x150</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa</td><td>305,500</td><td></td></tr></tbody></table>

|<image_89>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>và cáp điện
Vạn Xuân</td><td></td><td>bàn tỉnh Lạng
Sơn</td><td></td><td></td></tr><tr><td>1685</td><td>Vật liệu
ngành điện</td><td>ABC 4x185</td><td>m</td><td>TCVN:6447</td><td>Al/XLPE</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>379,500</td><td></td></tr><tr><td>1686</td><td>Cáp nhôm trần lõi thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1687</td><td>Vật liệu
ngành điện</td><td>AC 50/8</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>133,500</td><td></td></tr><tr><td>1688</td><td>Vật liệu
ngành điện</td><td>AC 70/11</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>133,000</td><td></td></tr><tr><td>1689</td><td>Vật liệu
ngành điện</td><td>AC 95/16</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>132,600</td><td></td></tr><tr><td>1690</td><td>Vật liệu
ngành điện</td><td>AC 120/19</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>139,900</td><td></td></tr><tr><td>1691</td><td>Vật liệu
ngành điện</td><td>AC 150/19</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>143,300</td><td></td></tr></tbody></table>

|<image_90>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1692</td><td>Vật liệu
ngành điện</td><td>AC 150/24</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>138,400</td><td></td></tr><tr><td>1693</td><td>Vật liệu
ngành điện</td><td>AC 185/24</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>141,500</td><td></td></tr><tr><td>1694</td><td>Vật liệu
ngành điện</td><td>AC 185/29</td><td>m</td><td>TCVN
8090:2009</td><td>Fe/Al</td><td>Công ty
TNHH dây
và cáp điện
Vạn Xuân</td><td>Đã bao
gồm VC</td><td>Giá bán tại
chân công
trình trên địa
bàn tỉnh Lạng
Sơn</td><td>138,000</td><td></td></tr><tr><td>14,5</td><td>Thiết bị điện SINO</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Aptomat MCB Sino SC68N, 6kA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1695</td><td>Vật liệu
ngành điện</td><td>Loại 1 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>56,364</td></tr><tr><td>1696</td><td>Vật liệu
ngành điện</td><td>Loại 1 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>65,455</td></tr><tr><td>1697</td><td>Vật liệu
ngành điện</td><td>Loại 2 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>123,636</td></tr><tr><td>1698</td><td>Vật liệu
ngành điện</td><td>Loại 2 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>144,091</td></tr></tbody></table>

|<image_91>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1699</td><td>Vật liệu
ngành điện</td><td>Loại 3 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>189,091</td></tr><tr><td>1700</td><td>Vật liệu
ngành điện</td><td>Loại 3 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>225,909</td></tr><tr><td>1701</td><td>Vật liệu
ngành điện</td><td>Loại 4 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>270,909</td></tr><tr><td>1702</td><td>Vật liệu
ngành điện</td><td>Loại 4 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>314,182</td></tr><tr><td>*</td><td>Aptomat MCB Sino SC108N, 10kA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1704</td><td>Vật liệu
ngành điện</td><td>Loại 1 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>59,273</td></tr><tr><td>1705</td><td>Vật liệu
ngành điện</td><td>Loại 1 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>68,727</td></tr><tr><td>1706</td><td>Vật liệu
ngành điện</td><td>Loại 2 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>129,818</td></tr><tr><td>1707</td><td>Vật liệu
ngành điện</td><td>Loại 2 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>150,909</td></tr></tbody></table>

|<image_92>|


## VIETTEL AI RACE

## TD645

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD645</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: VẬT LIỆU NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1708</td><td>Vật liệu
ngành điện</td><td>Loại 3 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>198,636</td></tr><tr><td>1709</td><td>Vật liệu
ngành điện</td><td>Loại 3 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>237,273</td></tr><tr><td>1710</td><td>Vật liệu
ngành điện</td><td>Loại 4 pha: 6A, 10A,
16A,
20A, 25A, 32A, 40A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>284,545</td></tr><tr><td>1711</td><td>Vật liệu
ngành điện</td><td>Loại 4 pha: 50A, 60A.</td><td>cái</td><td>TCVN 6434-
1:2008</td><td>không có thông tin</td><td>Công ty
TNHH
Xuân Lộc
Thọ</td><td>không</td><td>Giá bán tại
thành phố
Lạng
Sơn</td><td></td><td>330,000</td></tr></tbody></table>

|<image_93>|


