# Public_669

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD669</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU LỖ
TRỐNG VÀ KÝ HIỆU CỬA SỔ TRONG
BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Lỗ trống không tới sát mặt
sàn</td><td></td><td>Ký hiệu quy ước thể hiện
trên mặt bằng.</td></tr><tr><td>Lỗ trống hình tròn, không
tới sát mặt sản</td><td></td><td>Ký hiệu quy ước thể hiện
trên mặt bằng.</td></tr><tr><td>Lỗ trống tới sát mặt sàn</td><td></td><td>Ký hiệu quy ước thể hiện
trên mặt bằng.</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa sổ đơn thể hiện trên
mặt bằng</td><td></td><td>Hình vẽ tỷ lệ
1:100.</td></tr><tr><td>Cửa sổ kép thể hiện trên
mặt bằng</td><td></td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD669</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU LỖ
TRỐNG VÀ KÝ HIỆU CỬA SỔ TRONG
BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa sổ đơn thể hiện trên
mặt bằng</td><td></td><td>Hình vẽ tỷ lệ nhỏ
hơn 1:100.</td></tr><tr><td>Cửa sổ kép thể hiện trên
mặt bằng</td><td></td><td></td></tr><tr><td>Cửa sổ đơn cố định thể
hiện trên mặt cắt và mặt
đứng</td><td></td><td></td></tr><tr><td>Cửa sổ đơn hai cánh quay
theo bản lề đứng mở ra
ngoài</td><td></td><td>Ký hiệu mở cửa
ước là hình tam
giác cân, đỉnh tam
giác biểu thị phía
có bản lề.</td></tr></tbody></table>

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD669</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU LỖ
TRỐNG VÀ KÝ HIỆU CỬA SỔ TRONG
BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa sổ đơn hai cánh quay
theo hai bản lề đứng mở
vào trong</td><td></td><td></td></tr><tr><td>Cửa sổ đơn một cánh mở
quay theo trục đứng ở
giữa, thể hiện trên mặt
bằng và mặt đứng</td><td></td><td>Khi thể hiện ký
hiệu cần chú ý
hướng quay của
cánh cửa.</td></tr><tr><td>Cửa sổ đơn một cánh
quay theo bản lề ngang
trên mở ra ngoài</td><td></td><td>Hình tam giác ký
hiệu mở cửa thể
hiện nét liền là mở
ra ngoài, nét đứt là
mở vào trong.</td></tr></tbody></table>

|<image_12>|

|<image_13>|

|<image_14>|

|<image_15>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD669</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU LỖ
TRỐNG VÀ KÝ HIỆU CỬA SỔ TRONG
BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa sổ đơn một cánh
quay theo bản lề ngang
trên, mở vào trong</td><td></td><td>Chiều mở cánh cửa
trên mặt cắt quy
định vẽ theo độ
chếch 30°.</td></tr><tr><td>Cửa sổ đơn một cánh
quay theo bản lề ngang
dưới, mở vào trong</td><td></td><td></td></tr><tr><td>Cửa sổ lật một cách quay
theo trục ngang ở giữa</td><td></td><td></td></tr><tr><td>Cửa sổ cánh đẩy lên, thể
hiện trên mặt đứng và
mặt cắt</td><td></td><td></td></tr></tbody></table>

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD669</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU LỖ
TRỐNG VÀ KÝ HIỆU CỬA SỔ TRONG
BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa sổ cánh đẩy ngang
thể hiện trên mặt bằng và
mặt đứng</td><td></td><td></td></tr><tr><td>Cửa sổ kép bốn cánh
quay theo hai bản lề đứng
mở cả hai chiều</td><td></td><td></td></tr><tr><td>Cửa sổ kép hai cánh quay
theo bản lề ngang trên,
mở cả hai chiều</td><td></td><td></td></tr></tbody></table>

|<image_21>|

|<image_22>|

|<image_23>|

|<image_24>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD669</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU LỖ
TRỐNG VÀ KÝ HIỆU CỬA SỔ TRONG
BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa sổ kép hai cánh quay
theo bản lề đứng, mở cả
hai chiều</td><td></td><td></td></tr></tbody></table>

|<image_25>|

|<image_26>|


