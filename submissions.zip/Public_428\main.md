# Public_428

### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th></th><th></th></tr></thead><tbody><tr><td>STT</td><td>Tên ứng dụng</td><td>Chức năng cha</td><td>Mã chức năng</td><td>Tên chức năng</td><td>Mô tả</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
DC_HM</td><td></td><td>Đặt cọc/hạn mức (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>2</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH</td><td>Quản lý thông tin khách
hàng</td><td>Quản lý thông tin khách hàng (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>3</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_SAU
BAN_DVCD</td><td>Sau bán cố định</td><td>Sau bán cố định (Chủ trì nghiệp vụ: TT
CĐBR VTT)</td></tr><tr><td>4</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_HU
YDK_KM_TUONG
LAI_OWNER_H</td><td>Hủy đăng ký đổi KM
tương lai cho homephone
của user cùng shop, shop
con</td><td>Hủy đăng ký đổi KM tương lai cho
homephone của user cùng shop, shop con
(Chủ trì nghiệp vụ: TTĐH VTT -
phuongphuong@)</td></tr><tr><td>5</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_HU
YDK_KM_TUONG
LAI_OWNER_M</td><td>Hủy đăng ký đổi KM
tương lai cho mobile của
user cùng shop, shop con</td><td>Hủy đăng ký đổi KM tương lai cho mobile
của user cùng shop, shop con (Chủ trì
nghiệp vụ: TTĐH VTT - phuongphuong@)</td></tr><tr><td>6</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DVCD_TDDC
_HM_73</td><td>BCCS2_SALE_SAUBAN
_DVCD_TDDC_HM_73</td><td>Quyền "Quyền thực hiện chức năng thay
đổi đặt cọc hạn mức Sip trunk" (Chủ trì
nghiệp vụ: TT di động VTT -
huongdt46/phuoctv)</td></tr><tr><td>7</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
_BAN_DI_DONG_B
O_QUA_CK_GIN_G
IU_THUE_BAO</td><td>BCCS2_SALE_SAU_BA
N_DI_DONG_BO_QUA_
CK_GIN_GIU_THUE_B
AO</td><td>Quyền bỏ qua CK gìn giữ thuê bao (Chủ trì
nghiệp vụ: TTĐH VTT-phuongphuong@)</td></tr></tbody></table>

|<image_1>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>8</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Sau bán di động</th><th>BCCS2_SALE_SAU
_BAN_DI_DONG_G
IN_GIU_THUE_BA
O</th><th>BCCS2_SALE_SAU_BA
N_DI_DONG_GIN_GIU_
THUE_BAO</th><th>quyền lấy khuyến mại gìn giữ thuê bao
(Chủ trì nghiệp vụ: TTĐH VTT-
phuongphuong@)</th></tr></thead><tbody><tr><td>9</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_THA
NHTOAN</td><td>Thanh toán</td><td>Thanh toán (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>10</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_HOAN_CHA
N_ND49</td><td>Hoãn chặn thuê bao all in
one theo NĐ49</td><td>Hoãn chặn thuê bao all in one theo NĐ49
(Chủ trì nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>11</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_MO_CHAN_
ND49_KHONG_GIO
I_HAN</td><td>Mở chặn thuê bao NĐ 49
không giới hạn</td><td>Mở chặn thuê bao NĐ 49 không giới hạn
(Chủ trì nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>12</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_CAU
HINH</td><td>BCCS2_CC_CAUHI
NH_GIAOVIEC_TU
DONG</td><td>Cấu hình giao việc tự động</td><td>Cấu hình giao việc tự động(Chủ trì nghiệp
vụ: TT CSKH VTT - daott1@/ trangvt1@)</td></tr><tr><td>13</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_TIENIC
H</td><td>BCCS2_CC_TIENIC
H_HOANCHANTB</td><td>Hoãn chặn thuê bao
NĐ49 theo file</td><td>Hoãn chặn thuê bao NĐ49 theo file (Chủ trì
nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>14</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_BO_
CHECK_DIEU_KIE
N_THUE_BAO_DA
NG_KY</td><td>BCCS2_SALE_BO_CHE
CK_DIEU_KIEN_THUE_
BAO_DANG_KY</td><td>Quyền bỏ check điều kiện thuê bao phải
đăng ký mới được mở chặn(Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>15</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_DAN
HMUC</td><td>Danh mục</td><td>Danh mục (Chủ trì nghiệp vụ: CNTT VTT)</td></tr><tr><td>16</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Danh mục</td><td>BCCS2_SALE_DAN
HMUC_TRACUU_T
HONGTIN</td><td>Tra cứu thông tin</td><td>Tra cứu thông tin (Chủ trì nghiệp vụ: CNTT
VTT)</td></tr></tbody></table>

|<image_2>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>17</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Hệ thống
BCCS2.SALE</th><th>BCCS2_SALE_HOP
DONG</th><th>Quản lý hợp đồng</th><th>Quản lý hợp đồng (Chủ trì nghiệp vụ: TT
QLBH/TT CĐBR VTT)</th></tr></thead><tbody><tr><td>18</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Cập nhật thông tin
hợp đồng</td><td>BCCS2_SALE_HOP
DONG_CAPNHAT_
HD</td><td>Mã quyền cập nhật thông
tin hợp đồng</td><td>Mã quyền cập nhật thông tin hợp đồng (Chủ
trì nghiệp vụ: TT ĐHBH/TT di động VTT)</td></tr><tr><td>19</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý hợp đồng</td><td>BCCS2_SALE_HOP
DONG_TDTTHD</td><td>Cập nhật thông tin hợp
đồng</td><td>Cập nhật thông tin hợp đồng (Chủ trì nghiệp
vụ: TT QLBH/TT Di động VTT)</td></tr><tr><td>20</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_MNP
_CM</td><td>Chuyển mạng giữ số</td><td>Chuyển mạng giữ số (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>21</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Bỏ tích thuê bao
không chính chủ</td><td>BCCS2_SALE_NOT
_VALIDATE_LOG_
AI</td><td>BCCS2_SALE_NOT_VA
LIDATE_LOG_AI</td><td>Quyền "Quyền bỏ qua validate AI" (Chủ trì
nghiệp vụ: TTĐH VTT - trinhptt3/phuoctv)</td></tr><tr><td>22</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_QLH
OADON</td><td>Quản lý hóa đơn</td><td>Quản lý hóa đơn (Chủ trì nghiệp vụ: P.Tài
chính VTT)</td></tr><tr><td>23</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý hóa đơn</td><td>BCCS2_SALE_QLH
OADON_BANHAN
G</td><td>Quản lý hóa đơn bán hàng</td><td>Quản lý hóa đơn bán hàng (Chủ trì nghiệp
vụ: P.Tài chính VTT)</td></tr><tr><td>24</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý hóa đơn bán
hàng</td><td>BCCS2_SALE_QLH
OADON_BANHAN
G_INLAIBANCHUY
ENDOI_HOADOND
IENTU</td><td>Mã quyền in lại bản
chuyển đổi của hóa đơn
điện tử</td><td>Mã quyền in lại bản chuyển đổi của hóa đơn
điện tử (Chủ trì nghiệp vụ: P. Tài chính
VTT)</td></tr><tr><td>25</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý hóa đơn bán
hàng</td><td>BCCS2_SALE_QLH
OADON_BANHAN
G_INLAIHOADON</td><td>Mã quyền in lại bản chính
hóa đơn</td><td>Mã quyền in lại bản chính hóa đơn (Chủ trì
nghiệp vụ: P. Tài chính VTT)</td></tr></tbody></table>

|<image_3>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>26</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Quản lý hóa đơn bán
hàng</th><th>BCCS2_SALE_QLH
OADON_BANHAN
G_TKKHONGDON
VI</th><th>Mã quyền tìm kiếm hóa
đơn không theo đơn vị</th><th>Mã quyền tìm kiếm hóa đơn không theo đơn
vị (Chủ trì nghiệp vụ: P. Tài chính VTT)</th></tr></thead><tbody><tr><td>27</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý nhóm</td><td>BCCS2_SALE_QLN
HOM_BUNDLE</td><td>Quản lý loại nhóm bundle</td><td>Quản lý loại nhóm bundle (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>28</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý nhóm</td><td>BCCS2_SALE_QLN
HOM_CORPORATE</td><td>Quản lý nhóm corporate</td><td>Quản lý nhóm corporate (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>29</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý nhóm</td><td>BCCS2_SALE_QLN
HOM_FAMILY</td><td>Quản lý nhóm family</td><td>Quản lý nhóm family(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>30</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý nhóm</td><td>BCCS2_SALE_QLN
HOM_MULTISERVI
CE</td><td>Quản lý nhóm đa dịch vụ</td><td>Quản lý nhóm đa dịch vụ(Chủ trì nghiệp vụ:
TT Di động VTT)</td></tr><tr><td>31</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý nhóm</td><td>BCCS2_SALE_QLN
HOM_TRUOT</td><td>Quản lý nhóm trượt</td><td>Quản lý nhóm trượt (Chủ trì nghiệp vụ: TT
CĐBR VTT)</td></tr><tr><td>32</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_BA
OMAT</td><td>Mã quyền bỏ qua tìm
kiếm bảo mật</td><td>Mã quyền bỏ qua tìm kiếm bảo mật(Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>33</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_CH
ANMO</td><td>Chức năng chặn mở thuê
bao di động</td><td>Chức năng chặn mở thuê bao di động (Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>34</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Chức năng chặn mở
thuê bao di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_CH
ANMO_TS_M</td><td>Quyền chăn mở thuê bao
mobile trả sau</td><td>Quyền chăn mở thuê bao mobile trả sau
(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_4>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>35</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Chức năng chặn mở
thuê bao di động</th><th>BCCS2_SALE_SAU
BAN_DIDONG_CH
ANMO_TT_M</th><th>Quyền chăn mở thuê bao
mobile trả trước</th><th>Quyền chăn mở thuê bao mobile trả trước
(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>36</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_DOI
GOICUOC</td><td>Đổi gói cước di động</td><td>Đổi gói cước di động(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>37</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_NH
ANNOCUOC</td><td>ĐK nhận tin nhắn chặn
BADO/chặn chiều cước</td><td>ĐK nhận tin nhắn chặn BADO/chặn chiều
cước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>38</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>ĐK nhận tin nhắn
chặn BADO/chặn
chiều cước</td><td>BCCS2_SALE_SAU
BAN_DIDONG_NH
ANNOCUOC_QUY
EN</td><td>Quyền đăng ký STB nhận
tin nhắn nợ cước</td><td>Quyền đăng ký STB nhận tin nhắn nợ
cước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>39</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Đặt cọc/hạn mức</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
DC_HM_MB</td><td>Mã quyền thay đổi đặt
cọc, hạn mức cho thuê
bao Mobile</td><td>Mã quyền thay đổi đặt cọc, hạn mức cho
thuê bao Mobile (Chủ trì nghiệp vụ: TTĐH
VTT-phuongphuong@)</td></tr><tr><td>40</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Đặt cọc/hạn mức</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
DC_HM_QUYEN_N
ANG_HM</td><td>Quyền nâng hạn mức lớn
hơn quy định</td><td>Quyền nâng hạn mức lớn hơn quy định(Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>41</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý thông tin
khách hàng</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_CHUYENNH
UONG_TT</td><td>Mã quyền chuyển nhượng
thuê bao trả trước</td><td>Mã quyền chuyển nhượng thuê bao trả
trước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>42</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý thông tin
khách hàng</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_MB_TS</td><td>Mã quyền thay đổi thông
tin KH Mobile trả sau</td><td>Mã quyền thay đổi thông tin KH Mobile trả
sau(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_5>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>43</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Quản lý thông tin
khách hàng</th><th>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_MB_TT</th><th>Mã quyền thay đổi thông
tin KH Mobile trả trước</th><th>Mã quyền thay đổi thông tin KH Mobile trả
trước (Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>44</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý thông tin
khách hàng</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_MB_TT_DB</td><td>Mã quyền thay đổi thông
tin KH Mobile trả trước
full</td><td>Mã quyền thay đổi thông tin KH Mobile trả
trước full(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>45</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
VAS</td><td>Đổi GTGT</td><td>Đổi GTGT(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>46</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Đổi GTGT</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
VAS_MB_TS</td><td>Mã quyền đổi vas cho
thuê bao Mobile trả sau</td><td>Mã quyền đổi vas cho thuê bao Mobile trả
sau(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>47</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Đổi GTGT</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
VAS_MB_TT</td><td>Mã quyền đổi vas cho
thuê bao Mobile trả trước</td><td>Mã quyền đổi vas cho thuê bao Mobile trả
trước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>48</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Hệ thống
BCCS2.SALE</td><td>BCCS2_SALE_TIEN
ICH</td><td>Tiện ích</td><td>Tiện ích (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>49</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_INTHONGBAO
CUOC</td><td>In thông báo cước</td><td>In thông báo cước (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>50</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_QLTT_DACBI
ET</td><td>Quản lý thông tin đặc biệt</td><td>Quản lý thông tin đặc biệt (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>51</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_SS_CHANMO_
NOCUOC</td><td>Chức năng sửa sai mở
chặn nợ cước</td><td>Chức năng sửa sai mở chặn nợ cước(Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_6>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>52</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Chức năng sửa sai mở
chặn nợ cước</th><th>BCCS2_SALE_TIEN
ICH_SS_CHANMO_
NOCUOC_QUYEN</th><th>Mã quyền sửa sai mở
chặn nợ cước</th><th>Mã quyền sửa sai mở chặn nợ cước(Chủ trì
nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>53</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_SS_TTKH</td><td>Sửa sai thông tin khách
hàng</td><td>Sửa sai thông tin khách hàng (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>54</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sửa sai thông tin
khách hàng</td><td>BCCS2_SALE_TIEN
ICH_SS_TTKH_QU
YEN</td><td>Mã quyền sửa sai thông
tin KH</td><td>Mã quyền sửa sai thông tin KH (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>55</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_TDTT_THEO_
FILE</td><td>Thay đổi thông tin theo
file</td><td>Cập nhật thông tin theo File (Chủ trì nghiệp
vụ: TTQLBH VTT)</td></tr><tr><td>56</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_TRACUU_THO
NGTIN</td><td>Tra cứu thông tin</td><td>Tra cứu thông tin(Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>57</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Thanh toán</td><td>DELAY_LIST_FUL
L</td><td>Quyền đặc biệt cho phép
user hoãn chặn tất cả các
HTQL</td><td>Quyền cho phép user hoãn chặn tất cả các
HTQL(Chủ trì nghiệp vụ: TT QLBH VTT-
hangpm@)</td></tr><tr><td>58</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Thanh toán</td><td>PM_DELAY_LIST</td><td>Hoãn chặn</td><td>Hoãn chặn (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>59</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Thanh toán</td><td>PM_VERIFY</td><td>Xác minh</td><td>Xác minh (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>60</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Xác minh</td><td>PM_VERIFY_OPEN</td><td>Mở chặn khách hàng
không xác định</td><td>Mở chặn khách hàng không xác định (Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>61</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Xác minh</td><td>PM_VERIFY_REAS
SIGN</td><td>Giao lại xác minh</td><td>Giao lại xác minh (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr></tbody></table>

|<image_7>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>62</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Xác minh</th><th>PM_VERIFY_UPDA
TE</th><th>Cập nhật xác minh</th><th>Cập nhật xác minh (Chủ trì nghiệp vụ:
TTĐH VTT)</th></tr></thead><tbody><tr><td>63</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_SS_GOICUOC_
KM_CDT</td><td>Sửa sai gói cước, KM,
CĐT</td><td>Chức năng sửa sai đổi gói cước, khuyến
mại, cước đóng trước (Đơn vị chủ trì nghiệp
vụ: TT ĐH VTT)</td></tr><tr><td>64</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Tiện ích</td><td>BCCS2_SALE_TIEN
ICH_SS_KHUYEN
MAI</td><td>Sửa sai khuyến mại cho
tất cả các dịch vụ</td><td>Sửa sai khuyến mại cho tất cả các dịch
vụ(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>65</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sửa sai khuyến mại
cho tất cả các dịch vụ</td><td>BCCS2_SALE_TIEN
ICH_SS_KHUYEN
MAI_QUYEN</td><td>Quyền sửa sai khuyến mại
cho tất cả các dịch vụ</td><td>Quyền sửa sai khuyến mại cho tất cả các
dịch vụ ủy yêu cầu cố định đã đấu nối(Chủ
trì nghiệp vụ: TT Di động VTT)</td></tr><tr><td>66</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_QUA
NLY_HOSO</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_QUA
NLY_HOSO_KIEM_
TRA_DV_SO2</td><td>BCCS2_CC_QUANLY_K
HIEUNAI_QUANLY_HO
SO_KIEM_TRA_DV_SO
2</td><td>Tổng hợp YC kiểm tra dịch vụ (sổ 2) (Chủ
trì nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>67</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_QUA
NLY_HOSO</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_QUA
NLY_HOSO_NHAT
_KY_GQKN_SO1</td><td>BCCS2_CC_QUANLY_K
HIEUNAI_QUANLY_HO
SO_NHAT_KY_GQKN_
SO1</td><td>Nhật ký giải quyết khiếu nại (sổ 1) (Chủ trì
nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>68</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_QUA
NLY_HOSO</td><td>BCCS2_CC_QUANL
Y_KHIEUNAI_QUA
NLY_HOSO_TIMKI
EM_HO_SO_KH</td><td>BCCS2_CC_QUANLY_K
HIEUNAI_QUANLY_HO
SO_TIMKIEM_HO_SO_
KH</td><td>Tìm kiếm theo hồ sơ khách hàng (Chủ trì
nghiệp vụ: TT CSKH VTT)</td></tr></tbody></table>

|<image_8>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>69</th><th>Hệ thống Customer
Care 2.0</th><th>BCCS2_CC_ALL_IN
_ONE</th><th>BCCS2_CC_ALL_IN
_ONE_CHAN1C_K
H_QUAYROI</th><th>BCCS2_CC_ALL_IN_ON
E_CHAN1C_KH_QUAY
ROI</th><th>Chặn 1C do khách hàng quấy rối (là 1 phần
trong chặn 1C KHYC) (Chủ trì nghiệp vụ:
TT CSKH VTT)</th></tr></thead><tbody><tr><td>70</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_CHANMO_K
INHDOANH</td><td>BCCS2_CC_ALL_IN_ON
E_CHANMO_KINHDOA
NH</td><td>Chặn mở kinh doanh dịch vụ (Chủ trì
nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>71</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_CHANMO_Q
CRV</td><td>BCCS2_CC_ALL_IN_ON
E_CHANMO_QCRV</td><td>Quyền cho ĐTV chặn mở QCRV (Chủ trì
nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>72</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_CHANMO_Q
UAYROI_TONGDAI</td><td>BCCS2_CC_ALL_IN_ON
E_CHANMO_QUAYROI
_TONGDAI</td><td>Chặn mở quấy rối tổng đài (Chủ trì nghiệp
vụ: TT CSKH VTT)</td></tr><tr><td>73</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_CHANMO_T
INNHAN_SPAM</td><td>BCCS2_CC_ALL_IN_ON
E_CHANMO_TINNHAN
_SPAM</td><td>Chặn mở tin nhắn Spam (Chủ trì nghiệp vụ:
TT CSKH VTT)</td></tr><tr><td>74</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_CHAN_MO_
QUAYROITONGDA
I</td><td>BCCS2_CC_ALL_IN_ON
E_CHAN_MO_QUAYRO
ITONGDAI</td><td>Chặn mở quấy rối tổng đài (Chủ trì nghiệp
vụ: TT CSKH VTT)</td></tr></tbody></table>

<table><thead><tr><th>75</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Hệ thống
BCCS2.SALE</th><th>BCCS2_SALE_MNP</th><th>Chuyển mạng giữ số</th><th>Chuyển mạng giữ số (Theo
R814214_Chuyển mạng giữ số) (Chủ trì
nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>76</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Đặt cọc/hạn mức</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
DC_HM_HP</td><td>Mã quyền thay đổi đặt
cọc, hạn mức cho thuê
bao Homephone</td><td>Mã quyền thay đổi đặt cọc, hạn mức cho
thuê bao Homephone(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr></tbody></table>

|<image_9>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>77</th><th>Hệ thống Customer
Care 2.0</th><th>BCCS2_CC_ALL_IN
_ONE</th><th>BCCS2_CC_ALL_IN
_ONE_CAP_NHAT_
TINH_TRANG_TRA
NH_CHAP_THUE_
BAO</th><th>Quyền cập nhật tình trạng
tranh chấp thuê bao</th><th>Quyền cập nhật tình trạng tranh chấp thuê
bao (Chủ trì nghiệp vụ: TT CSKH VTT)</th></tr></thead><tbody><tr><td>78</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_WEB</td><td>BCCS2_CC_OPEN_
SUB_KXD</td><td>Mở chặn thuê bao không
xác định</td><td>Quyền mở chặn thuê bao không xác định
(Chủ trì nghiệp vụ: TTCSKH VTT -
tamnt9/phuonghtm2@)</td></tr><tr><td>79</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Chức năng chặn mở
thuê bao di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_CH
ANMO_TS_H</td><td>Quyền chăn mở thuê bao
homephone trả sau</td><td>Quyền chăn mở thuê bao homephone trả
sau(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>80</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Chức năng chặn mở
thuê bao di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_CH
ANMO_TT_H</td><td>Quyền chăn mở thuê bao
homephone trả trước</td><td>Quyền chăn mở thuê bao homephone trả
trước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>81</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý thông tin
khách hàng</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_HP_TS</td><td>Mã quyền thay đổi thông
tin KH Homephone trả sau</td><td>Mã quyền thay đổi thông tin KH
Homephone trả sau(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>82</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Quản lý thông tin
khách hàng</td><td>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_HP_TT</td><td>Mã quyền thay đổi thông
tin KH Homephone trả
trước</td><td>Mã quyền thay đổi thông tin KH
Homephone trả trước (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr></tbody></table>

<table><thead><tr><th>83</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Quản lý thông tin
khách hàng</th><th>BCCS2_SALE_SAU
BAN_DIDONG_TD
TTKH_HP_TT_DB</th><th>Mã quyền thay đổi thông
tin KH Homephone trả
trước full</th><th>Mã quyền thay đổi thông tin KH
Homephone trả trước full (Chủ trì nghiệp
vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>84</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_TIEN
ICH_CAPNHAT_TH
ONGTIN_NGUOISU
DUNG</td><td>Cập nhật thông tin người
sử dụng</td><td>Cập nhật thông tin người sử dụng (Theo
R817973)(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_10>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>85</th><th>Hệ thống quản khách
hàng bán hàng BCCS2</th><th>Quản lý hóa đơn</th><th>BCCS_SALE_QLHO
ADON_TRACUU_0
4SS</th><th>Quản lý thông tin biểu
mẫu hóa đơn 04 sai sót</th><th>QLý biều mẫu 04 sai sót (PYC 4044966-
(Chủ trì nghiệp vụ: B. Tài chính kế toán-
TĐ -Tuantv14/HoanTD)</th></tr></thead><tbody><tr><td>86</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_IMP
ORT_IMEI_EIR_BY
_FILE</td><td>BCCS2_SALE_IMPORT_
IMEI_EIR_BY_FILE</td><td>Quyền import imei theo file lên hệ thống
EIR (Chủ trì nghiệp vụ: TT Di động VTT-
phonglh3/haunt4)</td></tr><tr><td>87</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Sau bán di động</td><td>BCCS2_SALE_UPD
ATE_IMEI_EIR_BY
_FILE</td><td>BCCS2_SALE_UPDATE
_IMEI_EIR_BY_FILE</td><td>Quyền cập nhật imei theo file lên hệ thống
EIR (Chủ trì nghiệp vụ: TT Di động VTT-
phonglh3/haunt4)</td></tr><tr><td>88</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Đổi gói cước di động</td><td>BCCS2_SALE_SAU
BAN_DIDONG_DOI
GOICUOC_M_TT</td><td>Đổi gói cước di động
mobile trả trước</td><td>Đổi gói cước di động mobile trả trước (Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>89</td><td>Hệ thống quản khách
hàng bán hàng BCCS2</td><td>Thay đổi thông tin
theo file</td><td>BCCS2_SALE_TIEN
ICH_MO_CHAN_2_
CHIEU_THEO_FILE</td><td>Quyền mở chặn 2 chiều
thuê bao theo file</td><td>Quyền mở chặn 2 chiều thuê bao theo
file(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>90</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_WEB</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN_ON
E</td><td>Quyền đăng nhập màn hình all in one (Chủ
trì nghiệp vụ: TTCSKH VTT)</td></tr><tr><td>91</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_XEM_CTCU
OC_KOCAN_MSCN
_HOMEPHONE_TR
ATRUOC</td><td>BCCS2_CC_ALL_IN_ON
E_XEM_CTCUOC_KOC
AN_MSCN_HOMEPHO
NE_TRATRUOC</td><td>Xem chi tiết cước ko cần mã cá nhân
homephone trả trước (Chủ trì nghiệp vụ:
TTCSKH VTT)</td></tr><tr><td>92</td><td>Hệ thống Customer
Care 2.0</td><td></td><td>BCCS2_CC_WEB</td><td>BCCS2_CC_WEB</td><td>(Chủ trì nghiệp vụ: TTCSKH VTT)</td></tr><tr><td>93</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_ALL_IN
_ONE</td><td>BCCS2_CC_ALL_IN
_ONE_XEM_CTCU
OC_KOCAN_MSCN
_MOBILE_TRASAU</td><td>BCCS2_CC_ALL_IN_ON
E_XEM_CTCUOC_KOC
AN_MSCN_MOBILE_T
RASAU</td><td>Xem chi tiết cước ko cần mã cá nhân
mobile trả sau (Chủ trì nghiệp vụ: TTCSKH
VTT)</td></tr></tbody></table>

|<image_11>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>94</th><th>Hệ thống Customer
Care 2.0</th><th>BCCS2_CC_ALL_IN
_ONE</th><th>BCCS2_CC_ALL_IN
_ONE_XEM_CTCU
OC_KOCAN_MSCN
_MOBILE_TRATRU
OC</th><th>BCCS2_CC_ALL_IN_ON
E_XEM_CTCUOC_KOC
AN_MSCN_MOBILE_T
RATRUOC</th><th>Xem chi tiết cước không cần mã cá nhân
mobile trả trước (Chủ trì nghiệp vụ:
TTCSKH VTT)</th></tr></thead><tbody><tr><td>95</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_WEB</td><td>BCCS2_CC_TIENIC
H</td><td>BCCS2_CC_TIENICH</td><td>Tiện ích (Chủ trì nghiệp vụ: TTCSKH VTT)</td></tr><tr><td>96</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_TIENIC
H</td><td>BCCS2_CC_TIENIC
H_TRACUU_CHIEU
NHAN_CUOCGOI_
KHONG_MAHOA</td><td>BCCS2_CC_TIENICH_T
RACUU_CHIEUNHAN_
CUOCGOI_KHONG_MA
HOA</td><td>Quyền tra cứu chiều nhận cuộc gọi không
mã hóa (Chủ trì nghiệp vụ: TTCSKH VTT)</td></tr><tr><td>97</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_TIENIC
H</td><td>BCCS2_CC_TIENIC
H_TRACUU_CHIEU
NHAN_CUOCGOI_
NANGCAO</td><td>BCCS2_CC_TIENICH_T
RACUU_CHIEUNHAN_
CUOCGOI_NANGCAO</td><td>Quyền tra cứu chiều nhận cuộc gọi nâng
cao. Có thể tra cứu cả 2 chiều(Chủ trì
nghiệp vụ: TTCSKH VTT)</td></tr><tr><td>98</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_TIENIC
H</td><td>BCCS2_CC_TIENIC
H_TRACUU_CHIEU
NHAN_CUOCGOI_
TRAMBTS</td><td>BCCS2_CC_TIENICH_T
RACUU_CHIEUNHAN_
CUOCGOI_TRAMBTS</td><td>Quyền tra cứu chiều nhận cuộc gọi có thông
tin trạm BTS(Chủ trì nghiệp vụ: TTCSKH
VTT)</td></tr><tr><td>99</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_WEB</td><td>BCCS2_CC_TRACU
U</td><td>BCCS2_CC_TRACUU</td><td>Tra cứu (menu) (Chủ trì nghiệp vụ:
TTCSKH VTT)</td></tr><tr><td>100</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_TRACU
U_TIN_NHAN_DAU
_SO_NGAN</td><td>BCCS2_CC_TRACU
U_DAUSONGAN_N
HAYCAM</td><td>Tra cứu đầu số ngắn nhạy
cảm</td><td>Tra cứu đầu số ngắn nhạy cảm (Chủ trì
nghiệp vụ: TT CSKH VTT)</td></tr><tr><td>101</td><td>Hệ thống Customer
Care 2.0</td><td>BCCS2_CC_TRACU
U</td><td>BCCS2_CC_TRACU
U_TIN_NHAN_DA
U_SO_NGAN</td><td>BCCS2_CC_TRACUU_T
IN_NHAN_DAU_SO_NG
AN</td><td>Chức năng tra cứu tin nhắn đầu số ngắn
(Chủ trì nghiệp vụ: TT CSKH VTT)</td></tr></tbody></table>

|<image_12>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>102</th><th>BI_CR_MANAGEME
NT</th><th></th><th>CR_MANAGEMEN
T</th><th>CR_MANAGEMENT</th><th>Module quản lý yêu cầu lấy dữ liệu (Chủ trì
nghiệp vụ: TT DAC VTT)</th></tr></thead><tbody><tr><td>103</td><td>Web hồ sơ nghị định 49</td><td></td><td>WEB_HO_SO_ND49
_LOGIN_WEB</td><td>Chức năng đăng nhập</td><td>Chức năng đăng nhập</td></tr><tr><td>104</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>BOC2.ROUTE.MAN
AGEMENT</td><td>Giám sát lộ trình bán hàng</td><td>Giám sát lộ trình bán hàng (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>105</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>boc.kpi.target</td><td>BOC2.SALE.POINT.
ROUTE</td><td>BOC.SALE.POINT.ROU
TE</td><td>lo trinh cskh (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>106</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC2_BAOCAO_T
HIPHAN_HUYEN</td><td>Báo cáo thị phần Huyện</td><td>Báo cáo thị phần Huyện (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>107</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN001</td><td>a. Báo cáo Thuê bao Di
động trả trước PSC 3K3D
ngày</td><td>a. Báo cáo Thuê bao Di động trả trước PSC
3K3D ngày(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>108</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN002</td><td>a.1 Báo cáo tiêu dùng di
động, dcom tra trước theo
Reg ngày</td><td>a.1 Báo cáo tiêu dùng di động, dcom tra
trước theo Reg ngày (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>109</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN003</td><td>b. Báo cáo Thuê bao trả
sau PSC thực ngày</td><td>b. Báo cáo Thuê bao trả sau PSC thực
ngày(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>110</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN004</td><td>c. Báo cáo Thuê bao
Dcom PSC 3K3D ngày</td><td>c. Báo cáo Thuê bao Dcom PSC 3K3D
ngày(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>111</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN005</td><td>d. Báo cáo Thuê bao HP
trả trước PSC 3K3D ngày</td><td>d. Báo cáo Thuê bao HP trả trước PSC
3K3D ngày (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>112</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN006</td><td>e. Báo cáo thuê bao
Register</td><td>e. Báo cáo thuê bao Register (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_13>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>113</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th>Báo cáo chi tiết ngày</th><th>BOC2_CTN007</th><th>f. Báo cáo Thuê bao 3G
trả sau PSC thực</th><th>f. Báo cáo Thuê bao 3G trả sau PSC
thực(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>114</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN008</td><td>g. Báo cáo Phát triển mới
các dịch vụ trả sau</td><td>g. Báo cáo Phát triển mới các dịch vụ trả
sau(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>115</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN009</td><td>h. Báo cáo Rời mạng mới
các dịch vụ trả sau</td><td>h. Báo cáo Rời mạng mới các dịch vụ trả
sau(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>116</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN010</td><td>i. Báo cáo Thuê bao Di
động, Dcom kích hoạt mới</td><td>i. Báo cáo Thuê bao Di động, Dcom kích
hoạt mới(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>117</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN011</td><td>j. Báo cáo Thuê bao 3G
trả trước PSC 3K3D ngày</td><td>j. Báo cáo Thuê bao 3G trả trước PSC
3K3D ngày(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>118</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN012</td><td>k. Báo cáo cước đóng
trước</td><td>k. Báo cáo cước đóng trước (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>119</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN013</td><td>l. Số liệu bán hàng theo
kênh - Biểu mẫu chi tiết</td><td>l. Số liệu bán hàng theo kênh - Biểu mẫu chi
tiết(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>120</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN014</td><td>m. Số liệu bán hàng theo
kênh - Biểu mẫu tổng hợp</td><td>m. Số liệu bán hàng theo kênh - Biểu mẫu
tổng hợp(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>121</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN015</td><td>n. Báo cáo 4G trả sau ngày</td><td>n. Báo cáo 4G trả sau ngày(Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>122</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN016</td><td>o. Báo cáo 4G trả trước
ngày</td><td>o. Báo cáo 4G trả trước ngày(Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_14>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>123</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th>Báo cáo chi tiết ngày</th><th>BOC2_CTN017</th><th>p. Báo cáo lũy kế phát
sinh cước thực VAS</th><th>p. Báo cáo lũy kế phát sinh cước thực VAS
(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>124</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN018</td><td>q. Báo cáo dịch vụ VAS</td><td>q. Báo cáo dịch vụ VAS (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>125</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN019</td><td>r. Báo cáo dịch vụ VAS
cấp tỉnh</td><td>r.Báo cáo dịch vụ VAS cấp tỉnh (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>126</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN020</td><td>s. Báo cáo dịch vụ VAS
theo kênh</td><td>s. Báo cáo dịch vụ VAS theo kênh (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>127</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN021</td><td>t. Báo cáo thuê bao phát
sinh lưu lượng đầu tiên</td><td>t. Báo cáo thuê bao phát sinh lưu lượng đầu
tiên(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>128</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết ngày</td><td>BOC2_CTN022</td><td>u. Báo cáo đăng ký hủy
data</td><td>u. Báo cáo đăng ký hủy data (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>129</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT001</td><td>a. Báo cáo Thuê bao thực
Di động, Dcom 3K3D tạo
ra từ tháng n</td><td>a. Báo cáo Thuê bao thực Di động, Dcom
3K3D tạo ra từ tháng n(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>130</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT002</td><td>b. Báo cáo Thuê bao trả
sau PSC thực tạo ra từ
tháng n</td><td>b. Báo cáo Thuê bao trả sau PSC thực tạo ra
từ tháng n(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>131</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT003</td><td>c. Báo cáo Thuê bao 3G
trả sau PSC thực tháng</td><td>c. Báo cáo Thuê bao 3G trả sau PSC thực
tháng(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>132</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT004</td><td>d. Báo cáo Thuê bao trả
sau PSC thực tháng</td><td>d. Báo cáo Thuê bao trả sau PSC thực
tháng(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_15>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>133</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th>Báo cáo chi tiết tháng</th><th>BOC2_CTT005</th><th>e. Báo cáo thuê bao
DCOM PSC 3K3D tháng</th><th>e. Báo cáo thuê bao DCOM PSC 3K3D
tháng(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>134</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT006</td><td>f. Báo cáo Thuê bao HP
trả trước PSC 3K3D tháng</td><td>f. Báo cáo Thuê bao HP trả trước PSC
3K3D tháng (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>135</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT007</td><td>g. Báo cáo thuê bao 3G
trả trước PSC 3K3D</td><td>g. Báo cáo thuê bao 3G trả trước PSC
3K3D(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>136</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo chi tiết tháng</td><td>BOC2_CTT008</td><td>h. Báo cáo thuê bao di
động trả trước PSC 3K3D</td><td>h. Báo cáo thuê bao di động trả trước PSC
3K3D(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>137</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC2_REPORT_DA
ILY</td><td>Báo cáo tổng hợp</td><td>Báo cáo tổng hợp(Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>138</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC2_REPORT_DE
TAIL_DAILY</td><td>Báo cáo chi tiết ngày</td><td>Báo cáo chi tiết ngày (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>139</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC2_REPORT_DE
TAIL_MONTHLY</td><td>Báo cáo chi tiết tháng</td><td>Báo cáo chi tiết tháng (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>140</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC2_REPORT_RE
PORTBI</td><td>report</td><td>Module Report(Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>141</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC2_REPORT_SX
KD</td><td>Báo cáo kết quả SXKD
chi tiết</td><td>Báo cáo kết quả SXKD chi tiết (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>142</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Xem các báo cáo của
hệ thống</td><td>BOC2_REPORT_VI
EW_PDF</td><td>Xuất báo cáo dạng file pdf</td><td>Xuất báo cáo dạng file pdf(Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_16>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>143</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th>report</th><th>BOC2_REPORT_VI
EW_REPORT</th><th>Xem các báo cáo của hệ
thống</th><th>Chức năng dùng để phân quyền view báo
cáo(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>144</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Xem các báo cáo của
hệ thống</td><td>BOC2_REPORT_VI
EW_REPORT_EXC
EL</td><td>Xuất báo cáo dạng excel</td><td>Xuất báo cáo dạng excel(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>145</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Xem các báo cáo của
hệ thống</td><td>BOC2_REPORT_VI
EW_REPORT_TEX
T</td><td>Xuất báo cáo dạng file text</td><td>Xuất báo cáo dạng file text(Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>146</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo kết quả
SXKD chi tiết</td><td>BOC2_SXKD001</td><td>3.1 Báo cáo Doanh thu
tiêu dùng chi nhánh</td><td>3.1 Báo cáo Doanh thu tiêu dùng chi nhánh
(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>147</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo kết quả
SXKD chi tiết</td><td>BOC2_SXKD002</td><td>3.2 Báo cáo Tổng hợp kết
quả thuê bao</td><td>3.2 Báo cáo Tổng hợp kết quả thuê bao(Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>148</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo tổng hợp</td><td>BOC2_TH001</td><td>1.1 Kết quả SXKD ngày</td><td>1.1 Kết quả SXKD ngày(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>149</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo tổng hợp</td><td>BOC2_TH002</td><td>1.2 Kết quả SXKD tháng</td><td>1.2 Kết quả SXKD tháng(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>150</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>Báo cáo tổng hợp</td><td>BOC2_TH003</td><td>1.3 Báo cáo tổng hợp kết
quả SXKD CN&amp;DN</td><td>1.3 Báo cáo tổng hợp kết quả SXKD
CN&amp;DN(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>151</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>BOC_FTTH_DOIDA
Y_PTM</td><td>THUÊ BAO TRUYỀN
HÌNH DÙNG CHUNG
THUÊ BAO FTTH - Phát
triển mới</td><td>THUÊ BAO TRUYỀN HÌNH DÙNG
CHUNG THUÊ BAO FTTH - Phát triển
mới (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_17>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>152</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th></th><th>BOC_FTTH_PSC_T
HUC</th><th>THUÊ BAO TRUYỀN
HÌNH DÙNG CHUNG
THUÊ BAO FTTH- PSC
thực</th><th>THUÊ BAO TRUYỀN HÌNH DÙNG
CHUNG THUÊ BAO FTTH- PSC thực
(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>153</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC_WEB</td><td>GBOC.ALARM</td><td>GBOC.ALARM</td><td>Giám sát cảnh báo (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>154</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>GBOC.ALARM.ARE
A</td><td>Khoang vùng sự cố</td><td>Cảnh báo doanh thu, thuê bao (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>155</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC_WEB</td><td>GBOC.ALARM.B2B</td><td>Cảnh báo khối KHDN</td><td>Cảnh báo khối KHDN (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>156</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>GBOC.ALARM.DEB
T.CHART</td><td>Cảnh báo công nợ trên
biểu đồ</td><td>Quyền nhìn thấy Cảnh báo công nợ trên
biểu đồ (Chủ trì nghiệp vụ: TT QLBH
VTT-Phuongphuong)</td></tr><tr><td>157</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>GBOC.ALARM.MA
PMNGT</td><td>GBOC.ALARM.MAPMN
GT</td><td>Cảnh báo trên bản đồ (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>158</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>GBOC.ALARM.STA
FF.MNGT</td><td>GBOC.ALARM.STAFF.
MNGT</td><td>KPIs cảnh báo giám đốc (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>159</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>GBOC.ALARM.UN
USUAL</td><td>Cảnh báo bất thường</td><td>Cảnh báo bất thường (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>160</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.KPI_TARGET</td><td>GBOC.BOC2SALE.P
OINT.ROUTE</td><td>GBOC.BOC2SALE.POIN
T.ROUTE</td><td>Lộ trình chăm sóc điểm bán (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>161</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>Cảnh báo khối KHDN</td><td>GBOC.BUSSINESS.I
NTERNATIONAL</td><td>Kinh doanh quốc tế</td><td>Kinh doanh quốc tế (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr></tbody></table>

|<image_18>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>162</th><th>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</th><th>GBOC.KPI_TARGET</th><th>GBOC.CAMPAIGN.
STATION</th><th>BOC2.CAMPAIGN.STA
TION</th><th>Quản lý chiến dịch trạm thoát lỗ (Chủ trì
nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>163</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC_WEB</td><td>GBOC.CONF_SYST
EM</td><td>GBOC.CONF_SYSTEM</td><td>Cấu hình hệ thống (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>164</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.CONF_SYSTE
M</td><td>GBOC.CONF_SYST
EM.IMPORT</td><td>Import dữ liệu</td><td>Import dữ liệu (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>165</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>Import dữ liệu</td><td>GBOC.CONF_SYST
EM.IMPORT.MAP.
USER.CHANNEL</td><td>Map user với kênh</td><td>Quyền Map user với kênh (Chủ trì nghiệp
vụ: TT QLBH VT-tuanlm@)</td></tr></tbody></table>

<table><thead><tr><th>166</th><th>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</th><th>GBOC.ALARM</th><th>GBOC.DASHBOAR
D.ALARM</th><th>GBOC.DASHBOARD.AL
ARM</th><th>Cảnh báo kinh doanh (Chủ trì nghiệp vụ:
TTĐH VTT)</th></tr></thead><tbody><tr><td>167</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.KPI_TARGET</td><td>GBOC.KPI.TARGET
.ASSIGN</td><td>GBOC.KPI.TARGET.AS
SIGN</td><td>Giao chỉ tiêu kinh doanh (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>168</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC_WEB</td><td>GBOC.KPI_TARGE
T</td><td>GBOC.KPI_TARGET</td><td>Giao chỉ tiêu (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>169</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.WORK.PROC
ESS</td><td>GBOC.MP.PLAN.AS
SIGNSTAFF.PROGR
AM</td><td>GBOC.MP.PLAN.ASSIG
NSTAFF.PROGRAM</td><td>Giao việc theo chương trình trọng điểm
(Chủ trì nghiệp vụ: TT ĐH VTT)</td></tr><tr><td>170</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.WORK.PROC
ESS</td><td>GBOC.MP.PLAN.IM
PPROGRAMREPOR
T</td><td>GBOC.MP.PLAN.IMPPR
OGRAMREPORT</td><td>Báo cáo CSKH trọng điểm (Chủ trì nghiệp
vụ: TT ĐH VTT)</td></tr><tr><td>171</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.REPORT_GE
NERAL</td><td>GBOC.REPORT</td><td>GBOC.REPORT</td><td>Báo cao hệ thống GBOC (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_19>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>172</th><th>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</th><th>GBOC.REPORT_GE
NERAL</th><th>GBOC.REPORT_AU
TO_REPORT</th><th>GBOC.REPORT_AUTO_
REPORT</th><th>Báo cáo SXKD gửi tự động (Chủ trì nghiệp
vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>173</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC_WEB</td><td>GBOC.REPORT_GE
NERAL</td><td>GBOC.REPORT_GENER
AL</td><td>Báo cáo (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>174</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.KPI_TARGET</td><td>GBOC.SALE.PLAN
CTV</td><td>GBOC.SALE.PLANCTV</td><td>Kế hoạch bán hàng của CTV (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>175</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.KPI_TARGET</td><td>GBOC.SHOP.CARE.
ROUTE</td><td>Lộ trình chăm sóc cửa
hàng</td><td>Lộ trình chăm sóc cửa hàng (Chủ trì nghiệp
vụ: Phòng NV - TTĐH VTT-
hoantd@)/thuynt28@</td></tr><tr><td>176</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.WORK.PROC
ESS</td><td>GBOC.WORK.MAN
AGEMENT</td><td>GBOC.WORK.MANAGE
MENT</td><td>Quản lý công việc (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>177</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC_WEB</td><td>GBOC.WORK.PRO
CESS</td><td>GBOC.WORK.PROCESS</td><td>Điều hành (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>178</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_35TR_T
B_STAN_INFO</td><td>Báo cáo giao chỉ tiêu
chuẩn hóa thông tin</td><td>Báo cáo giao chỉ tiêu chuẩn hóa thông tin
(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>179</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_CSK_TH
EO_LO_TRINH</td><td>BÁO CÁO CHĂM SÓC
KÊNH THEO LỘ TRÌNH</td><td>BÁO CÁO CHĂM SÓC KÊNH THEO LỘ
TRÌNH(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>180</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_CTV_H
T0BHTHEOKH</td><td>Báo cóa chi tiết hạ tầng
lập kế hoạch nhưng không
bán hàng theo kế hoạch</td><td>Báo cóa chi tiết hạ tầng lập kế hoạch nhưng
không bán hàng theo kế hoạch (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>181</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_CTV_T
HUCHIEN_KHBH</td><td>Báo cáo toổng hợp công
tác thực hiện KH bán hàng</td><td>Báo cáo toổng hợp công tác thực hiện KH
bán hàng (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_20>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>182</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th></th><th>GBOC_BC_CT_CSK</th><th>BÁO CÁO CHI TIẾT
CHĂM SÓC KÊNH</th><th>BÁO CÁO CHI TIẾT CHĂM SÓC
KÊNH(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>183</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_CT_HA
DB</td><td>BÁO CÁO CHI TIẾT
HÌNH ẢNH ĐIỂM BÁN</td><td>BÁO CÁO CHI TIẾT HÌNH ẢNH ĐIỂM
BÁN(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>184</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_SD_BO
C2_DISTR_DETAIL</td><td>Báo cáo chi tiết huyện</td><td>Báo cáo chi tiết huyện(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>185</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_SD_BO
C2_PRV_CD</td><td>Báo cáo tổng hợp tỉnh
theo chức danh</td><td>Báo cáo tổng hợp tỉnh theo chức danh (Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>186</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_SD_BO
C2_PRV_DETAIL</td><td>Báo cáo chi tiết tỉnh</td><td>Báo cáo chi tiết tỉnh (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>187</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_SD_BO
C2_PRV_GCT</td><td>Báo cáo thống kê giao
chỉ tiêu</td><td>Báo cáo thống kê giao chỉ tiêu(Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>188</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_SD_BO
C2_PRV_WO</td><td>Báo cáo cập nhật wo theo
tỉnh</td><td>Báo cáo cập nhật wo theo tỉnh (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>189</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_SUDUN
G_BOC2_PROVINC
E</td><td>Báo cáo tổng hợp tỉnh
theo đơn vị</td><td>Báo cáo tổng hợp tỉnh theo đơn vị (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>190</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_TB_MU
A_DATA</td><td>5. Số lượt và số lượng TB
mua gói data theo kênh tư
vấn</td><td>5. Số lượt và số lượng TB mua gói data theo
kênh tư vấn (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>191</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_TB_MU
A_FT</td><td>6. Số lượt và số lượng TB
mua gói FT theo kênh tư
vấn</td><td>6. Số lượt và số lượng TB mua gói FT theo
kênh tư vấn (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_21>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>192</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th></th><th>GBOC_BC_TH_CSK</th><th>BÁO CÁO TỔNG HỢP
CHĂM SÓC KÊNH</th><th>BÁO CÁO TỔNG HỢP CHĂM SÓC
KÊNH(Chủ trì nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>193</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_TH_HA
DB</td><td>BÁO CÁO TỔNG HỢP
HÌNH ẢNH ĐIỂM BÁN</td><td>BÁO CÁO TỔNG HỢP HÌNH ẢNH ĐIỂM
BÁN(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>194</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_BC_TS_CS_
KENH</td><td>BÁO CÁO TẦN SUẤT
CHĂM SÓC KÊNH</td><td>BÁO CÁO TẦN SUẤT CHĂM SÓC
KÊNH(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>195</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_CONGNO_N
V</td><td>Báo cáo đánh giá công nợ
theo nhân viên</td><td>Báo cáo đánh giá công nợ theo nhân
viên(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>196</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_CONGNO_T
INH</td><td>Báo cáo công nợ cấp Tỉnh</td><td>Báo cáo công nợ cấp Tỉnh (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>197</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_CT_CS_KEN
H_BM05</td><td>BÁO CÁO CHI TIẾT
CHĂM SÓC
KÊNH_BM05</td><td>BÁO CÁO CHI TIẾT CHĂM SÓC
KÊNH_BM05(Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>198</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_CT_TRAM_
LO_HUYEN</td><td>Báo cáo chi tiết trạm lỗ
mức Huyện</td><td>Báo cáo chi tiết trạm lỗ mức Huyện(Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>199</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_HS_NOD_C
DBR</td><td>Báo cáo sử dụng node
CĐBR</td><td>Báo cáo sử dụng node CĐBR(Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>200</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_HS_TRAM</td><td>Báo cáo hiệu suất trạm</td><td>Báo cáo hiệu suất trạm(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>201</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_RPT_TB_TT
_PSLL_60</td><td>1. Thuê bao di động trả
trước đạt thực trong vòng
60 ngày kể từ ngày kích
hoạt</td><td>1. Thuê bao di động trả trước đạt thực trong
vòng 60 ngày kể từ ngày kích hoạt (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr></tbody></table>

|<image_22>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>202</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th></th><th>GBOC_SEARCH_A
CCOUNT</th><th>Tìm kiếm account</th><th>Tìm kiếm account(Chủ trì nghiệp vụ:
TTĐH VTT)</th></tr></thead><tbody><tr><td>203</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_STAFF_FAI
L_3MONTH</td><td>Báo cáo nhân viên không
đạt chỉ tiêu 3 tháng</td><td>Báo cáo nhân viên không đạt chỉ tiêu 3
tháng(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>204</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_STAFF_SU
M_FAIL_3MONTH</td><td>Báo cáo tổng hợp nhân
viên không hoàn thành
chỉ tiêu 3 tháng</td><td>Báo cáo tổng hợp nhân viên không hoàn
thành chỉ tiêu 3 tháng(Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>205</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_STATION_
MOBILE</td><td>Báo cáo trạm di động</td><td>Báo cáo trạm di động (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>206</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TB_DD_4G_
PSLL_TS</td><td>3. Thuê bao di động trả
sau đăng ký gói data và
PSLL trên hạ tầng 4G lần
đầu</td><td>3. Thuê bao di động trả sau đăng ký gói data
và PSLL trên hạ tầng 4G lần đầu (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>207</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TB_DD_4G_
PSLL_TT</td><td>2. Thuê bao di động trả
trước đăng ký gói data và
PSLL trên hạ tầng 4G lần
đầu</td><td>2. Thuê bao di động trả trước đăng ký gói
data và PSLL trên hạ tầng 4G lần đầu (Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>208</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TB_MUA_G
OI_ONME</td><td>7. Thuê bao di động phát
sinh lưu lượng sử dụng
DV Onme tối thiểu 3
ngày trong tháng</td><td>7. Thuê bao di động phát sinh lưu lượng sử
dụng DV Onme tối thiểu 3 ngày trong tháng
(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>209</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TB_RM_PSC
_200K_VIP</td><td>4. Thuê bao trả trước
tháng N-1 sử dụng trên
200K, rời mạng hoặc có
tiêu dùng dưới 200K
trong tháng</td><td>4. Thuê bao trả trước tháng N-1 sử dụng
trên 200K, rời mạng hoặc có tiêu dùng dưới
200K trong tháng (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr></tbody></table>

|<image_23>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>210</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th></th><th>GBOC_TDTH_CAP
HUYEN_ALL</th><th>Báo cáo tổng hợp cấp
huyện</th><th>Báo cáo tổng hợp cấp huyện(Chủ trì nghiệp
vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>211</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TDTH_CAP
HUYEN_CT</td><td>Báo cáo thực hiện chỉ tiêu
cấp huyện</td><td>Báo cáo thực hiện chỉ tiêu cấp huyện(Chủ
trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>212</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TDTH_CAP
NHANVIEN_KENH</td><td>Báo cáo chi tiết nhân viên
thực hiện các kênh</td><td>Báo cáo chi tiết nhân viên thực hiện các
kênh (Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>213</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TDTH_CAP
NHANVIEN_KENH
S</td><td>Báo cáo chi tiết nhân viên
thực hiện theo kênh</td><td>Báo cáo chi tiết nhân viên thực hiện theo
kênh(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>214</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TDTH_CAP
TINH_ALL</td><td>Báo cáo tổng hợp cấp tỉnh</td><td>Báo cáo tổng hợp cấp tỉnh (Chủ trì nghiệp
vụ: TTĐH VTT)</td></tr><tr><td>215</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td>2.02 Báo cáo thực
hiện cấp tỉnh</td><td>GBOC_TDTH_CAP
TINH_CHTT</td><td>Báo cáo tổng hợp tỉnh cấp
CHTT</td><td>Báo cáo tổng hợp tỉnh cấp CHTT --(Chủ trì
nghiệp vụ: TT ĐHBH VTT- tuanlm@)</td></tr><tr><td>216</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TDTH_CT_
CAPTINH</td><td>Báo cáo thực hiện chỉ tiêu
cấp tỉnh</td><td>Báo cáo thực hiện chỉ tiêu cấp tỉnh (Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>217</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TD_THUCU
OC_KHONGTC</td><td>BC cảnh báo CTV không
tham gia thu cước</td><td>BC cảnh báo CTV không tham gia thu
cước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>218</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TD_THUCU
OC_NVQL</td><td>BC NVQL có ít nhất 2
CTV không tham gia thu
cước</td><td>BC NVQL có ít nhất 2 CTV không tham gia
thu cước(Chủ trì nghiệp vụ: TTĐH VTT)</td></tr><tr><td>219</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TH_KQTX_
CO_DINH</td><td>Báo cáo giao tổng hợp
giao và kết quả tiếp xúc
cố định</td><td>Báo cáo giao tổng hợp giao và kết quả tiếp
xúc cố định (Chủ trì nghiệp vụ: Phòng NV -
TTĐH VTT- phuongphuong@)</td></tr></tbody></table>

|<image_24>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>220</th><th>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</th><th></th><th>GBOC_TH_TRAM_
LO_HUYEN</th><th>Báo cáo TH trạm lỗ mức
Huyện</th><th>Báo cáo TH trạm lỗ mức Huyện(Chủ trì
nghiệp vụ: TTĐH VTT)</th></tr></thead><tbody><tr><td>221</td><td>Hệ thống báo cáo điều
hành kinh doanh
BOC2.0</td><td></td><td>GBOC_TH_TRAM_
LO_TINH</td><td>Báo cáo TH trạm lỗ mức
Tỉnh</td><td>Báo cáo TH trạm lỗ mức Tỉnh(Chủ trì
nghiệp vụ: TTĐH VTT)</td></tr><tr><td>222</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td></td><td>GBOC_WEB</td><td>GBOC_WEB</td><td>GBOC_WEB (Chủ trì nghiệp vụ: TTĐH
VTT)</td></tr><tr><td>223</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>boc.kpi.target</td><td>NEW_BOC_COMM
ON.ASSIGN_KPI</td><td>NEW_BOC_COMMON.
ASSIGN_KPI</td><td>Giao chi tieu</td></tr><tr><td>224</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td></td><td>NEW_BOC_REPOR
T</td><td>Phân hệ Báo cáo</td><td>Phân hệ báo cáo</td></tr><tr><td>225</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>Phân hệ Báo cáo</td><td>NEW_BOC_REPOR
T.REPORT_LOG</td><td>Log báo cáo</td><td>Report Log</td></tr><tr><td>226</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>Phân hệ Báo cáo</td><td>NEW_BOC_REPOR
T.REPORT_LOG.RE
PORT_MANAGEM
ENT</td><td>Quản lý báo cáo</td><td>Report Management</td></tr><tr><td>227</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>Phân hệ Báo cáo</td><td>NEW_BOC_REPOR
T.VIEW_REPORT</td><td>Xem báo cáo</td><td>View report</td></tr><tr><td>228</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>Giám sát cảnh báo</td><td>boc.alarm.mapMngt</td><td>BOC.MAP.ALARM</td><td>Giám sát trên bản đồ</td></tr><tr><td>229</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>Giám sát cảnh báo</td><td>boc.dashboard.alarm</td><td>BOC.DASHBOARD.ALA
RM</td><td>Điều hành giám sát</td></tr></tbody></table>

|<image_25>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>230</th><th>Hệ thống điều hành
kinh doanh tập trung 2.0</th><th></th><th>boc2.alarm</th><th>Giám sát cảnh báo</th><th>Giám sát cảnh báo</th></tr></thead><tbody><tr><td>231</td><td>Hệ thống điều hành
kinh doanh toàn cầu
GBOC</td><td>GBOC.ALARM</td><td>boc2.alarm.chart</td><td>Cảnh báo theo biểu đồ</td><td>Cảnh báo theo biểu đồ (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>232</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td></td><td>boc2.dashboard.dash
board</td><td>common.config</td><td>Cấu hình</td></tr><tr><td>233</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td></td><td>boc2.kpi.target</td><td>boc.kpi.target</td><td>Quản lý danh mục (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>234</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td></td><td>boc2.mainPoint.plan</td><td>boc.mainPoint.plan</td><td>ban hang trong diem (Chủ trì nghiệp vụ:
TTĐH VTT)</td></tr><tr><td>235</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>boc.mainPoint.plan</td><td>boc2.mainPoint.plan.
assignIsdnStaff.custo
mer.care</td><td>customer.care.assign.isdn</td><td>Báo cáo chi tiết cập nhật KQ tiếp xúc (Chủ
trì nghiệp vụ: Phòng NV - TTĐH VTT-
phuongphuong@)</td></tr><tr><td>236</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>boc.mainPoint.plan</td><td>boc2.mainPoint.plan.
assignIsdnStaff.progr
am</td><td>boc.mainPoint.plan.assign
IsdnStaff.program</td><td>khach hang trong diem</td></tr><tr><td>237</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>boc.mainPoint.plan</td><td>boc2.mainPoint.plan.
assignStaff.sales</td><td>boc.mainPoint.plan.assign
Staff.sales</td><td>chuong trinh trong diem</td></tr><tr><td>238</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>common.config</td><td>boc2.menu.config</td><td>common.menu.manage.co
nfig</td><td>Quản lý cấu hình</td></tr><tr><td>239</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>common.menu.manage
.config</td><td>boc2.menu.config.rep
ort</td><td>com.dashboard.report</td><td>Quản lý báo cáo</td></tr></tbody></table>

|<image_26>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>240</th><th>Hệ thống điều hành
kinh doanh tập trung 2.0</th><th></th><th>boc2.work.process</th><th>BOC.WORK.PROCESS</th><th>Điều hành</th></tr></thead><tbody><tr><td>241</td><td>Hệ thống báo cáo
BOC2_TTDHKD VTT</td><td></td><td>olapBOC2</td><td>olapBOC2</td><td></td></tr><tr><td>242</td><td>Hệ thống báo cáo
BOC2_TTDHKD VTT</td><td>olapBOC2</td><td>viewOlapBOC2</td><td>viewOlap</td><td></td></tr><tr><td>243</td><td>Hệ thống điều hành
kinh doanh tập trung 2.0</td><td>BOC.WORK.PROCE
SS</td><td>work.management</td><td>BOC.WORK.MANAGE
MENT</td><td>Quản lý công việc</td></tr><tr><td>244</td><td>Hệ thống đánh giá
Callbot</td><td>manager.work</td><td>CALLBOT_ASSIGN
_WORK</td><td>assign.work</td><td>Phân công công việc (Chủ trì nghiệp vụ: TT
DVKH và TT DAC - VTT)</td></tr><tr><td>245</td><td>Hệ thống đánh giá
Callbot</td><td>manager.work</td><td>CALLBOT_BO_PER
MISSION</td><td>permission.callbot.bo</td><td>Quyền xử lý logic của BO (Chủ trì nghiệp
vụ: TT DVKH/TT PTDL - VTT)</td></tr><tr><td>246</td><td>Hệ thống đánh giá
Callbot</td><td>manager.work</td><td>CALLBOT_BO_SEA
RCH_FIELDS_PER
MISSION</td><td>permission.bo.search_field
s</td><td>Quyền hiển thị thêm các trường tìm kiếm
chỉ riêng BO/Admin (Chủ trì nghiệp vụ: TT
DVKH và TT DAC - VTT)</td></tr><tr><td>247</td><td>Hệ thống đánh giá
Callbot</td><td>manager.work</td><td>CALLBOT_CALLIN
FO_MANAGEMEN
T</td><td>manager.callinfo</td><td>Quản lý cuộc gọi (Chủ trì nghiệp vụ: TT
DVKH và TT DAC - VTT)</td></tr><tr><td>248</td><td>Hệ thống đánh giá
Callbot</td><td></td><td>CALLBOT_CATAL
OG_MANAGEMEN
T</td><td>manager.catalog</td><td>Quản lý danh mục (Chủ trì nghiệp vụ: TT
DAC/TT CSKH VTT)</td></tr><tr><td>249</td><td>Hệ thống đánh giá
Callbot</td><td>manager.catalog</td><td>CALLBOT_CATEG
ORY_MANAGEME
NT</td><td>manager.category</td><td>Quản lý nghiệp vụ (Chủ trì nghiệp vụ: TT
DVKH và TT DAC - VTT)</td></tr></tbody></table>

|<image_27>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>250</th><th>Hệ thống đánh giá
Callbot</th><th>manager.work</th><th>CALLBOT_DOWNL
OAD_AUDIO_PER
MISSION</th><th>permission.download.audi
o</th><th>Quyền download audio (Chủ trì nghiệp vụ:
TT DVKH và TT DAC - VTT)</th></tr></thead><tbody><tr><td>251</td><td>Hệ thống đánh giá
Callbot</td><td>manager.work</td><td>CALLBOT_EVALU
ATE_CALLINFO_P
ERMISSION</td><td>permission.evaluate.callinf
o</td><td>Quyền đánh giá cuộc gọi (Chủ trì nghiệp
vụ: TT DVKH và TT DAC - VTT)</td></tr><tr><td>252</td><td>Hệ thống đánh giá
Callbot</td><td>manager.catalog</td><td>CALLBOT_INTENT
_MANAGEMENT</td><td>manager.intent</td><td>Quản lý intent (Chủ trì nghiệp vụ: TT
DVKH và TT DAC - VTT)</td></tr><tr><td>253</td><td>Hệ thống đánh giá
Callbot</td><td>manager.catalog</td><td>CALLBOT_REASO
N_MANAGEMENT</td><td>manager.reason</td><td>Quản lý nguyên nhân (Chủ trì nghiệp vụ:
TT DVKH và TT DAC - VTT)</td></tr><tr><td>254</td><td>Hệ thống đánh giá
Callbot</td><td>manager.work</td><td>CALLBOT_RECHE
CK_EVALUATE_P
ERMISSION</td><td>permission.recheck.evalua
te</td><td>Quyền kiểm định kết quả (Chủ trì nghiệp
vụ: TT DVKH và TT DAC - VTT)</td></tr><tr><td>255</td><td>Hệ thống đánh giá
Callbot</td><td>manager.report</td><td>CALLBOT_REPOR
T_EVALUATE_PER
MISSION</td><td>permission.report.evaluate</td><td>Quyền xuất báo cáo đánh giá BOT (Chủ trì
nghiệp vụ: TT DVKH và TT DAC - VTT)</td></tr><tr><td>256</td><td>Hệ thống đánh giá
Callbot</td><td>manager.report</td><td>CALLBOT_REPOR
T_IMPACT_PERMI
SSION</td><td>permission.report.impact</td><td>Quyền xuất báo cáo tác động (Chủ trì
nghiệp vụ: TT DVKH và TT DAC - VTT)</td></tr><tr><td>257</td><td>Hệ thống đánh giá
Callbot</td><td></td><td>CALLBOT_REPOR
T_MANAGEMENT</td><td>manager.report</td><td>Báo cáo (Chủ trì nghiệp vụ: TT DVKH và
TT DAC - VTT)</td></tr><tr><td>258</td><td>Hệ thống đánh giá
Callbot</td><td>manager.report</td><td>CALLBOT_REPOR
T_RECHECK_PER
MISSION</td><td>permission.report.recheck</td><td>Quyền xuất báo cáo kiểm định(Chủ trì
nghiệp vụ: TT DVKH và TT DAC - VTT)</td></tr><tr><td>259</td><td>Hệ thống đánh giá
Callbot</td><td>manager.catalog</td><td>CALLBOT_USER_
MANAGEMENT</td><td>manager.user</td><td>Quản lý user (Chủ trì nghiệp vụ: TT DVKH
và TT DAC - VTT)</td></tr></tbody></table>

|<image_28>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>260</th><th>Hệ thống đánh giá
Callbot</th><th>manager.work</th><th>CALLBOT_VIEW_C
HECK_RESULT_PE
RMISSION</th><th>permission.view.check.res
ult</th><th>Quyền xem lại kết quả kiểm định (Chủ trì
nghiệp vụ: TT DVKH và TT DAC - VTT)</th></tr></thead><tbody><tr><td>261</td><td>Hệ thống đánh giá
Callbot</td><td></td><td>CALLBOT_WORK_
MANAGEMENT</td><td>manager.work</td><td>Quản lý công việc (Chủ trì nghiệp vụ: TT
DVKH và TT DAC - VTT)</td></tr><tr><td>262</td><td>Hệ thống đánh giá
Callbot</td><td>manager.catalog</td><td>CALLBOT_CONFIG
_MANAGEMENT</td><td>manager.config</td><td>Quản lý cấu hình (Chủ trì nghiệp vụ: TT
DVKH/TT PTDL - VTT)</td></tr><tr><td>263</td><td>Hệ thống đánh giá
Callbot</td><td>manager.tts.record</td><td>CALLBOT_IMPACT
_ALL_TTS_RECOR
D_PERMISSION</td><td>permission.impact.all.tts.r
ecord</td><td>Quyền được tác động tất cả các kịch bản thu
âm (Chủ trì nghiệp vụ: TT DVKH/TT
PTDL - VTT)</td></tr><tr><td>264</td><td>Hệ thống đánh giá
Callbot</td><td></td><td>CALLBOT_TTS_RE
CORD_MANAGEM
ENT</td><td>manager.tts.record</td><td>Quản lý kịch bản thu âm (Chủ trì nghiệp vụ:
TT DVKH/TT PTDL - VTT)</td></tr><tr><td>265</td><td>Hệ thống đánh giá
Callbot</td><td>manager.config</td><td>CALLBOT_TTS_RE
CORD_PARAM_PE
RMISSION</td><td>permission.param.callbot.t
ts.record</td><td>Quyền quản lý cấu hình tham số thu âm
callbot (Chủ trì nghiệp vụ: TT DVKH/TT
PTDL - VTT)</td></tr><tr><td>266</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.statistic_repo
rt</td><td>CALLMONITOR_A
GENT_CALL_STAT
ISTIC</td><td>manager.agent_call_statist
ic</td><td>Thống kê lượng cuộc gọi tiếp nhận của từng
agent trên tổng đài (Chủ trì nghiệp vụ: TT
DAC/TT DVKH VTT--duyentd/linhnvc)</td></tr><tr><td>267</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td></td><td>CALLMONITOR_C
ONFIGURATION</td><td>manager.configuration</td><td>Quản lý thông tin đánhá (Chủ trì nghiệp vụ:
TT PTDL VTT-binhnn7)</td></tr><tr><td>268</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.configuration</td><td>CALLMONITOR_P
ATTERN_CONFIGU
RATION</td><td>manager.pattern_configura
tion</td><td>Quản lý cấu hình tham số đánh giá (Chủ trì
nghiệp vụ: TT PTDL VTT-binhnn7)</td></tr></tbody></table>

|<image_29>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>269</th><th>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</th><th></th><th>CALLMONITOR_S
TATISTIC_REPORT</th><th>manager.statistic_report</th><th>Chức năng thống kê, báo cáo kết quả Giám
sát cuộc gọi (Chủ trì nghiệp vụ: TT
DAC/TT DVKH VTT-duyentd/linhnvc)</th></tr></thead><tbody><tr><td>270</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.statistic_repo
rt</td><td>CALLMONITOR_T
OPIC_SUMMARY</td><td>manager.topic_summary</td><td>Dashboard thống kê nhu cầu theo chủ đề
cuộc gọi (Chủ trì nghiệp vụ: TT DAC/TT
DVKH VTT--duyentd/linhnvc)</td></tr><tr><td>271</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.statistic_repo
rt</td><td>CALLMONITOR_T
OP_NOK</td><td>manager.top_nok</td><td>Thống kê top nhân viên có số lượng cuộc
gọi NOK cao để cảnh báo, nhắc nhở (Chủ
trì nghiệp vụ: TT DAC/TT DVKH VTT--
duyentd/linhnvc)</td></tr><tr><td>272</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.call_info_em
otion</td><td>CALL_INFO_EMOT
ION_EXPORT</td><td>callInfoEmotionExport</td><td>Quyền xuất báo cáo thông tin cảm xúc cuộc
gọi (Chủ trì nghiệp vụ: TT DAC/TT CSKH
VTT-toannv47)</td></tr><tr><td>273</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.menu</td><td>CALL_INFO_EMOT
ION_MANAGEMEN
T</td><td>manager.call_info_emotio
n</td><td>Quản lý thông tin cảm xúc cuộc gọi (Chủ trì
nghiệp vụ: TT DAC/TT CSKH VTT-
toannv47)</td></tr><tr><td>274</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.call_info_em
otion</td><td>CALL_INFO_EMOT
ION_UPDATE</td><td>callInfoEmotionUpdate</td><td>Quyền cập nhật thông tin cảm xúc cuộc gọi
(Chủ trì nghiệp vụ: TT DAC/TT CSKH
VTT-toannv47)</td></tr><tr><td>275</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.menu</td><td>CALL_INFO_MONI
TOR</td><td>callInfoMonitor</td><td>Quyền kiểm định viên (Chủ trì nghiệp vụ:
TT DAC/TT CSKH VTT-toannv47)</td></tr><tr><td>276</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.menu</td><td>CALL_INFO_USER
_MANAGEMENT</td><td>manager.call_info_user</td><td>Quản lý người dùng (Chủ trì nghiệp vụ: TT
DAC/TT CSKH VTT)</td></tr><tr><td>277</td><td>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</td><td>manager.menu</td><td>HOME_PAGE_CAL
LMONITOR</td><td>Trang chủ</td><td>Link về trang chủ (Chủ trì nghiệp vụ: TT
DAC/TT CSKH VTT-toannv47)</td></tr></tbody></table>

|<image_30>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>278</th><th>Hệ thống giám sát cuộc
gọi CSKH phân hệ web
TT CSKH</th><th></th><th>MENU_CATEGORY</th><th>manager.menu</th><th>Quản lý danh mục (Chủ trì nghiệp vụ: TT
DAC/TT CSKH VTT-toannv47)</th></tr></thead><tbody><tr><td>279</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_CREATE</td><td>Thêm mới chiến dịch</td><td>Thêm mới chiến dịch SMSBB - (Chủ trì
nghiệp vụ: BU Chiến dịch -TT CNTT VTT)</td></tr><tr><td>280</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_REPORT_EXPOR
T</td><td>Export kết quả triển khai
chiến dịch SMSBB</td><td>Export kết quả triển khai chiến dịch
SMSBB - (Chủ trì nghiệp vụ: BU Chiến
dịch -TT CNTT VTT)</td></tr><tr><td>281</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_REPORT_ROLES</td><td>Kết quả triển khai chiến
dịch SMSBB</td><td>Kết quả triển khai chiến dịch SMSBB -
(Chủ trì nghiệp vụ: BU Chiến dịch -TT
CNTT VTT)</td></tr><tr><td>282</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_REPORT_SEARC
H</td><td>Tìm kiếm kết quả triển
khai chiến dịch SMSBB</td><td>Tìm kiếm kết quả triển khai chiến dịch
SMSBB - (Chủ trì nghiệp vụ: BU Chiến
dịch -TT CNTT VTT)</td></tr><tr><td>283</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_RESULT_TEST</td><td>Kết quả test</td><td>Kết quả test chiến dịch SMSBB - (Chủ trì
nghiệp vụ: BU Chiến dịch -TT CNTT VTT)</td></tr><tr><td>284</td><td>Hệ thống Campaign
Management 2.0</td><td></td><td>CAMPAIGN_SMSB
B_ROLES</td><td>Quản lý chiến dịch
SMSBB</td><td>Quản lý chiến dịch SMSBB - (Chủ trì
nghiệp vụ: BU Chiến dịch -TT CNTT VTT)</td></tr><tr><td>285</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_RUNNING</td><td>Triển khai</td><td>Triển khai chiến dịch SMSBB - (Chủ trì
nghiệp vụ: BU Chiến dịch -TT CNTT VTT)</td></tr><tr><td>286</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_SEARCH</td><td>Tìm kiếm chiến dịch</td><td>Tìm kiếm chiến dịch SMSBB - (Chủ trì
nghiệp vụ: BU Chiến dịch -TT CNTT VTT)</td></tr><tr><td>287</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_STOP</td><td>Dừng triển khai</td><td>Dừng triển khai chiến dịch SMSBB - (Chủ
trì nghiệp vụ: BU Chiến dịch -TT CNTT
VTT)</td></tr></tbody></table>

|<image_31>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>288</th><th>Hệ thống Campaign
Management 2.0</th><th>Quản lý chiến dịch
SMSBB</th><th>CAMPAIGN_SMSB
B_TEST_MESSAGE</th><th>Test tin nhắn</th><th>Test tin nhắn SMSBB - (Chủ trì nghiệp vụ:
BU Chiến dịch -TT CNTT VTT)</th></tr></thead><tbody><tr><td>289</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_UPDATE</td><td>Chỉnh sửa chiến dịch</td><td>Chỉnh sửa chiến dịch SMSBB - (Chủ trì
nghiệp vụ: BU Chiến dịch -TT CNTT VTT)</td></tr><tr><td>290</td><td>Hệ thống Campaign
Management 2.0</td><td>Quản lý chiến dịch
SMSBB</td><td>CAMPAIGN_SMSB
B_VIEW_TEST</td><td>Xem kết quả test chiến
dịch</td><td>Xem kết quả test chiến dịch SMSBB - (Chủ
trì nghiệp vụ: BU Chiến dịch -TT CNTT
VTT)</td></tr><tr><td>291</td><td>Hệ thống Campaign
Management 2.0</td><td></td><td>CP2_CAMPAIGN_
MANAGEMENT</td><td>Quản lý chiến dịch</td><td>Quản lý chiến dịch - (Chủ trì nghiệp vụ: BU
Chiến dịch -TT CNTT VTT)</td></tr><tr><td>292</td><td>Contact Center
Management System</td><td>ipcc.report.system</td><td>ipcc.cms.reportSurve
yParticipants</td><td>ipcc.cms.reportSurveyPart
icipants</td><td>Thong ke danh sach thue bao thuc hien
survey (Chủ trì nghiệp vụ: TT CSKH VTT -
tungtt2)</td></tr><tr><td>293</td><td>Contact Center
Management System</td><td></td><td>ipcc.report</td><td>ipcc.report</td><td>Menu báo cáo (Chủ trì nghiệp vụ: TT
CSKH VTT - tungtt2)</td></tr></tbody></table>

<table><thead><tr><th>294</th><th>Contact Center
Management System</th><th>ipcc.report</th><th>ipcc.report.system</th><th>ipcc.report.system</th><th>Menu - Báo cáo về hệ thống (Chủ trì nghiệp
vụ: TT CSKH VTT - tungtt2)</th></tr></thead><tbody><tr><td>295</td><td>Contact Center
Management System</td><td>ipcc.report.customer</td><td>ipcc.ccms.CallerTran
GroupDetail</td><td>ipcc.ccms.CallerTranGrou
pDetail</td><td>Thong ke thong tin chi tiet khach hang
transfer chuyen gia (Chủ trì nghiệp vụ: TT
CSKH VTT - tungtt2)</td></tr><tr><td>296</td><td>Contact Center
Management System</td><td>ipcc.report.call</td><td>ipcc.ccms.CallerTran
GroupGeneral</td><td>ipcc.ccms.CallerTranGrou
pGeneral</td><td>Thong ke tong hop thong tin cuoc goi
chuyen chuyen gia (Chủ trì nghiệp vụ: TT
CSKH VTT - tungtt2)</td></tr><tr><td>297</td><td>Contact Center
Management System</td><td>ipcc.report.customer</td><td>ipcc.ccms.CustomerC
allToProThanN</td><td>ipcc.ccms.CustomerCallT
oProThanN</td><td>Thong ke khach hang chuyen cuoc goi
chuyen gia N lan (Chủ trì nghiệp vụ: TT
CSKH VTT - tungtt2)</td></tr><tr><td>298</td><td>Contact Center
Management System</td><td>ipcc.report.agent</td><td>ipcc.ccms.statisticCal
lPerProfes</td><td>ipcc.ccms.statisticCallPer
Profes</td><td>Thong ke cuoc goi cua chuyen gia (Chủ trì
nghiệp vụ: TT CSKH VTT - tungtt2)</td></tr></tbody></table>

|<image_32>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>299</th><th>Contact Center
Management System</th><th>ipcc.report</th><th>ipcc.report.agent</th><th>ipcc.report.agent</th><th>Menu - Báo cáo về Agent (Chủ trì nghiệp
vụ: TT CSKH VTT - tungtt2)</th></tr></thead><tbody><tr><td>300</td><td>Contact Center
Management System</td><td>ipcc.report</td><td>ipcc.report.call</td><td>ipcc.report.call</td><td>Menu - Báo cáo về cuộc gọi (Chủ trì nghiệp
vụ: TT CSKH VTT - tungtt2)</td></tr><tr><td>301</td><td>Contact Center
Management System</td><td>ipcc.report</td><td>ipcc.report.customer</td><td>ipcc.report.customer</td><td>Menu - Báo cáo về khách hàng (Chủ trì
nghiệp vụ: TT CSKH VTT - tungtt2)</td></tr><tr><td>302</td><td>Contact Center
Management System</td><td>aah.sch.sht.mng</td><td>aah.agent.confirm</td><td>aah.agent.confirm</td><td>(Chủ trì nghiệp vụ: TT CSKH VTT -
tungtt2)</td></tr><tr><td>303</td><td>Contact Center
Management System</td><td>aah.sch.sht.mng</td><td>aah.register.mng</td><td>aah.register.mng</td><td>Đăng ký trực (Chủ trì nghiệp vụ: TT CSKH
VTT - tungtt2)</td></tr><tr><td>304</td><td>Contact Center
Management System</td><td></td><td>aah.sch.sht.mng</td><td>aah.sch.sht.mng</td><td>Menu quản lý lịch trực, ca trực (Chủ trì
nghiệp vụ: TT CSKH VTT - tungtt2)</td></tr><tr><td>305</td><td>Contact Center
Management System</td><td>ipcc.report.agent</td><td>ipcc.cms.searchCallA
gent</td><td>ipcc.cms.searchCallAgent</td><td>Tim kiem va nghe lai cuoc gọi cua agent
(Chủ trì nghiệp vụ: TT CSKH VTT -
tungtt2)</td></tr><tr><td>306</td><td>ccms_63cn</td><td>ipcc.cms.searchCall</td><td>/utilAction!onExport.
do63cn</td><td>/utilAction!onExport.do</td><td>Tìm kiếm cuộc gọi</td></tr><tr><td>307</td><td>ccms_63cn</td><td>ipcc.cms.searchCall</td><td>/utilAction!onSearch.
do63cn</td><td>/utilAction!onSearch.do</td><td>Tìm kiếm cuộc gọi</td></tr><tr><td>308</td><td>ccms_63cn</td><td></td><td>Tool_ccms63cn</td><td>Tool</td><td>Menu tiện ích</td></tr><tr><td>309</td><td>ccms_63cn</td><td>Tool</td><td>importAction!getImp
ortResult.do63cn</td><td>importAction!getImportRe
sult.do</td><td>Import kết quả</td></tr><tr><td>310</td><td>ccms_63cn</td><td>Tool</td><td>importList!getImport
Result.do63cn</td><td>importList!getImportResul
t.do</td><td>Import kết quả</td></tr><tr><td>311</td><td>ccms_63cn</td><td>Tool</td><td>ipcc.cms.importCatal
og63cn</td><td>ipcc.cms.importCatalog</td><td>Import danh mục</td></tr><tr><td>312</td><td>ccms_63cn</td><td>ipcc.report.call</td><td>ipcc.cms.lastAgent.ca
llInfo63cn</td><td>ipcc.cms.lastAgent.callInf
o</td><td>Báo cáo cuộc gọi sử dụng last agent</td></tr><tr><td>313</td><td>ccms_63cn</td><td>Tool</td><td>ipcc.cms.searchCall6
3cn</td><td>ipcc.cms.searchCall</td><td>Tìm kiếm nghe lại cuộc gọi</td></tr><tr><td>314</td><td>ccms_63cn</td><td>ipcc.report.call</td><td>ipcc.cms.searchCallP
rofessor63cn</td><td>ipcc.cms.searchCallProfes
sor</td><td>Tim kiem va nghe lai cuoc goi cua chuyen
gia</td></tr><tr><td>315</td><td>ccms_63cn</td><td>ipcc.cms.searchCall</td><td>ipcc.cms.searchcall.d
ownload63cn</td><td>ipcc.cms.searchcall.downl
oad</td><td>Tim kiem va nghe lai cuoc goi</td></tr></tbody></table>

|<image_33>|


### VIETTEL AI RACE

### DANH MỤC CHỨC DANH CÁC HỆ THỐNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD428</th></tr></thead><tbody><tr><td></td><td>DANH MỤC CHỨC DANH CÁC HỆ THỐNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>316</th><th>Contact Center
Management System</th><th>ipcc.report.call</th><th>ipcc.cms.statisticCall
DisconnectStatus</th><th>ipcc.cms.statisticCallDisc
onnectStatus</th><th>Báo cáo thống kê trạng thái disconnect cuộc
gọi (Chủ trì nghiệp vụ: TT CSKH VTT -
tungtt2)</th></tr></thead><tbody><tr><td>317</td><td>ccms_63cn</td><td>ipcc.report.call</td><td>ipcc.cms.statisticCall
DisconnectStatus63c
n</td><td>ipcc.cms.statisticCallDisc
onnectStatus</td><td>Báo cáo thống kê trạng thái disconnect cuộc
gọi</td></tr><tr><td>318</td><td>ccms_63cn</td><td>ipcc.report</td><td>ipcc.report.call63cn</td><td>ipcc.report.call</td><td>Menu - Báo cáo về cuộc gọi</td></tr><tr><td>319</td><td>ccms_63cn</td><td></td><td>ipcc.report63cn</td><td>ipcc.report</td><td>Menu báo cáo</td></tr><tr><td>320</td><td>POS_V2</td><td></td><td>mbccs_sale_apply_st
art_time</td><td>mbccs_sale_apply_start_ti
me</td><td>Quyền off ngày hiệu lực chặn không thanh
toán ngày 1-3 (R562, (Chủ trì nghiệp vụ:
TT CĐBR VTT- HaTK@/AnhBH@)</td></tr><tr><td>321</td><td>ccms_63cn</td><td>ipcc.report</td><td>reportAction3!onStati
sticCallDisconnectSta
tus.do63cn</td><td>reportAction3!onStatistic
CallDisconnectStatus.do</td><td>Báo cáo CG003</td></tr><tr><td>322</td><td>Contact Center
Management System</td><td>ipcc.cms.statisticCallD
isconnectStatus</td><td>reportAction3.onExp
ortStatisticCallDisco
nnectStatus</td><td>Xuat bao cao trang thai
ket thuc cuoc goi</td><td>Xuat bao cao trang thai ket thuc cuoc
goi(Chủ trì nghiệp vụ: TT CSKH VTT -
tungtt2)</td></tr><tr><td>323</td><td>ccms_63cn</td><td>ipcc.cms.statisticCallD
isconnectStatus</td><td>reportAction3.onExp
ortStatisticCallDisco
nnectStatus63cn</td><td>Xuat bao cao trang thai
ket thuc cuoc goi</td><td>Xuat bao cao trang thai ket thuc cuoc goi</td></tr><tr><td>324</td><td>Contact Center
Management System</td><td>ipcc.cms.statisticCallD
isconnectStatus</td><td>reportAction3.onStati
sticCallDisconnectSta
tus</td><td>Tim kiem trang thai ket
thuc cuoc goi</td><td>Tim kiem trang thai ket thuc cuoc goi(Chủ
trì nghiệp vụ: TT CSKH VTT - tungtt2)</td></tr><tr><td>325</td><td>ccms_63cn</td><td>ipcc.cms.statisticCallD
isconnectStatus</td><td>reportAction3.onStati
sticCallDisconnectSta
tus63cn</td><td>Tim kiem trang thai ket
thuc cuoc goi</td><td>Tim kiem trang thai ket thuc cuoc goi</td></tr><tr><td>326</td><td>ccms_63cn</td><td>ipcc.cms.searchCall</td><td>utilAction!onExportS
earchCall.do63cn</td><td>utilAction!onExport.do</td><td>Button Export</td></tr><tr><td>327</td><td>ccms_63cn</td><td>ipcc.cms.searchCall</td><td>utilAction!onSearchC
all.do63cn</td><td>utilAction!onSearch.do</td><td>Button search trong chuc nang Tim kiem
nghe lai cuoc goi</td></tr></tbody></table>

|<image_34>|


