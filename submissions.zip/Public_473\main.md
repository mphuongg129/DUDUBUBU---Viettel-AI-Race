# Public_473

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Thông tin kỹ thuật máy bay Airbus A321</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Thông số kỹ thuật chính của Airbus A321</th><th></th><th></th><th></th></tr></thead><tbody><tr><td>Hạng mục</td><td>Thông số</td><td>Đơn vị</td><td>Ghi chú</td></tr><tr><td>Chiều dài</td><td>44,51</td><td>m</td><td>Dài hơn A320</td></tr><tr><td>Sải cánh</td><td>35,8</td><td>m</td><td>Có sharklets tăng
hiệu suất</td></tr><tr><td>Chiều cao</td><td>11,76</td><td>m</td><td></td></tr><tr><td>Sức chứa hành
khách</td><td>185 - 236</td><td>người</td><td>Tùy cấu hình</td></tr><tr><td>Tầm bay</td><td>5.950 - 7.400</td><td>km</td><td>Tùy phiên bản
A321neo/A321XLR</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Thông tin kỹ thuật máy bay Airbus A321</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th></tr></thead><tbody><tr><td></td></tr></tbody></table>

|<image_2>|

|<image_3>|

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Thông tin kỹ thuật máy bay Airbus A321</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Thông tin kỹ thuật máy bay Airbus A321</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_6>|

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Thông tin kỹ thuật máy bay Airbus A321</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_8>|

|<image_9>|


