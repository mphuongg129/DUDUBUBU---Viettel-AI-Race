# Public_660

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD660</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT PHỤC HỒI CỦA
MÀN HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Ảnh minh họa</th><th>Các thành phần
trên màn hình</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td>Dẻo hóa và đối áp</td><td>Phần này hiển thị cấu hình
phục hồi hiện tại. Cấu hình
này hiển thị theo số trong
các trường ở bên trái và theo
biểu đồ trong các trường ở
bên phải. Có thể sử dụng
trường Stages (Giai đoạn) ở
trên cùng bên trái để điều</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD660</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT PHỤC HỒI CỦA
MÀN HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Ảnh minh họa</th><th>Các thành phần
trên màn hình</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td></td><td>chỉnh số bước phục hồi. Bạn
có thể chọn tối đa là 5 bước.</td></tr><tr><td></td><td>Trường nhập giá trị
sạc và đối áp</td><td>Bạn có thể điều chỉnh các
mục cài đặt này bằng cách
nhập giá trị trực tiếp vào
những trường này. Những
trường này dùng để đặt giá
trị Backpressure (Đối áp) và
Charge (Sạc) giữa vị trí cuối
của giai đoạn trước (trong
trường hợp giai đoạn 1, vị trí
cuối chuyển động của bộ
phận trục trước) và vị trí
được chỉ định trong cột 'To'
(Đến).</td></tr><tr><td></td><td>Biểu đồ nhập giá trị
sạc và đối áp</td><td>Ngoài ra, các giá trị
Backpressure (Đối áp) (màu
mỏng kẻ) và Charge (Sạc)
(màu xám) hiển thị ở dạng
biểu đồ bên phải. Những giá
trị này có thể điều chỉnh
được. Mỗi lần nhập vào một
giá trị, biểu đồ cấu hình</td></tr></tbody></table>

|<image_5>|

|<image_6>|

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD660</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT PHỤC HỒI CỦA
MÀN HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Ảnh minh họa</th><th>Các thành phần
trên màn hình</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td></td><td>được điều chỉnh trong
khoảng +/- 5 bar và/hoặc +/-
5%.</td></tr><tr><td></td><td>Hiển thị dữ liệu</td><td>Vùng này của màn hình hiển
thị áp suất phun, vị trí và
vòng quay trục vít hiện tại.
Trường Delay (Độ trễ) có
thể điều chỉnh được –
xem bên dưới.</td></tr><tr><td></td><td>Screw position (Vị
trí trục vít)</td><td>Hiển thị vị trí trục vít hiện
tại.</td></tr><tr><td></td><td>Screw revolution
(Vòng quay trục
vít)</td><td>Hiển thị vòng quay trục vít
hiện tại.</td></tr><tr><td></td><td>Charge torque
(Mômen sạc)</td><td>Chỉ định mômen sạc tối đa.</td></tr><tr><td></td><td>Delay (Độ trễ)</td><td>Thời gian trễ để bắt đầu dẻo
hóa được chỉ định ở đây.</td></tr><tr><td></td><td>Plasticize
Parameter Settings
(Cài đặt thông số
dẻo hóa)</td><td>Max. decomp. time (Thời
gian giảm áp tối đa): Ở đây,
bạn có thể đặt thời gian
giảm áp tối đa được phép.
Giá trị này là giá trị tối đa
được phép nhập vào màn
hình dẻo hóa.</td></tr></tbody></table>

|<image_8>|

|<image_9>|

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD660</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT PHỤC HỒI CỦA
MÀN HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Ảnh minh họa</th><th>Các thành phần
trên màn hình</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td></td><td>Max. plasticize time (Thời
gian dẻo hóa tối đa): Ở đây,
bạn có thể đặt thời gian dẻo
hóa tối đa được phép. Nếu
vượt quá thời gian này, báo
động sẽ xuất hiện và chu kỳ
sẽ bị dừng.</td></tr><tr><td></td><td>Vibration Unit
(Thiết bị rung)</td><td>Enabled (Bật): Chọn hộp
này sẽ bật thiết bị rung. Bỏ
chọn hộp này sẽ tắt thiết bị
rung.</td></tr><tr><td></td><td></td><td>On Time (Thời gian bật):
Chỉ định khoảng thời gian
thiết bị rung trong chu kỳ
bật/tắt.</td></tr><tr><td></td><td></td><td>Off Time (Thời gian tắt):
Chỉ định khoảng thời gian
thiết bị rung trong chu kỳ
bật/tắt.</td></tr><tr><td></td><td>Decompression
(Giảm áp)</td><td>Các mục cài đặt này chỉ
được hiển thị trong chế độ
thủ công và tự động.</td></tr><tr><td></td><td>Mode (Chế độ)</td><td>Chế độ giảm áp trước khi
dẻo hóa với các tùy chọn sau
đây:</td></tr></tbody></table>

|<image_11>|

|<image_12>|

|<image_13>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD660</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT PHỤC HỒI CỦA
MÀN HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Ảnh minh họa</th><th>Các thành phần
trên màn hình</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td></td><td>No (Không): Không giảm
áp.</td></tr><tr><td></td><td></td><td>Time (Thời gian): Giảm áp
trong một khoảng thời gian
cố định.</td></tr><tr><td></td><td></td><td>Position (Vị trí): Giảm áp
đến khi đạt tới vị trí trục vít
chỉ định.</td></tr><tr><td></td><td>Pressure (Áp suất)</td><td>Chỉ định áp suất cho chuyển
động trục vít tuyến tính.
Trường này chỉ chỉnh sửa
được khi đã chọn chế độ
'Time' (Thời gian) hoặc
'Position' (Vị trí).</td></tr><tr><td></td><td>Velocity (Vận tốc)</td><td>Chỉ định vận tốc cho chuyển
động trục vít tuyến tính.
Trường này chỉ chỉnh sửa
được khi đã chọn chế độ
'Time' (Thời gian) hoặc
'Position' (Vị trí).</td></tr><tr><td></td><td>Position/Time (Vị
trí/Thời gian)</td><td>Chỉ định vị trí trục vít hoặc
khoảng thời gian giảm áp.
Màn hình phụ thuộc vào chế
độ được chọn.</td></tr></tbody></table>

|<image_14>|

|<image_15>|


