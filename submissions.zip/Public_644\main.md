# Public_644

## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>XI</td><td>Gạch
ốp, lát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11,1</td><td>Gạch ốp, lát Đồng Tâm (Công ty CP Đồng Tâm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Gạch Ceramic</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>949</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
1020ROCK002,
1020ROCK004,
1020ROCK005,
1020ROCK006,
1020ROCK010,
1020ROCK011,
1020ROCK012,
1020ROCK013,
1020ROCK014,
1020ROCK015,</td><td>m2</td><td>QCVN
16:2023/BXD</td><td>(100x200)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>200,000</td><td></td></tr><tr><td>950</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
2020MARINA001,
2020MARINA002,
2020MARINA004, TL01,
TL03</td><td></td><td>QCVN
16:2023/BXD</td><td>(200x200)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>177,000</td><td></td></tr><tr><td>951</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
2540CARARAS001</td><td></td><td>QCVN
16:2023/BXD</td><td>(250x400)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>147,182</td><td></td></tr><tr><td>952</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số: 25400</td><td></td><td>QCVN
16:2023/BXD</td><td>(250x400)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa</td><td>156,364</td><td></td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>953</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
3060AMBER001,
3060AMBER007,
3060ROXY001,
3060ROXY003,
3060ROXY005,
3060DELUXE001,3060DEL
UXE002, 3060DELUXE003,
306DELUXE004,
3060DELUXE005,
D3060DELUXE005,
3060DELUXE006,
3060DELUXE007,
3060SNOW001,</td><td></td><td>QCVN
16:2023/BXD</td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>244,444</td><td></td></tr><tr><td>954</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số :
3060CARARAS001</td><td></td><td>QCVN
16:2023/BXD</td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>250,000</td><td></td></tr><tr><td>955</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
4080CLOUD005-H+</td><td></td><td>QCVN
16:2023/BXD</td><td>(400x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>231,481</td><td></td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>956</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
4080CLOUD001-H+,
4080CLOUD002-H+,
4080CLOUD003-H+,
4080CLOUD004-H+,</td><td></td><td>QCVN
16:2023/BXD</td><td>(400x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>250,000</td><td></td></tr><tr><td>957</td><td>Vật liệu
hoàn
thiện</td><td>Gạch Ceramic mã số:
4080ROXY001-H+,
4080SNOW001-H+,
4080CARARAS001-H+,
4080FAME001-H+,
4080FAME005-H+,
4080REGAL014-H+,
4080REGAL017-H+,</td><td></td><td>QCVN
16:2023/BXD</td><td>(400x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>295,313</td><td></td></tr><tr><td>*</td><td>Gạch ốp lát Porcelain</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>958</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
2020HOAMY001,
2020HOAMY002,
2020HOAMY004,
2020HOAMY006,
2020HOAMY007,
2020HOAMY009,
2020HOAMY010,
2020HOAMY011,</td><td></td><td>QCVN
16:2023/BXD</td><td>(200x200)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>653,977</td><td></td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>959</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3060VAMCOTAY001,
3060VAMCOTAY002,
3060VAMCOTAY003,
3060VAMCOTAY004,
3060VAMCOTAY005,
3060VAMCOTAY006,
3060VAMCOTAY007,</td><td></td><td>QCVN
16:2023/BXD</td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>200,000</td><td></td></tr><tr><td>960</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3060HOANGLIENSON001,
3060HOANGLIENSON002,
3060HOANGLIENSON003,
3060HOANGLIENSON006,
3060HOANGLIENSON007,
3060HOANGLIENSON012,
3060HOANGLIENSON013,
3060HOANGLIENSON014,
3060HOANGLIENSON015,
3060GECKO010,
3060GECKO012,</td><td></td><td></td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>231,819</td><td></td></tr><tr><td>961</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3060THACHDONG007-H+,
3060THACHDONG008-H+,
3060PHUQUY001,
3060PHUQUY004,
3060SAHARA005,
3060SAHARA006,
3060SAHARA_008,
3060SAHARA009,</td><td></td><td></td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>250,000</td><td></td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>962</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3060HOANGLIENSON004,
3060HOANGLIENSON005,
3060HOANGLIENSON006,
3060HOANGLIENSON008,
3060HOANGLIENSON009,
3060HOANGLIENSON010,
3060HOANGLIENSON011,
3060GECKO011,</td><td></td><td></td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>268,181</td><td></td></tr><tr><td>963</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3060THACHDONG001-H+,
3060THACHDONG002-H+,
3060THACHDONG003-H+,
3060THACHDONG004-H+,
3060THACHDONG005-H+,
3060THACHDONG006-H+,
3060VICTORIA001,
3060VICTORIA002,
3060VICTORIA003,
3060VICTORIA004,
3060VICTORIA005,
3060VICTORIA006,
3060VICTORIA007,
3060VICTORIA008,</td><td></td><td></td><td>(300x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>359,428</td><td></td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>964</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
1530DIAMOND001,
1530DIAMOND002,
1530DIAMOND003,
1530DIAMOND004,
1530DIAMOND005,
1530DIAMOND006,
1530DIAMOND007,
1530DIAMOND008,
1530DIAMOND009,
1530DIAMOND010,</td><td></td><td></td><td>(150x300)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>289,937</td><td></td></tr><tr><td>965</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3030GECKO001,
3030GECKO002,
3030GECKO005,
3030GECKO006,
3030GECKO07,
3030GECKO009,
3030GECKO010,</td><td></td><td></td><td>(150x300)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>210,009</td><td></td></tr><tr><td>966</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
3030GECKO008,
3030GECKO011,
3030GECKO012,</td><td></td><td></td><td>(300x300)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>230,909</td><td></td></tr><tr><td>967</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
4040DASONTRA001LA,
COTTOLA,
4040CLG001, 4040CLG002,</td><td></td><td></td><td>(300x300)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>196,213</td><td></td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>968</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
DTD4040HOANGSA001LA</td><td></td><td></td><td>(400x400)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>217,519</td><td></td></tr><tr><td>969</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
4040GECKO005,
4040GECKO006,
4040GECKO007,
4040GECKO008,
4040GECKO009,</td><td></td><td></td><td>(400x400)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>223,674</td><td></td></tr><tr><td>970</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
4040LYSON001,
4040LYSON002,
4040LYSON003,
4040LYSON004,
4040LYSON005,
4040LYSON006,
4040LYSON007,
4040LYSON008,
4040LYSON009,
4040LYSON010,
4040LYSON011,</td><td></td><td></td><td>(400x400)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>223,674</td><td></td></tr><tr><td>971</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
2080BANYAN001-H+,
2080BANYAN002-H+,
2080BANYAN003-H+,
2080BANYAN004-H+,
2080BANYAN005-H+</td><td></td><td></td><td>(200x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>379,000</td><td></td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>972</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
4080SAPA001-H+,
4080SAPA002-H+,
4080SAPA003-H+,
4080SAPA004-H+,
4080SAPA005-H+,
4080SAPA006-H+,</td><td></td><td></td><td>(400x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>313,947</td><td></td></tr><tr><td>973</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
4080SAPA007-H+,
4080SAPA008-H+,</td><td></td><td></td><td>(400x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>327,691</td><td></td></tr><tr><td>974</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
4080GECKO002,
4080GECKO003,
4080GECKO004,
4080GECKO005,</td><td></td><td></td><td>(400x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>328,125</td><td></td></tr><tr><td>975</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060TRANGAN001-FP,
6060TRANGAN002-FP,
6060TRANGAN003-FP,
6060TRANGAN004-FP,
6060TRANGAN005-FP,
6060TRANGAN006-FP,
6060TRANGAN007-FP,</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>220,013</td><td></td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>976</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060VAMCODONG001-FP,
6060VAMCODONG002-FP,
6060VAMCODONG003-FP,
6060VAMCODONG004-FP,
6060VAMCODONG005-FP,
6060VAMCODONG006-FP,
6060VAMCOTAY001,
6060VAMCOTAY002,
6060VAMCOTAY003,
6060VAMCOTAY004,
6060VAMCOTAY005,
6060STONE005-FP</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>220,013</td><td></td></tr><tr><td>977</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060BINHTHUAN002,
6060BINHTHUAN005,
6060VENUS002,
6060TAMDAO002,</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>233,333</td><td></td></tr><tr><td>978</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060BRIGHT001LA-FP</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>242,000</td><td></td></tr><tr><td>979</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060PHARAON001-H+,
6060PHARAON006-H+,
6060PHARAON007-H+,
6060PHARAON008-H+,
6060PHARAON009-H+,</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>247,159</td><td></td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>980</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
DTD6060CARARAS002-FP,
6060HAIVAN003-FP,
6060HAIVAN004-FP,
DTD6060TRUONGSON002-
FP, 6060TRUONGSON003-
FP,
6060TRUONGSON004-FP,
6060TRUONGSON005-FP,</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>257,765</td><td></td></tr><tr><td>981</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060DONGVAN001-FP-H+,
6060DONGVAN002-FP-H+,
6060DONGVAN003-FP-H+,
6060DONGVAN004-FP -
H+,
6060PHARAON002-H+,
6060PHARAON003-H+,
6060PHARAON010-H+,
6060PHARAON011-H+,
6060PHARAON012-H+,</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>275,631</td><td></td></tr><tr><td>982</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060SNOW001-FP,
6060HAIVAN005-FP,
DTD6060TRUONGSON001-
FP</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>285,543</td><td></td></tr><tr><td>983</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060DB032</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>288,889</td><td></td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>984</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060PHARAON004-H+,
6060PHARAON005-H+</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>303,156</td><td></td></tr><tr><td>985</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060DB034, 6060DB038</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>308,333</td><td></td></tr><tr><td>986</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060DONGVAN005-FP-H+,
6060DONGVAN006-FP-H+,
6060DONGVAN007-FP-H+</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>309,091</td><td></td></tr><tr><td>987</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060MARMOL005,</td><td></td><td></td><td>(600x600)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>327,778</td><td></td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>988</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
6060VICTORIA001,
6060VICTORIA002,
6060VICTORIA003,
6060VICTORIA004,
6060VICTORIA005,
6060VICTORIA006,
6060VICTORIA007,
6060VICTORIA008,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>368,308</td><td></td></tr><tr><td>989</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080NAPOLEON003-H+,
8080NAPOLEON004-H+,
8080NAPOLEON009-H+,
8080NAPOLEON011-H+,
8080NAPOLEON014-H+,
8080ROME002-H+,
8080ROME003-H+,
8080ROME005-H+,
8080ROME006-H+,
8080STONE004-FP-H+,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>314,063</td><td></td></tr><tr><td>990</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080PHARAON001-H+,
8080PHARAON003-H+,
8080PHARAON006-H+,
8080PHARAON007-H+,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>314,110</td><td></td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>991</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080CARARAS001-FP-H+,
8080CARARAS002-FP-H+,
8080CARARAS003-FP-H+,
8080DONGVAN001-FP-H+,
8080DONGVAN002-FP-H+,
8080DONGVAN003-FP-H+,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>344,555</td><td></td></tr><tr><td>992</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080FANSIPAN001-FP-H+,
8080FANSIPAN002-FP-H+,
8080FANSIPAN004-FP-H+,
8080FANSIPAN006-FP-H+,
8080FANSIPAN007-FP-H+,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>344,555</td><td></td></tr><tr><td>993</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080PHARAON002-H+,
8080PHARAON008-H+,
8080PHARAON009-H+,
8080PHARAON010-H+,
8080STONE003-FP-H+,
8080STONE005-FP-H+,
8080THUTHIEM001-FP-H+,
8080THUTHIEM002-FP-H+,
8080TRUONGSON001-FP-
H+, 8080TRUONGSON002-
FP-H+,
8080TRUONGSON003-FP-
H+,
8080SNOW001-FP-H+,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>344,555</td><td></td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>994</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080THIENTHACH001-H+,
8080THIENTHACH002-H+,
8080THIENTHACH003-H+,
8080THIENTHACH004-H+,
8080THIENTHACH005-H+,
8080THIENTHACH006-H+,
8080DB006, 8080DB100,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>359,375</td><td></td></tr><tr><td>995</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080FANSIPAN006-FP-H+</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>361,884</td><td></td></tr><tr><td>996</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080DONGVAN007-FP-H+,
8080DONGVAN008-FP-H+,
8080DONGVAN009-FP-H+,
8080DONGVAN010-FP-H+,</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>386,364</td><td></td></tr><tr><td>997</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080DB032</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>395,455</td><td></td></tr><tr><td>998</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080PHARAON004-H+,
8080PHARAON005-H+</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>396,354</td><td></td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>999</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080DONGVAN004-FP-H+,
8080DONGVAN005-FP-H+,
8080DONGVAN006-FP-H+</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>429,072</td><td></td></tr><tr><td>1000</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080MARMOL005,
8080DB038</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>431,723</td><td></td></tr><tr><td>1001</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
8080YALY003-FP-H+</td><td></td><td></td><td>(800x800)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>450,000</td><td></td></tr><tr><td>1002</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain má số:
8080PLATINUM001,
8080PLATINUM003,
8080PLATINUM004</td><td></td><td></td><td>(1000x1000)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>600,000</td><td></td></tr><tr><td>1003</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
100DONGVAN001-FP-H+,
100DONGVAN002-FP-H+,
100DONGVAN003-FP-H+,
100DONGVAN008-FP-H+</td><td></td><td></td><td>(1000x1000)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>447,909</td><td></td></tr><tr><td>1004</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
100DONGVAN006-FP-H+,
100DONGVAN007-FP-H+,</td><td></td><td></td><td>(1000x1000)mm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình</td><td>502,273</td><td></td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trên địa
bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1005</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
100DONGVAN004-FP-H+,
100DONGVAN005-FP-H+,</td><td></td><td></td><td>100x100cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>557,818</td><td></td></tr><tr><td>1006</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
100MARMOL005,
100DB038</td><td></td><td></td><td>100x100cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>572,818</td><td></td></tr><tr><td>1007</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
100VICTORIA005</td><td></td><td></td><td>20x120cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>660,000</td><td></td></tr><tr><td>1008</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
20120BANYAN001-H+,
20120BANYAN002-H+,
20120BANYAN003-H+,
20120BANYAN004-H+,
20120BANYAN005-H+</td><td></td><td></td><td>60x120cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>546,275</td><td></td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1009</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
60120SNOW001-FP-H+,
60120LANGBIANG001FP-
H+,
60120NILE001-H+,
60120NILE002-H+,
60120NILE004-H+,
60120NILE005-H+</td><td></td><td></td><td>60x120cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>546,275</td><td></td></tr><tr><td>1010</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
60120LANGBIANG002FP-
H+,
60120LANGBIANG003FP-
H+,
60120LANGBIANG004FP-
H+,
60120LANGBIANG008FP-
H+,
60120NILE003-H+,
60120NILE006-H+,
60120STONE003-FP-H+</td><td></td><td></td><td>60x120cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>666,667</td><td></td></tr><tr><td>1011</td><td>Vật liệu
hoàn
thiện</td><td>Gạch ốp lát Porcelain mã số:
60120STONE004-FP-H+,
60120LANGBIANG005FP-
H+,
60120LANGBIANG006FP-
H+,
60120LANGBIANG007FP-
H+,
60120LANGBIANG009FP-
H+</td><td></td><td></td><td>60x120cm</td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>1.111.111</td><td></td></tr><tr><td>*</td><td>Ngói tráng men</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1012</td><td>Vật liệu
hoàn
thiện</td><td>Ngói nóc Titan</td><td></td><td></td><td></td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>36,364</td><td></td></tr><tr><td>1013</td><td>Vật liệu
hoàn
thiện</td><td>Ngói chạc ba Titan</td><td></td><td></td><td></td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>86,364</td><td></td></tr><tr><td>1014</td><td>Vật liệu
hoàn
thiện</td><td>Ngói chạc tư Titan</td><td></td><td></td><td></td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>104,545</td><td></td></tr><tr><td>1015</td><td>Vật liệu
hoàn
thiện</td><td>Ngói chữ T Titan</td><td></td><td></td><td></td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>86,364</td><td></td></tr><tr><td>1016</td><td>Vật liệu
hoàn
thiện</td><td>Ngói chặn cuối nóc Titan</td><td></td><td></td><td></td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>27,273</td><td></td></tr><tr><td>1017</td><td>Vật liệu
hoàn
thiện</td><td>Ngói chặn cuối rìa Titan</td><td></td><td></td><td></td><td>Công ty CP
Đồng Tâm</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình</td><td>25,000</td><td></td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trên địa
bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>11,2</td><td>Gạch ốp, lát Thạch Bàn (Công ty CP Thạch Bàn miền Bắc)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Gạch Granite</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1018</td><td>Vật liệu
hoàn
thiện</td><td>Grany Lite men mài
bóng/men khô bề mặt phẳng.
GSB/GSM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm,
(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>360,185</td></tr><tr><td>1019</td><td>Vật liệu
hoàn
thiện</td><td>Grany Lite men mài
bóng/men khô bề mặt phẳng.
GSB/GSM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm,
(800x800)cmm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>452,778</td></tr><tr><td>1020</td><td>Vật liệu
hoàn
thiện</td><td>Grany Lite men mài
bóng/men khô bề mặt phẳng.
GSB/GSM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(60x120)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>526,852</td></tr><tr><td>1021</td><td>Vật liệu
hoàn
thiện</td><td>Grany Lite men mài
bóng/men khô bề mặt phẳng.
GSB/GSM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(195x1200)cm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>536,111</td></tr><tr><td>1022</td><td>Vật liệu
hoàn
thiện</td><td>TBGres/Lujo men mài bóng.
TGB/FGB/LGB</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(30x60)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>276,852</td></tr><tr><td>1023</td><td>Vật liệu
hoàn
thiện</td><td>TBGres/Lujo men mài bóng.
TGB/FGB/LGB</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td></td><td>378,704</td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chưa gồm
vận chuyển</td><td></td><td></td></tr><tr><td>1024</td><td>Vật liệu
hoàn
thiện</td><td>TBGres/Lujo men vi tinh.
TGB/FGB/LGB</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>406,481</td></tr><tr><td>1025</td><td>Vật liệu
hoàn
thiện</td><td>TBGres/Lujo men mài bóng.
TGB/FGB/LGB</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>267,593</td></tr><tr><td>1026</td><td>Vật liệu
hoàn
thiện</td><td>TBGres/Lujo men mài bóng.
TGB/FGB/LGB</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>369,444</td></tr><tr><td>1027</td><td>Vật liệu
hoàn
thiện</td><td>TBGres/Lujo men vi tinh.
TGB/FGB/LGB</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>406,481</td></tr><tr><td>1028</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Lujo men khô, bề
mặt phẳng. PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>276,852</td></tr><tr><td>1029</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
trang trí</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>304,630</td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1030</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
dị hình, PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>286,111</td></tr><tr><td>1031</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men kim cương.
PGM/ TGM/ FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>295,370</td></tr><tr><td>1032</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, sân
vườn. PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>406,481</td></tr><tr><td>1033</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Lujo men khô, bề
mặt phẳng. PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>267,593</td></tr><tr><td>1034</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
trang trí</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>304,630</td></tr><tr><td>1035</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
dị hình, PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>286,111</td></tr><tr><td>1036</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men kim cương.
PGM/ TGM/ FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td></td><td>295,370</td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chưa gồm
vận chuyển</td><td></td><td></td></tr><tr><td>1037</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, sân
vườn. PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>406,481</td></tr><tr><td>1038</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Lujo men khô, bề
mặt phẳng. PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>378,704</td></tr><tr><td>1039</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
trang trí</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>425,000</td></tr><tr><td>1040</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
dị hình, PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>397,222</td></tr><tr><td>1041</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men kim cương.
PGM/ TGM/ FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(400x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>415,741</td></tr><tr><td>1042</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Lujo men khô, bề
mặt phẳng. PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>369,444</td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1043</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
trang trí</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>406,481</td></tr><tr><td>1044</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men khô, bề mặt
dị hình, PGM/ TGM/
FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>378,704</td></tr><tr><td>1045</td><td>Vật liệu
hoàn
thiện</td><td>Porugia/Luj men kim cương.
PGM/ TGM/ FGM/LGM</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Thạch Bàn
miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>397,222</td></tr><tr><td>11,3</td><td>Gạch ốp, lát VITTO (Công ty CP Tập đoàn VITTO)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Gạch lát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1046</td><td>Vật liệu
hoàn
thiện</td><td>BIa lát nền G men matt loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>200,516</td></tr><tr><td>1047</td><td>Vật liệu
hoàn
thiện</td><td>BIa lát nền G mài bóng loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>231,476</td></tr><tr><td>1048</td><td>Vật liệu
hoàn
thiện</td><td>BIa lát nền mài bóng loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(800x800)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>307,344</td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1049</td><td>Vật liệu
hoàn
thiện</td><td>BIa lát nền mài bóng loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x900)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>403,004</td></tr><tr><td>1050</td><td>Vật liệu
hoàn
thiện</td><td>BIa lát nền mài bóng loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x1200)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>535,524</td></tr><tr><td>1051</td><td>Vật liệu
hoàn
thiện</td><td>BIIb lát nền loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(500x500)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>99,464</td></tr><tr><td>1052</td><td>Vật liệu
hoàn
thiện</td><td>BIIb lát nền mài bóng loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(500x500)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>140,448</td></tr><tr><td>1053</td><td>Vật liệu
hoàn
thiện</td><td>BIIb lát nền C loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(600x600)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>139,740</td></tr><tr><td>*</td><td>Gạch ốp, lát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1054</td><td>Vật liệu
hoàn
thiện</td><td>BIII ốp loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x450)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>122,241</td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1055</td><td>Vật liệu
hoàn
thiện</td><td>BIII ốp loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x600)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>205,537</td></tr><tr><td>1056</td><td>Vật liệu
hoàn
thiện</td><td>BIII ốp loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x800)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>275,783</td></tr><tr><td>1057</td><td>Vật liệu
hoàn
thiện</td><td>BIII ốp loại 1</td><td>m2</td><td>QCVN
16:2019/BXD</td><td>(300x300)mm</td><td>Công ty CP
Tập đoàn
VITTO</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa gồm
vận chuyển</td><td></td><td>205,537</td></tr><tr><td>11,4</td><td>Gạch Ốp, lát VIGLACERA (Công ty CP kinh doanh gạch ốp lát VIGLACERA)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Gạch men EuroTile</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1058</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile VOC, PHS, ANN,
LUS, MOL- G</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>458,182</td><td></td></tr><tr><td>1059</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile hoa đá HOD, NGC-
G</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>516,000</td><td></td></tr><tr><td>1060</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile THD, SAT,
THK,VOC,VAD,BIY</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa</td><td>492,000</td><td></td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1061</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile NGC H</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>528,000</td><td></td></tr><tr><td>1062</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MOL,MMI, MOC-
M</td><td>m2</td><td>TCVN
7745:2007</td><td>(150x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>584,727</td><td></td></tr><tr><td>1063</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile
DAV,LTH,DAS,MOC, D</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>516,000</td><td></td></tr><tr><td>1064</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile NGC, HOD, D</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>516,000</td><td></td></tr><tr><td>1065</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MOL,PHS,HAT, I</td><td>m2</td><td>TCVN
7745:2007</td><td>(450x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>516,000</td><td></td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1066</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile NGC I</td><td>m2</td><td>TCVN
7745:2007</td><td>(450x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>584,727</td><td></td></tr><tr><td>1067</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MOL,MMI K</td><td>m2</td><td>TCVN
7745:2007</td><td>(200x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>824,727</td><td></td></tr><tr><td>1068</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile
DAS,PHS,SOK,TRA</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>722,182</td><td></td></tr><tr><td>1069</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile SHI G04, 06, 07</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>1.111.636</td><td></td></tr><tr><td>1070</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MOT T</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>824,727</td><td></td></tr><tr><td>1071</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile HOA,
PHA,SOK,TRA,TRAE</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình</td><td>584,727</td><td></td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>gạch ốp lát
VIGLACERA</td><td></td><td>trên địa
bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>*</td><td>Gạch granite EuroTile</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1072</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MDK</td><td>m2</td><td>TCVN
7745:2007</td><td>(150x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>356,727</td><td></td></tr><tr><td>1073</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile bóng MDP</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>245,455</td><td></td></tr><tr><td>1074</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MDP, MDK</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>279,818</td><td></td></tr><tr><td>1075</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MDK điểm</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>304,364</td><td></td></tr><tr><td>1076</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile men bóng MDP</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa</td><td>237,273</td><td></td></tr></tbody></table>

|<image_28>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1077</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MDK</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>271,636</td><td></td></tr><tr><td>1078</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile UB, UM, TB, UTB,
MDP</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>292,909</td><td></td></tr><tr><td>1079</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MD</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>394,364</td><td></td></tr><tr><td>1080</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile UB, UM, MDP,
MD</td><td>m2</td><td>TCVN
7745:2007</td><td>(400x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>301,091</td><td></td></tr><tr><td>1081</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MD-D</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>471,273</td><td></td></tr></tbody></table>

|<image_29>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1082</td><td>Vật liệu
hoàn
thiện</td><td>EuroTile MDK</td><td>m2</td><td>TCVN
7745:2007</td><td>(200x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>410,727</td><td></td></tr><tr><td>*</td><td>Gạch men Signature</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1083</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-P, L,M</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>653,455</td><td></td></tr><tr><td>1084</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-P, L,M</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>687,273</td><td></td></tr><tr><td>1085</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-P, L,M</td><td>m2</td><td>TCVN
7745:2007</td><td>(400x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>687,273</td><td></td></tr><tr><td>1086</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-P, L,M</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>785,455</td><td></td></tr></tbody></table>

|<image_30>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1087</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-P</td><td>m2</td><td>TCVN
7745:2007</td><td>(200x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>785,455</td><td></td></tr><tr><td>1088</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-NHV, SIG-
SOB,SIG-THT E01</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>687,273</td><td></td></tr><tr><td>1089</td><td>Vật liệu
hoàn
thiện</td><td>Signature SIG-NHV, SIG-
SOB, SIG -TAS</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>785,455</td><td></td></tr><tr><td>1090</td><td>Vật liệu
hoàn
thiện</td><td>Signature PT20</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>944,727</td><td></td></tr><tr><td>1091</td><td>Vật liệu
hoàn
thiện</td><td>Signature LIG G, GIB G,
POM G</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>1.088.727</td><td></td></tr><tr><td>*</td><td>Gạch Granite in kỹ thuật số Viglacera Tiên Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_31>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1092</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn PGM, PGP, PM</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>310,000</td><td></td></tr><tr><td>1093</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn PGM</td><td>m2</td><td>TCVN
7745:2007</td><td>(6400x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>378,000</td><td></td></tr><tr><td>1094</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn PGM,PGB, PTL</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>300,000</td><td></td></tr><tr><td>1095</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn PGB, PGM</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>368,000</td><td></td></tr><tr><td>1096</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn PED, PEM</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x1200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>586,000</td><td></td></tr><tr><td>1097</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn MDK, MDP</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình</td><td>352,000</td><td></td></tr></tbody></table>

|<image_32>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>gạch ốp lát
VIGLACERA</td><td></td><td>trên địa
bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1098</td><td>Vật liệu
hoàn
thiện</td><td>In kỹ thuật số Viglacera Tiên
Sơn PK, PGT</td><td>m2</td><td>TCVN
7745:2007</td><td>(150x900)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>446,000</td><td></td></tr><tr><td>1099</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Tiên Sơn
PG1,PG2, PG3, PG4, PG5</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>362,365</td><td></td></tr><tr><td>1100</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Tiên Sơn
PG1,PG2, PG3, PG4, PG5</td><td>m2</td><td>TCVN
7745:2007</td><td>(800x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>423,430</td><td></td></tr><tr><td>*</td><td>Gạch Ceramic Viglacera Hà nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1101</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Hà nội PUM,
PKS, PCM, PNP, PFN, PNQ,
PSP</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x300)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>170,000</td><td></td></tr><tr><td>1102</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Hà nội PUM, PKS,
PCM, PNP, PFN, PNQ, PSP</td><td>m2</td><td>TCVN
7745:2007</td><td>(400x400)mmx</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa</td><td>168,000</td><td></td></tr></tbody></table>

|<image_33>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1103</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Hà nội GM, KM,
H,KQ, PGM, PKM,PH,PKQ</td><td>m2</td><td>TCVN
7745:2007</td><td>(500x500)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>156,000</td><td></td></tr><tr><td>1104</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Hà nội PSM,
PVHP, PBS</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>224,000</td><td></td></tr><tr><td>1105</td><td>Vật liệu
hoàn
thiện</td><td>Viglacera Hà nội PSM, PBS,
PVHP</td><td>m2</td><td>TCVN
7745:2007</td><td>(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>216,000</td><td></td></tr><tr><td>*</td><td>Gạch Platium Thăng Long, Hà Nội</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1106</td><td>Vật liệu
hoàn
thiện</td><td>Thăng Long, Hà Nội
PL3601,02</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>318,455</td><td></td></tr><tr><td>1107</td><td>Vật liệu
hoàn
thiện</td><td>Thăng Long, Hà Nội
PL2801,02</td><td>m2</td><td>TCVN
7745:2007</td><td>(200x800)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa</td><td>348,000</td><td></td></tr></tbody></table>

|<image_34>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1108</td><td>Vật liệu
hoàn
thiện</td><td>Thăng Long, Hà Nội PH364-
1,2</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>257,000</td><td></td></tr><tr><td>1109</td><td>Vật liệu
hoàn
thiện</td><td>Thăng Long, Hà Nội CB-
P01, CB-L00, 36</td><td>m2</td><td>TCVN
7745:2007</td><td>(300x600)mm,
(600x600)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>257,000</td><td></td></tr><tr><td>1110</td><td>Vật liệu
hoàn
thiện</td><td>Thăng Long, Hà Nội PH22</td><td>m2</td><td>TCVN
7745:2007</td><td>(200x200)mm</td><td>Công ty CP
KD
gạch ốp lát
VIGLACERA</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>462,636</td><td></td></tr><tr><td>11,4</td><td>Đá ốp lát tự nhiên</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Đá Granite</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1111</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu đỏ</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Bình Định</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>1.000.000</td><td></td></tr><tr><td>1112</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu hồng</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Bình Định</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa</td><td>500,000</td><td></td></tr></tbody></table>

|<image_35>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bàn tỉnh
Lạng Sơn</td><td></td><td></td></tr><tr><td>1113</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu vàng</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Bình Định</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>572,727</td><td></td></tr><tr><td>1114</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu tím hoa cà</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Bình Định</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>318,182</td><td></td></tr><tr><td>1115</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Đá lát nền</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Bình Định</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>600,000</td><td></td></tr><tr><td>1116</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu vàng</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>227,273</td><td></td></tr><tr><td>1117</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu vân mây</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>163,636</td><td></td></tr></tbody></table>

|<image_36>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1118</td><td>Vật liệu
hoàn
thiện</td><td>Loại 1. Màu đen</td><td>m2</td><td>không có thông
tin</td><td>dày (18-20)mm</td><td>Nguồn từ tỉnh
Thừa Thiên
Huế</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>572,727</td><td></td></tr><tr><td>*</td><td>Đá xẻ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1119</td><td>Vật liệu
hoàn
thiện</td><td>Đá xám lát vỉa hè</td><td>m2</td><td>không có thông
tin</td><td>(15 x 15 x
0.5)cm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>800,000</td><td></td></tr><tr><td>1120</td><td>Vật liệu
hoàn
thiện</td><td>Đá xám lát vỉa hè</td><td>m2</td><td>không có thông
tin</td><td>(30 x 30 x
0.5)cm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>700,000</td><td></td></tr><tr><td>1121</td><td>Vật liệu
hoàn
thiện</td><td>Đá xám lát vỉa hè</td><td>m2</td><td>không có thông
tin</td><td>(30 x 60 x
0.5)cm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>700,000</td><td></td></tr><tr><td>1122</td><td>Vật liệu
hoàn
thiện</td><td>Đá bó vỉa</td><td>m2</td><td>không có thông
tin</td><td>(15 x 20)cm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>400,000</td><td></td></tr></tbody></table>

|<image_37>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1123</td><td>Vật liệu
hoàn
thiện</td><td>Đá bó vỉa</td><td>m2</td><td>không có thông
tin</td><td>(20 x 25)cm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>400,000</td><td></td></tr><tr><td>1124</td><td>Vật liệu
hoàn
thiện</td><td>Đá bó vỉa</td><td>m2</td><td>không có thông
tin</td><td>(25 x 30)cm</td><td>Nguồn từ tỉnh
Thanh Hoá</td><td>Đã bao
gồm
VC</td><td>Giá bán
đến chân
công trình
trên địa
bàn tỉnh
Lạng Sơn</td><td>400,000</td><td></td></tr><tr><td></td><td>- Ghi chú: Giá đá loại 2 giảm đi 50.000,0 đồng/m2 so với giá đá loại 1; Giá đá loại 3 giảm đi 100.000,0 đồng/m2 so với giá đá loại 1.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>XII</td><td>Vật liệu
lợp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12,1</td><td>Tôn lợp (Công ty Cổ phần tôn Đông Á)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Tôn lạnh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1125</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, TD</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.35mm
(0.350*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>71,818</td><td></td></tr><tr><td>1126</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, TD</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.4mm
(0.4*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>80,000</td><td></td></tr><tr><td>1127</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, TD</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.45mm
(0.45*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>92,727</td><td></td></tr></tbody></table>

|<image_38>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1128</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, AZ100</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.35mm
(0.35*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>80,000</td><td></td></tr><tr><td>1129</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, AZ100</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.4mm
(0.4*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>89,091</td><td></td></tr><tr><td>1130</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, AZ100</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.42mm
(0.420*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>95,455</td><td></td></tr><tr><td>1131</td><td>Vật liệu
lợp</td><td>(6-11)sóng, mạ nhôm kẽm
phủ sơn, AZ100</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.45mm
(0.450*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>104,545</td><td></td></tr><tr><td>*</td><td>Tôn 3 lớp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1132</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, TD</td><td>m2</td><td>TCVN
8053:2009</td><td>0.35mm
(0.35*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>140,000</td><td></td></tr><tr><td>1133</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, TD</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.4mm
(0.4*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>148,182</td><td></td></tr></tbody></table>

|<image_39>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1134</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, TD</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.45mm
(0.45*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>160,909</td><td></td></tr><tr><td>1135</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, AZ100</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.35mm
(0.35*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>148,182</td><td></td></tr><tr><td>1136</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, AZ101</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.40mm
(0.4*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>157,273</td><td></td></tr><tr><td>1137</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, AZ102</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.42mm
(0.42*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>163,636</td><td></td></tr><tr><td>1138</td><td>Vật liệu
lợp</td><td>Joiviet trên nền tôn lạnh (6-
11)sóng, mạ nhôm kẽm phủ
sơn, AZ103</td><td>m2</td><td>TCVN
8053:2009</td><td>dày 0.45mm
(0.45*1200)mm</td><td>Công ty Cổ
phần tôn
Đông Á</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm VC</td><td>172,727</td><td></td></tr><tr><td>12,2</td><td>Tôn lợp (Công ty Cổ phần Austnam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1139</td><td>Vật liệu
lợp</td><td>Tôn Austnam AC11 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 11
sóng
dày 0.45mm, lớp
mạ Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>196,364</td><td></td></tr></tbody></table>

|<image_40>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1140</td><td>Vật liệu
lợp</td><td>Tôn Austnam AC11 -
0,47mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 11
sóng
dày 0.47mm, lớp
mạ Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>200,000</td><td></td></tr><tr><td>1141</td><td>Vật liệu
lợp</td><td>Tôn Austnam ATEK1000 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 6
sóng
dày 0.45mm, lớp
mạ Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>197,273</td><td></td></tr><tr><td>1142</td><td>Vật liệu
lợp</td><td>ATEK1000 - 0,47mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 6
sóng
dày 0.47mm, lớp
mạ Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>200,909</td><td></td></tr><tr><td>1143</td><td>Vật liệu
lợp</td><td>Tôn Austnam ATEK1088 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 5
sóng
dày 0.45mm, lớp
mạ Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>192,727</td><td></td></tr><tr><td>1144</td><td>Vật liệu
lợp</td><td>Tôn Austnam ATEK1088 -
0,47mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 5
sóng
dày 0.47mm, lớp
mạ Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>197,273</td><td></td></tr><tr><td>1145</td><td>Vật liệu
lợp</td><td>Tôn Austnam AD11 -
0,42mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 11
sóng
dày 0.42mm, lớp
mạ Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>182,727</td><td></td></tr><tr><td>1146</td><td>Vật liệu
lợp</td><td>Tôn Austnam AD11 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 11
sóng</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td>188,182</td><td></td></tr></tbody></table>

|<image_41>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>dày 0.45mm, lớp
mạ Az100</td><td></td><td></td><td>đã bao gồm
vận chuyển</td><td></td><td></td></tr><tr><td>1147</td><td>Vật liệu
lợp</td><td>Tôn Austnam AD06 -
0,42mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 6
sóng
dày 0.42mm, lớp
mạ Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>183,636</td><td></td></tr><tr><td>1148</td><td>Vật liệu
lợp</td><td>Tôn Austnam AD06 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 6
sóng
dày 0.45mm, lớp
mạ Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>190,909</td><td></td></tr><tr><td>1149</td><td>Vật liệu
lợp</td><td>Tôn Austnam AD05 -
0,42mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 5
sóng
dày 0.42mm, lớp
mạ Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>180,000</td><td></td></tr><tr><td>1150</td><td>Vật liệu
lợp</td><td>Tôn Austnam AD05 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 5
sóng
dày 0.45mm, lớp
mạ Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>187,273</td><td></td></tr><tr><td>1151</td><td>Vật liệu
lợp</td><td>Tôn Austnam ADTile -
0,42mm (Sóng giả ngói)</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, sóng
ngói dày
0.42mm, lớp mạ
Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>191,818</td><td></td></tr><tr><td>1152</td><td>Vật liệu
lợp</td><td>Tôn Austnam Alok 420 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn liên kết
bằng
đai kẹp âm, dày
0.45mm( 3 sóng)</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>250,909</td><td></td></tr></tbody></table>

|<image_42>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1153</td><td>Vật liệu
lợp</td><td>Tôn Austnam Alok 420 -
0,47mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn liên kết
bằng
đai kẹp âm, dày
0.47mm( 3 sóng)</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>256,364</td><td></td></tr><tr><td>1154</td><td>Vật liệu
lợp</td><td>Tôn Austnam ASEAM 480 -
0,45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn liên kết
bằng
đai kẹp âm, dày
0.45mm( 2 sóng)</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>230,000</td><td></td></tr><tr><td>1155</td><td>Vật liệu
lợp</td><td>Tôn Austnam ASEAM 480 -
0,47mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn liên kết
bằng
đai kẹp âm, dày
0.47mm( 2 sóng)</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>234,545</td><td></td></tr><tr><td>1156</td><td>Vật liệu
lợp</td><td>Tôn Austnam AR-EPS -
0.40/50/0.35, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn mái chống
nóng, xốp EPS
dày 50mm, 2 lớp
tôn,
G340-G550</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>362,727</td><td></td></tr><tr><td>1157</td><td>Vật liệu
lợp</td><td>Tôn Austnam AR-EPS -
0.45/50/0.35, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn mái chống
nóng, xốp EPS
dày 50mm, 2 lớp
tôn,
G340-G551</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>378,182</td><td></td></tr><tr><td>1158</td><td>Vật liệu
lợp</td><td>Tôn Austnam AR-EPS -
0.40/50/0.40, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn mái chống
nóng, xốp EPS
dày 50mm, 2 lớp
tôn,
G340-G552</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>382,727</td><td></td></tr></tbody></table>

|<image_43>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1159</td><td>Vật liệu
lợp</td><td>Tôn Austnam AR-EPS -
0.45/50/0.40, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn mái chống
nóng, xốp EPS
dày 50mm, 2 lớp
tôn,
G340-G553</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>395,455</td><td></td></tr><tr><td>1160</td><td>Vật liệu
lợp</td><td>Tôn Austnam AP-EPS -
0.35/50/0.35, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tấm vách EPS
chống nóng,
chống ồn, xốp
dày 50mm,
G340-G550</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>317,273</td><td></td></tr><tr><td>1161</td><td>Vật liệu
lợp</td><td>Tôn Austnam AP-EPS -
0.40/50/0.35, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tấm vách EPS
chống nóng,
chống ồn, xốp
dày 50mm,
G340-G551</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>328,182</td><td></td></tr><tr><td>1162</td><td>Vật liệu
lợp</td><td>Tôn Austnam AP-EPS -
0.40/50/0.40, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tấm vách EPS
chống nóng,
chống ồn, xốp
dày 50mm,
G340-G552</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>338,182</td><td></td></tr><tr><td>1163</td><td>Vật liệu
lợp</td><td>Tôn Austnam AP-EPS -
0.45/50/0.40, Tỉ trọng EPS
11kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tấm vách EPS
chống nóng,
chống ồn, xốp
dày 50mm,
G340-G553</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>350,000</td><td></td></tr><tr><td>1164</td><td>Vật liệu
lợp</td><td>Tôn Austnam APU1-
0,45mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az150</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>285,455</td><td></td></tr></tbody></table>

|<image_44>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1165</td><td>Vật liệu
lợp</td><td>Tôn Austnam APU1-
0,47mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az151</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>289,091</td><td></td></tr><tr><td>1166</td><td>Vật liệu
lợp</td><td>Tôn Austnam APU1-
0,45mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az152</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>281,818</td><td></td></tr><tr><td>1167</td><td>Vật liệu
lợp</td><td>Tôn Austnam APU1-
0,47mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az153</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>286,364</td><td></td></tr><tr><td>1168</td><td>Vật liệu
lợp</td><td>Tôn Austnam ADPU1-
0,40mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az100</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>265,455</td><td></td></tr><tr><td>1169</td><td>Vật liệu
lợp</td><td>Tôn Austnam ADPU1-
0,42mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az101</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>271,818</td><td></td></tr><tr><td>1170</td><td>Vật liệu
lợp</td><td>Tôn Austnam ADPU1-
0,40mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az102</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>261,818</td><td></td></tr></tbody></table>

|<image_45>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1171</td><td>Vật liệu
lợp</td><td>Tôn Austnam ADPU1-
0,42mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ
Az103</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>268,182</td><td></td></tr><tr><td>1172</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 300 mm, dày 0,42mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k300</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>53,636</td><td></td></tr><tr><td>1173</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 400 mm, dày 0,42mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k400</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>70,455</td><td></td></tr><tr><td>1174</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 600 mm, dày 0,42mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k600</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>100,909</td><td></td></tr><tr><td>1175</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 300 mm, dày 0,45mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k300</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>58,636</td><td></td></tr><tr><td>1176</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 400 mm, dày 0,45mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k400</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>76,818</td><td></td></tr><tr><td>1177</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 600 mm, dày 0,45mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k600</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td>110,909</td><td></td></tr></tbody></table>

|<image_46>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đã bao gồm
vận chuyển</td><td></td><td></td></tr><tr><td>1178</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 300 mm, dày 0,47mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k300</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>59,545</td><td></td></tr><tr><td>1179</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 400 mm, dày 0,47mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k400</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>78,636</td><td></td></tr><tr><td>1180</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Austnam khổ
rộng 600 mm, dày 0,47mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k600</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>113,636</td><td></td></tr><tr><td>1181</td><td>Vật liệu
lợp</td><td>Tôn Suntek EC11 (11 sóng)
dày 0.40mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 11
sóng
dày 0.40mm, lớp
mạ AZ50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>125,455</td><td></td></tr><tr><td>1182</td><td>Vật liệu
lợp</td><td>Tôn Suntek EC11 (11 sóng)
dày 0.45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 11
sóng
dày 0.45mm, lớp
mạ AZ50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>137,273</td><td></td></tr><tr><td>1183</td><td>Vật liệu
lợp</td><td>Tôn Suntek EK106 (6 sóng)
dày 0.40mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 6
sóng
dày 0.40mm, lớp
mạ AZ50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>126,364</td><td></td></tr></tbody></table>

|<image_47>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1184</td><td>Vật liệu
lợp</td><td>Tôn Suntek EK106 (6 sóng)
dày 0.45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 6
sóng
dày 0.45mm, lớp
mạ AZ50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>138,182</td><td></td></tr><tr><td>1185</td><td>Vật liệu
lợp</td><td>Tôn Suntek EK108 (5 sóng)
dày 0.40mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 5
sóng
dày 0.40mm, lớp
mạ AZ50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>123,636</td><td></td></tr><tr><td>1186</td><td>Vật liệu
lợp</td><td>Tôn Suntek EK108 (5 sóng)
dày 0.45mm</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn 1 lớp, 5
sóng
dày 0.45mm, lớp
mạ AZ50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>135,455</td><td></td></tr><tr><td>1187</td><td>Vật liệu
lợp</td><td>Tôn Suntek ELOK420 dày
0.45mm,G550(3 sóng )</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn liên kết
bằng
đai kẹp âm, dày
0.45mm, Az50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>200,000</td><td></td></tr><tr><td>1188</td><td>Vật liệu
lợp</td><td>Tôn Suntek ESEAM480 dày
0.45mm, G340(2 sóng)</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn liên kết
bằng
đai kẹp âm, dày
0.45mm Az50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>183,636</td><td></td></tr><tr><td>1189</td><td>Vật liệu
lợp</td><td>Tôn Suntek EPU1 (11 sóng)
dày 0.40mm, lớp PU tỷ trọng
28-32kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ Az50</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>218,182</td><td></td></tr><tr><td>1190</td><td>Vật liệu
lợp</td><td>Tôn Suntek EPU1 (11 sóng)
dày 0.45mm, lớp PU tỷ trọng
28-32kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td>230,000</td><td></td></tr></tbody></table>

|<image_48>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>dày 18mm, tôn
mạ Az51</td><td></td><td></td><td>đã bao gồm
vận chuyển</td><td></td><td></td></tr><tr><td>1191</td><td>Vật liệu
lợp</td><td>Tôn Suntek EPU1 (6 sóng)
dày 0.40mm, lớp PU tỷ trọng
28-32kg/m3</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ Az52</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>217,273</td><td></td></tr><tr><td>1192</td><td>Vật liệu
lợp</td><td>Tôn EPU1 (6 sóng) dày
0.45mm, lớpPU tỷ trọng 28-
32kg/m33</td><td>m2</td><td>ASTM
A755/A792/A92
4</td><td>Tôn xốp chống
nóng, lớp PU
dày 18mm, tôn
mạ Az53</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>229,091</td><td></td></tr><tr><td>1193</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Suntek khổ
300mm dày 0.40mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k300</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>50,000</td><td></td></tr><tr><td>1194</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Suntek khổ
400mm dày 0.40mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k400</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>53,636</td><td></td></tr><tr><td>1195</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Suntek khổ
600mm dày 0.40mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k600</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>74,545</td><td></td></tr><tr><td>1196</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Suntek khổ
300mm dày 0.45mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k300</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>45,455</td><td></td></tr></tbody></table>

|<image_49>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1197</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Suntek khổ
400mm dày 0.45mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k400</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>58,182</td><td></td></tr><tr><td>1198</td><td>Vật liệu
lợp</td><td>Phụ kiện tôn Suntek khổ
600mm dày 0.45mm</td><td>md</td><td>ASTM
A755/A792/A92
4</td><td>Phu kiện k600</td><td>Công ty CP
Austnam</td><td>không</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td>82,727</td><td></td></tr><tr><td>XIII</td><td>Vật liệu chuyên ngành giao thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13,1</td><td>Công ty cổ phần Carbon Việt Nam</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1199</td><td>VL
ngành
giao
thông</td><td>Bê tông nhựa Carboncor
Asphalt - CA 9.5</td><td>tấn</td><td>TCCS
09:2014/TCĐBV
N</td><td>Bao 25kg, 1 tấn</td><td>Công ty cổ
phần Carbon
Việt Nam</td><td>3.000
đ/tấn</td><td>Giá bán tại
thành phố
Lạng Sơn,
thêm cước
vận chuyển
đối với các
địa điểm xa
hơn</td><td></td><td>3.700.000</td></tr><tr><td>1200</td><td>VL
ngành
giao
thông</td><td>Bê tông nhựa Carboncor
Asphalt - CA 12,5</td><td>tấn</td><td>TCCS
09:2014/TCĐBV
N</td><td>Bao 25kg, 1 tấn</td><td>Công ty cổ
phần Carbon
Việt Nam</td><td>3.000
đ/tấn</td><td>Giá bán tại
thành phố
Lạng Sơn,
thêm cước
vận chuyển
đối với các
địa điểm xa
hơn</td><td></td><td>3.700.000</td></tr><tr><td>1201</td><td>VL
ngành
giao
thông</td><td>Bê tông nhựa Carboncor
Asphalt - CA 19 (bê tông
nhựa rỗng Carbon)</td><td>tấn</td><td>TCCS
09:2014/TCĐBV
N</td><td>Bao 25kg, 1 tấn</td><td>Công ty cổ
phần Carbon
Việt Nam</td><td>3.000
đ/tấn</td><td>Giá bán tại
thành phố
Lạng Sơn,
thêm cước
vận chuyển</td><td></td><td>2.880.000</td></tr></tbody></table>

|<image_50>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đối với các
địa điểm xa
hơn</td><td></td><td></td></tr><tr><td>1202</td><td>VL
ngành
giao
thông</td><td>Nhũ tương kiềm thấm bám</td><td>lít</td><td>TCVN
13506:2022</td><td>Phuy 150 lít</td><td>Công ty cổ
phần Carbon
Việt Nam</td><td>300
đ/lít</td><td>Giá bán tại
thành phố
Lạng Sơn,
thêm cước
vận chuyển
đối với các
địa điểm xa
hơn</td><td></td><td>23,100</td></tr><tr><td>1203</td><td>VL
ngành
giao
thông</td><td>Nhũ tương kiềm dính bám</td><td>lít</td><td>TCVN
13506:2022</td><td>Phuy 150 lít</td><td>Công ty cổ
phần Carbon
Việt Nam</td><td>300
đ/lít</td><td>Giá bán tại
thành phố
Lạng Sơn,
thêm cước
vận chuyển
đối với các
địa điểm xa
hơn</td><td></td><td>19,250</td></tr><tr><td>1204</td><td>VL
ngành
giao
thông</td><td>Nhũ tương kiềm dính bám</td><td>lít</td><td>TCVN
13506:2022</td><td>Phuy 150 lít</td><td>Công ty cổ
phần Carbon
Việt Nam</td><td>300
đ/lít</td><td>Giá bán tại
thành phố
Lạng Sơn,
thêm cước
vận chuyển
đối với các
địa điểm xa
hơn</td><td></td><td>19,250</td></tr><tr><td>13,2</td><td>Thiết bị điện, chiếu sáng Miền Bắc (Công ty TNHH thiết bị và chiếu sáng Miền Bắc)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Trụ sở: số 30, khu C, tổ dân phố Phũ Mỹ, Mỹ Đình 2, Nam Từ Liên, Hà Nội.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cột đèn Tín hiệu giao thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_51>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1205</td><td>VL
ngành
giao
thông</td><td>Cột thép đa giác, tròn côn
THGT dày 6mm, tay vươn
đơn 6m dày 5mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 6,2m</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>12.900.000</td></tr><tr><td>1206</td><td>VL
ngành
giao
thông</td><td>Cột thép đa giác, tròn côn
THGT dày 6mm, tay vươn
đơn 4m dày 5mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 6,2m</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>12.300.000</td></tr><tr><td>1207</td><td>VL
ngành
giao
thông</td><td>Cột thép đa giác, tròn côn
THGTtay vươn đơn 4m, dày
5mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 3,3m</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>10.600.000</td></tr><tr><td>1208</td><td>VL
ngành
giao
thông</td><td>Cột thép đa giác, tròn côn
THGT dày 6mm, tay vươn
vuông góc 5m + 2m dày
4mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 6,2m</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>13.000.000</td></tr><tr><td>1209</td><td>VL
ngành
giao
thông</td><td>Cột thép đa giác, tròn côn
THGT tay vươn đơn 5m, dày
5mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 5,6m,</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>10.600.000</td></tr><tr><td>1210</td><td>VL
ngành</td><td>Cột thép đa giác, tròn côn
THGT dày 3mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 4,4m</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td></td><td>2.670.000</td></tr></tbody></table>

|<image_52>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td>giao
thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td>chưa bao
gồm vận
chuyển</td><td></td><td></td></tr><tr><td>1211</td><td>VL
ngành
giao
thông</td><td>Thanh giá treo đèn thép mạ
kẽmdày 3mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D60</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>450.000</td></tr><tr><td>1212</td><td>VL
ngành
giao
thông</td><td>Cột thép đa giác, tròn côn
THGT dày 3mm</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>H= 2,5m</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>2.140.000</td></tr><tr><td>1213</td><td>VL
ngành
giao
thông</td><td>Đèn LED cảnh báo tín hiệu
giao thông màu vàngử dụng
năng lượng mặt trời (đã bao
gồm pin năng lượng mặt trời,
tủ điều khiển)</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D300</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>7.300.000</td></tr><tr><td>1214</td><td>VL
ngành
giao
thông</td><td>Bộ Đèn tín hiệu giao thông 3
màu xanh, đỏ, vàng (Led), vỏ
hộp và tay đỡ bóng nhựa
ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td></td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>8.056.000</td></tr><tr><td>1215</td><td>VL
ngành
giao
thông</td><td>Đèn LED THGT</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>3 x D100</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>5.560.000</td></tr></tbody></table>

|<image_53>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1216</td><td>VL
ngành
giao
thông</td><td>Đèn LED THGT</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>3 x D200</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>6.060.000</td></tr><tr><td>1217</td><td>VL
ngành
giao
thông</td><td>Đèn LED THGT</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>3 x D300</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>7.970.000</td></tr><tr><td>1218</td><td>VL
ngành
giao
thông</td><td>Đèn Led mũi tên chỉ hướng</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D300</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>2.900.000</td></tr><tr><td>1219</td><td>VL
ngành
giao
thông</td><td>Đèn chữ thập (Led), vỏ hộp
và tay đỡ bóng nhựa ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D200</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>3.180.000</td></tr><tr><td>1220</td><td>VL
ngành
giao
thông</td><td>Đèn LED chữ thập (Led), vỏ
hộp và tay đỡ bóng nhựa
ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D300</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>3.620.000</td></tr><tr><td>1221</td><td>VL
ngành</td><td>Đèn LED đếm ngược (Led)
vỏ hộp và tay đỡ bóng nhựa
ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D300</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,</td><td></td><td>2.680.000</td></tr></tbody></table>

|<image_54>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td>giao
thông</td><td></td><td></td><td></td><td></td><td></td><td></td><td>chưa bao
gồm vận
chuyển</td><td></td><td></td></tr><tr><td>1222</td><td>VL
ngành
giao
thông</td><td>Đèn LED đếm ngược (Led)
vỏ hộp và tay đỡ bóng nhựa
ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D400</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>3.700.000</td></tr><tr><td>1223</td><td>VL
ngành
giao
thông</td><td>Đèn LED đếm ngược (Led)
vỏ hộp và tay đỡ thép sơn
tĩnh điện</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D600</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>6.000.000</td></tr><tr><td>1224</td><td>VL
ngành
giao
thông</td><td>Đèn LED đi bộ (Led hình
người đỏ, xanh), vỏ hộp và
tay nhựa ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>2 x D200</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>4.900.000</td></tr><tr><td>1225</td><td>VL
ngành
giao
thông</td><td>Đèn LED đi bộ (Led hình
người đỏ, xanh), vỏ hộp và
tay nhựa ABS</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>D300</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>2.950.000</td></tr><tr><td>1226</td><td>VL
ngành
giao
thông</td><td>Trụ tủ điều khiển tín hiệu
giao thông</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td></td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>52.500.000</td></tr></tbody></table>

|<image_55>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1227</td><td>VL
ngành
giao
thông</td><td>Tủ điều khiển tín hiệu giao
thông 2 pha, ổn áp 2000VA</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>(800x800x450)
mm</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>32.500.000</td></tr><tr><td>1228</td><td>VL
ngành
giao
thông</td><td>Tủ điện điều khiển chiếu sáng
trọn bộ 50A (tôn dày 1,2mm,
thiết bị đóng cắt LS Hàn
Quốc chính hãng) chưa bao
gồm Công tơ điện lực cấp</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>(1200x600x400)
mm</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>10.350.000</td></tr><tr><td>1229</td><td>VL
ngành
giao
thông</td><td>Tủ điện điều khiển chiếu sáng
trọn bộ 63A (tôn dày 1,2mm,
thiết bị đóng cắt LS Hàn
Quốc chính hãng) chưa bao
gồm Công tơ điện lực cấp</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>(1200x600x400)
mm</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>10.950.000</td></tr><tr><td>1230</td><td>VL
ngành
giao
thông</td><td>Tủ điện điều khiển chiếu sáng
trọn bộ 100A (tôn dày
1,2mm, thiết bị đóng cắt LS
Hàn Quốc chính hãng) chưa
bao gồm Công tơ điện lực
cấp</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>(1200x600x400)
mm</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>12.950.000</td></tr><tr><td>1231</td><td>VL
ngành
giao
thông</td><td>Tủ điện điều khiển chiếu sáng
trọn bộ 50A ( tôn dày 1,5mm,
thiết bị đóng cắt LS Hàn
Quốc chính hãng) chưa bao
gồm Công tơ điện lực cấp</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>(1200x600x350)
mm</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>11.350.000</td></tr></tbody></table>

|<image_56>|


## VIETTEL AI RACE

## TD644

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

## NGÀNH GIAO THÔNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>1232</td><td>VL
ngành
giao
thông</td><td>Tủ điện điều khiển chiếu sáng
trọn bộ 63A (tôn dày 1,5mm,
thiết bị đóng cắt LS Hàn
Quốc chính hãng) chưa bao
gồm Công tơ điện lực cấp</td><td>Cái</td><td>TCCS
1:2018/CSMB</td><td>(1200x600x350)
mm</td><td>Công ty
TNHH TB và
CS Miền Bắc</td><td>Không</td><td>Giá bán tại
thành phố
Lạng Sơn,
chưa bao
gồm vận
chuyển</td><td></td><td>12.950.000</td></tr><tr><td>13,3</td><td>Nhựa đường (Công ty TNHH Nhựa đường Petrolimex)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Trụ sở: số 1 Hùng Vương, phường Sở Dầu, quận Hồng Bàng, thành phố Hải Phòng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1233</td><td>VL
ngành
giao
thông</td><td>Nhựa đường 60/70 - xá</td><td>kg</td><td>TCVN 13567-
1:2022</td><td>Xe téc chuyên
dùng</td><td>Công ty
TNHH
Nhựa đường
Petrolimex</td><td>Đã bao
gồm
VC</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td></td><td>16,300</td></tr><tr><td>1234</td><td>VL
ngành
giao
thông</td><td>Nhựa đường Polime PMB3</td><td>kg</td><td>TCVN
11193:2021</td><td>Xe téc chuyên
dùng</td><td>Công ty
TNHH
Nhựa đường
Petrolimex</td><td>Đã bao
gồm
VC</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td></td><td>22,100</td></tr><tr><td>1235</td><td>VL
ngành
giao
thông</td><td>Nhựa đường lỏng MC 70-xá</td><td>kg</td><td>TCVN
8818:2011</td><td>Xe téc chuyên
dùng</td><td>Công ty
TNHH
Nhựa đường
Petrolimex</td><td>Đã bao
gồm
VC</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td></td><td>23,400</td></tr><tr><td>1236</td><td>VL
ngành
giao
thông</td><td>Nhựa đường nhũ tương
CRS1- xá</td><td>kg</td><td>TCVN
8817:2011</td><td>Xe téc chuyên
dùng</td><td>Công ty
TNHH
Nhựa đường
Petrolimex</td><td>Đã bao
gồm
VC</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td></td><td>14,300</td></tr><tr><td>1237</td><td>VL
ngành
giao
thông</td><td>Nhựa đường nhũ tương
CRS1P- xá</td><td>kg</td><td>TCVN
8816:2011</td><td>Xe téc chuyên
dùng</td><td>Công ty
TNHH
Nhựa đường
Petrolimex</td><td>Đã bao
gồm
VC</td><td>Giá bán tại
thành phố
Lạng Sơn,
đã bao gồm
vận chuyển</td><td></td><td>19,300</td></tr></tbody></table>

|<image_57>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

### LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN

### NGÀNH GIAO THÔNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD644</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: GẠCH ỐP LÁT, VẬT LIỆU LỢP, VẬT LIỆU CHUYÊN
NGÀNH GIAO THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td></td><td>Giá trên chỉ áp dụng cho thành phố Lạng Sơn, nếu tính tại các huyện thì tính thêm tiền như sau:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Tại Chi Lăng - Lạng Sơn: -100đ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Tại Hữu Nghị và Cao Lộc - Lạng Sơn: +
50đ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Tại Văn Lãng - Lạng Sơn: +100đ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Tại Tràng Định - Lạng Sơn: +250đ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_58>|


