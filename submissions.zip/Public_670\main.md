# Public_670

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD670</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU CỬA ĐI
VÀ KÝ HIỆU CẦU THANG VÀ ĐƯỜNG
DỐC TRONG BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Cửa đi
đơn</td><td>Cửa đi đơn,
một cánh thể
hiện trên mặt
bằng</td><td></td><td>Ký hiệu chiều quay
của cánh cửa trên
mặt bằng theo 90°
hoặc 45°.</td></tr><tr><td></td><td>Cửa đi đơn hai
cánh</td><td></td><td></td></tr><tr><td></td><td>Cửa đi cánh
xếp</td><td></td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD670</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU CỬA ĐI
VÀ KÝ HIỆU CẦU THANG VÀ ĐƯỜNG
DỐC TRONG BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td></td><td>Cửa đi đơn
một cánh mở
cả hai phía,
dạng tự động</td><td></td><td>Chiều quay cánh
cửa vẽ theo độ
chênh 30°.</td></tr><tr><td></td><td>Cửa đi đơn hai
cánh mở cả hai
phía, dạng tự
động</td><td></td><td></td></tr><tr><td>Cửa đi
quay</td><td>Cửa đi quay
theo trục đứng
giữa</td><td></td><td></td></tr><tr><td>Cửa lùa
đơn</td><td>Cửa lùa đơn
một cánh</td><td></td><td></td></tr><tr><td></td><td>Cửa lùa đơn
hai cánh</td><td></td><td></td></tr><tr><td>Cửa
nâng</td><td>Cửa nâng hay
cửa cuốn</td><td></td><td></td></tr><tr><td>Cửa
kép</td><td>Cửa kép hai
cánh</td><td></td><td></td></tr></tbody></table>

|<image_5>|

|<image_6>|

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD670</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU CỬA ĐI
VÀ KÝ HIỆU CẦU THANG VÀ ĐƯỜNG
DỐC TRONG BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td></td><td>Cửa kép bốn
cánh</td><td></td><td></td></tr><tr><td>Cửa lẩn</td><td>Cửa lẩn đẩy
vào trong
tường</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Đường
dốc</td><td>Đường dốc
cho xe ra
vào, thể hiện
trên mặt
bằng</td><td></td><td>Độ dốc phải ghi ở
phía trên của mũi
tên, chỉ hướng
dốc.</td></tr></tbody></table>

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD670</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU CỬA ĐI
VÀ KÝ HIỆU CẦU THANG VÀ ĐƯỜNG
DỐC TRONG BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td>Mặt
cắt</td><td>Mặt cắt cầu
thang</td><td></td><td>Thể hiện trên bản
vẽ tỷ lệ 1:200 và
nhỏ hơn.</td></tr><tr><td></td><td>Mặt cắt cầu
thang</td><td></td><td>Thể hiện trên bản
vẽ tỷ lệ lớn hơn
1:200.</td></tr><tr><td>Mặt
bằng</td><td>Mặt bằng cầu
thang tầng
dưới cùng</td><td></td><td>Điểm bắt đầu của
mũi tên ký hiệu
được thể hiện bằng
dấu chấm nhỏ đặt
tại khởi điểm của
bậc cầu thang đầu
tiên; đầu ngắt bậc
thang quy định cắt
tại mức cao độ 1 m
so với mặt sàn.</td></tr><tr><td></td><td>Mặt bằng cầu
thang tầng
trung gian</td><td></td><td>Đường mũi tên ký
hiệu phải vẽ liên
tục.</td></tr></tbody></table>

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|

|<image_21>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD670</th></tr></thead><tbody><tr><td></td><td>QUY ƯỚC THỂ HIỆN KÝ HIỆU CỬA ĐI
VÀ KÝ HIỆU CẦU THANG VÀ ĐƯỜNG
DỐC TRONG BẢN VẼ THI CÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên ký hiệu</th><th></th><th>Ký hiệu</th><th>Chú thích</th></tr></thead><tbody><tr><td></td><td>Mặt bằng cầu
thang tầng
trên cùng</td><td></td><td>Đường mũi tên ký
hiệu phải vẽ liên
tục, đầu nhọn mũi
tên phải vẽ tới
ranh giới mặt bằng
cầu thang.</td></tr><tr><td>Thang
máy</td><td>Thang máy,
thể hiện trên
mặt bằng</td><td></td><td></td></tr></tbody></table>

|<image_22>|

|<image_23>|

|<image_24>|


