# Public_634

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT</th><th></th></tr></thead><tbody><tr><td>1</td><td>I. YÊU CẦU
CHUNG</td><td>- Thiết bị mới 100%, sản xuất từ năm 2023 trở về sau</td></tr><tr><td>2</td><td></td><td>- Đạt tiêu chuẩn ISO 13485 hoặc tương đương</td></tr><tr><td>3</td><td></td><td>Điện nguồn sử dụng 100 - 240V/ 50/60 Hz</td></tr><tr><td>4</td><td></td><td>Điều kiện môi trường làm việc:</td></tr><tr><td>5</td><td></td><td>+ Nhiệt độ: Từ 100 đến 350C</td></tr><tr><td>6</td><td></td><td>+ Độ ẩm tối đa tới 80%</td></tr><tr><td>7</td><td></td><td>+ Áp suất: 700 hPa – 1060 hPa</td></tr><tr><td>8</td><td>II. YÊU CẦU CẤU
HÌNH</td><td>Máy chính – Màn hình LCD 21.5 inch</td></tr><tr><td>9</td><td></td><td>Đầu dò kèm theo:</td></tr><tr><td>10</td><td></td><td>- Đầu dò Convex bằng tần số rộng 6C1(Model: PVT-375BT): 01 cái</td></tr><tr><td>11</td><td></td><td>- Đầu dò Linear bằng tần số rộng 14L5 (Model: PLT-1005BT): 01 cái</td></tr><tr><td>12</td><td></td><td>- Đầu dò Sector bằng tần số rộng 5S2 (Model: PST-30BT): 01 cái</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>14</th><th></th><th>Phần mềm bao gồm cả hệ điều hành và các ứng dụng có bản quyền trọn đời
máy: 01 bộ
Thiết bị phụ trợ kèm theo (Mua ở Việt Nam):</th></tr></thead><tbody><tr><td>15</td><td></td><td></td></tr><tr><td>16</td><td></td><td>- Bộ máy Vi tính để bàn kèm máy in laser màu : 01 Bộ</td></tr><tr><td>17</td><td></td><td>- Cáp kết nối tín hiệu: 01 Cái</td></tr><tr><td>18</td><td></td><td>- Bộ lưu điện online 2kVA</td></tr><tr><td>19</td><td></td><td>- Gel siêu âm 05 kg</td></tr><tr><td>20</td><td>III. THÔNG SỐ KỸ
THUẬT</td><td>1. Đặc tính chung</td></tr><tr><td>21</td><td></td><td>Máy được thiết kế đồng bộ trên xe đẩy, bánh xe có khóa</td></tr><tr><td>22</td><td></td><td>Số cổng kết nối đầu dò: 04</td></tr><tr><td>23</td><td></td><td>Bảng điều khiển có thể điều chỉnh lên xuống</td></tr><tr><td>24</td><td></td><td>Màn hình có thể điều đỉnh lên, xuống, xoay, nâng góc</td></tr><tr><td>25</td><td></td><td>Loa Stereo tích hợp</td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>27</th></tr></thead><tbody><tr><td>28</td></tr><tr><td>29</td></tr><tr><td>30</td></tr><tr><td>31</td></tr><tr><td>32</td></tr><tr><td>33</td></tr><tr><td>34</td></tr><tr><td>35</td></tr><tr><td>36</td></tr><tr><td>37</td></tr><tr><td>38</td></tr><tr><td>39</td></tr><tr><td>40</td></tr><tr><td>41</td></tr></tbody></table>

<table><thead><tr><th>- Chức năng kết nối Sever</th></tr></thead><tbody><tr><td>+ Storage (Serve, Media)</td></tr><tr><td>+ MWM (Modality Worklist Management)</td></tr><tr><td>+ MPPS (Modality Performed Procedure Step)</td></tr><tr><td>- Chức năng lưu trữ (Lưu trữ, truy vấn/truy xuất)</td></tr><tr><td>- Chức năng in</td></tr><tr><td>2. Màn hình hiển thị hình ảnh siêu âm</td></tr><tr><td>Màn hình LCD 21.5 inch</td></tr><tr><td>Độ phân giải 1920 x 1080 (Full HD) pixel</td></tr><tr><td>Góc nhìn: 178º</td></tr><tr><td>Có thể nâng lên, hạ xuống, xoay nghiêng các hướng</td></tr><tr><td>Thời gian phản hồi (ms): 14 (typ)</td></tr><tr><td>Độ tương phản: 1000:1 (typ.)</td></tr><tr><td>Độ sáng (cd / m2): 300 (typ.)</td></tr><tr><td>3. Màn hình điều khiển</td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>43</th></tr></thead><tbody><tr><td>44</td></tr><tr><td>45</td></tr><tr><td>46</td></tr><tr><td>47</td></tr><tr><td>48</td></tr><tr><td>49</td></tr><tr><td>50</td></tr><tr><td>51</td></tr><tr><td>52</td></tr><tr><td>53</td></tr><tr><td>54</td></tr></tbody></table>

<table><thead><tr><th>Độ phân giải 1280 x 800 pixel</th></tr></thead><tbody><tr><td>4. Cài đặt chế độ thăm khám (Application Preset): 20 chế độ ứng dụng</td></tr><tr><td>5. Chế độ hoạt động</td></tr><tr><td>Chế độ siêu âm 2D (B Mode)</td></tr><tr><td>Chế độ siêu âm M (M-Mode)</td></tr><tr><td>Chế độ siêu âm Doppler</td></tr><tr><td>Chế độ siêu âm Doppler màu:</td></tr><tr><td>- Chế độ siêu âm Doppler màu 2D</td></tr><tr><td>- Chế độ siêu âm Doppler màu M (MDF Mode)</td></tr><tr><td>Phần mềm Elastography (Linear /Convex):</td></tr><tr><td>(USEL-AA551A hoặc USEL- AA550A)</td></tr><tr><td>+ Độ cứng của các mô có thể được hình dung dựa trên những thay đổi của vận
tốc do nén và giải nén vật lý ở vùng mục tiêu</td></tr></tbody></table>

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>56</th></tr></thead><tbody><tr><td>57</td></tr><tr><td>58</td></tr><tr><td>59</td></tr><tr><td>60</td></tr><tr><td>61</td></tr><tr><td>62</td></tr><tr><td>63</td></tr><tr><td>64</td></tr><tr><td>65</td></tr><tr><td>66</td></tr><tr><td>67</td></tr><tr><td>68</td></tr><tr><td>69</td></tr><tr><td>70</td></tr><tr><td>71</td></tr></tbody></table>

<table><thead><tr><th>6. Bộ nhớ Cine</th></tr></thead><tbody><tr><td>Dung lượng bộ nhớ: 960 MB</td></tr><tr><td>Chế độ thu nhận/ phát lại:</td></tr><tr><td>+ Có thể phát lặp lại</td></tr><tr><td>+ Có thể phát lại khung trước</td></tr><tr><td>+ Có thể phát lại cine ở chế độ Doppler hoặc M</td></tr><tr><td>+ Có thể ghi hình ảnh trực tiếp (Clip)</td></tr><tr><td>7. Chế độ 2D (2D Mode – B Mode)</td></tr><tr><td>Mật độ dòng quét:</td></tr><tr><td>+ Phụ thuộc vào từng loại đầu dò</td></tr><tr><td>+ Mật độ dòng quét có thể thay đổi được</td></tr><tr><td>Tốc độ khung hình siêu âm:</td></tr><tr><td>Tốc độ khung hình có thể điều chỉnh theo sự kết hợp:</td></tr><tr><td>+ Mật độ dòng</td></tr><tr><td>+ Bộ xử lý tín hiệu song song</td></tr><tr><td>Góc quét và Chiều rộng quét:</td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>73</th></tr></thead><tbody><tr><td>74</td></tr><tr><td>75</td></tr><tr><td>76</td></tr><tr><td>77</td></tr><tr><td>78</td></tr><tr><td>79</td></tr><tr><td>80</td></tr><tr><td>81</td></tr><tr><td>82</td></tr><tr><td>83</td></tr><tr><td>84</td></tr><tr><td>85</td></tr></tbody></table>

<table><thead><tr><th>PAN/(EXPAND) thời gian thực:</th></tr></thead><tbody><tr><td>+ Phóng to/ thu nhỏ ảnh bằng bộ mã hóa</td></tr><tr><td>+ Có thể sử di chuyển đến phần mong muốn bằng cách sử dụng bi xoay</td></tr><tr><td>+ Tiêu điểm truyền được tối ưu hóa</td></tr><tr><td>+ Phạm vi được chỉ định trên hình ảnh có thể được phóng to</td></tr><tr><td>Tiêu điểm truyền:</td></tr><tr><td>Điều kiện truyền: 8 bước</td></tr><tr><td>Tần số truyền: Đa tần. Có thể chọn 3 tần số từ 13 loại tần số</td></tr><tr><td>Gain:</td></tr><tr><td>+ Điều chỉnh độ sáng ảnh chế độ 2D (có thể điều chỉnh ngay cả khi dừng hình)
+ Điều chỉnh độ sáng ảnh đồng thời cả chế độ 2D và M mode.</td></tr><tr><td>STC (Sensitivity Time Control):</td></tr></tbody></table>

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>87</th></tr></thead><tbody><tr><td>88</td></tr><tr><td>89</td></tr><tr><td>90</td></tr><tr><td>91</td></tr><tr><td>92</td></tr><tr><td>93</td></tr><tr><td>94</td></tr><tr><td>95</td></tr><tr><td>96</td></tr><tr><td>97</td></tr><tr><td>98</td></tr><tr><td>99</td></tr></tbody></table>

<table><thead><tr><th>+ Theo hướng bên: 6 mức trượt (chế độ 2D và M Mode).</th></tr></thead><tbody><tr><td>Đầu ra âm thanh (Ascoutic Output): có thể điều chỉnh lên 100%</td></tr><tr><td>Điều chỉnh chất lượng hình ảnh 2D:</td></tr><tr><td>+ Dải động (có thể điều chỉnh ngay cả khi dừng hình)</td></tr><tr><td>+ Làm mịn hình ảnh theo thời gian</td></tr><tr><td>+ Gamma (có thể điều chỉnh ngay cả khi dừng hình)</td></tr><tr><td>+ Tốc độ khung hình</td></tr><tr><td>+ ApliPure</td></tr><tr><td>+ Precision</td></tr><tr><td>Bản đồ màu 2D:</td></tr><tr><td>+ Có thể thay đổi mẫu màu xám và thay đổi màu ảo cho hình ảnh 2D</td></tr><tr><td>+ Có thể điều chỉnh ngay cả khi dừng hình</td></tr><tr><td>Quick Scan 2D: Chức năng QuickScan tự động điều chỉnh Gain và STC</td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>101</th></tr></thead><tbody><tr><td>102</td></tr><tr><td>103</td></tr><tr><td>104</td></tr><tr><td>105</td></tr><tr><td>106</td></tr><tr><td>107</td></tr><tr><td>108</td></tr><tr><td>109</td></tr><tr><td>110</td></tr><tr><td>111</td></tr></tbody></table>

<table><thead><tr><th>+ Phương pháp Pulse Subtraction</th></tr></thead><tbody><tr><td>+ Phương pháp lọc</td></tr><tr><td>+ Phương pháp chuyên biệt</td></tr><tr><td>Định hướng hiển thị: Hình ảnh hiển thị có thể được điều chỉnh đảo chiều (Trái –
Phải, Lên – Xuống)</td></tr><tr><td>Kích thước hình ảnh: có thể thay đổi giữa 2 chế độ Lớn và Nhỏ</td></tr><tr><td>Chức năng ApliPure</td></tr><tr><td>+ Chức năng này làm giảm nhiễu nền và nhiễu hạt trên ảnh 2D</td></tr><tr><td>+ Chức năng ApliPure Plus (+): Chức năng này có thể hiển thị ranh giới giữa
các mô rõ ràng hơn, giảm nhiễu đốm và ảnh giả bóng lưng âm.</td></tr><tr><td>Chức năng Precision Imaging</td></tr><tr><td>Precision +:</td></tr><tr><td>+ Các cấu trúc trong hình ảnh chế độ 2D có thể được hiển thị rõ ràng hơn và
nền có thể được hiển thị mịn hơn</td></tr></tbody></table>

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>113</th></tr></thead><tbody><tr><td>114</td></tr><tr><td>115</td></tr><tr><td>116</td></tr><tr><td>117</td></tr><tr><td>118</td></tr><tr><td>119</td></tr><tr><td>120</td></tr><tr><td>121</td></tr><tr><td>122</td></tr><tr><td>123</td></tr><tr><td>124</td></tr></tbody></table>

<table><thead><tr><th>+ Tối ưu hóa mô cụ thể: Có thể thực hiện lấy tiêu điểm trước</th></tr></thead><tbody><tr><td>+ Có thể thực hiện lấy tiêu điểm tự động</td></tr><tr><td>Chức năng BEAM</td></tr><tr><td>+ Tăng cường hình ảnh của kim sinh thiết trong siêu âm</td></tr><tr><td>+ Có thể điều chỉnh được mức độ tăng cường</td></tr><tr><td>8. Chế độ siêu âm M (M Mode)</td></tr><tr><td>Tần số truyền M: Đa tần (tối đa 5 mức điều chỉnh)</td></tr><tr><td>Tốc độ quét: Tốc độ quét có thể thay đổi ngay cả khi dừng hình</td></tr><tr><td>M Gain: Có thể điều chỉnh hình ảnh M Gain lên hình ảnh 2D.</td></tr><tr><td>Các tham số điều chỉnh hình ảnh M:</td></tr><tr><td>+ Dải động (có thể điều chỉnh ngay cả khi dừng hình)</td></tr></tbody></table>

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>126</th></tr></thead><tbody><tr><td>127</td></tr><tr><td>128</td></tr><tr><td>129</td></tr><tr><td>130</td></tr><tr><td>131</td></tr><tr><td>132</td></tr><tr><td>133</td></tr><tr><td>134</td></tr><tr><td>135</td></tr><tr><td>136</td></tr><tr><td>137</td></tr><tr><td>138</td></tr><tr><td>139</td></tr></tbody></table>

<table><thead><tr><th>+ M gamma (có thể điều chỉnh ngay cả khi dừng hình)</th></tr></thead><tbody><tr><td>Bản đồ màu M: Có thể thay đổi màu ảo cho hình ảnh M ngay cả khi dừng hình
THI - Tần số hòa âm mô:</td></tr><tr><td>Chế độ 2D liên kết với chế độ THI, hình ảnh M có thể hiển thị trong chế độ THI
+ Phương pháp Pulse Subtraction</td></tr><tr><td>+ Phương pháp lọc</td></tr><tr><td>+ Phương pháp chuyên biệt</td></tr><tr><td>M Mark:</td></tr><tr><td>+ Con trỏ M có thể hiển thị trên hình ảnh 2D hoặc hình ảnh màu</td></tr><tr><td>+ Có thể điều chỉnh được vị trí con trỏ</td></tr><tr><td>Flex-M: Flex- M:</td></tr><tr><td>+ Bất kỳ mặt phẳng mong muốn nào cũng có thể được đặt trên hình ảnh chế độ
2D và hình ảnh chế độ M, mặt phẳng đã đặt có thể được tạo lại</td></tr><tr><td>9. Chế độ siêu âm Doppler</td></tr><tr><td>Chế độ Doppler:</td></tr></tbody></table>

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>141</th></tr></thead><tbody><tr><td>142</td></tr><tr><td>143</td></tr><tr><td>144</td></tr><tr><td>145</td></tr><tr><td>146</td></tr><tr><td>147</td></tr><tr><td>148</td></tr><tr><td>149</td></tr><tr><td>150</td></tr><tr><td>151</td></tr><tr><td>152</td></tr></tbody></table>

<table><thead><tr><th>+ Chế độ HPRF PWD (có thể được chuyển sang chế độ HPRF bằng cách đặt
trước)
+ CWD (có thể được chuyển sang chế độ HPRF bằng cách đặt trước)</th></tr></thead><tbody><tr><td>Tần số lặp xung:</td></tr><tr><td>+ Chế độ xung (PW): 0.3 kHz đến 52.1 kHz</td></tr><tr><td>+ Chế độ liên tục (CW): ≤ 1.4 kHz đến ≥ 52.1 kHz</td></tr><tr><td>Quét Doppler:</td></tr><tr><td>+ Chức năng quét kết hợp 2D, Doppler</td></tr><tr><td>+ Chỉ quét Doppler</td></tr><tr><td>Thể tích lấy mẫu Doppler: Cổng Doppler có thể thay đổi được (tối thiểu 0.3
mm)
Độ sâu lấy mẫu: 0 cm đến tối đa tùy thuộc vào đầu dò</td></tr><tr><td>Chế độ con trỏ Doppler: Hiển thị hình ảnh 2D với thể tích mẫu Doppler</td></tr><tr><td>Bộ lọc Doppler: Bộ lọc Doppler có thể thay đổi được</td></tr></tbody></table>

|<image_11>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>154</th></tr></thead><tbody><tr><td>155</td></tr><tr><td>156</td></tr><tr><td>157</td></tr><tr><td>158</td></tr><tr><td>159</td></tr><tr><td>160</td></tr><tr><td>161</td></tr><tr><td>162</td></tr><tr><td>163</td></tr><tr><td>164</td></tr></tbody></table>

<table><thead><tr><th>Quick Scan Doppler: Kích thước và độ rộng Doppler có thể được tự động điều
chỉnh
Bộ xử lí hình ảnh và phân tích tần số Doppler</th></tr></thead><tbody><tr><td>+ Phương pháp: FFT</td></tr><tr><td>+ Dữ liệu tối đa: 255</td></tr><tr><td>Chỉ định hướng phổ Doppler: Có thể hiển thị ngược phổ tốc độ</td></tr><tr><td>Đường nền màu C-Line (Zero Shift)</td></tr><tr><td>+ Đường nền của hình ảnh Doppler có thể điều chỉnh được</td></tr><tr><td>+ Đường nền có thể được điều chỉnh ngay cả khi dừng hình và những hình ảnh
trong bộ nhớ được hiển thị</td></tr><tr><td>Doppler Audio: âm thanh của dòng chảy (hướng lại gần hay ra xa đầu dò)
Bản đồ màu Doppler: Có thể cài đặt bảng chuyển đổi độ sáng và màu ảo cho
hình ảnh Doppler
Hiển thị Doppler scale</td></tr></tbody></table>

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>166</th></tr></thead><tbody><tr><td>167</td></tr><tr><td>168</td></tr><tr><td>169</td></tr><tr><td>170</td></tr><tr><td>171</td></tr><tr><td>172</td></tr><tr><td>173</td></tr><tr><td>174</td></tr><tr><td>175</td></tr></tbody></table>

<table><thead><tr><th>Tiêu điểm Doppler: Có thể tự động lấy tiêu điểm theo vị trí mẫu</th></tr></thead><tbody><tr><td>Doppler Angle Mark: Doppler Angle Mark được hiển thị để đo góc giữa hướng
của vận tốc và hướng của chùm siêu âm</td></tr><tr><td>Quét Doppler xiên:</td></tr><tr><td>+ Những đầu dò Linear chuyên biệt có thể quét xiên</td></tr><tr><td>+ Có khả năng tự động đảo ngược</td></tr><tr><td>Đa tần Doppler: có thể thay đổi tần số truyền trong chế độ Doppler xung PWD
Tốc độ quét và dải rộng - Dynamic Range Doppler:</td></tr><tr><td>+ Có thể điều chỉnh được tốc độ quét</td></tr><tr><td>+ Có thể điều chỉnh được độ rộng hiển thị Doppler</td></tr></tbody></table>

|<image_13>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>177</th></tr></thead><tbody><tr><td>178</td></tr><tr><td>179</td></tr><tr><td>180</td></tr><tr><td>181</td></tr><tr><td>182</td></tr><tr><td>183</td></tr><tr><td>184</td></tr><tr><td>185</td></tr><tr><td>186</td></tr><tr><td>187</td></tr><tr><td>188</td></tr><tr><td>189</td></tr></tbody></table>

<table><thead><tr><th>+ Thông số đo: Max, min, Mean, PI, RI và các thông số đo liên quan tùy theo
vùng thăm khám
10. Chế độ siêu âm Doppler màu</th></tr></thead><tbody><tr><td>10.1.Chế độ siêu âm Doppler màu</td></tr><tr><td>Chế độ hiển thị</td></tr><tr><td>- CDI - Ảnh siêu âm màu</td></tr><tr><td>+ Vận tốc dòng chảy</td></tr><tr><td>+ Vận tốc/Sự biến thiên dòng chảy</td></tr><tr><td>+ Năng lượng</td></tr><tr><td>- TDI – Doppler mô</td></tr><tr><td>- Có thể hiển thị chế độ siêu âm năng lượng mạch máu - Power Angio Doppler
Chế độ TwinView: Hiển thị đồng thời hai màn hình với chế độ 2D</td></tr><tr><td>Chế độ ADF (Dynamic Flow): Hiển thị hướng</td></tr></tbody></table>

|<image_14>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>191</th></tr></thead><tbody><tr><td>192</td></tr><tr><td>193</td></tr><tr><td>194</td></tr><tr><td>195</td></tr><tr><td>196</td></tr><tr><td>197</td></tr><tr><td>198</td></tr><tr><td>199</td></tr><tr><td>200</td></tr><tr><td>201</td></tr></tbody></table>

<table><thead><tr><th>- Mỗi chế độ Doppler màu có thể chọn bảng màu C- Map</th></tr></thead><tbody><tr><td>- Có thể điều chỉnh được ngay cả khi dừng hình</td></tr><tr><td>C Scale (điều chỉnh khoảng vận tốc): có thể</td></tr><tr><td>Làm mịn ảnh theo thời gian (Persistence): Có thể hiển thị kết quả xử lý tương
quan thời gian giữa hình ảnh trước đó và hình ảnh hiện tại</td></tr><tr><td>Đường nền màu C-Line:</td></tr><tr><td>- Đường nền của hình ảnh Doppler có thể được dịch chuyển</td></tr><tr><td>- Đường nền có thể được điều chỉnh ngay cả khi dừng hình và những hình ảnh
trong bộ nhớ được hiển thị</td></tr><tr><td>Hiển thị đảo ngược màu</td></tr><tr><td>- Màu sắc có thể được đảo ngược</td></tr><tr><td>- Có thể điều chỉnh được ngay cả khi dừng hình</td></tr><tr><td>Chế độ cân bằng Đen/ Trắng</td></tr></tbody></table>

|<image_15>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>203</th></tr></thead><tbody><tr><td>204</td></tr><tr><td>205</td></tr><tr><td>206</td></tr><tr><td>207</td></tr><tr><td>208</td></tr><tr><td>209</td></tr><tr><td>210</td></tr><tr><td>211</td></tr><tr><td>212</td></tr><tr><td>213</td></tr><tr><td>214</td></tr><tr><td>215</td></tr><tr><td>216</td></tr></tbody></table>

<table><thead><tr><th>- Có thể điều chỉnh ngay cả khi dừng hình</th></tr></thead><tbody><tr><td>Có thể thay đổi được độ sáng của hình ảnh Doppler màu C-Gain</td></tr><tr><td>C-Multifrequency:</td></tr><tr><td>- Tần số truyền của hình ảnh Doppler có thể được điều chỉnh</td></tr><tr><td>Vùng quan tâm ROI</td></tr><tr><td>- Vị trí, kích thước, hướng cho các đường Doppler màu</td></tr><tr><td>Mật độ dòng màu</td></tr><tr><td>- Mật độ dòng màu có thể thay đổi được</td></tr><tr><td>Tiêu điểm phát màu: Tự động lấy theo vùng quan tâm ROI</td></tr><tr><td>Bộ lọc màu:</td></tr><tr><td>- Bộ lọc màu có thể thay đổi</td></tr><tr><td>- Bộ lọc FIO</td></tr><tr><td>Đường biến thiên màu: Có thể điều chỉnh được đường biến thiên màu</td></tr><tr><td>Color Quick Scan:</td></tr></tbody></table>

|<image_16>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>218</th></tr></thead><tbody><tr><td>219</td></tr><tr><td>220</td></tr><tr><td>221</td></tr><tr><td>222</td></tr><tr><td>223</td></tr><tr><td>224</td></tr><tr><td>225</td></tr></tbody></table>

<table><thead><tr><th>- Vị trí trường nhìn ROI và góc xiên có thể tự động điều chỉnh</th></tr></thead><tbody><tr><td>- Khi thể tích mẫu Doppler xung PW được hiển thị, vị trí cửa sổ Doppler, góc
nghiêng Doppler (angle steering) và góc Doppler được điều chỉnh tự động
10.2. Chế độ siêu âm Doppler màu M (MDF Mode)</td></tr><tr><td>Chế độ hiển thị:</td></tr><tr><td>- Chế độ MCDI: Hiển thị tốc độ,Hiển thi tốc độ/ biến thiên, Hiển thị năng lượng
- Chế độ M-TDI</td></tr><tr><td>Bản đồ màu M (CDI MAP): Bản đồ màu được lựa chọn tùy theo từng chế độ C-
Baseline
- Đường nền zero trên hình ảnh Doppler M có thể được dịch chuyển.</td></tr></tbody></table>

|<image_17>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>227</th></tr></thead><tbody><tr><td>228</td></tr><tr><td>229</td></tr><tr><td>230</td></tr><tr><td>231</td></tr><tr><td>232</td></tr><tr><td>233</td></tr><tr><td>234</td></tr><tr><td>235</td></tr><tr><td>236</td></tr><tr><td>237</td></tr><tr><td>238</td></tr></tbody></table>

<table><thead><tr><th>Hiển thị đảo ngược màu sắc</th></tr></thead><tbody><tr><td>- Có thể được đảo ngược</td></tr><tr><td>- Có thể điều chỉnh được khi hình ảnh đóng băng</td></tr><tr><td>Chế độ cân bằng Đen/ Trắng</td></tr><tr><td>- Bằng việc so sánh các hình ảnh Doppler màu M và hình ảnh đen trắng, có thể
đặt trọng số màu B/W.</td></tr><tr><td>- Có thể điều chỉnh khi hình ảnh đóng băng</td></tr><tr><td>C – Gain</td></tr><tr><td>Có thể thay đổi được độ sáng hiển thị của hình ảnh Doppler màu</td></tr><tr><td>Đa tần Doppler màu M</td></tr><tr><td>- Tần số truyền Doppler có thể được lựa chọn trong bộ thu hình ảnh Doppler
màu M
Bộ lọc Doppler màu M</td></tr><tr><td>- Bộ lọc màu có thể thay đổi</td></tr></tbody></table>

|<image_18>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>240</th></tr></thead><tbody><tr><td>241</td></tr><tr><td>242</td></tr><tr><td>243</td></tr><tr><td>244</td></tr><tr><td>245</td></tr><tr><td>246</td></tr><tr><td>247</td></tr><tr><td>248</td></tr><tr><td>249</td></tr><tr><td>250</td></tr><tr><td>251</td></tr><tr><td>252</td></tr><tr><td>253</td></tr></tbody></table>

<table><thead><tr><th>Dải tần số: 4.2 – 14.0 MHz</th></tr></thead><tbody><tr><td>Trường nhìn khoảng 58mm</td></tr><tr><td>Ứng dụng: siêu âm mạch máu, cơ xương khớp, bộ phận nhỏ</td></tr><tr><td>12. Đầu dò Convex bằng tần số rộng PVT-375BT (6C1)</td></tr><tr><td>Dải tần số: 1.5 - 6.0 MHz</td></tr><tr><td>Góc trường nhìn: 70o</td></tr><tr><td>Ứng dụng: siêu âm ổ bụng – tổng quát, sản phụ khoa</td></tr><tr><td>13. Đầu dò Sector bằng tần số rộng PST–30BT (5S2)</td></tr><tr><td>Dải tần số: 1.7 – 5.2 MHz</td></tr><tr><td>Góc trường nhìn: 90o</td></tr><tr><td>Ứng dụng: siêu âm tim người lớn, dopper xuyên sọ</td></tr><tr><td>14. Chức năng báo cáo và xuất hình ảnh</td></tr><tr><td>14.1. Chức năng báo cáo</td></tr><tr><td>- Các hàm bảng tính:</td></tr></tbody></table>

|<image_19>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>255</th></tr></thead><tbody><tr><td>256</td></tr><tr><td>257</td></tr><tr><td>258</td></tr><tr><td>259</td></tr><tr><td>260</td></tr><tr><td>261</td></tr><tr><td>262</td></tr><tr><td>263</td></tr><tr><td>264</td></tr><tr><td>265</td></tr><tr><td>266</td></tr><tr><td>267</td></tr></tbody></table>

<table><thead><tr><th>+ Hiển thị các giá trị sau có thể được đặt thành BẬT hoặc TẮT: Giá trị trung
bình, giá trị mới nhất, giá trị lớn nhất, giá trị nhỏ nhất</th></tr></thead><tbody><tr><td>+ Biểu đồ xu hướng có thể được hiển thị (bảng tính đo OB)</td></tr><tr><td>+ Có thể nhập nhận xét</td></tr><tr><td>- Chức năng báo cáo (On Board Report):</td></tr><tr><td>+ Báo cáo có thể được tạo trên hệ thống</td></tr><tr><td>+ Các báo cáo được tạo có thể được in</td></tr><tr><td>+ Các báo cáo được tạo có thể được xuất dưới dạng tệp PDF</td></tr><tr><td>+ Có thể chỉnh sửa mẫu báo cáo</td></tr><tr><td>14.2.Xuất hình ảnh</td></tr><tr><td>Hình tĩnh: BMP/JPEG</td></tr><tr><td>Hình động: WMV9</td></tr><tr><td>15. Thu Video</td></tr></tbody></table>

|<image_20>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>269</th></tr></thead><tbody><tr><td>270</td></tr><tr><td>271</td></tr><tr><td>272</td></tr><tr><td>273</td></tr><tr><td>274</td></tr><tr><td>275</td></tr><tr><td>276</td></tr><tr><td>277</td></tr><tr><td>278</td></tr><tr><td>279</td></tr></tbody></table>

<table><thead><tr><th>16. Chức năng bảo mật</th></tr></thead><tbody><tr><td>- Kiểm soát sự bảo mật</td></tr><tr><td>- Hệ thống này hỗ trợ một chức năng ghi lại quyền truy cập và nhật ký truy cập
của người dùng để bảo vệ thông tin cá nhân</td></tr><tr><td>+ Xác thực người dùng</td></tr><tr><td>+ Ghi chép đánh giá</td></tr><tr><td>+ Không nhận dạng (hình ảnh trực tiếp/ hình ảnh lưu trữ)</td></tr><tr><td>17. Kết nối mạng</td></tr><tr><td>Ethernet: 10BASE-T/100BASE-TX/Gigabit Ethernet</td></tr><tr><td>18. Cổng vào/cổng ra</td></tr><tr><td>Tín hiệu đầu vào/ra VCR: 02 Ngõ vào âm thanh, 02 Ngõ ra âm thanh, tín hiệu
DVI cho màn hình cảm ứng</td></tr><tr><td>Tín hiệu ngõ ra kết nối video bên ngoài: DVI</td></tr></tbody></table>

|<image_21>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>281</th></tr></thead><tbody><tr><td>282</td></tr><tr><td>283</td></tr><tr><td>284</td></tr><tr><td>285</td></tr><tr><td>286</td></tr><tr><td>287</td></tr><tr><td>288</td></tr><tr><td>289</td></tr><tr><td>290</td></tr><tr><td>291</td></tr><tr><td>292</td></tr><tr><td>293</td></tr><tr><td>294</td></tr><tr><td>295</td></tr><tr><td>296</td></tr></tbody></table>

<table><thead><tr><th>Cổng USB bên ngoài: 05 cổng</th></tr></thead><tbody><tr><td>Cổng kết nối Ethernet :01 cổng</td></tr><tr><td>Ổ cứng chuẩn SATA</td></tr><tr><td>- Để kết nối với HDD nội bộ: hỗ trợ 1 HDD</td></tr><tr><td>- Để kết nối với SDD: hỗ trợ 1 SDD</td></tr><tr><td>- Cho DVD: 1ch</td></tr><tr><td>19. Phân loại an toàn</td></tr><tr><td>Chuẩn an toàn điện: CLASS I – Loại BF chống sốc điện</td></tr><tr><td>Chống thấm theo tiêu chuẩn IPX0.</td></tr><tr><td>Riêng công tắc chân theo chuẩn IPX8 và đầu dò theo chuẩn IPX7</td></tr><tr><td>20. Thiết bị phụ trợ kèm theo mua tại Việt Nam</td></tr><tr><td>20.1 Bộ máy vi tính để bàn</td></tr><tr><td>Vi xử lý: Intel Core I5 trở lên, tốc độ 3.0 GHz</td></tr><tr><td>Ổ cứng 500 GB</td></tr><tr><td>Ram 4 GB</td></tr><tr><td>Màn hình màu LCD 18.5 inch</td></tr></tbody></table>

|<image_22>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>298</th><th></th><th>Hệ điều hành Windows có bản quyền</th></tr></thead><tbody><tr><td>299</td><td></td><td>20.2. Máy in laser màu</td></tr><tr><td>300</td><td></td><td>Khổ giấy: A4/A5</td></tr><tr><td>301</td><td></td><td>Cổng giao tiếp: USD/Lan/Wifi</td></tr><tr><td>302</td><td></td><td>Kết nối được với hệ điều hành Windows có bản quyền sử dụng</td></tr><tr><td>303</td><td></td><td>20.3. Bộ lưu điện online Santak, công suất 2KVA</td></tr><tr><td>304</td><td></td><td>Thời gian lưu điện khi chạy 100 tải: 9 Phút</td></tr><tr><td>305</td><td></td><td>Điện áp vào/ra: 220V/50Hz</td></tr><tr><td>306</td><td></td><td>Độ ồn 50dB tại khoảng cách 1m</td></tr><tr><td>307</td><td>IV. CÁC YÊU CẦU
KHÁC:</td><td>Bảo hành toàn hệ thống: 24 tháng kể từ ngày hoàn thành nghiệm thu đưa vào sử
dụng.
Bảo trì định kỳ theo tiêu chuẩn hãng sản xuất (tối thiểu 4 tháng/lần).</td></tr><tr><td>308</td><td></td><td></td></tr><tr><td>309</td><td></td><td>Cam kết hướng dẫn sử dụng, chuyển giao công nghệ.</td></tr><tr><td>310</td><td></td><td>Cung cấp tài liệu hướng dẫn sử dụng bằng tiếng Anh/Việt</td></tr></tbody></table>

|<image_23>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD634</th></tr></thead><tbody><tr><td></td><td>CẤU HÌNH VÀ THÔNG SỐ KỸ THUẬT CHI TIẾT CỦA MÁY SIÊU ÂM
DOPPLER MÀU 3 ĐẦU DÒ</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_24>|


