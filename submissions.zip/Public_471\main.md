# Public_471

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Yêu cầu kỹ thuật đối với tài liệu giấy và
hình ảnh in/ghi</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Yêu cầu kỹ thuật đối với tài liệu giấy và
hình ảnh in/ghi</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>Mật độ quang học tối thiểu</th><th></th></tr></thead><tbody><tr><td>Hình thức ghi</td><td>Màu</td><td></td><td></td></tr><tr><td></td><td></td><td>Điều 4.1, 4.4 và 4.7</td><td>Điều 4.3</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>Máy sao chụp, máy in laser</td><td>Đen</td><td>0,90</td><td>0,80</td></tr><tr><td>và các thiết bị in khác</td><td>Xanh da trời</td><td>0,65</td><td>0,55</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Màu khác</td><td>0,40</td><td>0,30</td></tr><tr><td>Các tài liệu ghi khác</td><td>Đen</td><td>0,50</td><td>0,40</td></tr><tr><td></td><td>Xanh da trời</td><td>0,40</td><td>0,35</td></tr><tr><td></td><td>Màu khác</td><td>0,35</td><td>0,30</td></tr><tr><td>CHÚ THÍCH 1: Lý do của các giá trị tối thiểu khác nhau với các hình thức ghi</td><td></td><td></td><td></td></tr><tr><td>khác nhau được nêu trong Phụ lục C.</td><td></td><td></td><td></td></tr><tr><td>CHÚ THÍCH 2: Sử dụng máy đo mật độ có sẵn trên thị trường với các bộ lọc mà</td><td></td><td></td><td></td></tr><tr><td>không phù hợp với ISO 5-3 được xử lý trong 6.1 và được nêu trong Phụ lục C</td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th></th><th>L*</th><th>a*</th><th>b*</th></tr></thead><tbody><tr><td>điều 4.3</td><td>± 8</td><td>± 5</td><td>± 5</td></tr><tr><td>điều 4.4 và 4.7</td><td>+ 5</td><td>± 3</td><td>± 3</td></tr><tr><td>CHÚ THÍCH: L*, a* và b* là những chênh lệch màu sắc.</td><td></td><td></td><td></td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Yêu cầu kỹ thuật đối với tài liệu giấy và
hình ảnh in/ghi</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_3>|

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Yêu cầu kỹ thuật đối với tài liệu giấy và
hình ảnh in/ghi</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Yêu cầu kỹ thuật đối với tài liệu giấy và
hình ảnh in/ghi</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_7>|


