# Public_672

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD672</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th>Ký hiệu</th><th>Ghi chú</th></tr></thead><tbody><tr><td>1</td><td>Tường nhà</td><td></td><td></td></tr><tr><td>2</td><td>Cửa ra vào 1 cánh</td><td></td><td></td></tr><tr><td>3</td><td>Cửa ra vào 2 cánh</td><td></td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD672</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th>Ký hiệu</th><th>Ghi chú</th></tr></thead><tbody><tr><td>4</td><td>Cửa gấp, cửa kéo</td><td></td><td></td></tr><tr><td>5</td><td>Cửa lùa 1 cánh, 2
cánh</td><td></td><td></td></tr><tr><td>6</td><td>Cửa sổ đơn không
mở</td><td></td><td></td></tr><tr><td>7</td><td>Cửa sổ kép không
mở</td><td></td><td></td></tr><tr><td>8</td><td>Cửa sổ đơn quay</td><td></td><td></td></tr><tr><td>9</td><td>Cầu thang 1 cánh</td><td></td><td></td></tr><tr><td>10</td><td>Cầu thang 2 cánh</td><td></td><td></td></tr></tbody></table>

|<image_5>|

|<image_6>|

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD672</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th>Ký hiệu</th><th>Ghi chú</th></tr></thead><tbody><tr><td>11</td><td>Cầu thang 3 cánh</td><td></td><td></td></tr><tr><td>12</td><td>Bếp</td><td></td><td></td></tr><tr><td>13</td><td>Bồn tắm</td><td></td><td></td></tr><tr><td>14</td><td>Sàn nước</td><td></td><td></td></tr><tr><td>15</td><td>Chậu rửa mặt</td><td></td><td></td></tr><tr><td>16</td><td>Hố xí</td><td></td><td></td></tr></tbody></table>

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD672</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th>Ký hiệu</th><th>Ghi chú</th></tr></thead><tbody><tr><td>1</td><td>Dòng điện 1 chiều</td><td></td><td></td></tr><tr><td>2</td><td>Dòng điện xoay chiều</td><td>AC; ~</td><td></td></tr><tr><td>3</td><td>Dây trung tính</td><td>N</td><td></td></tr><tr><td>4</td><td>Mạng điện 3 pha 4 dây</td><td>3~ +N</td><td></td></tr><tr><td>5</td><td>Dòng điện xoay chiều có
số pha m, tần số f và điện
áp U</td><td>m~, f, U</td><td></td></tr><tr><td>6</td><td>Các dây pha của mạng điện
3 pha</td><td>A/L1; B/L2; C/L3</td><td>Thường dùng màu:
A (vàng); B
(xanh); C (đỏ)</td></tr><tr><td>7</td><td>Hai dây dẫn không nối
nhau về điện</td><td></td><td></td></tr><tr><td>8</td><td>Hai dây dẫn nối nhau về
điện</td><td></td><td></td></tr><tr><td>9</td><td>Nối đất</td><td></td><td></td></tr><tr><td>10</td><td>Nối vỏ, nối mass</td><td></td><td></td></tr></tbody></table>

|<image_20>|

|<image_21>|

|<image_22>|

|<image_23>|

|<image_24>|

|<image_25>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD672</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên gọi</th><th>Ký hiệu</th><th></th></tr></thead><tbody><tr><td></td><td>Trên sơ đồ nguyên lí</td><td>Trên sơ đồ vị trí</td></tr><tr><td>Chuông điện</td><td></td><td></td></tr><tr><td>Quạt trần, quạt treo
tường</td><td></td><td></td></tr><tr><td>Đèn sợi đốt</td><td></td><td></td></tr><tr><td>Đèn huỳnh quang</td><td></td><td></td></tr><tr><td>Đèn nung sáng có
chụp</td><td></td><td></td></tr><tr><td>Lò điện trở</td><td></td><td></td></tr><tr><td>Lò hồ quang</td><td></td><td></td></tr><tr><td>Lò cảm ứng</td><td></td><td></td></tr><tr><td>Lò điện phân</td><td></td><td></td></tr></tbody></table>

|<image_26>|

|<image_27>|

|<image_28>|

|<image_29>|

|<image_30>|

|<image_31>|

|<image_32>|

|<image_33>|

|<image_34>|

|<image_35>|

|<image_36>|

|<image_37>|


