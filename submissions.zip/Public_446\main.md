# Public_446

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị</th><th>Thông số</th><th>Mức yêu
cầu</th><th>Tiêu chuẩn</th><th>Mô tả chi tiết</th><th>Ghi chú</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
TCVN 7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>942.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Router
Huawei
NE40E</th><th>Chống ồn ≥
35dB</th><th>Bắt buộc</th><th>ITU-T
G.826</th><th>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ITU-T G.826.</th><th>Phải kiểm
thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Firewall
PaloAlto</td><td>Hỗ trợ 2
nguồn điện</td><td>Bắt buộc</td><td>3GPP TS</td><td>Thiết bị Firewall
PaloAlto 5220 cần</td><td>Yêu cầu
cấu hình</td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>5220</th><th>AC/DC</th><th></th><th>29.060</th><th>đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</th><th>HA cluster</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>CPU ≥ 32
core Intel</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU</td><td>Có chứng
nhận</td></tr></tbody></table>

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Xeon</th><th></th><th></th><th>≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</th><th>CO/CQ</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ISO 27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>tiêu chuẩn 3GPP
TS 29.060.</th><th></th></tr></thead><tbody><tr><td>Headset
Jabra
Evolve 75</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Latency &lt; 20ms,
ở mức Bắt buộc,
theo tiêu chuẩn
TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ITU-T</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>G.826.</th><th></th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Switch
Cisco 9300</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Server Dell
R740</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Firewall
PaloAlto
5220</th><th>Throughput
≥ 40Gbps</th><th>Bắt buộc</th><th>ANSI/TIA-
942</th><th>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</th><th>Phải kiểm
thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto</td><td>Hỗ trợ 2
nguồn điện</td><td>Bắt buộc</td><td>TCVN</td><td>Thiết bị Firewall
PaloAlto 5220 cần</td><td>Hỗ trợ
SNMPv3</td></tr></tbody></table>

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>5220</th><th>AC/DC</th><th></th><th>7560</th><th>đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</th><th>để giám sát</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Router
Huawei
NE40E</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</th><th></th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ISO 27001.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Chống ồn ≥
35dB, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_11>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>27001.</th><th></th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Firewall
PaloAlto
5220</th><th>Latency &lt;
20ms</th><th>Bắt buộc</th><th>TCVN
7560</th><th>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</th><th>Hỗ trợ
SNMPv3
để giám sát</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage</td><td>Throughput</td><td>Khuyến</td><td>TCVN</td><td>Thiết bị Storage</td><td>Phải kiểm</td></tr></tbody></table>

|<image_13>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>NetApp
AFF</th><th>≥ 40Gbps</th><th>nghị</th><th>7560</th><th>NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</th><th>thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_14>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Firewall
PaloAlto
5220</th><th>Throughput
≥ 40Gbps</th><th>Bắt buộc</th><th>ITU-T
G.826</th><th>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</th><th>Hỗ trợ
SNMPv3
để giám sát</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_15>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Storage
NetApp
AFF</th><th>Throughput
≥ 40Gbps</th><th>Bắt buộc</th><th>3GPP TS
29.060</th><th>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</th><th>Tích hợp
với hệ
thống
OSS/NMS</th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_16>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Switch
Cisco 9300</th><th>Dung
lượng lưu
trữ ≥
100TB</th><th>Bắt buộc</th><th>ANSI/TIA-
942</th><th>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</th><th>Tích hợp
với hệ
thống
OSS/NMS</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_17>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Switch
Cisco 9300</th><th>Hỗ trợ 2
nguồn điện
AC/DC</th><th>Bắt buộc</th><th>3GPP TS
29.060</th><th>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</th><th>Tích hợp
với hệ
thống
OSS/NMS</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Headset</td><td>Uptime ≥</td><td>Khuyến</td><td>ANSI/TIA-</td><td>Thiết bị Headset</td><td>Có chứng</td></tr></tbody></table>

|<image_18>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Jabra
Evolve 75</th><th>99.999%</th><th>nghị</th><th>942</th><th>Jabra Evolve 75
cần đáp ứng thông
số Uptime ≥
99.999%, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</th><th>nhận
CO/CQ</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Storage</td><td>Uptime ≥</td><td>Khuyến</td><td>TCVN</td><td>Thiết bị Storage</td><td>Yêu cầu</td></tr></tbody></table>

|<image_19>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>NetApp
AFF</th><th>99.999%</th><th>nghị</th><th>7560</th><th>NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn TCVN 7560.</th><th>cấu hình
HA cluster</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_20>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ECC, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</th><th></th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_21>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>theo tiêu chuẩn
ITU-T G.826.</th><th></th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Storage
NetApp
AFF</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_22>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Router
Huawei
NE40E</th><th>Uptime ≥
99.999%</th><th>Khuyến
nghị</th><th>ISO 27001</th><th>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</th><th>Tích hợp
với hệ
thống
OSS/NMS</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell
R740</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_23>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Storage
NetApp
AFF</th><th>Hỗ trợ 2
nguồn điện
AC/DC</th><th>Bắt buộc</th><th>TCVN
7560</th><th>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</th><th>Tích hợp
với hệ
thống
OSS/NMS</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch</td><td>Chống ồn ≥</td><td>Bắt buộc</td><td>ANSI/TIA-</td><td>Thiết bị Switch
Cisco 9300 cần đáp</td><td>Tích hợp
với hệ</td></tr></tbody></table>

|<image_24>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Cisco 9300</th><th>35dB</th><th></th><th>942</th><th>ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</th><th>thống
OSS/NMS</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
TCVN 7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_25>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>buộc, theo tiêu
chuẩn ISO 27001.</th><th></th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Uptime ≥
99.999%, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_26>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>G.826.</th><th></th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_27>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>942.</th><th></th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
TCVN 7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_28>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Storage
NetApp
AFF</th><th>Latency &lt;
20ms</th><th>Bắt buộc</th><th>3GPP TS
29.060</th><th>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</th><th>Yêu cầu
cấu hình
HA cluster</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số</td><td>Hỗ trợ
SNMPv3</td></tr></tbody></table>

|<image_29>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</th><th>để giám sát</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số</td><td>Tích hợp
với hệ
thống</td></tr></tbody></table>

|<image_30>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>NE40E</th><th></th><th></th><th></th><th>Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</th><th>OSS/NMS</th></tr></thead><tbody><tr><td>Headset
Jabra
Evolve 75</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Chống ồn ≥ 35dB,</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_31>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Server Dell
R740</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn TCVN 7560.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_32>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>chuẩn ANSI/TIA-
942.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn 3GPP TS</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_33>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>29.060.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Dung lượng lưu
trữ ≥ 100TB, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_34>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>942.</th><th></th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_35>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Switch
Cisco 9300</th><th>CPU ≥ 32
core Intel
Xeon</th><th>Bắt buộc</th><th>ITU-T
G.826</th><th>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</th><th>Hỗ trợ
SNMPv3
để giám sát</th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch</td><td>RAM ≥
128GB</td><td>Khuyến</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp</td><td>Hỗ trợ
SNMPv3</td></tr></tbody></table>

|<image_36>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Cisco 9300</th><th>ECC</th><th>nghị</th><th></th><th>ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</th><th>để giám sát</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Dung lượng lưu
trữ ≥ 100TB, ở</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_37>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</th><th></th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
TCVN 7560.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_38>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>tiêu chuẩn ITU-T
G.826.</th><th></th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_39>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Storage
NetApp
AFF</th><th>Dung
lượng lưu
trữ ≥
100TB</th><th>Bắt buộc</th><th>ANSI/TIA-
942</th><th>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-
942.</th><th>Phải kiểm
thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei</td><td>Latency &lt;</td><td>Khuyến</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần</td><td>Có chứng
nhận</td></tr></tbody></table>

|<image_40>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>NE40E</th><th>20ms</th><th>nghị</th><th></th><th>đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</th><th>CO/CQ</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_41>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>mức Bắt buộc, theo
tiêu chuẩn ITU-T
G.826.</th><th></th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_42>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>7560.</th><th></th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_43>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Router
Huawei
NE40E</th><th>Dung
lượng lưu
trữ ≥
100TB</th><th>Bắt buộc</th><th>ISO 27001</th><th>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ISO 27001.</th><th>Hỗ trợ
SNMPv3
để giám sát</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei</td><td>Uptime ≥</td><td>Bắt buộc</td><td>ANSI/TIA-</td><td>Thiết bị Router
Huawei NE40E cần</td><td>Yêu cầu
cấu hình</td></tr></tbody></table>

|<image_44>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>NE40E</th><th>99.999%</th><th></th><th>942</th><th>đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</th><th>HA cluster</th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Storage
NetApp
AFF</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Storage
NetApp
AFF</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core</td><td>Phải kiểm
thử trong
môi trường</td></tr></tbody></table>

|<image_45>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</th><th>DataCenter</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_46>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>chuẩn 3GPP TS
29.060.</th><th></th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_47>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>tiêu chuẩn ISO
27001.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn TCVN
7560.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Latency &lt; 20ms,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Storage
NetApp
AFF</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_48>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>chuẩn 3GPP TS
29.060.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Storage
NetApp
AFF</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_49>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>G.826.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_50>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Firewall
PaloAlto
5220</th><th>RAM ≥
128GB
ECC</th><th>Khuyến
nghị</th><th>ITU-T
G.826</th><th>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</th><th>Có chứng
nhận
CO/CQ</th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell</td><td>Hỗ trợ 2
nguồn điện</td><td>Bắt buộc</td><td>3GPP TS</td><td>Thiết bị Server
Dell R740 cần đáp</td><td>Tích hợp
với hệ</td></tr></tbody></table>

|<image_51>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>R740</th><th>AC/DC</th><th></th><th>29.060</th><th>ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</th><th>thống
OSS/NMS</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Dung lượng lưu
trữ ≥ 100TB, ở
mức Khuyến nghị,
theo tiêu chuẩn
TCVN 7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_52>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_53>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>buộc, theo tiêu
chuẩn ISO 27001.</th><th></th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Switch
Cisco 9300</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn ISO</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_54>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>27001.</th><th></th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Server Dell
R740</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_55>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Storage
NetApp
AFF</th><th>Latency &lt;
20ms</th><th>Khuyến
nghị</th><th>3GPP TS
29.060</th><th>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
3GPP TS 29.060.</th><th>Có chứng
nhận
CO/CQ</th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei</td><td>CPU ≥ 32
core Intel</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số</td><td>Tích hợp
với hệ
thống</td></tr></tbody></table>

|<image_56>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>NE40E</th><th>Xeon</th><th></th><th></th><th>CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn TCVN 7560.</th><th>OSS/NMS</th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel</td><td>Phải kiểm
thử trong
môi trường</td></tr></tbody></table>

|<image_57>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</th><th>DataCenter</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Switch
Cisco 9300</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_58>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>theo tiêu chuẩn
ANSI/TIA-942.</th><th></th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_59>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ITU-T G.826.</th><th></th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Storage
NetApp
AFF</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Throughput
≥ 40Gbps</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_60>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Server Dell
R740</th><th>Throughput
≥ 40Gbps</th><th>Khuyến
nghị</th><th>3GPP TS
29.060</th><th>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</th><th>Có chứng
nhận
CO/CQ</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_61>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Firewall
PaloAlto
5220</th><th>Dung
lượng lưu
trữ ≥
100TB</th><th>Bắt buộc</th><th>ITU-T
G.826</th><th>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ITU-T
G.826.</th><th>Hỗ trợ
SNMPv3
để giám sát</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_62>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Switch
Cisco 9300</th><th>Latency &lt;
20ms</th><th>Bắt buộc</th><th>ANSI/TIA-
942</th><th>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</th><th>Hỗ trợ
SNMPv3
để giám sát</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ISO 27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Server Dell</td><td>CPU ≥ 32
core Intel</td><td>Khuyến</td><td>ISO 27001</td><td>Thiết bị Server
Dell R740 cần đáp</td><td>Có chứng
nhận</td></tr></tbody></table>

|<image_63>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>R740</th><th>Xeon</th><th>nghị</th><th></th><th>ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</th><th>CO/CQ</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Latency &lt; 20ms,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB</td><td>Phải kiểm
thử trong
môi trường</td></tr></tbody></table>

|<image_64>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</th><th>DataCenter</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>TCVN
7560</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Storage
NetApp
AFF</td><td>Latency &lt;
20ms</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_65>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>ANSI/TIA-942.</th><th></th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Chống ồn ≥
35dB, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Router
Huawei
NE40E</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn 3GPP TS</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr></tbody></table>

|<image_66>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>29.060.</th><th></th></tr></thead><tbody><tr><td>Headset
Jabra
Evolve 75</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell
R740</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP</td><td>Có chứng
nhận
CO/CQ</td></tr></tbody></table>

|<image_67>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>TS 29.060.</th><th></th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO
27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Bắt buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Server Dell
R740</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Latency &lt; 20ms, ở
mức Bắt buộc, theo
tiêu chuẩn 3GPP
TS 29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_68>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Headset
Jabra
Evolve 75</th><th>Throughput
≥ 40Gbps</th><th>Khuyến
nghị</th><th>TCVN
7560</th><th>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Throughput ≥
40Gbps, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</th><th>Phải kiểm
thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Server Dell
R740</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số Dung
lượng lưu trữ ≥
100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
TCVN 7560.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Router
Huawei
NE40E</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_69>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Switch
Cisco 9300</th><th>Hỗ trợ 2
nguồn điện
AC/DC</th><th>Khuyến
nghị</th><th>ITU-T
G.826</th><th>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</th><th>Tích hợp
với hệ
thống
OSS/NMS</th></tr></thead><tbody><tr><td>Router
Huawei
NE40E</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_70>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Server Dell
R740</th><th>Throughput
≥ 40Gbps</th><th>Bắt buộc</th><th>TCVN
7560</th><th>Thiết bị Server
Dell R740 cần đáp
ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn TCVN 7560.</th><th>Yêu cầu
cấu hình
HA cluster</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp
AFF</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_71>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Headset
Jabra
Evolve 75</th><th>RAM ≥
128GB
ECC</th><th>Bắt buộc</th><th>ISO 27001</th><th>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ISO 27001.</th><th>Phải kiểm
thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Headset
Jabra
Evolve 75</td><td>Uptime ≥
99.999%</td><td>Khuyến
nghị</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Uptime ≥
99.999%, ở mức
Khuyến nghị, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số CPU
≥ 32 core Intel
Xeon, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_72>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Router
Huawei
NE40E</th><th>Uptime ≥
99.999%</th><th>Khuyến
nghị</th><th>ISO 27001</th><th>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Khuyến
nghị, theo tiêu
chuẩn ISO 27001.</th><th>Phải kiểm
thử trong
môi trường
DataCenter</th></tr></thead><tbody><tr><td>Storage
NetApp
AFF</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức Bắt
buộc, theo tiêu
chuẩn ITU-T
G.826.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Latency &lt;
20ms</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Latency &lt; 20ms,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>RAM ≥
128GB
ECC</td><td>Khuyến
nghị</td><td>TCVN
7560</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
RAM ≥ 128GB
ECC, ở mức
Khuyến nghị, theo
tiêu chuẩn TCVN
7560.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Storage
NetApp</td><td>CPU ≥ 32
core Intel</td><td>Khuyến</td><td>3GPP TS</td><td>Thiết bị Storage
NetApp AFF cần</td><td>Yêu cầu
cấu hình</td></tr></tbody></table>

|<image_73>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>AFF</th><th>Xeon</th><th>nghị</th><th>29.060</th><th>đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn 3GPP
TS 29.060.</th><th>HA cluster</th></tr></thead><tbody><tr><td>Headset
Jabra
Evolve 75</td><td>Throughput
≥ 40Gbps</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Throughput ≥
40Gbps, ở mức Bắt
buộc, theo tiêu
chuẩn 3GPP TS
29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Storage
NetApp
AFF</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>3GPP TS
29.060</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Uptime ≥ 99.999%,
ở mức Bắt buộc,
theo tiêu chuẩn
3GPP TS 29.060.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ISO 27001.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số CPU ≥ 32 core</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_74>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</th><th></th></tr></thead><tbody><tr><td>Headset
Jabra
Evolve 75</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Bắt buộc, theo
tiêu chuẩn ISO
27001.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Server Dell
R740</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Server
Dell R740 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Yêu cầu
cấu hình
HA cluster</td></tr><tr><td>Switch
Cisco 9300</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>3GPP TS
29.060</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu</td><td>Yêu cầu
cấu hình
HA cluster</td></tr></tbody></table>

|<image_75>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>chuẩn 3GPP TS
29.060.</th><th></th></tr></thead><tbody><tr><td>Switch
Cisco 9300</td><td>RAM ≥
128GB
ECC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số RAM
≥ 128GB ECC, ở
mức Bắt buộc, theo
tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Router
Huawei
NE40E</td><td>Chống ồn ≥
35dB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Khuyến
nghị, theo tiêu
chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Storage
NetApp
AFF</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Storage
NetApp AFF cần
đáp ứng thông số
Hỗ trợ 2 nguồn
điện AC/DC, ở
mức Khuyến nghị,
theo tiêu chuẩn
ITU-T G.826.</td><td>Có chứng
nhận
CO/CQ</td></tr><tr><td>Headset
Jabra
Evolve 75</td><td>Uptime ≥
99.999%</td><td>Bắt buộc</td><td>ISO 27001</td><td>Thiết bị Headset
Jabra Evolve 75
cần đáp ứng thông
số Uptime ≥
99.999%, ở mức
Bắt buộc, theo tiêu</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr></tbody></table>

|<image_76>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>chuẩn ISO 27001.</th><th></th></tr></thead><tbody><tr><td>Firewall
PaloAlto
5220</td><td>Chống ồn ≥
35dB</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Chống ồn ≥ 35dB,
ở mức Bắt buộc,
theo tiêu chuẩn
ANSI/TIA-942.</td><td>Tích hợp
với hệ
thống
OSS/NMS</td></tr><tr><td>Switch
Cisco 9300</td><td>Hỗ trợ 2
nguồn điện
AC/DC</td><td>Bắt buộc</td><td>ANSI/TIA-
942</td><td>Thiết bị Switch
Cisco 9300 cần đáp
ứng thông số Hỗ
trợ 2 nguồn điện
AC/DC, ở mức Bắt
buộc, theo tiêu
chuẩn ANSI/TIA-
942.</td><td>Phải kiểm
thử trong
môi trường
DataCenter</td></tr><tr><td>Firewall
PaloAlto
5220</td><td>Dung
lượng lưu
trữ ≥
100TB</td><td>Khuyến
nghị</td><td>ITU-T
G.826</td><td>Thiết bị Firewall
PaloAlto 5220 cần
đáp ứng thông số
Dung lượng lưu trữ
≥ 100TB, ở mức
Khuyến nghị, theo
tiêu chuẩn ITU-T
G.826.</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr><tr><td>Router
Huawei
NE40E</td><td>CPU ≥ 32
core Intel
Xeon</td><td>Khuyến
nghị</td><td>ISO 27001</td><td>Thiết bị Router
Huawei NE40E cần
đáp ứng thông số
CPU ≥ 32 core
Intel Xeon, ở mức
Khuyến nghị, theo
tiêu chuẩn ISO</td><td>Hỗ trợ
SNMPv3
để giám sát</td></tr></tbody></table>

|<image_77>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD446</th></tr></thead><tbody><tr><td></td><td>THÔNG SỐ KỸ THUẬT HẠ TẦNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th></th><th>27001.</th><th></th></tr></thead><tbody></tbody></table>

|<image_78>|


