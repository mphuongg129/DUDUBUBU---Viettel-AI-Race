# Public_469

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_5>|


### VIETTEL AI RACE

### QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE

### CHƯA QUA SỬ DỤNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Loại phương tiện</th><th>Khoảng cách dừng tối đa</th><th></th></tr></thead><tbody><tr><td></td><td>Phanh chính</td><td>Phanh phụ</td></tr><tr><td>Máy cạp, xe tự đổ khung cứng và xe
tự đổ khung khớp nối có khối lượng
thử ≤32 000 kg và máy tự đổ nửa rơ
moóc có khối lượng bất kỳ(*)</td><td>𝒗𝟐
+𝟎,𝟏(𝟑𝟐−𝒗)
𝟒𝟒</td><td>𝒗𝟐
+𝟎,𝟏(𝟑𝟐−𝒗)
𝟑𝟎</td></tr><tr><td>Máy cạp, máy xúc lật khung cứng và
máy xúc lật khung khớp nối với khối
lượng thử &gt;32 000 kg</td><td>𝒗𝟐
𝟒𝟖−𝟐,𝟔𝒂</td><td>𝒗𝟐
𝟑𝟒−𝟐,𝟔𝒂</td></tr><tr><td>Xe lu các loại</td><td>𝒗𝟐
+𝟎,𝟐(𝟓+𝒗)
𝟏𝟓𝟎</td><td>𝒗𝟐
+𝟎,𝟒(𝟓+𝒗)
𝟕𝟓</td></tr><tr><td>Các Xe khác, bao gồm các xe kéo rơ
móc có tải</td><td>𝒗𝟐
+𝟎,𝟐(𝟓+𝒗)
𝟏𝟔𝟎</td><td>𝒗𝟐
+𝟎,𝟒(𝟓+𝒗)
𝟖𝟎</td></tr><tr><td>𝒗 là vận tốc thử (km/h)</td><td></td><td></td></tr><tr><td>𝑎 là độ dốc kiểm tra (8-10%)</td><td></td><td></td></tr><tr><td>Chú thích *: Xóa công thức 0,1(32-v) đối với các xe có tốc độ lớn hơn 32 km/h</td><td></td><td></td></tr></tbody></table>

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Loại phanh</th><th>Loại xe</th><th>Độ dốc
(%)</th></tr></thead><tbody><tr><td>Phanh chính</td><td>Xe tự đổ có khối lượng thử &gt; 32000 kg</td><td>20</td></tr><tr><td></td><td>Xe lu các loại</td><td>20</td></tr><tr><td></td><td>Xe tự đổ, sơ mi rơ moóc tự đổ được
kết hợp với xe kéo có khối lượng thử ≤
32000 kg</td><td>25</td></tr><tr><td></td><td>Tất cả các xe khác</td><td>25</td></tr><tr><td>Phanh đỗ</td><td>Xe tự đổ, xe cạp đất được kết hợp với
xe kéo</td><td>15</td></tr><tr><td></td><td>Xe lu các loại</td><td>20</td></tr><tr><td></td><td>Sơ mi rơ moóc tự đổ</td><td>20</td></tr><tr><td></td><td>Tất cả các xe khác</td><td>20</td></tr><tr><td>Chú ý:
1. Khi thử phanh cần ngắt hệ thống truyền lực, động cơ hoạt động ở
trạng thái
không tải hoặc dừng
2. Không áp dụng đối với các xe có hệ thống phanh truyền động thủy
tĩnh hoặc
tương tự.</td><td></td><td></td></tr></tbody></table>

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>QUY ĐỊNH KỸ THUẬT ĐỐI VỚI XE
CHƯA QUA SỬ DỤNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th></tr></thead><tbody><tr><td></td></tr></tbody></table>

|<image_9>|

|<image_10>|

|<image_11>|


