# Public_642

## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>VIII</td><td>Hệ thống cửa đi, cửa sổ, vách kính</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7,1</td><td>Công ty TNHH MTV Xây dựng và TM Cửa Việt (Địa chỉ: Số 04, phố Tinh Dầu, phường Vĩnh Trại, tp Lạng Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>CỬA NHÔM CAO CẤP HỆ FRAVI XINGFA ( * Nhôm sơn tĩnh điện màu : Nâu café ; ghi ; trắng* Độ dày nhôm hệ 1.0mm* Độ dày
kính 5mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>333</td><td>Cửa sổ 1 cánh</td><td>Mở quay ra ngoài, hệ
thanh sử dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(800x1400) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.142.156</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>395,000</td></tr><tr><td>334</td><td>Cửa sổ 1 cánh</td><td>Mở hất ra ngoài, hệ
thanh sử dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(800x1400) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.142.156</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>420,000</td></tr><tr><td>335</td><td>Cửa sổ 2 cánh</td><td>Mở trượt, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1200x1800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.163.872</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td></tr><tr><td>336</td><td>Cửa sổ 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1200x1800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.163.872</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>670,000</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>337</td><td>Cửa sổ 4 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(2400x1800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.117.809</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.340.000</td></tr><tr><td>338</td><td>Cửa sổ 4 cánh</td><td>Mở trượt, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(2400x1800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.117.809</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>500,000</td></tr><tr><td>339</td><td>Cửa đi 1 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(700x2000) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.089.602</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.160.000</td></tr><tr><td>340</td><td>Cửa đi 1 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(800x2200) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.922.401</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.160.000</td></tr><tr><td>341</td><td>Cửa đi 1 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(800x2700) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.835.580</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.160.000</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>342</td><td>Cửa đi 1 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(900x2200)mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.826.506</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.160.000</td></tr><tr><td>343</td><td>Cửa đi 1 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(900x2700)mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.754.675</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.160.000</td></tr><tr><td>344</td><td>Cửa đi 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1200x2200) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.136.710</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr><tr><td>345</td><td>Cửa đi 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1200x2700) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.823.949</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr><tr><td>346</td><td>Cửa đi 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1300x2200) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.053.720</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>347</td><td>Cửa đi 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1300x2700) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.764.629</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr><tr><td>348</td><td>Cửa đi 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1600x2200) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.867.005</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr><tr><td>349</td><td>Cửa đi 2 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1600x2700) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.631.161</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr><tr><td>350</td><td>Cửa đi 2 cánh</td><td>Mở trượt, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1600x2200) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.867.005</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr><tr><td>351</td><td>Cửa đi 2 cánh</td><td>Mở trượt, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(1600x2700) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.631.161</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.760.000</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>352</td><td>Cửa đi 4 cánh</td><td>Mở quay, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(2400x2800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.854.235</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.850.000</td></tr><tr><td>353</td><td>Cửa đi 4 cánh</td><td>Mở trượt, hệ thanh sử
dụng HXF</td><td>m2</td><td>TCVN
9366:2013</td><td>(2400x2800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.854.235</td></tr><tr><td></td><td></td><td>Phụ kiện đồng bộ</td><td>bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.850.000</td></tr><tr><td>354</td><td>Vách kính</td><td>Vách kính cố định</td><td>m2</td><td>TCVN
9366:2013</td><td>(2400x2800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>1.349.000</td></tr><tr><td>355</td><td>Vách kính</td><td>Vách mặt dựng mặt tiền</td><td>m2</td><td>TCVN
9366:2013</td><td>(2400x2800) mm</td><td>Công ty
TNHH MTV
Xây dựng và
TM Cửa Việt</td><td>VC đến
TPLS</td><td>Giá bán tại thành
phố Lạng Sơn đã
bao gồm chi phí
vận chuyển đến
chân công trình</td><td></td><td>2.033.000</td></tr><tr><td></td><td>- Sử dụng kính đơn dày 8mm cộng thêm 120.000 đồng/m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>- Sử dụng kính đơn dày 6,38mm cộng thêm 180.000 đồng/m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>- Cửa nhôm có chia ô trên cánh công thêm 200.00 đồng/m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8,1</td><td>Cửa thép (Công ty TNHH thiết bị Bảo Minh An)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Văn phòng đại diện tại Lạng Sơn: số 98, đường Bắc Sơn, thị trấn Hữu Lũng, huyện Hữu Lũng, tỉnh Lạng Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cửa đi khung thép sơn tĩnh điện sần ngoài trời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>356</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi Pano kính 5mm,
phụ
kiện đồng bộ, chưa bao
gồm khoá</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>KT theo yêu cầu</td><td>Công ty
TNHH
thiết bị Bảo
Minh An</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.825.000</td><td></td></tr><tr><td>*</td><td>Cửa sổ khung thép sơn tĩnh điện sần ngoài trời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>357</td><td>Vật liệu hoàn
thiện</td><td>Cửa sỏ kính trắng 5mm,
phụ
kiện đồng bộ, chưa bao
gồm khoá</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>KT theo yêu cầu</td><td>Công ty
TNHH
thiết bị Bảo
Minh An</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.795.000</td><td></td></tr><tr><td>358</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ kính 5mm mở
trượt,
phụ kiện đồng bộ, chưa
bao gồm khoá</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>KT theo yêu cầu</td><td>Công ty
TNHH
thiết bị Bảo
Minh An</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.880.000</td><td></td></tr><tr><td></td><td>- Kính cường lực 5mm thì đơn giá tăng them 120.000 đồng/m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8,2</td><td>Cửa kính khung nhôm (Công ty Cổ phần tập đoàn AUSDOOR)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Số 37 đường Lê văn Thiêm, phường Nhân Chính, quận Thanh Xuân, HN</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện (Topal Prima) - (Khung cửa đi(55x65,5)mm dày 2mm; Khung cửa sổ (55x48,5)mm dày 1,4mm; Khung cửa lùa (58,2x48)mm dày 1,6mm.
Gioăng EPDM và phụ kiện đồng bộ. Kính dán an toàn dày 8,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>359</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>360</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh.</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.900.000</td><td></td></tr><tr><td>361</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh.</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.900.000</td><td></td></tr><tr><td>362</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>363</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td>364</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td>365</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.000.000</td><td></td></tr><tr><td>366</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr><tr><td>367</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr><tr><td>368</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ gấp trượt 3 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td>369</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi gấp trượt 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung với mầu vân gỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>300,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng khung bao 11cm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>200,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng kính dán an toàn 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện (Topal Slima) - (Cửa đi, cửa sổ: Khung (47,5x52,2)mm dày 1,1mm; cửa lùa: Khung (47,5x87)mm dày 1,1mm. Gioăng EPDM và phụ kiện đồng
bộ. Kính dán an toàn dày 6,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>370</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>371</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.900.000</td><td></td></tr><tr><td>372</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.900.000</td><td></td></tr><tr><td>373</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr><tr><td>374</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td>375</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td>376</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.000.000</td><td></td></tr><tr><td>377</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>378</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr><tr><td>379</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ gấp trượt 3 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td>380</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi gấp trượt 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.100.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung với mầu vân gỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>300,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng khung bao 11cm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>200,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng kính dán an toàn 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện (Topal Slima) - (Cửa đi, cửa sổ: Khung (47,5x52,2)mm dày 1,1mm; cửa lùa: Khung (47,5x87)mm dày 1,1mm.
Gioăng EPDM và
phụ kiện đồng bộ. Kính dán an toàn dày 6,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>381</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.350.000</td><td></td></tr><tr><td>382</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr><tr><td>383</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>384</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>385</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.000.000</td><td></td></tr><tr><td>386</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.000.000</td><td></td></tr><tr><td>387</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.000.000</td><td></td></tr><tr><td>388</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>389</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.550.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>200,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng khung bao 10cm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng khóa đa điểm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>50,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng kính dán an toàn 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện (Topal XFAD) - (Cửa đi: Khung (54,8x66)mm dày 2mm; Cửa sổ: Khung (54,8x50)mm dày 1,4mm; cửa lùa:
Khung (54,8x76)mm dày 1,4mm. Gioăng EPDM và phụ kiện đồng bộ. Kính dán an toàn dày 6,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>390</td><td>Vật liệu hoàn
thiện</td><td>Vách kính hệ 55</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.489.000</td><td></td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>391</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.543.000</td><td></td></tr><tr><td>392</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.766.000</td><td></td></tr><tr><td>393</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.229.000</td><td></td></tr><tr><td>394</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.530.000</td><td></td></tr><tr><td>395</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.635.000</td><td></td></tr><tr><td>396</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.635.000</td><td></td></tr><tr><td>397</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.798.000</td><td></td></tr><tr><td>398</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.678.000</td><td></td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>399</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh lùa 93</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.815.000</td><td></td></tr><tr><td>400</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh lùa 93</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.815.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung với mầu vân gỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>300,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng kính dán an toàn 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng kính dán an toàn 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>Cửa nhôm sơn tĩnh điện (Topal XFEC) - (Cửa đi: Khung (54,8x66)mm dày 1,2mm; Cửa sổ: Khung (54,8x50)mm dày 1,2mm; cửa lùa:
Khung (54,8x76)mm dày 1,2mm. Gioăng EPDM và phụ kiện đồng bộ. Kính dán an toàn dày 6,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>401</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.732.000</td><td></td></tr><tr><td>402</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.854.000</td><td></td></tr><tr><td>403</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.991.000</td><td></td></tr><tr><td>404</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.038.000</td><td></td></tr><tr><td>405</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.783.000</td><td></td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>406</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.806.000</td><td></td></tr><tr><td>407</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.806.000</td><td></td></tr><tr><td>408</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.203.000</td><td></td></tr><tr><td>409</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.203.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>300,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung khi dùng kính dán an toàn 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện (Topal mặt dựng) - (khung Dày 2,5mm. Kính dán an toàn dày 8,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>410</td><td>Vật liệu hoàn
thiện</td><td>Vách mặt dựng liền cửa
sổ 1 cánh mở hất (dấu
đố cửa)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.272.000</td><td></td></tr><tr><td>411</td><td>Vật liệu hoàn
thiện</td><td>Vách mặt dựng liền cửa
sổ 1 cánh mở hất (lộ đố
cửa)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.291.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện (Topal thủy lực) - (Dày 2mm. Gioăng EPDM và phụ kiện đồng bộ. Kính hộp dày 19mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>412</td><td>Vật liệu hoàn
thiện</td><td>Cửa 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.700.000</td><td></td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>413</td><td>Vật liệu hoàn
thiện</td><td>Cửa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.500.000</td><td></td></tr><tr><td>414</td><td>Vật liệu hoàn
thiện</td><td>Cửa 2 cánh liền vách
(thanh nhôm vách dày
1,5mm)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty Cổ
phần
tập đoàn
AUSDOOR</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.250.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung mầu xám đá</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>150,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung mầu vân gỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>350,000</td><td></td></tr><tr><td>8,3</td><td>Cửa kính khung nhôm (Công ty TNHH Huihuang Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Lô E3, KCN Đình Trám, Việt Yên, Bắc Giang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - (Cửa đi: Khung (55x65,5)mm dày 2mm; cửa sổ: khung (55x48,5)mm dày 1,4mm; cửa lùa: khung (58,2x48)mm dày 1,6mm; kính trắng dày
8,38mm).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>415</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.300.000</td><td></td></tr><tr><td>416</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>417</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>418</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>419</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>420</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>421</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>422</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>423</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>424</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ gấp trượt 3 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td>425</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi gấp trượt 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>105,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung màu vân gỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>305,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung có thêm khung bao 11cm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>205,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung, dùng kính trắng 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>105,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - (Khung (47,5x52x2)mm dày 1,1mm; kính an toàn 6,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>426</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>427</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>428</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>429</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>430</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>431</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>432</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>433</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Mầu trắng, ghi,
cà phê</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.600.000</td><td></td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>434</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.600.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>205,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung có thêm khung bao 10cm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>105,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung dùng kính trắng 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>82,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung dùng khóa đa điểm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>55,000</td><td></td></tr><tr><td>*</td><td>Vách mặt dựng - (Hệ khung dày 2,5mm, kính an toàn 8,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>435</td><td>Vật liệu hoàn
thiện</td><td>Vách dựng liền cửa sổ, 1
cánh, mở hất (đố cửa
kín)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, ghi,
cà phê, xám đá</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr><tr><td>436</td><td>Vật liệu hoàn
thiện</td><td>Vách dựng liền cửa sổ, 1
cánh, mở hất (đố cửa
hở)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>120,000</td><td></td></tr><tr><td>*</td><td>Thanh nhôm định hình</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>437</td><td>Vật liệu hoàn
thiện</td><td>Thanh nhôm hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu nâu, trắng,
xám, ghi xám</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>107,000</td><td></td></tr><tr><td>438</td><td>Vật liệu hoàn
thiện</td><td>Thanh nhôm hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu vân gỗ</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>135,000</td><td></td></tr><tr><td>439</td><td>Vật liệu hoàn
thiện</td><td>Thanh nhôm hệ thủy lực</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu nâu, trắng,
xám, ghi xám</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,000</td><td></td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>440</td><td>Vật liệu hoàn
thiện</td><td>Thanh nhôm hệ thủy lực</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu vân gỗ</td><td>Công ty
TNHH
Huihuang Việt
Nam</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>136,000</td><td></td></tr><tr><td>8,4</td><td>Cửa kính khung nhôm (Công ty Cổ phần EUROHOUSE Việt Nam )</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Km2, đường 196, Yên Tập, xã Nhân Hòa, huyện Mỹ hào, Hưng Yên</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - Hệ vát cạnh. Màu trắng, xám, nâu (khung cửa đi, cửa sổ (54,6x55)mm dày 1,2mm; khung cửa lùa (54,6x42)mm dày 1mm;
kính trắng an toàn dày 6,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>441</td><td>Vật liệu hoàn
thiện</td><td>Vách kính hệ 55</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.500.000</td><td></td></tr><tr><td>442</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>443</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.700.000</td><td></td></tr><tr><td>444</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.600.000</td><td></td></tr><tr><td>445</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr><tr><td>446</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.800.000</td><td></td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>447</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.850.000</td><td></td></tr><tr><td>448</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>449</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Màu cà phê</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>50,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - (khung cửa đi, cửa sổ (54,68x50)mm dày 1mm; khung cửa lùa (54,6x42)mm dày 1mm; kính trắng an toàn dày 6,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>450</td><td>Vật liệu hoàn
thiện</td><td>Vách kính hệ 55</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.400.000</td><td></td></tr><tr><td>451</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.550.000</td><td></td></tr><tr><td>452</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.600.000</td><td></td></tr><tr><td>453</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.600.000</td><td></td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>454</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.700.000</td><td></td></tr><tr><td>455</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.700.000</td><td></td></tr><tr><td>456</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>457</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Hệ vát cạnh.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>458</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - Hệ XF (khung: cửa lùa (54,8x66)mm dày 2mm; cửa lùa (54,8x76)mm dày 1,4mm; cửa sổ (54,8x50)mm dày 1,4mm. Kính trắng an toàn dày
6,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>459</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>460</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.450.000</td><td></td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>461</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.450.000</td><td></td></tr><tr><td>462</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.250.000</td><td></td></tr><tr><td>463</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.550.000</td><td></td></tr><tr><td>464</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.600.000</td><td></td></tr><tr><td>465</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.600.000</td><td></td></tr><tr><td>466</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.350.000</td><td></td></tr><tr><td>467</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.350.000</td><td></td></tr><tr><td>468</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh lùa 93</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.450.000</td><td></td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>469</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh lùa 93</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.450.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>50,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Màu cà phê</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - Hệ XF mỏng (khung: cửa lùa (54,8x66)mm dày 1,4mm; cửa lùa (54,8x76)mm dày 1,2mm; cửa sổ (54,8x50)mm dày 1,2mm.
Kính trắng an toàn dày 6,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>470</td><td>Vật liệu hoàn
thiện</td><td>Vách kính</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.650.000</td><td></td></tr><tr><td>471</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.250.000</td><td></td></tr><tr><td>472</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.250.000</td><td></td></tr><tr><td>473</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.050.000</td><td></td></tr><tr><td>474</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.350.000</td><td></td></tr><tr><td>475</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.400.000</td><td></td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>476</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.400.000</td><td></td></tr><tr><td>477</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.150.000</td><td></td></tr><tr><td>478</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.150.000</td><td></td></tr><tr><td>479</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh lùa 93</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.250.000</td><td></td></tr><tr><td>480</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh lùa 93</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.250.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>50,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Màu cà phê</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - Hệ đa khoang cách âm, cách nhiệt (khung: cửa đi, cửa sổ (78,6x60)mm dày 1,4mm; cửa lùa (110x42)mm dày 1,5mm. Kính an toàn dày
6,38mm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>481</td><td>Vật liệu hoàn
thiện</td><td>Vách kính hệ 55</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.750.000</td><td></td></tr><tr><td>482</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay, mở hất
1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.650.000</td><td></td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>483</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.750.000</td><td></td></tr><tr><td>484</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.300.000</td><td></td></tr><tr><td>485</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.650.000</td><td></td></tr><tr><td>486</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.700.000</td><td></td></tr><tr><td>487</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở quay 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.700.000</td><td></td></tr><tr><td>488</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu.</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.400.000</td><td></td></tr><tr><td>489</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi mở lùa 4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.400.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung Dùng kính trắng 10,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện - Mặt dựng. Màu trắng, xám, nâu (khung dày 2-2,5mm; kính an toàn dày 8,38mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>490</td><td>Vật liệu hoàn
thiện</td><td>Vách mặt dựng liền cửa
sổ 1 cánh mở hất (đố
cửa ẩn)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu trắng, xám,
nâu</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.450.000</td><td></td></tr><tr><td>491</td><td>Vật liệu hoàn
thiện</td><td>Vách mặt dựng liền cửa
sổ 1 cánh mở hất (đố
cửa hở)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.550.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td>*</td><td>Cửa nhôm sơn tĩnh điện, hệ thủy lực - Màu nâu, xám (khung dày 2mm); kính hộp dày 19mm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>492</td><td>Vật liệu hoàn
thiện</td><td>Cửa 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu, xám</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.650.000</td><td></td></tr><tr><td>493</td><td>Vật liệu hoàn
thiện</td><td>Cửa 2 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Màu nâu, xám</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.450.000</td><td></td></tr><tr><td>494</td><td>Vật liệu hoàn
thiện</td><td>Cửa 2 cánh liền vách
(thanh nhôm vách dày
2mm)</td><td>m2</td><td>TCVN 9366-
2:2012</td><td></td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>3.550.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>100,000</td><td></td></tr><tr><td></td><td>- Giá bổ sung dùng màu vân gỗ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>250,000</td><td></td></tr><tr><td>*</td><td>Thanh nhôm định hình</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>495</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu nâu</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>106,400</td><td></td></tr><tr><td>496</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu trắng</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>107,400</td><td></td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>497</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu xám</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>107,400</td><td></td></tr><tr><td>498</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>122,400</td><td></td></tr><tr><td>499</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu nâu cà phê
Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>107,500</td><td></td></tr><tr><td>500</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu vân gỗ cẩm
lai</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>136,400</td><td></td></tr><tr><td>501</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ 55</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu xanh</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>105,400</td><td></td></tr><tr><td>502</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ nội thất</td><td>kg</td><td>TCVN
12513:2018</td><td>Vân gỗ</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>123,400</td><td></td></tr><tr><td>503</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ thủy lực</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu nâu cà phê
Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,900</td><td></td></tr><tr><td>504</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ thủy lực</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu xám ngọc
trai</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,900</td><td></td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>505</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ thủy lực</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ cẩm
lai</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>136,400</td><td></td></tr><tr><td>506</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ trượt
quay</td><td>kg</td><td>TCVN
12513:2018</td><td>Màu nâu cà phê
Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,900</td><td></td></tr><tr><td>507</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ trượt
quay</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ cẩm
lai</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>136,400</td><td></td></tr><tr><td>508</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ trượt
ECENTO</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu cà phê
Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,900</td><td></td></tr><tr><td>509</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ
ECENTO 70</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu cà phê
Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,900</td><td></td></tr><tr><td>510</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ
ECENTO 70</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ cẩm
lai</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>141,400</td><td></td></tr><tr><td>511</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ
ECENTO 70</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ cẩm
lai
+ Cà phê Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>128,900</td><td></td></tr><tr><td>512</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ chấn
song</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu cà phê
Metalic</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>116,900</td><td></td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>513</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ chấn
song</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ
Batelo</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>122,400</td><td></td></tr><tr><td>514</td><td>Vật liệu hoàn
thiện</td><td>Nhôm thanh hệ chấn
song</td><td>kg</td><td>TCVN
12513:2018</td><td>Mầu vân gỗ cẩm
lai</td><td>Công ty CP
EUROHOUSE
VN</td><td>Bao gồm
VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>136,400</td><td></td></tr><tr><td>8,5</td><td>Cửa kính khung nhôm (Công ty CP Tập đoàn SINGHAL )</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: CCN Hà Mãn – Trí Quả, P. Trí Quả, TX. Thuận Thành, Tỉnh Bắc Ninh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cửa nhôm tĩnh điện - Hệ 55 vát cạnh (kính dán an toàn 6.38mm trắng, gioăng 1mm ±5%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>515</td><td>Vật liệu hoàn
thiện</td><td>Vách kính cố định
(2x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.590.000</td></tr><tr><td>516</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh mở quay
(0,8x2,2)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.057.000</td></tr><tr><td>517</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở quay
(1,6x2,2)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.943.000</td></tr><tr><td>518</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 1 cánh mở hất
(0,8x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.174.000</td></tr></tbody></table>

|<image_28>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>519</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh mở hất
(1,2x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.252.000</td></tr><tr><td>520</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 2
(1,4x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.851.000</td></tr><tr><td>521</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ mở lùa 4 cánh
(2,4x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 vát cạnh</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.738.000</td></tr><tr><td>*</td><td>Cửa nhôm tĩnh điện - Hệ 55 XINHFA mặt cắt (kính dán an toàn 6.38mm trắng, gioăng 1mm ±5%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>522</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định (2x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 Xinhfa</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.592.000</td></tr><tr><td>523</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh mở quay
(1x,2,2)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 Xinhfa</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.644.000</td></tr></tbody></table>

|<image_29>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>524</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở quay
(1,6x2,2)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 Xinhfa</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.620.000</td></tr><tr><td>525</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ hất 1 cánh
(0,8x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 Xinhfa</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.630.000</td></tr><tr><td>526</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ hất 2 cánh
(1,4x1,6)m</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 55 Xinhfa</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.568.000</td></tr><tr><td>*</td><td>Cửa nhôm tĩnh điện - Hệ 56 sập liền (kính dán an toàn 6.38mm trắng, gioăng 1,4mm ±5%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>527</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định kích
thước: 2000 * 1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.635.000</td></tr><tr><td>528</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh mở quay
kích thước:
1000*2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.571.000</td></tr></tbody></table>

|<image_30>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>529</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh mở quay
liền
vách kích thước: 1000 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.529.000</td></tr><tr><td>530</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở quay
kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.630.000</td></tr><tr><td>531</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở quay
liền
vách kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.593.000</td></tr><tr><td>532</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở trượt
kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.275.000</td></tr><tr><td>533</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở trượt
liền
vách kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.481.000</td></tr><tr><td>534</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định kích
thước: 2000 * 1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.275.000</td></tr></tbody></table>

|<image_31>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>535</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 1 cánh mở hất
kích thước 800 *
1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.423.000</td></tr><tr><td>536</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 1 cánh mở hất
liền
vách kích thước 800 *
1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.699.000</td></tr><tr><td>537</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh mở quay
kích thước
1200*1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.837.000</td></tr><tr><td>538</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh mở quay
liền vách kích thước
1200*1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.851.000</td></tr><tr><td>539</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh mở trượt
kích thước
1200*1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.767.000</td></tr><tr><td>540</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 4 cánh mở trượt
kích thước
2400*1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.011.000</td></tr></tbody></table>

|<image_32>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>541</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh mở quay
kích thước: 1000 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.666.000</td></tr><tr><td>542</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh mở quay
liền vách kích thước:
1000*2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.624.000</td></tr><tr><td>543</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở quay
kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.725.000</td></tr><tr><td>544</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở quay
liền
vách kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.688.000</td></tr><tr><td>545</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở trượt
kích thước:
1600*2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.370.000</td></tr><tr><td>546</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh mở trượt
liền
vách kích thước: 1600 *
2200mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.576.000</td></tr></tbody></table>

|<image_33>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>547</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 1 cánh mở hất
kích thước 800 *
1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.528.000</td></tr><tr><td>548</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 1 cánh mở hất
liền
vách kích thước 800 *
1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.804.000</td></tr><tr><td>549</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh mở quay
kích thước
1200*1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.942.000</td></tr><tr><td>550</td><td>Vật liệu hoàn
thiện</td><td>Cửa sổ 2 cánh mở quay
liền vách kích thước
1200*1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.956.000</td></tr><tr><td>551</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định kích
thước: 2000 * 1600mm</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ 56 sập rời</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.635.000</td></tr><tr><td>*</td><td>Hệ mặt dựng - 65 ( kính dán an toàn 6.38mm trắng, gioăng 2.5mm ±5%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>552</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định hệ mặt
dựng</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ mặt dựng -
65</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>3.018.000</td></tr></tbody></table>

|<image_34>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>553</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định hệ mặt
dựng
nối đố liền cửa sổ 1 cánh
mở hất</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ mặt dựng -
65</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>3.149.000</td></tr><tr><td>554</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định hệ mặt
dựng
dấu đố liền cửa sổ 1
cánh mở lùa</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ mặt dựng -
65</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.833.000</td></tr><tr><td>*</td><td>Hệ mặt dựng - 25 (kính dán an toàn 6.38mm trắng, gioăng 2mm ±5%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>555</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định hệ mặt
dựng</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ mặt dựng -
H25</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.868.000</td></tr><tr><td>556</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định hệ mặt
dựng
nối đố liền cửa sổ 1 cánh
mở hất</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ mặt dựng -
H26</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.999.000</td></tr><tr><td>557</td><td>Vật liệu hoàn
thiện</td><td>Vách cố định hệ mặt
dựng
dấu đố liền cửa sổ 1
cánh mở lùa</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ mặt dựng -
H27</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.683.000</td></tr><tr><td>*</td><td>Hệ thuỷ lực (kính dán an toàn 6.38mm trắng, gioăng 2mm ±5%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_35>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>558</td><td>Vật liệu hoàn
thiện</td><td>Cửa thuỷ lực K200-
SC180</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ thuỷ lực</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>6.255.000</td></tr><tr><td>559</td><td>Vật liệu hoàn
thiện</td><td>Cửa thuỷ lực K200-
SC120</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ thuỷ lực</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>5.822.000</td></tr><tr><td>560</td><td>Vật liệu hoàn
thiện</td><td>Cửa thuỷ lực K200-
SC140</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ thuỷ lực</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>6.064.000</td></tr><tr><td>561</td><td>Vật liệu hoàn
thiện</td><td>Cửa thuỷ lực SK120-
SC180</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ thuỷ lực</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>5.250.000</td></tr><tr><td>562</td><td>Vật liệu hoàn
thiện</td><td>Cửa thuỷ lực SK120-
SC120</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ thuỷ lực</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>4.866.000</td></tr><tr><td>563</td><td>Vật liệu hoàn
thiện</td><td>Cửa thuỷ lực SK120-
SC140</td><td>m2</td><td>TCVN
12513:2018</td><td>Hệ thuỷ lực</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>4.878.000</td></tr></tbody></table>

|<image_36>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>*</td><td>Cửa cuốn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>564</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn chống bão
G91:
- Thân cửa sản xuất từ
hợp kim nhôm, sơn màu
nâu vàng, lỗ thoáng hình
kim tiền, Bản nan
90mm, giảm âm 2 chiều
lên xuống.</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>3.170.000</td></tr><tr><td>565</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn SE03:
- Thân cửa sản xuất từ
hợp kim nhôm, sơn màu
caphe, lỗ thoáng hình
ôvan, bản nan 50mm,
4chân, 2 vít, giảm âm 1
chiều lên, xuống.</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.680.000</td></tr><tr><td>566</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn G61:
- Sơn màu cà phê sáng,
giảm âm 2 chiều lên,
xuống.
- Day hộp U76
- Trục phi 113,5 mm dày
1,8 mm + puli nhựa.</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.350.000</td></tr><tr><td>567</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn S70 Plus:
- Thân cửa sản xuất từ
hợp kim nhôm, kết hợp
2 nan sơn màu cà phê
+vàng cát, lỗ thoáng kim
tiền, bản nan 90mm,
giảm âm 2 chiều lên,
xuống.</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.940.000</td></tr></tbody></table>

|<image_37>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>568</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn G88:
- Thân cửa sản xuất từ
hợp kim nhôm,kết hợp 2
nan, sơn màu xanh
mint, lỗ thoáng hình hoa
văn, bản nan 88mm,
giảm âm 2 chiều lên,
xuống.</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>2.650.000</td></tr><tr><td>569</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn G60 plus
- Sơn màu ghi sáng,
giảm âm 1 chiều lên,
xuống.
- Day hộp U76
- Trục phi 113,5mm dày
1,8mm + puli nhựa</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>1.500.000</td></tr><tr><td>570</td><td>Vật liệu hoàn
thiện</td><td>Nan cửa cuốn S70:
- Kết hợp 2 nan, sơn
màu xanh nâu + vàng
cát, giảm âm 1chiều lên,
xuống.
- Day hộp U76
- Trục phi 113,5mm dày
1,8 mm + puli nhựa.</td><td>m</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn (đã bao gồm
phụ kiện)</td><td></td><td>3.060.000</td></tr><tr><td>*</td><td>Phụ kiện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>571</td><td>Vật liệu hoàn
thiện</td><td>Lưu điện singdoor
900W</td><td>cái</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>2.650.000</td></tr><tr><td>572</td><td>Vật liệu hoàn
thiện</td><td>Lưu điện singdoor
1200W</td><td>cái</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>2.480.000</td></tr></tbody></table>

|<image_38>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>573</td><td>Vật liệu hoàn
thiện</td><td>Mô tơ Singdoor 300kg</td><td>cái</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>2.450.000</td></tr><tr><td>574</td><td>Vật liệu hoàn
thiện</td><td>Mô tơ Singdoor 500kg</td><td>cái</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>2.400.000</td></tr><tr><td>575</td><td>Vật liệu hoàn
thiện</td><td>Mô tơ Singdoor 800kg</td><td>cái</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>2.350.000</td></tr><tr><td>576</td><td>Vật liệu hoàn
thiện</td><td>Mô tơ Singdoor 1000kg</td><td>cái</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>1.970.000</td></tr><tr><td>577</td><td>Vật liệu hoàn
thiện</td><td>Sơn bảo hành 10 năm</td><td>bộ</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>1.840.000</td></tr><tr><td>578</td><td>Vật liệu hoàn
thiện</td><td>Sơn bảo hành 15 năm</td><td>bộ</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>6.650.000</td></tr><tr><td>579</td><td>Vật liệu hoàn
thiện</td><td>Sơn chống ăn mòn muối
biển</td><td>bộ</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>7.650.000</td></tr><tr><td>580</td><td>Vật liệu hoàn
thiện</td><td>Kính dán an toàn trắng
trong
8.38mm</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>9.250.000</td></tr></tbody></table>

|<image_39>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>581</td><td>Vật liệu hoàn
thiện</td><td>Kính dán an toàn trắng
trong
10.38mm</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>11.350.000</td></tr><tr><td>582</td><td>Vật liệu hoàn
thiện</td><td>Kính dán an toàn trắng
trong
12.38mm</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>7.850.000</td></tr><tr><td>583</td><td>Vật liệu hoàn
thiện</td><td>Kính dán an toàn phim
mờ
hoặc màu</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>8.850.000</td></tr><tr><td>584</td><td>Vật liệu hoàn
thiện</td><td>Kính dán an toàn phản
quang
8.38mm</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>4.285.000</td></tr><tr><td>585</td><td>Vật liệu hoàn
thiện</td><td>Kính dán an toàn phản
quang
10.38mm</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>5.600.000</td></tr><tr><td>586</td><td>Vật liệu hoàn
thiện</td><td>Kính cường lực 5 mm
trắng
trong</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>1.200.000</td></tr><tr><td>587</td><td>Vật liệu hoàn
thiện</td><td>Kính cường lực 8 mm
trắng
trong</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>1.500.000</td></tr><tr><td>588</td><td>Vật liệu hoàn
thiện</td><td>Kính cường lực 10 mm
trắng
trong</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>500,000</td></tr></tbody></table>

|<image_40>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>589</td><td>Vật liệu hoàn
thiện</td><td>Kính cường lực 12 mm
trắng
trong</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>1.800.000</td></tr><tr><td>590</td><td>Vật liệu hoàn
thiện</td><td>Kính hộp cường lực dày
24mm (6+12+6)</td><td>m2</td><td>TCVN
12513:2018</td><td>không có thông
tin</td><td>Công ty CP
Tập
đoàn
SINGHAL</td><td>Không</td><td>Giá bán tại kho
đại lý trên địa
bàn tỉnh Lạng
Sơn</td><td></td><td>650,000</td></tr><tr><td>8,6</td><td>Cửa thép vân gỗ (Công ty CP Dịch vụ và Thương mại Thống Nhất)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Cum CN Vôi-Yên Mỹ, số 1 Hoàng Hoa Thám, thị trấn Vôi, Lạng Giang, Bắc Giang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cửa thép vân gỗ (cửa đi). Phụ kiện gồm: bản lề, chốt; không bao gồm khoá, chân bậu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>591</td><td>Vật liệu hoàn
thiện</td><td>Cửa đặc 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung đơn
(130x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.470.000</td><td></td></tr><tr><td>592</td><td>Vật liệu hoàn
thiện</td><td>Cửa đặc 1 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung kép
(250x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.570.000</td><td></td></tr><tr><td>593</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính 1 cánh, kính
dày 6,38mm</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung đơn
(130x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.720.000</td><td></td></tr><tr><td>594</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính 1 cánh, kính
dày 6,38mm</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung kép
(250x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.940.000</td><td></td></tr><tr><td>595</td><td>Vật liệu hoàn
thiện</td><td>Cửa đặc 2-4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung đơn
(130x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.620.000</td><td></td></tr></tbody></table>

|<image_41>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>596</td><td>Vật liệu hoàn
thiện</td><td>Cửa đặc 2-4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung kép
(250x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.830.000</td><td></td></tr><tr><td>597</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính 2-4 cánh, kính
dày 6,38mm</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung đơn
(130x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.850.000</td><td></td></tr><tr><td>598</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính 2-4 cánh, kính
dày 6,38mm</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung kép
(250x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>3.180.000</td><td></td></tr><tr><td>599</td><td>Vật liệu hoàn
thiện</td><td>Cửa dập huỳnh 2-4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung đơn
(130x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.770.000</td><td></td></tr><tr><td>600</td><td>Vật liệu hoàn
thiện</td><td>Cửa dập huỳnh 2-4 cánh</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung kép
(250x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.990.000</td><td></td></tr><tr><td>601</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính dập huỳnh 2-4
cánh, kính dày 6,38mm</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung đơn
(130x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>3.020.000</td><td></td></tr><tr><td>602</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính dập huỳnh 2-4
cánh, kính dày 6,38mm</td><td>m2</td><td>TCVN 9366-
2:2012</td><td>Khung kép
(250x55x1,2)mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>3.230.000</td><td></td></tr><tr><td>*</td><td>Cửa thép SPEC. Phụ kiện gồm: bản lề, chốt và lắp đặt hoàn thiện; không bao gồm: khóa, chân bậu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>603</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh phẳng.
Màu nhám, trơn.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.810.000</td><td></td></tr></tbody></table>

|<image_42>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>592</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh phẳng.
Màu vân gỗ.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.910.000</td><td></td></tr><tr><td>593</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh
kính/phẳng. Màu nhám
trơn</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.910.000</td><td></td></tr><tr><td>594</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 1 cánh
kính/phẳng. Màu vân
gỗ.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.010.000</td><td></td></tr><tr><td>595</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh phẳng.
Màu nhám, trơn.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.870.000</td><td></td></tr><tr><td>596</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh phẳng.
Màu vân gỗ.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.970.000</td><td></td></tr><tr><td>597</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh
kính/phẳng. Màu nhám,
trơn.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.970.000</td><td></td></tr><tr><td>598</td><td>Vật liệu hoàn
thiện</td><td>Cửa đi 2 cánh
kính/phẳng. Màu vân
gỗ.</td><td>m2</td><td>KT.TC.02-
2024/TN</td><td>Khung đơn
130x55x0.45
mm</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>2.070.000</td><td></td></tr><tr><td>*</td><td>Phụ kiện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>599</td><td>Vật liệu hoàn
thiện</td><td>Khóa tay ngang Inox</td><td>bộ</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>580,000</td><td></td></tr></tbody></table>

|<image_43>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>600</td><td>Vật liệu hoàn
thiện</td><td>Khóa Huy Hoàng
EX5810</td><td>bộ</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>840,000</td><td></td></tr><tr><td>601</td><td>Vật liệu hoàn
thiện</td><td>Khóa Huy Hoàng
EX8510</td><td>bộ</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.030.000</td><td></td></tr><tr><td>602</td><td>Vật liệu hoàn
thiện</td><td>Khóa Việt Tiệp 04941</td><td>bộ</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.320.000</td><td></td></tr><tr><td>603</td><td>Vật liệu hoàn
thiện</td><td>Khóa vân tay, mã số, thẻ
từ cao cấp</td><td>chiếc</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>6.500.000</td><td></td></tr><tr><td>604</td><td>Vật liệu hoàn
thiện</td><td>Khóa đấm Engle</td><td>bộ</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>430,000</td><td></td></tr><tr><td>605</td><td>Vật liệu hoàn
thiện</td><td>Mắt kính (ống nhòm)
thân kim loại</td><td>bộ</td><td>TCVN
9383:2012</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>150,000</td><td></td></tr><tr><td>606</td><td>Vật liệu hoàn
thiện</td><td>Khóa Kospi</td><td></td><td>TCVN
5762:1993</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>580,000</td><td></td></tr><tr><td>607</td><td>Vật liệu hoàn
thiện</td><td>Khóa EX5810</td><td></td><td>TCCS28:
2010/HH</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>840,000</td><td></td></tr></tbody></table>

|<image_44>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>608</td><td>Vật liệu hoàn
thiện</td><td>Khóa EX8510</td><td></td><td>TCCS28:
2010/HH</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.030.000</td><td></td></tr><tr><td>609</td><td>Vật liệu hoàn
thiện</td><td>Khóa VT941</td><td></td><td>TCVN 5762-
1993</td><td>không có thông
tin</td><td>Công ty CP
DV và TM
Thống Nhất</td><td>Không</td><td>Giá tại kho bên
bán, đã bao gồm
lắp đặt hoàn
chỉnh</td><td>1.320.000</td><td></td></tr><tr><td>8,7</td><td>Cửa gỗ tự nhiên các loại</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Khung cửa
gỗ nhóm II</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>610</td><td>Vật liệu hoàn
thiện</td><td>Loại (6x12)cm</td><td>m</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>470,000</td><td></td></tr><tr><td>611</td><td>Vật liệu hoàn
thiện</td><td>Loại (6x24)cm</td><td>m</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>800,000</td><td></td></tr><tr><td>*</td><td>Khung cửa gỗ nhóm IV,V</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>612</td><td>Vật liệu hoàn
thiện</td><td>Loại (6x12)cm</td><td>m</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>303,000</td><td></td></tr><tr><td>613</td><td>Vật liệu hoàn
thiện</td><td>Loại (6x24)cm</td><td>m</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>470,000</td><td></td></tr><tr><td>*</td><td>Cánh cửa gỗ nhóm II ( dày 4 cm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>614</td><td>Vật liệu hoàn
thiện</td><td>Cửa panô gỗ nhóm II</td><td>m2</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.100.000</td><td></td></tr></tbody></table>

|<image_45>|


## VIETTEL AI RACE

## TD642

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD642</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: HỆ THỐNG CỬA ĐI, CỬA SỔ, VÁCH KÍNH,</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm vật
liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành phố
LS</td></tr><tr><td>615</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính gỗ nhóm II
(kính màu dày 5 mm )</td><td>m2</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.960.000</td><td></td></tr><tr><td>616</td><td>Vật liệu hoàn
thiện</td><td>Cửa panô chớp gỗ nhóm
II</td><td>m2</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>2.350.000</td><td></td></tr><tr><td>*</td><td>Cánh cửa gỗ nhóm IV,V ( dày 4 cm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>617</td><td>Vật liệu hoàn
thiện</td><td>Cửa panô gỗ nhóm IV,V</td><td>m2</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.275.000</td><td></td></tr><tr><td>618</td><td>Vật liệu hoàn
thiện</td><td>Cửa kính gỗ nhóm IV,V
(kính màu dày 5 mm)</td><td>m2</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.160.000</td><td></td></tr><tr><td>*</td><td>Nẹp khuôn, tay vịn lan can</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>619</td><td>Vật liệu hoàn
thiện</td><td>Nẹp khuôn</td><td>m</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td>Đã bao
gồm VC
Đã bao
gồm VC</td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>100,000</td><td></td></tr><tr><td>620</td><td>Vật liệu hoàn
thiện</td><td>Tay vịn lan can, cầu
thang</td><td>m</td><td>không có
thông tin</td><td>không có thông
tin</td><td>không có
thông tin</td><td></td><td>Giá bán tại chân
công trình trên
địa bàn tỉnh Lạng
Sơn</td><td>1.350.000</td><td></td></tr></tbody></table>

|<image_46>|


