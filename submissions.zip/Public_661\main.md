# Public_661

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD661</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT E-DRIVE VÀ MÀN
HÌNH CÀI ĐẶT CỬA VAN CỦA MÀN
HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Các thành phần trên màn hình</th><th>Mô tả</th></tr></thead><tbody></tbody></table>

|<image_1>|

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD661</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT E-DRIVE VÀ MÀN
HÌNH CÀI ĐẶT CỬA VAN CỦA MÀN
HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Manual Settings Limits (Giới hạn cài
đặt thủ công)
Đặt giới hạn tối đa có thể điều chỉnh khi
ở chế độ thủ công.
Home to Closed Position Only (Chỉ vị
trí ban đầu đến vị trí đóng)
Tấm di chuyển đến vị trí ban đầu, tìm cữ
dừng cố định và không kiểm tra hành
trình bằng cách chuyển đến cữ dừng cố
định khác.</th></tr></thead><tbody><tr><td></td><td>Auto Settings Limits (Giới hạn cài đặt
tự động)
Đặt giới hạn tối đa mà người vận hành có
thể điều chỉnh trên màn hình tổng quan.
Torque Warning and Alarm
Thresholds (Các ngưỡng cảnh báo và
báo động mômen)
Đặt ngưỡng (%) sẽ tạo cảnh báo và báo
động</td></tr><tr><td></td><td>Mechanical Settings Limits (Giới hạn
cài đặt cơ khí)
Gear Ratio Value: (Giá trị tỷ số truyền):
Đây là độ xoay tổng thể của động cơ trên
mỗi mm tuyến tính của hành trình.</td></tr></tbody></table>

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD661</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT E-DRIVE VÀ MÀN
HÌNH CÀI ĐẶT CỬA VAN CỦA MÀN
HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Max Stroke (Hành trình tối đa): Đây là
hành trình tối đa được đặt cho tấm E-
Drive. Giá trị này được đặt khi xuất
xưởng.</th></tr></thead><tbody><tr><td></td><td>Options (Tùy chọn)
Bạn có thể kích hoạt bước mở/đóng ở
giữa tại đây. Nếu được kích hoạt, các
trường để đặt vị trí và thời gian trễ sẽ hiển
thị trên màn hình Overview (Tổng quan).
Đóng/mở trơn tru
Tấm E-Drive chuyển từ bước này sang
bước khác mà không cần dừng.</td></tr><tr><td></td><td>Servo Movement Alarms (Báo động
chuyển động của servo)
Chuyển động phải đến đích trong khoảng
thời gian chỉ định. Nếu không đến được
vị trí này, hệ thống sẽ bị lỗi.
Enabled (Bật) – chọn để bật Cài đặt thời
gian chờ di chuyển.</td></tr><tr><td></td><td>Idle too long in Auto Mode? (Set
Timeout) (Chạy không tải quá lâu ở
Chế độ tự động? (Đặt thời gian chờ))
Thoát khỏi chế độ Auto (Tự động) sau
một khoảng thời gian không hoạt động đã
chỉ định.</td></tr></tbody></table>

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD661</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT E-DRIVE VÀ MÀN
HÌNH CÀI ĐẶT CỬA VAN CỦA MÀN
HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Các thành phần trên màn hình</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td>Các tab ở đầu màn hình
Các tab ở đầu màn hình sẽ đưa người
dùng đến phần cài đặt cho hai cửa van
cùng một lúc (ví dụ: Van 1 và 2; Van 3 và
4).
Người dùng có thể đặt thời gian và bộ
kích hoạt Mở và Đóng</td></tr><tr><td></td><td>Open Trigger (Bộ kích hoạt mở)
Các tùy chọn thả xuống:
Off (Tắt)
MoldClosing (Đóng khuôn)
Khuôn ZA6 đã đóng – tín hiệu
ZB3 Phun lùi 1 – tín hiệu (phun)
ZB4 Phun tiến 1 – tín hiệu (phun)
ZB5 Lõi 1 Vị trí 1 – tín hiệu (rô-bốt) ZB5
Lõi 1 Vị trí 2 – tín hiệu (rô-bốt) ZB5
Lõi 2 Vị trí 1 – tín hiệu (rô-bốt) ZB5
Lõi 2 Vị trí 2 – tín hiệu (rô-bốt)</td></tr><tr><td></td><td>Delay time open (Thời gian trễ mở)
Ngoài bộ kích hoạt mở, bạn có thể thêm
thời gian trễ tính theo giây để tinh chỉnh</td></tr></tbody></table>

|<image_11>|

|<image_12>|

|<image_13>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD661</th></tr></thead><tbody><tr><td></td><td>MÀN HÌNH CÀI ĐẶT E-DRIVE VÀ MÀN
HÌNH CÀI ĐẶT CỬA VAN CỦA MÀN
HÌNH CẢM ỨNG E-MULTI</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>chuyển động của van tương ứng với tín
hiệu của bộ kích hoạt.</th></tr></thead><tbody><tr><td></td><td>Close Trigger (Bộ kích hoạt đóng)
Các tùy chọn thả xuống: Sau khi giữ E-
Multi
Sau khi giảm áp E-Multi Sau khi dẻo hóa
E-Multi</td></tr><tr><td></td><td>Delay time close (Thời gian trễ đóng)
Ngoài bộ kích hoạt đóng, bạn có thể thêm
thời gian trễ tính theo giây để tinh chỉnh
chuyển động của van tương ứng với tín
hiệu của bộ kích hoạt.</td></tr><tr><td></td><td>Trạng thái hiện tại
Một hộp chỉ báo màu lục cho biết liệu
cửa van hiện đang mở hay đã đóng.</td></tr></tbody></table>

|<image_14>|

|<image_15>|

|<image_16>|


