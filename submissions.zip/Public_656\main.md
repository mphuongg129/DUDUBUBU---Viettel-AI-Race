# Public_656

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD656</th></tr></thead><tbody><tr><td></td><td>BẢNG ĐIỀU KHIỂN MÁY IN
BROTHER HL2240D</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Đèn LED</th><th>Tình trạng của máy</th></tr></thead><tbody><tr><td></td><td>SLEEP
Máy đang trong Sleep Mode: giống như trạng thái máy đã
tắt. Nhưng khi nhấn nút Go hay nhận được tín hiệu thì máy
sẽ tự động chuyển sang chế độ Ready.</td></tr><tr><td></td><td>DEEP SLEEP
Nếu máy không nhận được bất cứ tín hiệu nào khi đang ở
chế độ Sleep thì sau một khoảng thời gian nó sẽ tự động
chuyển sang chế độ Deep sleep. Nhấn nút Go hay truyền</td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD656</th></tr></thead><tbody><tr><td></td><td>BẢNG ĐIỀU KHIỂN MÁY IN
BROTHER HL2240D</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>lệnh in để máy trở lại chế độ Ready
Riêng máy HL-2270DW nếu mạng wireless được kích
hoạt thì máy sẽ không đi vào trạng thái Deep Sleep.</th></tr></thead><tbody><tr><td></td><td>READY
Máy sẵn sàng để in</td></tr><tr><td></td><td>PRINTING
Máy đang in</td></tr><tr><td></td><td>WARMING UP
Máy đang được khởi động</td></tr><tr><td></td><td>COOLING DOWN
Máy đang được làm mát, đợi 1 lát cho các phần bên trong
máy được làm mát lại</td></tr><tr><td></td><td>RECEIVING DATA
Máy hoặc là đang nhận dữ liệu từ máy tính hoặc là đang
xử lý dữ liệu</td></tr><tr><td></td><td>DATA REMAINING
Có dữ liệu in còn trong bộ nhớ. Nếu thấy đèn nháy lâu mà
chưa thấy máy in thì nhấn nút Go để in dữ liệu trong bộ
nhớ.</td></tr><tr><td></td><td>TONER LOW
Hộp mực cần được thay sớm. Mua mực mới để sẵn sàng
thay khi báo hiệu REPLACE TONER.
Đèn sẽ sáng trong 2 giây và tắt trong 3 giây</td></tr><tr><td></td><td>REPLACE TONER
Thay mực mới
CARTRIDGE ERROR
Trục trống từ có thể chưa được lắp chính xác, tháo ra và</td></tr></tbody></table>

|<image_4>|

|<image_5>|

|<image_6>|

|<image_7>|

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD656</th></tr></thead><tbody><tr><td></td><td>BẢNG ĐIỀU KHIỂN MÁY IN
BROTHER HL2240D</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>gắn lại vào máy một lần nữa
NO TONER
Mở mặt trước của máy ra và cho hộp mực vào</th></tr></thead><tbody><tr><td></td><td>REPLACE TONER
Máy sẽ tiếp tục in cho đến khi xuất hiện đèn báo TONER
ENDED</td></tr><tr><td></td><td>TONER ENDED
Thay thế hộp mực mới</td></tr><tr><td></td><td>DRUM END SOON
Trục trống từ cần được thay sớm.
Đèn sẽ sáng trong 2 giây và tắt trong 3 giây</td></tr><tr><td></td><td>REPLACE DRUM
Thay trống mới</td></tr><tr><td></td><td>NO PAPER T1
Đặt giấy vào khay rồi nhấn nút Go</td></tr><tr><td></td><td>MANUAL FEED
Đặt giấy vào khe cấp giấy thủ công</td></tr><tr><td></td><td>DRUM ERROR
Dây Cao áp cần được làm vệ sinh</td></tr><tr><td></td><td>DRUM STOP
Thay trục trống mới</td></tr></tbody></table>

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD656</th></tr></thead><tbody><tr><td></td><td>BẢNG ĐIỀU KHIỂN MÁY IN
BROTHER HL2240D</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>FRONT COVER OPEN
Nắp đậy mặt trước máy vẫn mở</th></tr></thead><tbody><tr><td></td><td>FUSER COVER OPEN
Đóng nắp khối sấy ở phía sau lưng máy</td></tr><tr><td></td><td>JAM TRAY 1/ JAM INSIDE/ JAM REAR/ JAM
DUPLEX
Lấy giấy bị kẹt ra và nếu nhấn nút Go nếu máy chưa tiến
hành in
MEMORY FULL
Bộ nhớ máy bị đầy và máy không thể in toàn bộ trang tài
liệu</td></tr><tr><td></td><td>PRINT OVER RUN
Hiện tượng này diễn ra và máy không thể in hết các trang
tài liệu</td></tr><tr><td></td><td>SIZE ERROR DX (HL-2240D/ HL-2250DN/ HL-
2270DW)
Để giấy đúng kích thước mà bạn muốn in hoặc cài lại khổ
giấy trên máy. Khổ giấy mà bạn có thể in hai mặt tự động
là A4, Letter, Legal và Folio.</td></tr><tr><td></td><td>DUPLEX DISABLED (HL-2240D/ HL-2250DN/ HL-
2270DW)
Đặt khay giấy để in hai mặt vào máy và đóng nắp lại</td></tr></tbody></table>

|<image_17>|

|<image_18>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD656</th></tr></thead><tbody><tr><td></td><td>BẢNG ĐIỀU KHIỂN MÁY IN
BROTHER HL2240D</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Đèn
LED</th><th>Hư bo
chính</th><th>Hư
khối
sấy</th><th>Hư
Laser</th><th>Hư Mô
tơ
chính</th><th>Hư bo
cao áp</th><th>Quạt bị
hư</th><th>Bo nguồn
bị lỗi</th></tr></thead><tbody><tr><td>Tone</td><td>tắt</td><td>vàng</td><td>tắt</td><td>vàng</td><td>vàng</td><td>tắt</td><td>vàng</td></tr><tr><td>Drum</td><td>tắt</td><td>tắt</td><td>vàng</td><td>tắt</td><td>vàng</td><td>vàng</td><td>vàng</td></tr><tr><td>Error</td><td>cam</td><td>tắt</td><td>tắt</td><td>cam</td><td>tắt</td><td>cam</td><td>cam</td></tr><tr><td>Ready</td><td>tắt</td><td>tắt</td><td>tắt</td><td>tắt</td><td>tắt</td><td>tắt</td><td>tắt</td></tr></tbody></table>

|<image_19>|

|<image_20>|


