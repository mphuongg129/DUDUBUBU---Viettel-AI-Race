# Public_652

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Nếu phím hiển thị chữ
Alt, thì dường như quý vị
có một bàn phím
Windows</th><th></th><th>Nếu phím hiển thị chữ
command, thì dường như
quý vị có một bàn phím
Apple</th></tr></thead><tbody><tr><td></td><td>Phím Windows thường
nằm dưới cùng bên trái</td><td></td><td>Phím Option thường nằm
dưới cùng bên trái</td></tr><tr><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Phím</th><th>Mô tả</th><th>Phím</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td>Mở màn hình Trợ giúp</td><td></td><td>Kiểm tra chính tả và ngữ
pháp của tài liệu trong
Microsoft Apps (ví dụ:
Word</td></tr><tr><td></td><td>Sửa tên tệp hoặc thư mục
đã chọn</td><td></td><td>Nhấn phím F8 ngay khi
laptop vừa khởi động để
khởi động laptop ở chế độ
Safe Mode.</td></tr><tr><td></td><td>Mở tính năng tìm kiếm cho
một ứng dụng đang hoạt
động tại thời điểm hiện tại</td><td></td><td>Làm mới tài liệu trong
Microsoft Word và gửi và
nhận email trong Outlook</td></tr><tr><td></td><td>Mở thanh địa chỉ trên
Windows Explorer và
Internet Explorer.</td><td></td><td>Kích hoạt thanh menu của
ứng dụng đang mở</td></tr><tr><td></td><td>Làm mới hoặc tải lại trang
hoặc cửa sổ tài liệu</td><td></td><td>Sử dụng phím F11 để mở
chế độ toàn màn hình trên
các trình duyệt phổ biến
(IE, Firefox, Google
Chrome...).</td></tr></tbody></table>

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Di chuyển con trỏ đến
thanh địa chỉ trong hầu hết
các trình duyệt Internet</th><th></th><th>Mở hộp thoại Lưu dưới
dạng trong Microsoft
Word.
Mở chức năng xem mã
nguồn website trên bất kỳ
trình duyệt nào.</th></tr></thead><tbody></tbody></table>

|<image_20>|

|<image_21>|

|<image_22>|

|<image_23>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Phím</th><th>Mô tả</th></tr></thead><tbody><tr><td>1</td><td></td><td>Phím Esc (viết tắt của từ escape) có tác dụng dừng
(stop) hoặc thoát (quit) một chương trình hoặc hoạt
động.</td></tr><tr><td></td><td></td><td>Phím Esc cũng giúp đóng các menu chuột phải và
có thể dùng để loại bỏ một số hộp bật lên</td></tr><tr><td>2</td><td></td><td>Phím Tab để di chuyển con trỏ đến trường tiếp
theo trên một biểu mẫu.</td></tr><tr><td></td><td></td><td>Hoặc cho phép bạn thụt lề văn bản khi gõ văn bản</td></tr><tr><td>3</td><td></td><td>Phím Caps Lock cho phép quý vị gõ các chữ cái IN
HOA (UPPERCASE).</td></tr><tr><td></td><td></td><td>Nhấn phím này một lần để bắt đầu sử dụng chữ viết
hoa và một lần nữa để quay lại chữ thường.</td></tr><tr><td>4</td><td></td><td>Di chuyển xuống xa hơn về phía tay trái chúng ta
tìm thấy phím Shift. Nếu nhấn cùng một lúc phím
Shift và một phím chữ cái, có thể biến chữ cái đó
thành một chữ in hoa.
Nếu nhấn phím Shift và một trong các phím số ở
trên cùng bàn phím, quý vị có thể gõ ký hiệu xuất
hiện bên cạnh số đó. Ví dụ
- Shift + 2 sẽ cho phép bạn gõ @
- Shift + 5 sẽ cho phép bạn gõ %.</td></tr></tbody></table>

|<image_24>|

|<image_25>|

|<image_26>|

|<image_27>|

|<image_28>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>5</th><th></th><th>Phím Delete (hay Del) cho phép xóa ký tự (chữ,
số, khoảng trống hoặc ký tự, tập tin) được chọn.
Ngoài ra, phím Delete còn có một số chức năng
khác như:
- Khởi động lại máy tính: Nhấn và giữ Delete khi
khởi động máy tính có thể truy cập vào BIOS hoặc
menu khởi động.
- Xóa dữ liệu khỏi ổ cứng: Một số chương trình cho
phép bạn sử dụng Delete để xóa dữ liệu khỏi ổ cứng
một cách an toàn.
- Thực hiện các phím tắt: Một số phím tắt yêu cầu
nhấn Delete kết hợp với các phím khác.</th></tr></thead><tbody><tr><td>6</td><td></td><td>Phím Backspace cho phép xóa ký tự (chữ, số,
khoảng trống hoặc ký tự cuối cùng ) ở bên trái của
đường thẳng đứng nhấp nháy, hay con trỏ, trên màn
hình máy tính.</td></tr><tr><td>7</td><td></td><td>Phím Enter hoặc Return để bắt đầu một dòng mới
khi bạn đang gõ một tài liệu hoặc bắt đầu tìm kiếm
khi duyệt trang mạng (trong trường hợp duyệt trang
web, bạn có thể sử dụng nó thay con chuột để nhấn
nút Tìm kiếm (Search) trên màn hình máy tính)</td></tr><tr><td>8</td><td></td><td>Các phím mũi tên (arrow) giúp di chuyển xung
quanh và điều hướng.
Bạn có thể sử dụng các phím mũi tên để di chuyển
con trỏ đường thẳng đứng nhấp nháy trên một tài</td></tr></tbody></table>

|<image_29>|

|<image_30>|

|<image_31>|

|<image_32>|

|<image_33>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>liệu khi gõ. Sử dụng các mũi tên để đi lên và xuống
giữa các dòng văn bản hoặc sang trái và phải giữa
các ký tự trong một câu.</th></tr></thead><tbody><tr><td>9</td><td></td><td>Ở dưới cùng bàn phím là Thanh dấu cách
(Spacebar). Phím này có thể không có bất cứ chữ
cái hoặc số nào trên đó hoặc có chữ “Space”, đây
là phím dài nhất trên bàn phím (vì cả hai ngón tay
cái đều phải đặt trên phím cách), thường ở dưới
cùng của bàn phím.
Thanh dấu cách cho phép tạo một khoảng trống ở
bên phải của con trỏ đường thẳng đứng nhấp nháy
trên màn hình khi bạn đang soạn thảo văn bản để
tạo khoảng trống giữa các từ.</td></tr></tbody></table>

|<image_34>|

|<image_35>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD652</th></tr></thead><tbody><tr><td></td><td>SỬ DỤNG BÀN PHÍM ĐÚNG CÁCH</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_36>|


