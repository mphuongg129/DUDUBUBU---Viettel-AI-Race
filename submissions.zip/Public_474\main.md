# Public_474

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Máy in 3D Elegoo Saturn 4 Ultra 4 Nhựa
Ultra 16K</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Nhựa</th><th>Độ dày lớp</th><th>Thời gian
phơi sáng
(giây)</th><th>Lớp cơ
sở/lớp
chuyển
tiếp</th><th>Tiếp xúc
lớp cơ sở</th><th>Tốc độ</th><th>Chế độ
chờ</th><th>Thời gian
nghỉ mỗi
bước (giây)</th></tr></thead><tbody><tr><td>Deep Blue</td><td>100 µm</td><td>n / a</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>50 µm</td><td>n / a</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Stone Coal
Black</td><td>100 µm</td><td>n / a</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>50 µm</td><td>6,5</td><td>2 / 15</td><td>40</td><td>NHANH
CHÓNG</td><td>Giờ nghỉ</td><td>2,0/0/0,5</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Máy in 3D Elegoo Saturn 4 Ultra 4 Nhựa
Ultra 16K</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Bio-Med
Clear</th><th>100 µm</th><th>n / a</th><th></th><th></th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td>50 µm</td><td>5,0</td><td>2 / 15</td><td>40</td><td>NHANH
CHÓNG</td><td>Giờ nghỉ</td><td>2,0/0/0,5</td></tr><tr><td>Tough-X</td><td>100 µm</td><td>15,0</td><td>2 / 15</td><td>40</td><td>Chậm</td><td>Giờ nghỉ</td><td>2,0/0/0,5</td></tr><tr><td></td><td>50 µm</td><td>n / a</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Flexible-X</td><td>100 µm</td><td>n / a</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>50 µm</td><td>12,0</td><td>2 / 15</td><td>50</td><td>Chậm</td><td>Giờ nghỉ</td><td>2,0/0/0,5</td></tr><tr><td>Elastomer-X</td><td>100 µm</td><td>16,0</td><td>2 / 20</td><td>60</td><td>Chậm</td><td>Giờ nghỉ</td><td>2,0/0/0,5</td></tr><tr><td></td><td>50 µm</td><td>n / a</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_2>|

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Máy in 3D Elegoo Saturn 4 Ultra 4 Nhựa
Ultra 16K</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_4>|

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Máy in 3D Elegoo Saturn 4 Ultra 4 Nhựa
Ultra 16K</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Máy in 3D Elegoo Saturn 4 Ultra 4 Nhựa
Ultra 16K</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_7>|


