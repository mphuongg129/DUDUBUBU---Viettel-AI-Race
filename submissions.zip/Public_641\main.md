# Public_641

## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>I</td><td>Đá xây
dựng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1,1</td><td>Mỏ đá Lùng Hang, phố Tân An, trị trấn Văn Quan</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>42</td><td>Đá xây
dựng</td><td>Đá hộc</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên ≥
(10x20x25) cm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>148,000</td><td></td></tr><tr><td>43</td><td>Đá xây
dựng</td><td>Đá &lt; 5 mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên &lt;
5 mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>158,000</td><td></td></tr><tr><td>44</td><td>Đá xây
dựng</td><td>Đá (5 x 10)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>158,000</td><td></td></tr><tr><td>45</td><td>Đá xây
dựng</td><td>Đá (10 x 20)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>158,000</td><td></td></tr><tr><td>46</td><td>Đá xây
dựng</td><td>Đá (20 x 40)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(20
&lt; và ≤ 40) mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>158,000</td><td></td></tr><tr><td>47</td><td>Đá xây
dựng</td><td>Đá (40 x 60)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(40&lt; và ≤ 60)mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>158,000</td><td></td></tr><tr><td>48</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại I
(Base)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,075 &lt; và ≤
40)mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>158,000</td><td></td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>49</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại II
(Subbase)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,1
&lt; và ≤ 25) mm</td><td>Công ty CP
khai thác đá
đông phong</td><td>Không</td><td>Giá bán tại mỏ, bao
gồm chi phí bốc xúc
lên xe</td><td>110,000</td><td></td></tr><tr><td>1,2</td><td>Công ty TNHH Đá Thượng Thành (địa chỉ: khu Trung tâm, thị trấn Đồng Mỏ, huyện Chi Lăng, tỉnh Lạng
Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>50</td><td>Đá xây
dựng</td><td>Đá hộc</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên ≥
(10x20x25) cm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>185,000</td><td></td></tr><tr><td>51</td><td>Đá xây
dựng</td><td></td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>173,000</td><td></td></tr><tr><td>52</td><td>Đá xây
dựng</td><td>Đá (10 x 20)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>205,000</td><td></td></tr><tr><td>53</td><td>Đá xây
dựng</td><td>Đá (20 x 40)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(20
&lt; và ≤ 40) mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>195,000</td><td></td></tr><tr><td>54</td><td>Đá xây
dựng</td><td>Đá (40 x 60)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(40&lt; và ≤ 60)mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>190,000</td><td></td></tr><tr><td>55</td><td>Đá xây
dựng</td><td>Đá mạt</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên &lt;
5 mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>173,000</td><td></td></tr><tr><td>56</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại I
(Base)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,075 &lt; và ≤
40)mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>188,000</td><td></td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>57</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại II
(Subbase)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,1
&lt; và ≤ 25) mm</td><td>Hợp tác xã
Hòa Bình</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>140,000</td><td></td></tr><tr><td>1,3</td><td>Mỏ đá Giang Sơn 1, huyện Cao Lộc (Địa chỉ: thôn Tềnh Chè, xã Hồng Phong, huyện Cao Lộc)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>58</td><td>Đá xây
dựng</td><td>Đá hộc</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên ≥
(10x20x25) cm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>240,000</td><td></td></tr><tr><td>59</td><td>Đá xây
dựng</td><td>Đ á (5x10)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>230,000</td><td></td></tr><tr><td>60</td><td>Đá xây
dựng</td><td>Đá (5x18)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 18) mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>230,000</td><td></td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>61</td><td>Đá xây
dựng</td><td>Đá (10 x 20)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>230,000</td><td></td></tr><tr><td>62</td><td>Đá xây
dựng</td><td>Đá (20 x 40)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(20
&lt; và ≤ 40) mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>230,000</td><td></td></tr><tr><td>63</td><td>Đá xây
dựng</td><td>Đá mạt</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên &lt;
5 mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>190,000</td><td></td></tr><tr><td>64</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại I
(Base)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,075 &lt; và ≤
40)mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>230,000</td><td></td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>65</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại II
(Subbase)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,1
&lt; và ≤ 25) mm</td><td>Công ty
TNHH MTV
Sản xuất và
Thương mại
Dịch
vụ Giang Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>165,000</td><td></td></tr><tr><td>1,4</td><td>Mỏ đá Hồng Phong I, huyện Cao Lộc (Địa chỉ: thôn Tềnh Chè, xã Hồng Phong, huyện Cao Lộc)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>66</td><td>Đá xây
dựng</td><td>Đá (5x10)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>220,000</td><td></td></tr><tr><td>67</td><td>Đá xây
dựng</td><td>Đá hộc</td><td>m3</td><td>QCVN
16:2023/BXD</td><td></td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>240,000</td><td></td></tr><tr><td>68</td><td>Đá xây
dựng</td><td>Đá (10 x 20)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>240,000</td><td></td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>69</td><td>Đá xây
dựng</td><td>Đá (20 x 40)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(20
&lt; và ≤ 40) mm</td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>240,000</td><td></td></tr><tr><td>70</td><td>Đá xây
dựng</td><td>Đá mạt</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên &lt;
5 mm</td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>210,000</td><td></td></tr><tr><td>71</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại I
(Base)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,075 &lt; và ≤
40)mm</td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>240,000</td><td></td></tr><tr><td>72</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại II
(Subbase)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,1
&lt; và ≤ 25) mm</td><td>Công ty
TNHH Xây
dựng và
Thương mại
tổng
hợp TNX</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>180,000</td><td></td></tr><tr><td>1,5</td><td>Mỏ đá Lùng Khứ, xã Hưng Vũ, huyện Bắc Sơn(Địa chỉ: thôn Nông Lục, xã Hưng Vũ, huyện Bắc Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>73</td><td>Đá xây
dựng</td><td>Đá hộc</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên ≥
(10x20x25) cm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>74</td><td>Đá xây
dựng</td><td>Bột đá</td><td>m4</td><td>QCVN
16:2023/BXD</td><td></td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>75</td><td>Đá xây
dựng</td><td>Đá (5x10)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>76</td><td>Đá xây
dựng</td><td>Đá (5x18)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 18) mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>77</td><td>Đá xây
dựng</td><td>Đá (10 x 20)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>78</td><td>Đá xây
dựng</td><td>Đá (20 x 40)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(20
&lt; và ≤ 40) mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>79</td><td>Đá xây
dựng</td><td>Đá (40 x 60)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(40&lt; và ≤ 60)mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>80</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại I
(Base)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,075 &lt; và ≤
40)mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>81</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại II
(Subbase)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,1
&lt; và ≤ 25) mm</td><td>Công ty
TNHH
MTV Sơn
Đức Bắc Sơn</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>154,454</td><td></td></tr><tr><td>1,6</td><td>Mỏ đá Hồng Phong IV, thị trấn Bình Gia, huyện Bình Gia</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>82</td><td>Đá xây
dựng</td><td>Đá (5x10)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>83</td><td>Đá xây
dựng</td><td>Đá (10 x 20)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>250,000</td><td></td></tr><tr><td>84</td><td>Đá xây
dựng</td><td>Đá (20 x 40)mm</td><td>m3</td><td>QCVN
16:2023/BXD</td><td>Kích thước viên
(20
&lt; và ≤ 40) mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>250,000</td><td></td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>85</td><td>Đá xây
dựng</td><td>Đá mạt ( Đá 0-5)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên &lt;
5 mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>200,000</td><td></td></tr><tr><td>86</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại I
(Base)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,075 &lt; và ≤
40)mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>250,000</td><td></td></tr><tr><td>87</td><td>Đá xây
dựng</td><td>Đá dăm cấp phối loại II
(Subbase)</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(0,1
&lt; và ≤ 25) mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>170,000</td><td></td></tr><tr><td>1,7</td><td>Mỏ đá Khau Đêm, xã Quan Sơn, huyện Chi Lăng, tỉnh Lạng
Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>88</td><td>Đá xây
dựng</td><td>Đá gốc Bazan &lt;5mm</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên &lt;
5 mm</td><td>Công ty
TNHH Kỹ
Nghệ Thái An</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>464,813</td><td></td></tr><tr><td>89</td><td>Đá xây
dựng</td><td>Đá gốc Bazan (5x10)mm</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty
TNHH Kỹ
Nghệ Thái An</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>464,813</td><td></td></tr><tr><td>90</td><td>Đá xây
dựng</td><td>Đá gốc Bazan (10x20)mm</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty
TNHH Kỹ
Nghệ Thái An</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>464,813</td><td></td></tr><tr><td>91</td><td>Đá xây
dựng</td><td>Đá BTXM (5x10)mm</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên (5
≤ và ≤ 10) mm</td><td>Công ty
TNHH Kỹ
Nghệ Thái An</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>464,813</td><td></td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>92</td><td>Đá xây
dựng</td><td>Đá BTXM (10x20)mm</td><td>m3</td><td>TCVN
7572:2006</td><td>Kích thước viên
(10
&lt; và ≤ 20) mm</td><td>Công ty
TNHH Kỹ
Nghệ Thái An</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>464,813</td><td></td></tr><tr><td>II</td><td>Gạch xây dựng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2,1</td><td>Công ty TNHH Hồng Phong</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>93</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN đặc GT1,
Mác 10</td><td>viên</td><td>TCVN
6477:2011</td><td>(220x105x60)
mm</td><td>Công ty
TNHH Hồng
Phong</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,150</td><td></td></tr><tr><td>94</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN 2 lỗ GT5,
Mác 10</td><td>viên</td><td>TCVN
6477:2011</td><td>(390x180x120)
mm</td><td>Công ty
TNHH Hồng
Phong</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>4,500</td><td></td></tr><tr><td>95</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN 2 lỗ GT4,
Mác 10</td><td>viên</td><td>TCVN
6477:2011</td><td>(390x180x140)
mm</td><td>Công ty
TNHH Hồng
Phong</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>5,200</td><td></td></tr><tr><td>2,2</td><td>Công ty TNHH sản xuất và thương mại Tuổi Trẻ Lạng Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>96</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN đặc
GTTLS 01, Mac 8</td><td>viên</td><td>TCVN
6477:2011</td><td>(220x105x60) mm</td><td>Công ty
TNHH SX và
TM Tuổi Trẻ
LS</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,180</td><td></td></tr><tr><td>97</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN đặc
GTTLS 03, Mac 8</td><td>viên</td><td>TCVN
6477:2011</td><td>(220x105x65) mm</td><td>Công ty
TNHH SX và
TM Tuổi Trẻ
LS</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,200</td><td></td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>98</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN lỗ
GTTLS 012, Mac 8</td><td>viên</td><td>TCVN
6477:2011</td><td>(390x180x120)
mm</td><td>Công ty
TNHH SX và
TM Tuổi Trẻ
LS</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>5,550</td><td></td></tr><tr><td>2,3</td><td>Công ty cổ phần gạch ngói Hợp Thành</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>99</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN Tuynel,
Mác 150</td><td>viên</td><td>TCVN
6477:2011</td><td>(210x90x55) mm</td><td>Công ty cổ
phần
gạch ngói
Hợp Thành</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,198</td><td></td></tr><tr><td>2,4</td><td>Công ty TNHH MTV Hiếu Hằng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>100</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN đặc
GKNHH01, mác 100</td><td>viên</td><td>TCVN
6477:2011</td><td>(220 x 105 x 65)
mm</td><td>Công ty
TNHH MTV
Hiếu Hằng</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,150</td><td></td></tr><tr><td>101</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN đặc
GKNHH02, mác 100</td><td>viên</td><td>TCVN
6477:2011</td><td>(220 x 100 x 60)
mm</td><td>Công ty
TNHH MTV
Hiếu Hằng</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,101</td><td></td></tr><tr><td>102</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN lỗ
GKNHH03, mác 75</td><td>viên</td><td>TCVN
6477:2011</td><td>(220 x 105 x 60)
mm</td><td>Công ty
TNHH MTV
Hiếu Hằng</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,045</td><td></td></tr><tr><td>2,5</td><td>Công ty TNHH Tư vấn đầu tư xây dựng An Khánh VQ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>103</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN GAKVQ
01, Mác 70</td><td>viên</td><td>TCVN
6477:2011</td><td>(220x105x60) mm</td><td>Công ty
TNHH TV
ĐTXD An
Khánh VQ</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,050</td><td></td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>104</td><td>Gạch xây
dựng</td><td>Gạch bê tông KN GAKVQ
02, Mác 100</td><td>viên</td><td>TCVN
6477:2011</td><td>(220x105x60) mm</td><td>Công ty
TNHH TV
ĐTXD An
Khánh VQ</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>1,050</td><td></td></tr><tr><td>2,6</td><td>Công ty CP kinh doanh gạch ốp lát VIGLACERA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>105</td><td>Gạch xây
dựng</td><td>Gạch Bê tông khí AAC3
Cấp cường độ nén B3
≥3.5mpa, khối lượng thể
tích khô từ 450kg/m3 -
650kg/m3</td><td>m3</td><td>TCVN
7959:2011</td><td>(600x200x100),
(600x200x150),
(600x200x200)
mm.</td><td>Công ty CP
KD gạch ốp
lát
VIGLACERA</td><td>Đã bao
gồm VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.789.095</td><td></td></tr><tr><td>106</td><td>Gạch xây
dựng</td><td>Gạch bê tông khí AAC4.
Cấp cường độ nén B4
≥5mpa, khối lượng thể tích
khô từ 650kg/m3 -
850kg/m3</td><td>m3</td><td>TCVN
7959:2011</td><td>(600x200x100),
(600x200x150),
(600x200x200)
mm</td><td>Công ty CP
KD gạch ốp
lát
VIGLACERA</td><td>Đã bao
gồm VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>1.904.595</td><td></td></tr><tr><td>III</td><td>Cát xây
dựng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3,1</td><td>Công ty TNHH Hồng Phong</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>107</td><td>Cát xây
dựng</td><td>Cát nghiền dùng cho bê
tông và vữa (cát nghiền từ
đá vôi)</td><td>m3</td><td>TCVN
9205:2013</td><td>(0-5)mm</td><td>Công ty
TNHH Hồng
Phong</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>220,000</td><td></td></tr><tr><td>108</td><td>Cát xây
dựng</td><td>Cát nghiền dùng cho bê
tông và vữa (cát nghiền từ
đá vôi)</td><td>m3</td><td>TCVN
9205:2013</td><td>(0-10)mm</td><td>Công ty
TNHH Hồng
Phong</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>320,000</td><td></td></tr><tr><td>3,2</td><td>Công ty Cổ phần Gia Lộc (Địa chỉ: xã Hùng Sơn, huyện Tràng Định, tỉnh Lạng Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>109</td><td>Cát xây
dựng</td><td>Cát nghiền dùng cho bê
tông và vữa (từ cát kết,
cuội kết)</td><td>m3</td><td>QCVN
16:2019/BXD</td><td>(0-1,4)mm</td><td>Công ty Cổ
phần Gia Lộc</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>280,000</td><td></td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>3,3</td><td>Công ty TNHH MTV Hồng Phong ATK</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>110</td><td>Cát xây
dựng</td><td>Cát nghiền từ dá vôi dùng
cho bê tông và vữa (cát
mịn)</td><td>m3</td><td>QCVN
16:2019/BXD</td><td>(0-1,5)mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>385,000</td><td></td></tr><tr><td>111</td><td>Cát xây
dựng</td><td>Cát nghiền từ dá vôi dùng
cho bê tông và vữa (cát
thô)</td><td>m3</td><td>QCVN
16:2019/BXD</td><td>(0-2,5)mm</td><td>Công ty
TNHH
MTV Hồng
Phong ATK</td><td>Không</td><td>Giá bán tại kho bên
bán, bao gồm chi
phí bốc xúc lên xe</td><td>385,000</td><td></td></tr><tr><td>3,4</td><td>Cát tự nhiên</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>112</td><td>Cát xây
dựng</td><td>Cát tự nhiên (mịn)</td><td>m3</td><td>QCVN
16:2019/BXD</td><td>(0,7-1)mm</td><td>Nguồn từ Bắc
Giang, Tuyên
Quang</td><td>Không</td><td>Giá bán tại trung
tâm thành phố và thị
trấn</td><td></td><td>390,000</td></tr><tr><td>113</td><td>Cát xây
dựng</td><td>Cát tự nhiên (mịn)</td><td>m3</td><td>QCVN
16:2019/BXD</td><td>(1-2)mm</td><td>Nguồn từ Bắc
Giang, Tuyên
Quang</td><td>Không</td><td>Giá bán tại trung
tâm thành phố và thị
trấn</td><td></td><td>410,000</td></tr><tr><td>114</td><td>Cát xây
dựng</td><td>Cát tự nhiên (thô)</td><td>m3</td><td>QCVN
16:2019/BXD</td><td>&gt; 2 mm</td><td>Nguồn từ Bắc
Giang, Tuyên
Quang</td><td>Không</td><td>Giá bán tại trung
tâm thành phố và thị
trấn</td><td></td><td>580,000</td></tr><tr><td>IV</td><td>Thép xây dựng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4,1</td><td>Thép Nghi Sơn (Công ty cổ phần Ganh thép Nghi Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Phường Hải Thượng, thị xã Nghi Sơn, tỉnh Thanh Hóa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Thép cuộn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>115</td><td>Thép xây
dựng</td><td>D6mm -CB240T</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>cuộn</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,252</td></tr><tr><td>116</td><td>Thép xây
dựng</td><td>D8mm -CB240T</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>cuộn</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,252</td></tr><tr><td>117</td><td>Thép xây
dựng</td><td>D8mm -CB300V</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>cuộn</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,352</td></tr><tr><td>*</td><td>Thép thanh vằn</td><td></td><td></td><td>TCVN 1651-
1:2018</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>118</td><td>Thép xây
dựng</td><td>D10mm -GR40</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,252</td></tr><tr><td>119</td><td>Thép xây
dựng</td><td>D12mm - CB300V</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,102</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>120</td><td>Thép xây
dựng</td><td>D14-20mm -
CB300V/GR40</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,102</td></tr><tr><td>121</td><td>Thép xây
dựng</td><td>D10mm -CB400V/CB500</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,782</td></tr><tr><td>122</td><td>Thép xây
dựng</td><td>D12mm - CB400V/CB500</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,632</td></tr><tr><td>123</td><td>Thép xây
dựng</td><td>D14-32mm -
CB400V/CB500</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,632</td></tr><tr><td>124</td><td>Thép xây
dựng</td><td>D36mm - CB400V/CB500</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>14,832</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>125</td><td>Thép xây
dựng</td><td>D40mm - CB400V/CB500</td><td>kg</td><td>TCVN 1651-
1:2018</td><td>L=11.7m</td><td>Công ty CP
Gang thép
Nghi Sơn</td><td>412 đ/kg</td><td>Giá bán tại TP Lạng
Sơn, thêm
cước vận chuyển đối
với các địa điểm xa
hơn</td><td></td><td>15,032</td></tr><tr><td>4,3</td><td>Thép SEAL (Công ty TNHH thép SEAH Việt Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Địa chỉ: Số 7, đường 3A, KCN Biên Hòa II, tỉnh Đồng Nai</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Thép đen</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>126
*</td><td>Thép xây
dựng</td><td>Thép tròn, vuông, hộp,
DN(10-100)</td><td>kg</td><td>ASTM
A53/A500</td><td>dầy (1-1,5)mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>27,700</td></tr><tr><td></td><td>Thép ống đen</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>127</td><td>Thép xây
dựng</td><td>Thép tròn, vuông, hộp,
DN(10-100)</td><td>kg</td><td>ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500</td><td>dầy (1,6-1,9)mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>26,900</td></tr><tr><td>128</td><td>Thép xây
dựng</td><td>Ống thép (tròn, vuông,
hộp), DN(10-100)</td><td>kg</td><td></td><td>dầy (2,0-5,4)mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>26,600</td></tr><tr><td>129</td><td>Thép xây
dựng</td><td>Thép tròn, vuông, hộp,
DN(10-100)</td><td>kg</td><td></td><td>dầy (5,5-6,35)mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>26,600</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>130</td><td>Thép xây
dựng</td><td>Ống thép (tròn, vuông,
hộp), DN(10-100)</td><td>kg</td><td></td><td>dầy &gt; 6,35mm,</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>26,800</td></tr><tr><td>131</td><td>Thép xây
dựng</td><td>Thép tròn, vuông, hộp,
DN(125-200)</td><td>kg</td><td></td><td>dầy (3,4- 8,2)mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>27,000</td></tr><tr><td>132</td><td>Thép xây
dựng</td><td>Thép tròn, vuông, hộp,
DN(125-200)</td><td>kg</td><td>ASTM
A53/A500</td><td>dầy &gt; 8,2 mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>27,600</td></tr><tr><td>*</td><td>Thép ống mạ kẽm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>133</td><td>Thép xây
dựng</td><td>DN10 - DN32</td><td>kg</td><td>ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500
ASTM
A53/A500</td><td>dầy (1,6-1,9) mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>33,800</td></tr><tr><td>134</td><td>Thép xây
dựng</td><td>DN10 - DN32</td><td>kg</td><td></td><td>dầy &gt;2 mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>33,000</td></tr><tr><td>135</td><td>Thép xây
dựng</td><td>DN40 - DN100</td><td>kg</td><td></td><td>dầy (1,6-1,9) mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>33,600</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật
ASTM
A53/A500</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>136</td><td>Thép xây
dựng</td><td>DN40 - DN100</td><td>kg</td><td></td><td>dầy (2-5,4) mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>32,800</td></tr><tr><td>137</td><td>Thép xây
dựng</td><td>DN40 - DN100</td><td>kg</td><td></td><td>dầy &gt;5,4 mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>32,800</td></tr><tr><td>138</td><td>Thép xây
dựng</td><td>DN125 - DN200</td><td>kg</td><td></td><td>dầy (3,4-8,2) mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>33,200</td></tr><tr><td>139</td><td>Thép xây
dựng</td><td>DN125 - DN200</td><td>kg</td><td></td><td>dầy &gt;8,2 mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>33,800</td></tr><tr><td>*</td><td>Ống tôn mạ kẽm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>140</td><td>Thép xây
dựng</td><td>DN(10-200)</td><td>kg</td><td>ASTM
A53/A500</td><td>dày (1-2,3)mm</td><td>Công ty
TNHH
thép SEAH
Việt Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>27,900</td></tr><tr><td>4,4</td><td>Ống thép mạ kẽm - VINAPINE (Công ty TNHH ống thép Việt
Nam)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>141</td><td>Thiết bị
ngành
nước</td><td>D15</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>23,182</td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>142</td><td>Thiết bị
ngành
nước</td><td>D20</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>29,091</td></tr><tr><td>143</td><td>Thiết bị
ngành
nước</td><td>D26</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>38,182</td></tr><tr><td>144</td><td>Thiết bị
ngành
nước</td><td>D33</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>45,455</td></tr><tr><td>145</td><td>Thiết bị
ngành
nước</td><td>D40</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>60,000</td></tr><tr><td>146</td><td>Thiết bị
ngành
nước</td><td>D50</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>78,182</td></tr><tr><td>147</td><td>Thiết bị
ngành
nước</td><td>D65</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>115,455</td></tr><tr><td>148</td><td>Thiết bị
ngành
nước</td><td>D80</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>136,364</td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>149</td><td>Thiết bị
ngành
nước</td><td>D100</td><td>m</td><td>TCCS
01/2008/VNP</td><td>L=6m</td><td>Công ty
TNHH ống
thép Việt
Nam</td><td>đến
TPLS</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn</td><td></td><td>181,818</td></tr><tr><td>V</td><td>Xi măng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>150</td><td>Xi măng</td><td>PCB30 - La Hiên</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty Cổ
phần
Xi măng La
Hiên VVMI</td><td>Không</td><td>Tại kho Công ty xi
măng La Hiên</td><td>1,065</td><td></td></tr><tr><td>151</td><td>Xi măng</td><td>PCB30 - La Hiên</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty Cổ
phần
Xi măng La
Hiên VVMI</td><td>Không</td><td>Tại kho Công ty xi
măng La Hiên</td><td>1,230</td><td></td></tr><tr><td>152</td><td>Xi măng</td><td>PC 30 - Thạch Long</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty
TNHH
MTV Xi
măng Quang
Sơn</td><td>đã bao
gồm VC</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn và các thị trấn</td><td>1,407</td><td></td></tr><tr><td>153</td><td>Xi măng</td><td>PC 40 - Thạch Long</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty
TNHH
MTV Xi
măng Quang
Sơn</td><td>đã bao
gồm VC</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn và các thị trấn</td><td>1,500</td><td></td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>154</td><td>Xi măng</td><td>PC 30 - Thần Sa</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty
TNHH
MTV Xi
măng Quang
Sơn</td><td>đã bao
gồm VC</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn và các thị trấn</td><td>1,407</td><td></td></tr><tr><td>155</td><td>Xi măng</td><td>PC 40 - Thần Sa</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty
TNHH
MTV Xi
măng Quang
Sơn</td><td>đã bao
gồm VC</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn và các thị trấn</td><td>1,500</td><td></td></tr><tr><td>156</td><td>Xi măng</td><td>PC 30 - Thành Thắng</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty
TNHH Đại
Long Bình</td><td>đã bao
gồm VC</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn và các thị trấn</td><td>1,540</td><td></td></tr><tr><td>157</td><td>Xi măng</td><td>PC 40 - Thành Thắng</td><td>kg</td><td>TCVN
6260:2020</td><td>bao 50kg</td><td>Công ty
TNHH Đại
Long Bình</td><td>đã bao
gồm VC</td><td>Giá bán tại trung
tâm thành phố Lạng
Sơn và các thị trấn</td><td>1,600</td><td></td></tr><tr><td></td><td>Phụ gia</td><td>Clinker CPC50</td><td>kg</td><td></td><td></td><td>Công ty Cổ
phần
Xi măng La
Hiên VVMI</td><td>Không</td><td>Tại kho Công ty xi
măng La Hiên</td><td>703</td><td></td></tr><tr><td>VI</td><td>Vữa, bê
tông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6,1</td><td>Công ty cổ phần Gạch ngói Hợp Thành</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: Thị trấn Cao Lộc, huyện Cao Lộc, tỉnh Lạng Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>158</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm mác
200</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần
gạch ngói
Hợp Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>818,182</td><td></td></tr><tr><td>159</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
250</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần
gạch ngói
Hợp Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>863,636</td><td></td></tr><tr><td>160</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
300</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần
gạch ngói
Hợp Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>954,545</td><td></td></tr><tr><td>161</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
350</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần
gạch ngói
Hợp Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.000.000</td><td></td></tr><tr><td>6,2</td><td>Công ty cổ phần bê tông Lạng Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: thôn Đại Sơn, xã Hợp Thành, thành phố Lạng Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>162</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
150</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>863,636</td><td></td></tr><tr><td>163</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
200</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>909,091</td><td></td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>164</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
250</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>954,545</td><td></td></tr><tr><td>165</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
300</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.000.000</td><td></td></tr><tr><td>166</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
350</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.045.455</td><td></td></tr><tr><td>167</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
400</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.090.909</td><td></td></tr><tr><td>168</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
150</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
nghiền</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>818,182</td><td></td></tr><tr><td>169</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
200</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
nghiền</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>863,636</td><td></td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>170</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
250</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
nghiền</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>909,091</td><td></td></tr><tr><td>171</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
300</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
nghiền</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>954,545</td><td></td></tr><tr><td>172</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
350</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
nghiền</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.000.000</td><td></td></tr><tr><td>173</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
400</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
nghiền</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.045.455</td><td></td></tr><tr><td>6,2</td><td>Công ty TNHH đá Thượng Thành</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: tại kho xã Mai Sao, huyện Chi Lăng, Lạng Sơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>174</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
150</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty
TNHH đá
Thượng
Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>768,000</td><td></td></tr><tr><td>175</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
200</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty
TNHH đá
Thượng
Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>811,000</td><td></td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>176</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
250</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty
TNHH đá
Thượng
Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>858,400</td><td></td></tr><tr><td>177</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
300</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty
TNHH đá
Thượng
Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>915,000</td><td></td></tr><tr><td>178</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
350</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty
TNHH đá
Thượng
Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>962,800</td><td></td></tr><tr><td>179</td><td>Vữa, bê
tông</td><td>Bê tông thương phẩm Mác
400</td><td>m3</td><td>TCVN
9340:2012</td><td>đá (1x2)cm, cát
vàng</td><td>Công ty
TNHH đá
Thượng
Thành</td><td>Không</td><td>Giá bán tại nơi bán,
chưa bao
gồm vận chuyển và
bơm bê tông</td><td>1.011.200</td><td></td></tr><tr><td>VII</td><td>Cấu kiện bê tông đúc sẵn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7,1</td><td>Công ty cổ phần Gạch ngói Hợp Thành (Địa chỉ: Thị trấn Cao Lộc, huyện Cao Lộc, tỉnh Lạng Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cống bê tông cốt thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>180</td><td>Cấu kiện
bt đúc sẵn</td><td>D300 miệng bát, không cốt
thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>270,613</td><td></td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>181</td><td>Cấu kiện
bt đúc sẵn</td><td>D300 miệng bát, dài 2m, có
cốt thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>330,750</td><td></td></tr><tr><td>182</td><td>Cấu kiện
bt đúc sẵn</td><td>D400 miệng bằng, 1 lớp
thép</td><td>m</td><td>TCVN
9113:2012</td><td>L=(1-2)m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>370,841</td><td></td></tr><tr><td>183</td><td>Cấu kiện
bt đúc sẵn</td><td>D400 miệng bát, 1 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L=(1-2)m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>390,887</td><td></td></tr><tr><td>184</td><td>Cấu kiện
bt đúc sẵn</td><td>D600 miệng bằng, 1 lớp
thép</td><td>m</td><td>TCVN
9113:2012</td><td>L=(1-2)m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>506,147</td><td></td></tr><tr><td>185</td><td>Cấu kiện
bt đúc sẵn</td><td>D600 miệng bát, 1 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L=(1-2)m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>546,238</td><td></td></tr><tr><td>186</td><td>Cấu kiện
bt đúc sẵn</td><td>D800 miệng bằng, 2 lớp
thép</td><td>m</td><td>TCVN
9113:2012</td><td>L=(1-2)m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>882,000</td><td></td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>187</td><td>Cấu kiện
bt đúc sẵn</td><td>D800 miệng bát, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L=(1-2)m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>927,103</td><td></td></tr><tr><td>188</td><td>Cấu kiện
bt đúc sẵn</td><td>D1000, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.508.421</td><td></td></tr><tr><td>189</td><td>Cấu kiện
bt đúc sẵn</td><td>D1250/120A, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.430.512</td><td></td></tr><tr><td>190</td><td>Cấu kiện
bt đúc sẵn</td><td>D1250/120B, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.530.738</td><td></td></tr><tr><td>191</td><td>Cấu kiện
bt đúc sẵn</td><td>D1250/120C, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.600.897</td><td></td></tr><tr><td>192</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/120A, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.876.522</td><td></td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>193</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/120B, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.026.863</td><td></td></tr><tr><td>194</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/120C, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.177.204</td><td></td></tr><tr><td>195</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/140A, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.683.353</td><td></td></tr><tr><td>196</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/140B, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.878.796</td><td></td></tr><tr><td>197</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/140C, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.049.182</td><td></td></tr><tr><td>198</td><td>Cấu kiện
bt đúc sẵn</td><td>D2000, 2 lớp thép</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>7.562.147</td><td></td></tr><tr><td>*</td><td>Cột điện chữ H</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_28>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>199</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 6,5A, trọng lượng
(TL) 421 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=6,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.102.500</td><td></td></tr><tr><td>200</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 6,5B TL 432 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=6,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.302.954</td><td></td></tr><tr><td>201</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 6,5C TL 435 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=6,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.468.329</td><td></td></tr><tr><td>202</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 7,5A, TL 565kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.378.125</td><td></td></tr><tr><td>203</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 7,5B, TL 576 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.573.568</td><td></td></tr><tr><td>204</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 7,5C, TL 580 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.723.909</td><td></td></tr><tr><td>205</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 8,5A, TL 660 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.733.932</td><td></td></tr><tr><td>206</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 8,5B, TL 672 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.959.443</td><td></td></tr></tbody></table>

|<image_29>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>207</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột H 8,5C, TL 685 kg/cột</td><td>cột</td><td>TCCS
2:2016/BTTL</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.154.887</td><td></td></tr><tr><td>*</td><td>Cột BT ly
tâm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>208</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 7A, TL 456 kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.443.272</td><td></td></tr><tr><td>209</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 7B, TL 465 kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.728.921</td><td></td></tr><tr><td>210</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 7,5A, TL 576
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.513.432</td><td></td></tr><tr><td>211</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 7,5B, TL 586
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.799.079</td><td></td></tr><tr><td>212</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 7,5C, TL 696
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.034.613</td><td></td></tr><tr><td>213</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 8,5A, TL 596
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.738.943</td><td></td></tr><tr><td>214</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 8,5B, TL 625
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.954.432</td><td></td></tr></tbody></table>

|<image_30>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>215</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 8,5C, TL 750
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.335.296</td><td></td></tr><tr><td>216</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 10A, TL 921,32
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.701.125</td><td></td></tr><tr><td>217</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 10B, TL 922,40
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.961.716</td><td></td></tr><tr><td>218</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 10C, TL 930,50
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.412.738</td><td></td></tr><tr><td>219</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 12A, TL 1288,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.485.171</td><td></td></tr><tr><td>220</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 12B, TL 1327,73
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>5.201.796</td><td></td></tr><tr><td>221</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 12C, TL 1373,30
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>6.274.228</td><td></td></tr><tr><td>222</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 12D, TL 1400,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>8.629.568</td><td></td></tr></tbody></table>

|<image_31>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>223</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 14B, TL 1905,60
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>12.122.488</td><td></td></tr><tr><td>224</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 14C, TL 2006,27
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>13.625.897</td><td></td></tr><tr><td>225</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 14D, TL 2042,87
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>14.457.784</td><td></td></tr><tr><td>226</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 16B, TL 2.182,64
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>13.440.478</td><td></td></tr><tr><td>227</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 16C, TL 2292,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>15.440.012</td><td></td></tr><tr><td>228</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 16D, TL 2340,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>17.850.478</td><td></td></tr><tr><td>229</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 18B, TL 2.650.00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>15.224.522</td><td></td></tr><tr><td>230</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 18C, TL 2715,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>17.294.216</td><td></td></tr></tbody></table>

|<image_32>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>231</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 18D, TL 2880,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>18.912.887</td><td></td></tr><tr><td>232</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 20B, TL 3.185,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>16.923.375</td><td></td></tr><tr><td>233</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 20C TL 3.297,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>19.018.125</td><td></td></tr><tr><td>234</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột LT 20D, TL 3.415,00
kg/cột</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>20.852.284</td><td></td></tr><tr><td></td><td>Cột BT ly tâm PC,I</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>235</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-7,5-160-2,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.713.887</td><td></td></tr><tr><td>236</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-7,5-160-3,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.894.296</td><td></td></tr><tr><td>237</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-7,5-160-5,4</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.255.113</td><td></td></tr><tr><td>238</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-7,5-190-4,3</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.179.943</td><td></td></tr></tbody></table>

|<image_33>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>239</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-7,5-190-6,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.385.409</td><td></td></tr><tr><td>240</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-160-2,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.360.353</td><td></td></tr><tr><td>241</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-160-2,5</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.450.557</td><td></td></tr><tr><td>242</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-160-3,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.635.978</td><td></td></tr><tr><td>243</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-160-4,3</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.811.375</td><td></td></tr><tr><td>244</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-190-3,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.806.363</td><td></td></tr><tr><td>245</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-190-4,3</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.956.704</td><td></td></tr><tr><td>246</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-8,5-190-5,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.036.887</td><td></td></tr></tbody></table>

|<image_34>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>247</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-10-190-3,5</td><td>cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.377.659</td><td></td></tr><tr><td>248</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-10-190-4,3</td><td>cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.467.863</td><td></td></tr><tr><td>249</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-10-190-5,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.558.068</td><td></td></tr><tr><td>250</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-12-190-3,5</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.029.137</td><td></td></tr><tr><td>251</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-12-190-4,3</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.279.704</td><td></td></tr><tr><td>252</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-12-190-5,4</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.655.557</td><td></td></tr><tr><td>253</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-12-190-7,2</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>5.632.772</td><td></td></tr><tr><td>254</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-12-190-9,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>6.354.409</td><td></td></tr></tbody></table>

|<image_35>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>255</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-12-190-10,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>7.451.897</td><td></td></tr><tr><td>256</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-14-190-8,5</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>12.598.568</td><td></td></tr><tr><td>257</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-14-190-11,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>16.948.432</td><td></td></tr><tr><td>258</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-14-190-13,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>17.950.704</td><td></td></tr><tr><td>259</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-16-190-9,2</td><td>cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>17.008.568</td><td></td></tr><tr><td>260</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-16-190-11,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>18.993.068</td><td></td></tr><tr><td>261</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-16-190-13,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>20.245.909</td><td></td></tr><tr><td>262</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-18-190-9,2</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>19.003.091</td><td></td></tr></tbody></table>

|<image_36>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>263</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-18-190-11,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>20.882.353</td><td></td></tr><tr><td>264</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-18-190-12,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>20.942.488</td><td></td></tr><tr><td>265</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-18-190-13,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>22.100.113</td><td></td></tr><tr><td>266</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-20-190-9,2</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>20.756.353</td><td></td></tr><tr><td>267</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-20-190-11,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>23.332.909</td><td></td></tr><tr><td>268</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-20-190-13,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>24.801.238</td><td></td></tr><tr><td>269</td><td>Cấu kiện
bt đúc sẵn</td><td>PC,I-20-190-14,0</td><td>cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty CP
Gạch ngói
Hợp Thành</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>25.628.113</td><td></td></tr><tr><td>7,2</td><td>Công ty cổ phần bê tông Lạng Sơn (Địa chỉ, Thôn Đại Sơn, Xã Hợp Thành, Huyện Cao Lộc, Tỉnh Lạng
Sơn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*
270</td><td>Cống bê tông cốt thép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Cấu kiện
bt đúc sẵn</td><td>D300/6cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>240,000</td><td></td></tr></tbody></table>

|<image_37>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>271</td><td>Cấu kiện
bt đúc sẵn</td><td>D400/6cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>320,909</td><td></td></tr><tr><td>272</td><td>Cấu kiện
bt đúc sẵn</td><td>D600/8cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>672,727</td><td></td></tr><tr><td>273</td><td>Cấu kiện
bt đúc sẵn</td><td>D750/8cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>1.272.727</td><td></td></tr><tr><td>274</td><td>Cấu kiện
bt đúc sẵn</td><td>D1000/12cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.129.091</td><td></td></tr><tr><td>275</td><td>Cấu kiện
bt đúc sẵn</td><td>D1250/12cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>2.727.273</td><td></td></tr><tr><td>276</td><td>Cấu kiện
bt đúc sẵn</td><td>D1250/14cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.334.545</td><td></td></tr><tr><td>277</td><td>Cấu kiện
bt đúc sẵn</td><td>D1250/18cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.669.091</td><td></td></tr><tr><td>278</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/14cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>3.645.455</td><td></td></tr></tbody></table>

|<image_38>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>279</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/16cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>4.801.818</td><td></td></tr><tr><td>280</td><td>Cấu kiện
bt đúc sẵn</td><td>D1500/22cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>6.621.818</td><td></td></tr><tr><td>281</td><td>Cấu kiện
bt đúc sẵn</td><td>D2000/16cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>5.496.364</td><td></td></tr><tr><td>282</td><td>Cấu kiện
bt đúc sẵn</td><td>D2000/20cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>7.682.727</td><td></td></tr><tr><td>283</td><td>Cấu kiện
bt đúc sẵn</td><td>D2000/24cm</td><td>m</td><td>TCVN
9113:2012</td><td>L= 1m</td><td>Công ty cổ
phần bê tông
Lạng Sơn</td><td>Không</td><td>Giá tại kho bên bán,
bao gồm chi phí bốc
xếp lên xe VC</td><td>11.940.909</td><td></td></tr><tr><td>7,3</td><td>Công ty CP kinh doanh gạch ốp lát
VIGLACERA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>284</td><td>Cấu kiện
bt đúc sẵn</td><td>Tấm Panel ALC A1 hai lớp
lưới thép</td><td>m3</td><td>TCVN
12867:2020</td><td>dày (100-200)mm,
dài &lt;4,8m</td><td>Công ty CP
kinh
doanh gạch
ốp lát
VIGLACERA</td><td>Đã bao
gồm VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>5.024.250</td><td></td></tr><tr><td>285</td><td>Cấu kiện
bt đúc sẵn</td><td>Tấm Panel ALC A1 một
lớp lưới thép</td><td>m4</td><td>TCVN
12867:2020</td><td>(1200x600x100),
(1200x600x150),
(1200x600x200)</td><td>Công ty CP
kinh
doanh gạch
ốp lát
VIGLACERA</td><td>Đã bao
gồm VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>4.389.000</td><td></td></tr></tbody></table>

|<image_39>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>286</td><td>Cấu kiện
bt đúc sẵn</td><td>Tấm Panel ALC A1 không
cốt thép</td><td>m5</td><td>TCVN
12867:2020</td><td>(1200x600x100),
(1200x600x150),
(1200x600x200)</td><td>Công ty CP
kinh
doanh gạch
ốp lát
VIGLACERA</td><td>Đã bao
gồm VC</td><td>Giá bán đến chân
công trình trên địa
bàn tỉnh Lạng Sơn</td><td>3.522.750</td><td></td></tr><tr><td>7,4</td><td>Công ty TNHH SX và TM Hải Bách</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Địa chỉ: KM 10, Quốc lộ 1A cũ, xã Tân Thành, huyện Cao Lộc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>*</td><td>Cột điện chữ H</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>287</td><td>Cấu kiện
bt đúc sẵn</td><td>H 6.5A 140 - 230 x 310 -
421</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=6,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.320.000</td><td></td></tr><tr><td>288</td><td>Cấu kiện
bt đúc sẵn</td><td>H 6.5B 140-230x310-432</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=6,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.545.241</td><td></td></tr><tr><td>289</td><td>Cấu kiện
bt đúc sẵn</td><td>H 6.5C 140-230x310-435</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=6,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.633.536</td><td></td></tr><tr><td>290</td><td>Cấu kiện
bt đúc sẵn</td><td>H 7.5A 140-230 x340-565</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.600.000</td><td></td></tr><tr><td>291</td><td>Cấu kiện
bt đúc sẵn</td><td>H 7.5B 140-230x340-576</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.853.633</td><td></td></tr><tr><td>292</td><td>Cấu kiện
bt đúc sẵn</td><td>H 7.5C 140-230x340-580</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.940.649</td><td></td></tr></tbody></table>

|<image_40>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>293</td><td>Cấu kiện
bt đúc sẵn</td><td>H 8.5A 140-230x370-660</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.806.287</td><td></td></tr><tr><td>294</td><td>Cấu kiện
bt đúc sẵn</td><td>H 8.5B 140-230 x370-672</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.110.652</td><td></td></tr><tr><td>295</td><td>Cấu kiện
bt đúc sẵn</td><td>H 8.5C 140-230x370-421</td><td>cột</td><td>TCCS
01:2016/HB</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.411.555</td><td></td></tr><tr><td>*</td><td>Cột BT ly tâm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>296</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 7,5-
160- 3.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>1.905.200</td><td></td></tr><tr><td>297</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 7,5-
160- 4.3</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.085.725</td><td></td></tr><tr><td>298</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 7,5-
160- 5.4</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.157.230</td><td></td></tr><tr><td>299</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 7,5-
190- 4.3</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.190.210</td><td></td></tr><tr><td>300</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 7,5-
190- 6.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=7,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.372.812</td><td></td></tr></tbody></table>

|<image_41>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>301</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 8,5-
160- 3.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.605.300</td><td></td></tr><tr><td>302</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 8,5-
160- 4.3</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.682.215</td><td></td></tr><tr><td>303</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 8,5-
190- 3.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.702.500</td><td></td></tr><tr><td>304</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 8,5-
190- 4.3</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.830.210</td><td></td></tr><tr><td>305</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 8,5-
190- 5.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=8,5m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>2.910.205</td><td></td></tr><tr><td>306</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 10-190-
3.5</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>3.302.100</td><td></td></tr><tr><td>307</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 10-190-
4.3</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>3.751.300</td><td></td></tr><tr><td>308</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 10-190-
5.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=10m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>3.817.120</td><td></td></tr></tbody></table>

|<image_42>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>309</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 12-190-
4.3</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>4.700.602</td><td></td></tr><tr><td>310</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 12-190-
5.4</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>5.100.030</td><td></td></tr><tr><td>311</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 12-190-
7.2</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>5.420.245</td><td></td></tr><tr><td>312</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 12-190-
9.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>6.564.800</td><td></td></tr><tr><td>313</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 12-190-
10.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=12m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>7.995.623</td><td></td></tr><tr><td>314</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 14-190-
8.5</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>12.102.362</td><td></td></tr><tr><td>315</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 14-190-
9.2</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>12.908.200</td><td></td></tr><tr><td>316</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 14-190-
11.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>16.312.120</td><td></td></tr></tbody></table>

|<image_43>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>317</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 14-190-
13.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=14m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>17.291.300</td><td></td></tr><tr><td>318</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI -16-
190- 9.2</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>16.251.604</td><td></td></tr><tr><td>319</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI -16-
190- 11.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>18.190.812</td><td></td></tr><tr><td>320</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI -16-
190- 13.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=16m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>19.312.210</td><td></td></tr><tr><td>321</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 18-190-
9.2</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>18.195.410</td><td></td></tr><tr><td>322</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 18-190-
11.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>19.925.320</td><td></td></tr><tr><td>323</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 18-190-
12.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>19.995.235</td><td></td></tr><tr><td>324</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 18-190-
13.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=18m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>21.235.272</td><td></td></tr></tbody></table>

|<image_44>|


## VIETTEL AI RACE

## TD641

## GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH

## LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,

## THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ

## TÔNG ĐÚC SẴN

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD641</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG THÁNG 4 NĂM 2025 TRÊN ĐỊA BÀN TỈNH
LẠNG SƠN: ĐÁ XÂY DỰNG, GẠCH XÂY DỰNG, CÁT XÂY DỰNG,
THÉP XÂY DỰNG, VỮA, BÊ TÔNG, THÉP XI MĂNG, CẤU KIỆN BÊ
TÔNG ĐÚC SẴN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Stt</th><th>Nhóm
vật liệu</th><th>Tên vật liệu, loại vật
liệu</th><th>Đơn
vị
tính</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Vận
chuyển</th><th>Ghi chú</th><th>Giá bán (chưa
VAT)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Địa bàn
toàn
tỉnh</td><td>Thành
phố
LS</td></tr><tr><td>325</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 20-190-
9.2</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>19.542.332</td><td></td></tr><tr><td>326</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 20-190-
11.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>22.520.140</td><td></td></tr><tr><td>327</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 20-190-
13.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>23.686.242</td><td></td></tr><tr><td>328</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 20-190-
14.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=20m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>24.512.909</td><td></td></tr><tr><td>329</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 22-190-
9.2</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=22m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>22.379.500</td><td></td></tr><tr><td>330</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 22-190-
11.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=22m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>23.980.600</td><td></td></tr><tr><td>331</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 22-190-
13.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=22m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>24.956.227</td><td></td></tr><tr><td>332</td><td>Cấu kiện
bt đúc sẵn</td><td>Cột BT ly tâm PCI 22-190-
14.0</td><td>Cột</td><td>TCVN
5847:2016</td><td>L=22m</td><td>Công ty
TNHH SX và
TM Hải Bách</td><td>Chưa bao
gồm VC</td><td>Giá bán tại nơi sản
xuất</td><td>27.555.723</td><td></td></tr></tbody></table>

|<image_45>|


