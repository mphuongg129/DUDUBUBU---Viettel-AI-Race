# Public_673

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th></th><th>Ký hiệu</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Trên sơ đồ nguyên lí</td><td>Trên sơ đồ vị trí</td></tr><tr><td>1</td><td>Cầu dao</td><td>Cầu dao 1 pha</td><td></td><td></td></tr><tr><td>2</td><td></td><td>Cầu dao 1 pha 2 ngã
(cầu dao đảo 1 pha)</td><td></td><td></td></tr><tr><td>3</td><td></td><td>Cầu dao 3 pha</td><td></td><td></td></tr><tr><td>4</td><td></td><td>Cầu dao 3 pha 2 ngã
(cầu dao đảo 3 pha)</td><td></td><td></td></tr><tr><td>5</td><td>Công tắc</td><td>Công tắc 2 cực</td><td></td><td></td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi
Công tắc 3 cực
Công tắc xoay 4 cực</th><th></th><th>Ký hiệu</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Trên sơ đồ nguyên lí</td><td>Trên sơ đồ vị trí</td></tr><tr><td>6</td><td></td><td>Công tắc 3 cực</td><td></td><td></td></tr><tr><td>7</td><td></td><td>Công tắc xoay 4 cực</td><td></td><td></td></tr><tr><td>8</td><td>Ổ cắm</td><td>Ổ cắm điện</td><td></td><td></td></tr><tr><td>9</td><td>Aptomat</td><td>Aptomat 1 pha</td><td></td><td></td></tr><tr><td>10</td><td></td><td>Aptomat 3 pha</td><td></td><td></td></tr><tr><td>11</td><td>Cầu chì</td><td>Cầu chì</td><td></td><td></td></tr><tr><td>12</td><td>Nút bấm</td><td>Nút bấm
Thường mở
Thường đóng</td><td></td><td></td></tr></tbody></table>

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|

|<image_21>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th></th><th>Ký hiệu</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Trên sơ đồ nguyên lí</td><td>Trên sơ đồ vị trí</td></tr><tr><td>13</td><td>Hộp số</td><td>Hộp số quạt trần</td><td></td><td></td></tr><tr><td>14</td><td>Bảng và tủ
điều khiển</td><td>Bảng, tủ điều khiển</td><td></td><td></td></tr><tr><td>15</td><td></td><td>Bảng phân phối điện</td><td></td><td></td></tr><tr><td>16</td><td></td><td>Tủ phân phối (động
lực và ánh sáng</td><td></td><td></td></tr><tr><td>17</td><td>Hộp nối
dây</td><td>Hộp nối dây</td><td></td><td></td></tr><tr><td>18</td><td>Bảng chiếu
sáng</td><td>Bảng chiếu sáng làm
việc</td><td></td><td></td></tr><tr><td>19</td><td></td><td>Bảng chiếu sáng sự
cố</td><td></td><td></td></tr></tbody></table>

|<image_22>|

|<image_23>|

|<image_24>|

|<image_25>|

|<image_26>|

|<image_27>|

|<image_28>|

|<image_29>|

|<image_30>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên gọi</th><th>Ký hiệu</th></tr></thead><tbody><tr><td>Ampe kế</td><td></td></tr><tr><td>Volt kế</td><td></td></tr><tr><td>Ohm kế</td><td></td></tr><tr><td>Cosφ kế</td><td></td></tr><tr><td>Pha kế</td><td></td></tr><tr><td>Tần số kế</td><td></td></tr></tbody></table>

|<image_31>|

|<image_32>|

|<image_33>|

|<image_34>|

|<image_35>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên gọi</th><th>Ký hiệu</th></tr></thead><tbody><tr><td></td><td></td></tr><tr><td>Watt kế</td><td></td></tr><tr><td>Var kế</td><td></td></tr><tr><td>Điện kế</td><td></td></tr></tbody></table>

|<image_36>|

|<image_37>|

|<image_38>|

|<image_39>|

|<image_40>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th>Ký hiệu</th><th>Ghi chú</th></tr></thead><tbody><tr><td>1</td><td>Dao cách ly
Một cực
Ba cực</td><td></td><td>Chiều đóng cắt quy ước
là chiều kim đồng hồ</td></tr><tr><td>2</td><td>Dao cắt phụ tải 3 cực
điện áp cao</td><td></td><td>Chiều đóng cắt
quy ước là chiều kim
đồng hồ</td></tr><tr><td>3</td><td>Máy cắt phụ tải</td><td></td><td>Cho phép vẽ máy cắt
cao áp bằng hình vuông
và bên cạnh ghi ký hiệu
của loại máy cắt</td></tr><tr><td>4</td><td>Cầu chì tự rơi (FCO)</td><td></td><td></td></tr><tr><td>5</td><td>Trạm biến áp</td><td></td><td></td></tr></tbody></table>

|<image_41>|

|<image_42>|

|<image_43>|

|<image_44>|

|<image_45>|

|<image_46>|

|<image_47>|

|<image_48>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD673</th></tr></thead><tbody><tr><td></td><td>VẼ CÁC KÝ HIỆU, QUY ƯỚC DÙNG
TRONG BẢN VẼ ĐIỆN: ĐIỆN CHIẾU SÁNG
VÀ TRONG SƠ ĐỒ CUNG CẤP ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Tên gọi</th><th>Ký hiệu</th><th>Ghi chú</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>Chống sét van</td><td></td><td></td></tr><tr><td>7</td><td>Tụ bù
Bù ngang
Bù dọc</td><td></td><td></td></tr><tr><td>8</td><td>Nhà máy điện</td><td></td><td>A: loại nhà máy B: Công
suất</td></tr></tbody></table>

|<image_49>|

|<image_50>|

|<image_51>|

|<image_52>|

|<image_53>|

|<image_54>|


