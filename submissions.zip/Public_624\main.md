# Public_624

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Loại ga</th><th>Kiểu bố trí
đường đón, tiễn
tàu</th><th>Chiều dài
nền ga (m)</th><th>Chiều rộng nền ga
(m)</th></tr></thead><tbody><tr><td>1- Ga hành khách
- Ga cụt
- Ga thông qua</td><td></td><td>≥1000
≥1400</td><td>≥200
≥100</td></tr><tr><td>2- Ga hàng hóa</td><td></td><td>≥500</td><td>≥100</td></tr><tr><td>3- Ga kỹ thuật</td><td>Nối tiếp Hỗn hợp
Song song</td><td>≥4000
≥2700
≥2200</td><td>≥200
≥250
≥700</td></tr><tr><td>4- Ga hỗn hợp</td><td>Xếp dọc
Nửa xếp dọc
Xếp ngang</td><td>≥1500
≥1300
≥900</td><td>≥50
≥50
≥ 100</td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Loại ga</th><th>Kiểu bố trí
đường đón, tiễn
tàu</th><th>Chiều dài
nền ga (m)</th><th>Chiều rộng nền ga
(m)</th></tr></thead><tbody><tr><td>1- Ga hành khách, Ga cụt Ga
thông qua</td><td></td><td>≥1000
≥1400</td><td>≥200
≥100</td></tr><tr><td>2- Ga hàng hóa</td><td></td><td>≥500</td><td>≥100</td></tr><tr><td>3- Ga kỹ thuật</td><td>Nối tiếp
Hỗn hợp
Song song</td><td>≥4000
≥2700
≥2200</td><td>≥200
≥250
≥700</td></tr><tr><td>4- Ga hỗn hợp</td><td>Xếp dọc
Nửa xếp dọc
Xếp ngang</td><td>≥1500
≥1300
≥900</td><td>≥50
≥50
≥ 100</td></tr></tbody></table>

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_6>|


### VIETTEL AI RACE

### TIÊU CHUẨN QUY HOẠCH GIAO

### THÔNG

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Cấp
đường</th><th>Loại đường</th><th>Tốc độ
thiết kế
(km/h)</th><th>Bề rộng
1 làn xe
(m)</th><th>Bề rộng
của đường
(m)</th><th>Khoảng
cách hai
đường (m)</th><th>Mật độ
đườn
g
km/km2</th></tr></thead><tbody><tr><td>Cấp
đô thị(**)</td><td>1.Đường cao tốc
đô thị</td><td></td><td></td><td></td><td>4.800-8.000</td><td>0,4-0,25</td></tr><tr><td></td><td>- Cấp 100</td><td>100</td><td>3,75</td><td>27-110</td><td>-</td><td></td></tr><tr><td></td><td>- Cấp 80</td><td>80</td><td>3,75</td><td>27-90</td><td>-</td><td></td></tr><tr><td></td><td>2. Đường trục
chính đô thị</td><td>80-100</td><td>3,75</td><td>30-80 (*)</td><td>2400-4000</td><td>0,83-0,5</td></tr><tr><td></td><td>3. Đường chính
đô
thị</td><td>80-100</td><td>3,75</td><td>30-70 (*)</td><td>1200-2000</td><td>1,5-1,0</td></tr><tr><td></td><td>4. Đường liên khu
vực</td><td>60-80</td><td>3,75</td><td>30-50</td><td>600-1000</td><td>3,3-2,0</td></tr><tr><td>Cấp
khu vực</td><td>5. Đường chính
khu vực</td><td>50-60</td><td>3,5</td><td>22-35</td><td>300-500</td><td>6,5-4,0</td></tr><tr><td></td><td>6. Đường khu vực</td><td>40-50</td><td>3,5</td><td>16-25</td><td>250-300</td><td>8,0-6,5</td></tr><tr><td>Cấp nội
bộ</td><td>7.Đường phân
khu
vực</td><td>40</td><td>3,5</td><td>13-20</td><td>150-250</td><td>13,3-10</td></tr><tr><td></td><td>8. Đường nhóm
nhà ở, vào nhà</td><td>20-30</td><td>3,0</td><td>7-15</td><td>-</td><td>-</td></tr><tr><td></td><td>9.Đường đi xe
đạp Đường đi
bộ</td><td></td><td>1,5
0,75</td><td>3,0
1,5</td><td>-</td><td>-</td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_11>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Loại nhà</th><th>Nhu cầu tối thiểu về chỗ đỗ ô-tô</th></tr></thead><tbody><tr><td>- Khách sạn từ 3 sao trở lên</td><td>4 phòng/1 chỗ</td></tr><tr><td>- Văn phòng cao cấp, trụ sở cơ quan đối ngoại</td><td>100m2 sàn sử dụng/1chỗ</td></tr><tr><td>- Siêu thị, cửa hàng lớn, trung tâm hội nghị, triển
lãm, trưng bày</td><td>100m2 sàn sử dụng/1 chỗ</td></tr><tr><td>- Chung cư cao cấp</td><td>1 căn hộ/1,5 chỗ</td></tr></tbody></table>

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>Public 624</th></tr></thead><tbody><tr><td></td><td>TIÊU CHUẨN QUY HOẠCH GIAO
THÔNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_13>|


