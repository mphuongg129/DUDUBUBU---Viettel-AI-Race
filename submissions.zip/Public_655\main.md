# Public_655

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Thành phần</th><th></th><th>Mô tả</th></tr></thead><tbody><tr><td>(1)</td><td>Vùng bàn di chuột</td><td>Đọc các cử chỉ của ngón tay để di chuyển con trỏ hoặc
kích hoạt các mục trên màn hình.
GHI CHÚ: Để biết thêm thông tin, xem Sfi dụng cfi chỉ</td></tr></tbody></table>

|<image_1>|

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>trên touchpad và màn hình cảm ứng thuộc trang 27.</th></tr></thead><tbody><tr><td>(2)</td><td>Nút bàn di chuột trái</td><td>Hoạt động như nút trái của chuột ngoài.</td></tr><tr><td>(3)</td><td>Nút bàn di chuột phải</td><td>Hoạt động như nút phải của chuột ngoài.</td></tr></tbody></table>

<table><thead><tr><th>Thành phần</th><th></th><th></th><th>Mô tả</th></tr></thead><tbody><tr><td>(1)</td><td></td><td>Đèn báo phím
khóa viết hoa</td><td>Bật: Phím khóa viết hoa đang bật, mọi ký tự nhập vào sẽ
chuyển thành chữ viết hoa.</td></tr><tr><td>(2)</td><td></td><td>Đèn tắt tiếng</td><td>Bật: Âm thanh máy tính đã tắt.</td></tr><tr><td></td><td></td><td></td><td>Tắt: Âm thanh máy tính đang bật.</td></tr><tr><td>(3)</td><td></td><td>Đèn bàn di
chuột</td><td>Bật: Bàn di chuột tắt.</td></tr><tr><td></td><td></td><td></td><td>Tắt: Bàn di chuột bật.</td></tr></tbody></table>

|<image_3>|

|<image_4>|

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>(4)</th><th></th><th>Đèn nguồn</th><th>Bật: Máy tính đang bật.
Nhấp nháy (chỉ một số sản phẩm): Máy tính đang ở
trạng thái Ngủ, trạng thái tiết kiệm điện. Máy tính ngắt
điện đến màn hình và các thành phần không cần thiết
khác.</th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Tắt: Tùy theo model máy tính, máy tính của bạn sẽ ở
trạng thái tắt, Ngủ đông hoặc Ngủ. Ngủ đông là trạng
thái tiết kiệm điện sử dụng ít điện năng nhất.</td></tr></tbody></table>

<table><thead><tr><th>Thành phần</th><th></th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td>Nút nguồn</td><td>Khi máy tính tắt, nhấn nút này để bật máy tính.
Khi máy tính bật, nhấn nhanh nút này để vào chế độ Ngủ.
Khi máy tính đang ở trạng thái Ngủ, nhấn nhanh nút này để thoát chế</td></tr></tbody></table>

|<image_7>|

|<image_8>|

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>độ Ngủ (chỉ một số sản phẩm).
Khi máy tính đang ở trạng thái Ngủ đông, nhấn nhanh nút này để
thoát chế độ Ngủ đông.
QUAN TRỌNG: Nhấn và giữ nút nguồn sẽ làm mất nhfing thông tin
chưa lưu.
Nếu máy tính ngừng phản hồi và quy trình tắt máy vô hiệu, nhấn và
nhấn gifi nút nguồn trong ít nhất 10 giây để tắt máy tính.
Để tìm hiểu thêm về các cài đặt nguồn điện, hãy xem các tùy chọn
nguồn điện của bạn:
Nhấp chuột phải vào biểu tượng Power (Nguồn) , rồi sau đó
chọn Power Options (Tùy chọn Nguồn điện).</th></tr></thead><tbody></tbody></table>

<table><thead><tr><th>Thành phần</th><th></th><th></th><th>Mô tả</th></tr></thead><tbody><tr><td>(1)</td><td></td><td>Phím thao tác</td><td>Thực hiện các chức năng hệ thống được sfi dụng thường
xuyên khi được bấm kết hợp với phím fn. Các phím thao
tác được định nghĩa bởi các ký hiệu biểu tượng trên các
phím chức năng f1 đến f12. Các phím thao tác có thể
khác nhau tùy theo máy tính. Xem Phím thao tác thuộc
trang 12.</td></tr></tbody></table>

|<image_10>|

|<image_11>|

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>(2)</th><th></th><th>Phím máy tính
tay</th><th>Mở chương trình máy tính tay.
GHI CHÚ: Nhấn phím một lần nfia để đóng máy tính
tay.</th></tr></thead><tbody><tr><td>(3)</td><td></td><td>Phím esc</td><td>Hiển thị thông tin hệ thống khi nhấn kết hợp với phím fn.</td></tr><tr><td>(4)</td><td></td><td>Phím fn</td><td>Thực hiện các chức năng cụ thể khi được bấm kết hợp
với phím khác.</td></tr><tr><td>(5)</td><td></td><td>Phím Windows</td><td>Mở menu Start (Bắt đầu).
GHI CHÚ: Nhấn phím Windows một lần nfia sẽ đóng
menu Start (Bắt đầu).</td></tr><tr><td>(6)</td><td></td><td>Phím ứng dụng
Windows</td><td>Hiển thị các tùy chọn cho một đối tượng được chọn.</td></tr><tr><td>(7)</td><td></td><td>Nút nguồn</td><td>Khi máy tính tắt, nhấn nút này để bật máy tính.
Khi máy tính bật, nhấn nhanh nút này để vào chế độ Ngủ.
Khi máy tính đang ở trạng thái Ngủ, nhấn nhanh nút này
để thoát chế độ Ngủ (chỉ một số sản phẩm).
Khi máy tính đang ở trạng thái Ngủ đông, nhấn nhanh
nút này để thoát chế độ Ngủ đông.
QUAN TRỌNG: Nhấn và giữ nút nguồn sẽ làm mất
nhfing thông tin chưa lưu.
Nếu máy tính ngừng phản hồi và quy trình tắt máy vô
hiệu, nhấn và nhấn gifi nút nguồn trong ít nhất 10 giây để
tắt máy tính.
Để tìm hiểu thêm về các cài đặt nguồn điện, hãy xem các
tùy chọn nguồn điện của bạn:</td></tr><tr><td>(8)</td><td></td><td>Phím OMEN</td><td>Nhấp chuột phải vào biểu tượng Power (Nguồn), rồi sau
đó chọn Power Options (Tùy chọn Nguồn điện).</td></tr></tbody></table>

|<image_13>|

|<image_14>|

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>(9)</th><th></th><th>Phím num lock</th><th>Chuyển đổi gifia các chức năng điều hướng và số trên
bàn phím số tích hợp.</th></tr></thead><tbody><tr><td>(10)</td><td></td><td>Bàn phím số
tích hợp</td><td>Bàn phím số riêng biệt nằm bên phải bàn phím chfi cái.
Khi nhấn phím num lock, có thể sử dụng bàn phím này
như bàn phím số gắn ngoài.</td></tr></tbody></table>

<table><thead><tr><th>Biểu tượng</th><th>Mô tả</th></tr></thead><tbody><tr><td></td><td>Chuyển đổi hình ảnh màn hình giữa các thiết bị hiển thị kết nối với hệ thống. Ví
dụ: nếu máy tính được kết nối với một màn hình, nhấn liên tiếp phím này sẽ thay
đổi hình ảnh màn hình từ màn hình máy tính sang màn hình được kết nối và sang
hiển thị đồng thời trên cả máy tính và màn hình.</td></tr><tr><td></td><td>Giảm dần độ sáng màn hình bằng cách nhấn giữ phím.</td></tr><tr><td></td><td>Tăng dần độ sáng màn hình bằng cách nhấn giữ phím.</td></tr><tr><td></td><td>Bật hoặc tắt đèn nền bàn phím. Trên một số sản phẩm nhất định, bạn có thể điều
chỉnh độ sáng của đèn nền bàn phím. Nhấn phím này liên tục để điều chỉnh độ
sáng từ cao (khi bạn lần đầu tiên khởi động máy tính) xuống thấp hoặc tắt. Sau
khi bạn điều chỉnh cài đặt đèn nền bàn phím, đèn nền sẽ trở về cài đặt trước đó
mỗi lần bạn bật nguồn máy tính. Đèn nền bàn phím sẽ tắt sau 30 giây không hoạt
động. Để bật lại đèn nền bàn phím, nhấn phím bất kỳ hoặc nhấn vào bàn di chuột</td></tr></tbody></table>

|<image_19>|

|<image_20>|

|<image_21>|

|<image_22>|

|<image_23>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD655</th></tr></thead><tbody><tr><td></td><td>MÔ TẢ VÙNG BÀN PHÍM MÁY TÍNH
HP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>(chỉ có ở một số sản phẩm nhất định). Để tiết kiệm nguồn pin, hãy tắt tính năng
này.</th></tr></thead><tbody><tr><td></td><td>Tắt tiếng hoặc khôi phục âm thanh loa.</td></tr><tr><td></td><td>Giảm dần âm lượng loa trong khi bạn nhấn giứ phím.</td></tr><tr><td></td><td>Tăng dần âm lượng loa trong khi bạn nhấn giữ phím.</td></tr><tr><td></td><td>Phát bài trước trong đĩa CD âm thanh hoặc phần trước trong đĩa DVD hay đĩa
Blu-ray (BD).</td></tr><tr><td></td><td>Bắt đầu, tạm dfing hoặc tiếp tục phát lại đĩa CD âm thanh, DVD hoặc đĩa BD.</td></tr><tr><td></td><td>Phát bài tiếp theo trong đĩa CD âm thanh hoặc phần tiếp theo trong đĩa DVD hay
đĩa Blu-ray (BD).</td></tr><tr><td></td><td>Bật hoặc tắt bàn di chuột.</td></tr><tr><td></td><td>Tắt và bật phím Windows .</td></tr></tbody></table>

|<image_24>|

|<image_25>|

|<image_26>|

|<image_27>|

|<image_28>|

|<image_29>|

|<image_30>|

|<image_31>|

|<image_32>|

|<image_33>|


