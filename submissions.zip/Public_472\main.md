# Public_472

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_2>|

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_4>|

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_7>|

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_9>|

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Hãng</th><th></th><th></th><th>Intel</th><th></th><th></th><th></th><th>AMD</th><th></th><th></th><th></th><th>Apple</th><th></th></tr></thead><tbody><tr><td>Dòng
chip</td><td></td><td></td><td>Core
i3/i5/i7/i9</td><td></td><td>Core
Ultra
(Meteor
Lake)</td><td></td><td>Ryzen
5/7/9</td><td></td><td>Ryzen AI
(Phoenix/Hawk
Point)</td><td></td><td>Apple
M1/M2/M3</td><td></td><td></td></tr><tr><td>Hiệu
năng</td><td></td><td></td><td>Phổ thông
đến cao cấp</td><td></td><td>Tối ưu
AI, hiệu
năng cao</td><td></td><td>Đa nhân
mạnh mẽ,
hiệu suất
tốt</td><td></td><td>Tích hợp NPU,
tối ưu AI</td><td></td><td>Tối ưu hiệu
năng và tiết
kiệm pin</td><td></td><td></td></tr><tr><td>GPU
tích
hợp</td><td></td><td></td><td>Intel Iris Xe</td><td></td><td>Intel Arc
GPU</td><td></td><td>Radeon
Graphics</td><td></td><td>RDNA 3 iGPU</td><td></td><td>GPU tích
hợp mạnh
(Metal)</td><td></td><td></td></tr><tr><td>TDP
(mức
tiêu thụ
điện)</td><td></td><td></td><td>15W -
125W</td><td></td><td>15W -
45W</td><td></td><td>15W -
65W</td><td></td><td>15W - 45W</td><td></td><td>10W - 30W</td><td></td><td></td></tr><tr><td>Ứng
dụng
phổ
biến</td><td></td><td></td><td>Laptop văn
phòng,
gaming,
workstation</td><td></td><td>Laptop
AI, hiệu
năng cao</td><td></td><td>Gaming,
đồ họa,
văn phòng</td><td></td><td>Laptop AI,
gaming tầm
trung</td><td></td><td>MacBook
Air, Pro,
Studio</td><td></td><td></td></tr></tbody></table>

|<image_11>|

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Cấu tạo của laptop</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th></tr></thead><tbody><tr><td></td></tr></tbody></table>

|<image_13>|

|<image_14>|

|<image_15>|


