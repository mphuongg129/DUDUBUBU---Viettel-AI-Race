# Public_638

### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố
Cao Bằng</td></tr><tr><td>&lt;1&gt;</td><td>&lt;2&gt;</td><td>&lt;3&gt;</td><td>&lt;4&gt;</td><td>&lt;5&gt;</td><td>&lt;6&gt;</td><td>&lt;7&gt;</td><td>&lt;8&gt;</td><td>&lt;9&gt;</td><td>&lt;10&gt;</td><td>&lt;11&gt;</td></tr><tr><td>26</td><td>Trần,
vách
thạch
cao</td><td>Trần thạch cao phẳng (trần chìm) khung
xương Vĩnh Tường loại I, tấm thạch cao
LaGyp sản xuất tại Việt nam (bao gồm chi phí
lắp đặt, hoàn thiện)</td><td>m2</td><td></td><td></td><td></td><td>Việt
Nam</td><td>Giá thi
công
lắp đặt
tại
thành
phố
Cao
Bằng</td><td></td><td>250.000</td></tr><tr><td></td><td></td><td>Trần thạch cao phẳng (trần chìm) khung
xương Vĩnh Tường loại 2, tấm thạch cao
LaGyp sản xuất tại Việt nam (bao gồm chi phí
lắp đặt, hoàn thiện)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr></tbody></table>

|<image_1>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Trần thạch cao giật cấp (trần chìm) khung
xương Vĩnh Tường loại 1, tấm thạch cao
LaGyp sản xuất tại Việt nam (bao gồm chi phí
lắp đặt, hoàn thiện)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>280.000</td></tr><tr><td></td><td></td><td>Trần thạch cao giật cấp (trần chìm) khung
xương Vĩnh Tường loại 2, tấm thạch cao
LaGyp sản xuất tại Việt nam (bao gồm chi phí
lắp đặt, hoàn thiện )</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>260.000</td></tr><tr><td></td><td></td><td>Trần thạch cao phẳng (trần thả) khung xương
Vĩnh Tường loại 1, tấm thạch cao LaGyp Phủ
PVC mặt không có hoa văn (bao gồm chi phí
lắp đặt, hoàn thiện )</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>220.000</td></tr></tbody></table>

|<image_2>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Trần thạch cao phẳng ( trần thả) khung xương
Vĩnh Tường loại 1, tấm thạch cao LaGyp Phủ
PVC mặt có hoa văn (bao gồm chi phí lắp đặt,
hoàn thiện )</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr><tr><td></td><td></td><td>Trần thạch cao phẳng (trần thả) khung xương
Vĩnh Tường loại 2, tấm thạch cao LaGyp Phủ
PVC mặt không có hoa văn (bao gồm chi phí
lắp đặt, hoàn thiện )</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.000</td></tr><tr><td></td><td></td><td>Trần thạch cao phẳng (trần thả) khung xương
Vĩnh Tường loại 2, tấm thạch cao LaGyp Phủ
PVC mặt có hoa văn (bao gồm chi phí lắp đặt,
hoàn thiện )</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr></tbody></table>

|<image_3>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td>27</td><td>Trần,
vách
thạch
cao</td><td>Trần nhôm Foster, C-Shaped, màu trắng,
màu đen, màu ghi tiêu chuẩn. Sơn tĩnh điện
gia nhiệt PE.
Phụ kiện: khung xương thép tiêu chuẩn
1,2m/m², móc treo…</td><td></td><td></td><td></td><td>Công ty cổ
phần
FOSTER
Việt Nam</td><td></td><td>Giá thi
công
lắp đặt
tại
thành
phố
Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Trần nhôm Foster C100 phẳng- Shaped, chiều
dày 0,6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>450.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster C150 phẳng- Shaped, chiều
dày 0,6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>410.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster C300 phẳng- Shaped, chiều
dày 0,8mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>570.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster C300 phẳng- Shaped, chiều
dày 0,9mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>630.000</td></tr></tbody></table>

|<image_4>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Trần nhôm Foster, Clip- In bề mặt đục lỗ
D1,8mm, màu trắng tiêu chuẩn, sơn tĩnh
điện gia nhiệt PE.
Phụ kiện: Khung tam giác 1,8m, 02 móc treo,
0,4 nối</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Trần nhôm Foster Clip - in 600x600x0,6 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>440.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Clip - in 600x600x0,7 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>480.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Clip - in 600x600x0,8 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>530.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Clip - in 300x300x0,5 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>370.000</td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Trần nhôm Foster, Lay- In bề mặt đục lỗ
D1,8mm, màu trắng tiêu chuẩn, sơn tĩnh
điện gia nhiệt PE.
Không bao gồm khung và phụ kiện</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Trần nhôm Foster Lay - in T - Black
600x600x0,6 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>510.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Lay - in T - Black
600x600x0,7 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>550.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Lay - in T - Black
600x600x0,8 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>590.000</td></tr></tbody></table>

|<image_6>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Trần nhôm Foster, Lay- In T-Black bề mặt
đục lỗ D1,8mm, màu trắng tiêu chuẩn, sơn
tĩnh điện gia nhiệt PE.
Phụ kiện: Khung T chính, T phụ 1,62m, 02
móc treo, 0,5 nối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Trần nhôm Foster Lay - in T - Black
600x600x0,6 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>510.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Lay - in T - Black
600x600x0,7 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>550.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Lay - in T - Black
600x600x0,8 mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>590.000</td></tr></tbody></table>

|<image_7>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Trần nhôm Foster, Cell (Caro) dày 0,5mm,
màu trắng, đen, ghi tiêu chuẩn, sơn tĩnh điện
gia nhiệt PE.
Phụ kiện: móc treo 1,5 chiếc</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Trần nhôm Foster Caro vuông 50 x 50 x 50 x
15 x 1950mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.240.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Caro vuông 75x75x50x15x
1950mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>690.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Caro vuông
100x100x50x15 x 2000mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>640.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Caro vuông
150x150x50x15 x 1950mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>480.000</td></tr></tbody></table>

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Trần nhôm Foster Caro vuông
200x200x50x15 x 2000mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>420.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Caro tam giác 150 x 150 x
50 x 15 x 1950mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>870.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster Caro tam giác 200 x 200 x
50 x 15 x 2000mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>670.000</td></tr></tbody></table>

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Hệ lam chắn nắng Foster Sun Louver hình
C, Hình S, hình lá liễu, hình đầu đạn, hình
thoi, hình hộp chữ nhật làm từ hợp kim
nhôm; bề mặt sơn tĩnh điện cao cấp Akzo
Nobel (sơn tĩnh điện gia nhiệt PE ngoài
trời). Khung xương và phụ kiện hoàn chỉnh,
chiều dài theo yêu cầu.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Foster Sun Louver 85C (0,6mm), lam
11,5m/m², rộng 85, phụ kiện khung thép 1m</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>480.000</td></tr></tbody></table>

|<image_10>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Foster Sun Louver 85R (0,6mm), lam
13,5m/m², rộng 85, phụ kiện khung thép 1m</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>540.000</td></tr><tr><td></td><td></td><td>Foster Sun Louver 132S(0,6mm), lam 5m/m²,
rộng 132, phụ kiện móc treo 6 chiếc/m²</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>460.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình thoi,
FT - HT 150 x 24 x 1,3mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>390.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình thoi,
FT - HT 200 x 25 x 1,5mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>460.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình thoi,
FT - HT 250 x 50 x 1,3mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>630.000</td></tr></tbody></table>

|<image_11>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình lá
liễu, FT - LL 120 x 1,2mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>310.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình lá
liễu, FT - LL 150 x 1,4mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>390.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình lá
liễu, FT - LL 170 x 1,3mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>410.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình đầu
đạn, FT - DD 150 x 52 x 1,3mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>450.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình đầu
đạn, FT - DD 200 x 52 x 1,5mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>610.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình đầu
đạn, FT - DD 250 x 52 x 1,5mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>770.000</td></tr></tbody></table>

|<image_12>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 150 x 30 x 2,1mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>510.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 150 x 50 x 1.5mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>550.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 150 x 50 x 1,2mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>650.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 200 x 100 x 1.4mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>730.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 250 x 100 x 1.4mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>850.000</td></tr><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 300 x 100 x 1.5mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.018.000</td></tr></tbody></table>

|<image_13>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Lam chắn nắng Foster Sun Louver hình hộp,
FT - HH 400 x 100 x 1.5mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.360.000</td></tr><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Trần nhôm Foster, B- Shaped, màu trắng,
màu đen, màu ghi tiêu chuẩn. Sơn tĩnh điện
gia nhiệt PE
Phụ kiện: khung xương thép tiêu chuẩn.
1,2m/m², móc treo…</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster Multi B230 dày 0.6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>440.000</td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster Multi B180 dày 0.6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>480.000</td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster Multi B130 dày 0.6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>530.000</td></tr></tbody></table>

|<image_14>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Hệ trần nhôm Foster Multi B80 dày 0.6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>580.000</td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster Multi B30 dày 0.6mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>640.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster, G- Shaped, màu trắng,
màu đen, màu ghi tiêu chuẩn. Sơn tĩnh điện
gia nhiệt PE
Phụ kiện: khung xương thép tiêu chuẩn.
1,2m/m², móc treo…</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Trần nhôm Foster G - Shaped G100 chịu gió</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>600.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster G - Shaped G150 chịu gió</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>550.000</td></tr><tr><td></td><td></td><td>Trần nhôm Foster G - Shaped G200 chịu gió</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>500.000</td></tr></tbody></table>

|<image_15>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Trần nhôm Foster G - Shaped G250 chịu gió</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>440.000</td></tr><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Trần nhôm Foster, U - Shaped, màu trắng,
màu đen, màu ghi tiêu chuẩn. Sơn tĩnh điện
gia nhiệt PE, phụ kiện: khung xương thép
tiêu chuẩn. 1,2m/m², móc treo…</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster U - Shaped, 30 x 50, dày
0.6mm (đáy rộng 30mm, chiều cao 50mm,
A100mm)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>530.000</td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster U - Shaped, 30 x 100,
dày 0.6mm (đáy rộng 30mm, chiều cao
100mm, A100mm)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>830.000</td></tr></tbody></table>

<table><thead><tr><th>Hệ trần nhôm Foster U - Shaped, 30 x 50, dày</th></tr></thead><tbody><tr><td>0.6mm (đáy rộng 30mm, chiều cao 50mm,</td></tr><tr><td>A100mm)</td></tr></tbody></table>

<table><thead><tr><th>Hệ trần nhôm Foster U - Shaped, 30 x 100,</th></tr></thead><tbody><tr><td>dày 0.6mm (đáy rộng 30mm, chiều cao</td></tr><tr><td>100mm, A100mm)</td></tr></tbody></table>

|<image_16>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Hệ trần nhôm Foster U - Shaped, 50 x 100,
dày 0.6mm (đáy rộng 50mm, chiều cao
100mm, A100mm)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>840.000</td></tr><tr><td></td><td></td><td>Hệ trần nhôm Foster U - Shaped, 50 x150, dày
0.6mm (đáy rộng 50mm, chiều cao 150mm,
A100mm)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.160.000</td></tr><tr><td></td><td>Trần,
vách
thạch
cao</td><td>Trần Sợi khoáng Foster - FTS615, FTS91,
Vật tư phụ kiện hoàn chỉnh.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Trần sợi khoáng Foster - FTS915V,
900x600x15mm cạnh vuông</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>460.000</td></tr><tr><td></td><td></td><td>Trần sợi khoáng Foster - FTS615V,
600x600x15mm cạnh vuông</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>420.000</td></tr></tbody></table>

<table><thead><tr><th>Hệ trần nhôm Foster U - Shaped, 50 x 100,</th></tr></thead><tbody><tr><td>dày 0.6mm (đáy rộng 50mm, chiều cao</td></tr><tr><td>100mm, A100mm)</td></tr></tbody></table>

<table><thead><tr><th>Hệ trần nhôm Foster U - Shaped, 50 x150, dày</th></tr></thead><tbody><tr><td>0.6mm (đáy rộng 50mm, chiều cao 150mm,</td></tr><tr><td>A100mm)</td></tr></tbody></table>

<table><thead><tr><th>Trần sợi khoáng Foster - FTS915V,</th></tr></thead><tbody><tr><td>900x600x15mm cạnh vuông</td></tr></tbody></table>

<table><thead><tr><th>Trần sợi khoáng Foster - FTS615V,</th></tr></thead><tbody><tr><td>600x600x15mm cạnh vuông</td></tr></tbody></table>

|<image_17>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Trần sợi khoáng Foster - FTS615G,
600x600x15mm cạnh gờ</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>490.000</td></tr><tr><td>28</td><td>Trần,
vách
thạch
cao</td><td>Tấm nhựa loại 60x60 cm</td><td>m2</td><td></td><td></td><td></td><td></td><td>Giá bán
tại
thành
phố
Cao
Bằng</td><td></td><td>60.000</td></tr><tr><td></td><td></td><td>Tấm nhựa + khung xương loại 60 x 60</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>130.000</td></tr><tr><td>29</td><td>Vật
liệu
tấm
lợp,
bao
che</td><td>a. Tôn Austnam</td><td></td><td>ASTM
A755/A792/A924</td><td></td><td>CÔNG TY
CỔ PHẦN
AUSNTAM</td><td>Việt
Nam</td><td>Đã bao
gồm chi
phí vận
chuyển</td><td></td><td></td></tr><tr><td></td><td></td><td>Tôn 11 sóng AC11-0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>196.364</td></tr><tr><td></td><td></td><td>Tôn 11 sóng AC11-0,47mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Tôn 6 sóng ATEK1000 -0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>197.273</td></tr><tr><td></td><td></td><td>Tôn 6 sóng ATEK1000 - 0,47mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.909</td></tr><tr><td></td><td></td><td>Tôn 5 sóng ATEK1088 - 0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>192.727</td></tr><tr><td></td><td></td><td>Tôn 5 sóng ATEK1088 - 0,47mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>197.273</td></tr></tbody></table>

<table><thead><tr><th>Trần sợi khoáng Foster - FTS615G,</th></tr></thead><tbody><tr><td>600x600x15mm cạnh gờ</td></tr></tbody></table>

|<image_18>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tôn 11 sóng AD11 - 0,42mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>182.727</td></tr><tr><td></td><td></td><td>Tôn 11 sóng AD11 - 0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>188.182</td></tr><tr><td></td><td></td><td>Tôn 6 sóng AD06 - 0,42mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>183.636</td></tr><tr><td></td><td></td><td>Tôn 6 sóng AD06 - 0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Tôn 5 sóng AD05 - 0,42mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>180.000</td></tr><tr><td></td><td></td><td>Tôn 5 sóng AD05 - 0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>187.273</td></tr><tr><td></td><td></td><td>Tôn sóng giả ngói ADTile - 0,42mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>191.818</td></tr><tr><td></td><td></td><td>Tôn không vít Alok 420 - 0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>250.909</td></tr><tr><td></td><td></td><td>Tôn không vít Alok 420 - 0,47mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>256.364</td></tr><tr><td></td><td></td><td>Tôn không vít ASEAM 480 - 0,45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr><tr><td></td><td></td><td>Tôn không vít ASEAM 480 - 0,47mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>234.545</td></tr></tbody></table>

|<image_19>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tôn 3 lớp AR-EPS - 0.40/50/0.35, Tỉ trọng
EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>362.727</td></tr><tr><td></td><td></td><td>Tôn 3 lớp AR-EPS - 0.45/50/0.35, Tỉ trọng
EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>378.182</td></tr><tr><td></td><td></td><td>Tôn 3 lớp AR-EPS - 0.40/50/0.40, Tỉ trọng
EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>382.727</td></tr><tr><td></td><td></td><td>Tôn 3 lớp AR-EPS - 0.45/50/0.40, Tỉ trọng
EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>395.455</td></tr><tr><td></td><td></td><td>Tấm vách 3 lớp AP-EPS - 0.35/50/0.35, Tỉ
trọng EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>317.273</td></tr><tr><td></td><td></td><td>Tấm vách 3 lớp AP-EPS - 0.40/50/0.35, Tỉ
trọng EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>328.182</td></tr><tr><td></td><td></td><td>Tấm vách 3 lớp AP-EPS - 0.40/50/0.40, Tỉ
trọng EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>338.182</td></tr><tr><td></td><td></td><td>Tấm vách 3 lớp AP-EPS - 0.45/50/0.40, Tỉ
trọng EPS 11kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>350.000</td></tr></tbody></table>

|<image_20>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tôn xốp APU1-0,45mm, lớp Pu tỉ trọng 28-32
kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>285.455</td></tr><tr><td></td><td></td><td>Tôn xốp APU1-0,47mm, lớp Pu tỉ trọng 28-32
kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>289.091</td></tr><tr><td></td><td></td><td>Tôn xốp APU1-0,45mm, lớp Pu tỉ trọng 28-32
kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>281.818</td></tr><tr><td></td><td></td><td>Tôn xốp APU1-0,47mm, lớp Pu tỉ trọng 28-32
kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>286.364</td></tr><tr><td></td><td></td><td>Tôn xốp ADPU1-0,40mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>265.455</td></tr><tr><td></td><td></td><td>Tôn xốp ADPU1-0,42mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>271.818</td></tr><tr><td></td><td></td><td>Tôn xốp ADPU1-0,40mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>261.818</td></tr><tr><td></td><td></td><td>Tôn xốp ADPU1-0,42mm, lớp Pu tỉ trọng 28-
32 kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>268.182</td></tr></tbody></table>

|<image_21>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tôn khổ rộng 300 mm, dày 0,42mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>53.636</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 400 mm, dày 0,42mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>70.455</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 600 mm, dày 0,42mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>100.909</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 300 mm, dày 0,45mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>58.636</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 400 mm, dày 0,45mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>76.818</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 600 mm, dày 0,45mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>110.909</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 300 mm, dày 0,47mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>59.545</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 400 mm, dày 0,47mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>78.636</td></tr><tr><td></td><td></td><td>Tôn khổ rộng 600 mm, dày 0,47mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>113.636</td></tr><tr><td></td><td></td><td>b. Tôn Suntek</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Tôn EC11 (11 sóng) dày 0.40mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>125.455</td></tr><tr><td></td><td></td><td>Tôn EC11 (11 sóng) dày 0.45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>137.273</td></tr></tbody></table>

|<image_22>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tôn EK106 (6 sóng) dày 0.40mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>126.364</td></tr><tr><td></td><td></td><td>Tôn EK106 (6 sóng) dày 0.45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>138.182</td></tr><tr><td></td><td></td><td>Tôn EK108 (5 sóng) dày 0.40mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>123.636</td></tr><tr><td></td><td></td><td>Tôn EK108 (5 sóng) dày 0.45mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>135.455</td></tr><tr><td></td><td></td><td>Tôn ELOK 420 dày 0.45mm , G550 (3 sóng)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Tôn ESEAM 480 dày 0.45mm, G340 (2 sóng)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>183.636</td></tr><tr><td></td><td></td><td>Tôn EPU1 (11 sóng) dày 0.40mm, lớp PU tỷ
trọng 28-32kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>218.182</td></tr><tr><td></td><td></td><td>Tôn EPU1 (11 sóng) dày 0.45mm, lớp PU tỷ
trọng 28-32kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr><tr><td></td><td></td><td>Tôn EPU1 (6 sóng) dày 0.40mm, lớp PU tỷ
trọng 28-32kg/m3</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>217.273</td></tr></tbody></table>

|<image_23>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tôn EPU1 (6 sóng) dày 0.45mm, lớp PU tỷ
trọng 28-32kg/m33</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>229.091</td></tr><tr><td></td><td></td><td>Khổ 300mm dày 0.40mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>50.000</td></tr><tr><td></td><td></td><td>Khổ 400mm dày 0.40mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>53.636</td></tr><tr><td></td><td></td><td>Khổ 600mm dày 0.40mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>74.545</td></tr><tr><td></td><td></td><td>Khổ 300mm dày 0.45mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>45.455</td></tr><tr><td></td><td></td><td>Khổ 400mm dày 0.45mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>58.182</td></tr><tr><td></td><td></td><td>Khổ 600mm dày 0.45mm</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>82.727</td></tr><tr><td>30</td><td>Vật
liệu
tấm
lợp,
bao
che</td><td>Tấm lợp nhựa Tiền phong 1,5x0,8m</td><td>Tấm</td><td></td><td></td><td></td><td></td><td>Giá bán
tại
thành
phố
Cao
Bằng</td><td></td><td>54.450</td></tr><tr><td>31</td><td>Vật
liệu
tấm</td><td>Tấm lợp Fibrô xi măng Thái Nguyên (KT: 0,9
x 1,5m)</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>42.000</td></tr></tbody></table>

|<image_24>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td>lợp,
bao
che</td><td>Tấm lợp Fibrô xi măng Đông Anh (KT: 0,9 x
1,5m)</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>55.000</td></tr><tr><td></td><td></td><td>Fibrô xi măng úp nóc Thái Nguyên</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>12.000</td></tr><tr><td></td><td></td><td>Fibrô xi măng úp nóc Đông Anh</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>15.000</td></tr><tr><td>32</td><td>Vật
liệu
tấm
lợp,
bao
che</td><td>Sản phẩm Bê tông nhẹ khí chưng áp ALC
và AAC</td><td></td><td></td><td></td><td>Công ty
TNHH An
Phát CBG</td><td>Việt
Nam</td><td>Giá trên
địa bàn
thành
phố
Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Tấm Panel Bê tông nhẹ khí chưng áp SCL-
ALC-LC (không lõi thép) KT:D*R*C=
Lx60xH(cm)
L: Chiều dài tấm cắt theo yêu, cầu tối đa 4,8m
- Áp dụng đói với số lượng lớn
H: Chiều dày tấm gồm các modul: 10cm;
15cm; 20cm</td><td>m3</td><td>TCVN 12867:
2020</td><td></td><td></td><td></td><td></td><td></td><td>2.491.667</td></tr></tbody></table>

|<image_25>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tấm Panel Bê tông nhẹ khí chưng áp SCL-
ALC-L1 (1 lõi thép) KT:D*R*C=
Lx60xH(cm)</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.508.333</td></tr><tr><td></td><td></td><td>Tấm Panel Bê tông nhẹ khí chưng áp SCL-
ALC-L2 (2 lõi thép) KT:D*R*C=
Lx60xH(cm)</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.722.222</td></tr><tr><td></td><td></td><td>Gạch Bê tông nhẹ khí chưng áp SCL-AAC
Block B3. KT: D*R*C =60x20xH(cm) Chiều
dày Block gồm các modul: 7,5cm, 10cm,
15cm,20cm.</td><td>m3</td><td>QCVN 16: 2019</td><td></td><td></td><td></td><td></td><td></td><td>1.707.407</td></tr><tr><td></td><td></td><td>- Gạch Block 60x20x7,5cm (Quy đổi:
1m3=111 viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>15.382</td></tr><tr><td></td><td></td><td>- Gạch Block 60x20x10cm (Quy đổi: 1m3=83
viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>20.571</td></tr></tbody></table>

|<image_26>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>- Gạch Block 60x20x15cm (Quy đổi: 1m3=55
viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>31.044</td></tr><tr><td></td><td></td><td>- Gạch Block 60x20x20cm (Quy đổi: 1m3=41
viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>41.644</td></tr><tr><td></td><td></td><td>Gạch Bê tông nhẹ khí chưng áp SCL-AAC
Block B4. KT: D*R*C=60x20xH(cm) Chiều
dày Block gồm các modul: 7,5cm, 10cm,
15cm, 20cm.</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.830.556</td></tr><tr><td></td><td></td><td>- Gạch Block 60x20x7,5cm (Quy đổi:
1m3=111 viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>16.491</td></tr><tr><td></td><td></td><td>- Gạch Block 60x20x10cm (Quy đổi: 1m3=83
viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>22.055</td></tr><tr><td></td><td></td><td>- Gạch Block 60x20x15cm (Quy đổi: 1m3=55
viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>33.283</td></tr></tbody></table>

|<image_27>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>- Gạch Block 60x20x20cm (Quy đổi: 1m3=41
viên)</td><td>viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>44.648</td></tr><tr><td></td><td></td><td>Vữa xây gạch AAC SCL-Mortar, Bao 50kg</td><td>bao</td><td>TCVN
9028:2011;</td><td></td><td></td><td></td><td></td><td></td><td>142.593</td></tr><tr><td></td><td></td><td>Vữa xây gạch AAC SCL-Mortar, Bao 50kg</td><td>bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td>132.870</td></tr><tr><td></td><td></td><td>Vữa trát gạch AAC SCL-Mortar, Bao 50kg</td><td>bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td>122.222</td></tr><tr><td></td><td></td><td>Vữa trát gạch AAC SCL-Mortar, Bao 50kg</td><td>bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td>111.667</td></tr><tr><td></td><td></td><td>Vữa xây các loại gạch đá SCL-Mortar, Bao
50kg</td><td>bao</td><td>TCVN 4314:
2003</td><td></td><td></td><td></td><td></td><td></td><td>101.852</td></tr><tr><td></td><td></td><td>Vữa xây các loại gạch đá SCL-Mortar, Bao
50kg</td><td>bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td>95.370</td></tr><tr><td></td><td></td><td>Vữa liên kết tấm Panel SCL-Ekoflex, Bao
25kg</td><td>bao</td><td>TCVN 9028:
2011</td><td></td><td></td><td></td><td></td><td></td><td>163.889</td></tr><tr><td></td><td></td><td>Keo dán gạch đá SCL-EkoTex, Bao 25kg</td><td>bao</td><td>TCVN 7899-1:
2008</td><td></td><td></td><td></td><td></td><td></td><td>152.778</td></tr><tr><td></td><td></td><td>Tấm Xi Măng Dura Flex Pháp - Việt
Nam(LD)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_28>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam(LD)
4.5mm</td><td>Tấm</td><td>TCVN 8258:
2009</td><td></td><td></td><td></td><td></td><td></td><td>172.222</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam(LD)
6mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>234.259</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam(LD)
8mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>330.556</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam(LD)
9mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.926</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam (LD)
10mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>467.593</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam(LD)
12mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>512.037</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp-Việt Nam(LD)
16mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>615.741</td></tr><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp-Việt Nam(LD)
18mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>676.852</td></tr></tbody></table>

|<image_29>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Tấm Xi măng Dura Flex Pháp -Việt Nam(LD)
20mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>762.593</td></tr><tr><td></td><td></td><td>Sản phẩm Cốp pha nhựa Maxcop</td><td></td><td>TCVN ISO
9001:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Tấm Cốp pha nhựa Maxcop dày 15mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>636.111</td></tr><tr><td></td><td></td><td>Tấm Cốp pha nhựa Maxcop dày 15mm</td><td>Tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td>755.556</td></tr><tr><td></td><td></td><td>CX MEN - Xi măng chống thấm, ký hiệu:
PCB 40</td><td></td><td>QCVN
7239:2014</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Xi măng chống thấm cao cấp CX Men, Bao
25kg</td><td>bao</td><td></td><td></td><td></td><td></td><td></td><td></td><td>762.593</td></tr><tr><td></td><td></td><td>Nhân công lắp dựng tấm Panel SCL-ALC
và định mức chi phí VL phụ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Nhân công lắp dựng tấm Panel SCL-ALC</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>100.000</td></tr></tbody></table>

|<image_30>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Định mức chi phí vật liệu phụ khi lắp dựng
tấm Panel ALC bê tông khí chưng áp (gồm:
keo liên kết tấm; ke thép mạ kẽm; đinh 7cm)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>30.000</td></tr><tr><td>33</td><td>Vật tư
ngành
điện</td><td>Dây đồng đơn cứng bọc PVC - 300/500V:
TCVN 6610-3</td><td></td><td>TCVN 5935-1</td><td></td><td>Công ty cổ
phần cáp
điện Việt
Nam-
CADIVI</td><td>Việt
Nam</td><td>Giá trên
địa bàn
tỉnh
Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>VC – 0,5-(F0,80) - 300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.250</td></tr><tr><td></td><td></td><td>VC – 1,0-(F1,13) - 300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.730</td></tr><tr><td></td><td></td><td>Dây điện mềm dẻo bọc nhựa PVC -0,6/1kV:
TCCS 10C:2011 (ruột đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>VCmd - 2x0,5-(2x16/0.2)-0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.260</td></tr><tr><td></td><td></td><td>VCmd - 2x0,75-(2x24/0.2)-0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.020</td></tr></tbody></table>

|<image_31>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>VCmd - 2x1-(2x32/0.2)-0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.710</td></tr><tr><td></td><td></td><td>VCmd - 2x1,5-(2x30/0.25)- 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>10.990</td></tr><tr><td></td><td></td><td>VCmd -2x2,5 -(2x50/0.25)- 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>17.820</td></tr><tr><td></td><td></td><td>Dây điện mềm bọc nhựa PVC -300/500V:
TCCS 6610-5 (ruột đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>VCmo - 2x1-(2x32/0.2)-300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.860</td></tr><tr><td></td><td></td><td>VCmo - 2x1.5-(2x30/0.25)-300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>12.480</td></tr><tr><td></td><td></td><td>VCmo - 2x6-(2x7x12/0.3)-300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>45.420</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 450/750V - TCVN
6610-3:2000 (ruột đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CV-1,5 (7/0,52) – 450/750V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.720</td></tr></tbody></table>

|<image_32>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>CV-2,5 (7/0,67) – 450/750V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>9.320</td></tr><tr><td></td><td></td><td>CV-10 (7/1,35) – 450/750V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>34.300</td></tr><tr><td></td><td></td><td>CV-50 (19/1,8) – 450/750V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>155.020</td></tr><tr><td></td><td></td><td>CV-240 (61/2,25) – 450/750V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>778.890</td></tr><tr><td></td><td></td><td>CV-300 (61/2,52) – 450/750V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>976.960</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 0,6/1kV - TCVN 5935
(1 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-1,0 (1x7/0,425) – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.400</td></tr><tr><td></td><td></td><td>CVV-1,5 (1x7/0,52) – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.210</td></tr><tr><td></td><td></td><td>CVV-6,0 (1x7/1,04) – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>24.310</td></tr><tr><td></td><td></td><td>CVV-25 – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>87.340</td></tr><tr><td></td><td></td><td>CVV-50 – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>161.810</td></tr><tr><td></td><td></td><td>CVV-95 – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>316.000</td></tr></tbody></table>

|<image_33>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>CVV-150 – 0,6/1KV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>488.840</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 300/500V - TCVN
6610-4 (2 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-2x1,5 (2x7/0,52) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>18.340</td></tr><tr><td></td><td></td><td>CVV-2x4 (2x7/0,85) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>38.930</td></tr><tr><td></td><td></td><td>CVV-2x10 (2x7/1,35) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>86.830</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 300/500V - TCVN
6610-4 (3 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-3x1,5 (3x7/0,52) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>24.210</td></tr><tr><td></td><td></td><td>CVV-3x2,5 (3x7/0,67) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>35.840</td></tr><tr><td></td><td></td><td>CVV-3x6 (3x7/1,04) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>74.780</td></tr></tbody></table>

|<image_34>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Cáp điện lực hạ thế - 300/500V - TCVN
6610-4 (4 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-4x1,5 (4x7/0,52) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>30.800</td></tr><tr><td></td><td></td><td>CVV-4x2,5 (4x7/0,67) -300/500V</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>45.630</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 0,6/1kV - TCVN 5935
(2 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-2x16 - 0,6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>134.620</td></tr><tr><td></td><td></td><td>CVV-2x25 - 0,6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>195.190</td></tr><tr><td></td><td></td><td>CVV-2x150 - 0,6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.021.760</td></tr><tr><td></td><td></td><td>CVV-2x185 - 0,6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.271.840</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 0,6/1kV - TCVN 5935
(3 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-3x16 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>186.330</td></tr></tbody></table>

|<image_35>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>CVV-3x50 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>502.020</td></tr><tr><td></td><td></td><td>CVV-3x95 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>975.720</td></tr><tr><td></td><td></td><td>CVV-3x120 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.263.090</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 0,6/1kV - TCVN 5935
(4 lõi, ruột đồng, vỏ PVC cách điện)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-4x16 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>239.170</td></tr><tr><td></td><td></td><td>CVV-4x25 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>361.840</td></tr><tr><td></td><td></td><td>CVV-4x50 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>661.470</td></tr><tr><td></td><td></td><td>CVV-4x120 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.673.440</td></tr><tr><td></td><td></td><td>CVV-4x185 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.487.040</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế - 0,6/1kV - TCVN 5935
(3 lõi pha + 1 lõi đất, ruột đồng, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV-3x16+1x10(3x7/1,7+1x7/1,35)</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>224.850</td></tr><tr><td></td><td></td><td>CVV-3x25+1x16 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>331.150</td></tr></tbody></table>

|<image_36>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>CVV-3x50 +1x25 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>588.650</td></tr><tr><td></td><td></td><td>CVV-3x95+1x50 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.135.470</td></tr><tr><td></td><td></td><td>CVV-3x120+1x70 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.497.620</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế có giaps bảo vệ - 0,6/1kV
- TCVN 5935 (1 lõi, ruột đồng, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV/DATA - 25 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>119.790</td></tr><tr><td></td><td></td><td>CVV/DATA - 50 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.750</td></tr><tr><td></td><td></td><td>CVV/DATA - 95 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>359.060</td></tr><tr><td></td><td></td><td>CVV/DATA - 240 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>859.540</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế có giáp bảo vệ- 0,6/1kV -
TCVN 5935 (2 lõi, ruột đồng, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_37>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>CVV/DSTA - 2x4 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>61.700</td></tr><tr><td></td><td></td><td>CVV/DSTA - 2x10 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>108.050</td></tr><tr><td></td><td></td><td>CVV/DSTA - 2x50 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.020</td></tr><tr><td></td><td></td><td>CVV/DSTA - 2x150 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.105.810</td></tr><tr><td></td><td></td><td>Cáp điện lực hạ thế có giáp bảo vệ- 0,6/1kV -
TCVN 5935 (3 lõi, ruột đồng, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x6 (3x7/1.04) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>101.350</td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x16 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>208.270</td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x50 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>534.260</td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x185 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.980.380</td></tr></tbody></table>

|<image_38>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Cáp điện lực hạ thế có giáp bảo vệ- 0,6/1kV -
TCVN 5935 (3 lõi pha + 1 lõi đất, ruột
đồng,cách điện PVC, giáp bang thép bảo vệ,
vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x4+1x2,5 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>89.610</td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x16+1x10 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>250.600</td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x50+1x25 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>628.510</td></tr><tr><td></td><td></td><td>CVV/DSTA - 3x240+1x150 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.107.510</td></tr><tr><td></td><td></td><td>Dây đồng trần xoắn (TCVN - 5064)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Dây đồng trần xoắn, tiết diện &gt;4 đến ≤ 10mm2
C-10</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>31.920</td></tr></tbody></table>

|<image_39>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Dây đồng trần xoắn, tiết diện &gt;10 đến ≤
50mm2 C-50</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>159.160</td></tr><tr><td></td><td></td><td>Cáp điện kế - 0,6/1kV - TCVN 5935 (2 lõi,
ruột đồng, cách điện PVC, vỏ PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>DK-CVV- 2x4 (2x7/0,85) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>52.430</td></tr><tr><td></td><td></td><td>DK-CVV- 2x10 (2x7/0,85) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>105.370</td></tr><tr><td></td><td></td><td>DK-CVV- 2x35 - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>283.560</td></tr><tr><td></td><td></td><td>Cáp điều khiển - 0,6/1kV - TCVN 5935
(2→37 lõi, ruột đồng, cách điện PVC, vỏ
PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>DVV - 2x1,5 (2x7/0,52) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>19.370</td></tr><tr><td></td><td></td><td>DVV - 10x2,5 (10x7/0,67) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>104.750</td></tr></tbody></table>

|<image_40>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>DVV - 19x4 (19x7/0,52) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>299.940</td></tr><tr><td></td><td></td><td>DVV - 37x2,5 (37x7/0,67) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>368.530</td></tr><tr><td></td><td></td><td>Cáp điều khiển có màn chắn chống nhiễu -
0,6/1kV - TCVN 5935 (2→37 lõi, ruột đồng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>DVV/Sc - 3x1,5 (3x7/0,52) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>36.670</td></tr><tr><td></td><td></td><td>DVV/Sc - 8x2,5 (8x7/0,67) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>102.790</td></tr><tr><td></td><td></td><td>DVV/Sc - 30x2,5 (30x7/0,67) - 0.6/1kv</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>325.270</td></tr><tr><td></td><td></td><td>Cáp trung thế treo -12/20(24)kV hoặc
12,7/22(24)kV - TCVN 5935 (ruột đồng, có
chống thấm bán dẫn ruột dẫn, cách điện
XLPE)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_41>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>CX1V/WBC-95-12/20(24)kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>376.980</td></tr><tr><td></td><td></td><td>CX1V/WBC-240-12/20(24)kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>886.930</td></tr><tr><td></td><td></td><td>Cáp trung thế có màn chắn kim loại có giáp
bảo vệ -12/20(24)kV hoặc 12,7/22(24)kV -
TCVN 5935 (ruột đồng, có chống thấm bán
dẫn ruột dẫn, cách điện XLPE, bán dẫn cách
điện, màn chắn kim loại cho từng lõi, vỏ
PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CXV/SE-DSTA-3x50-12/20(24)kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>941.730</td></tr><tr><td></td><td></td><td>CXV/SE-DSTA-3x400-12/20(24)kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.781.050</td></tr><tr><td></td><td></td><td>Dây điện lực ruột nhôm, bọc cách điện PVC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_42>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>AV-16 - 0.6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.310</td></tr><tr><td></td><td></td><td>AV- 35 - 0.6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>13.420</td></tr><tr><td></td><td></td><td>AV-120 - 0.6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>41.870</td></tr><tr><td></td><td></td><td>AV- 500 - 0.6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>166.420</td></tr><tr><td></td><td></td><td>Dây nhôm lõi thép TCVN 5064-1904; TCVN
5064:1994/SĐ:1995; TCVN 6483/IEC 61089
ASTN B232,DIN 48204</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>ACSR-50/8 (6/3.2+1/3.2) TCVN-5064</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>17.600</td></tr><tr><td></td><td></td><td>ACSR-95/16 (6/4.5+1/4.5) TCVN-5064</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>34.090</td></tr><tr><td></td><td></td><td>ACSR-240/32 (24/3.6+7/2.4 TCVN-5064</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>84.870</td></tr></tbody></table>

|<image_43>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Cáp vặn xoắn hạ thế 0,6/1kV - TCVN
6447/AS 3560 (2 lõi, ruột nhôm, cách điện
XLPE)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>LV- ABC - 2x50 - 0.6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>40.920</td></tr><tr><td></td><td></td><td>Ống luồn dây điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Ống luồn tròn F16-CA16M (ống dài 2,9m)</td><td>ống</td><td></td><td></td><td></td><td></td><td></td><td></td><td>22.870</td></tr><tr><td></td><td></td><td>Ống luồn cứng 1250N F16-CA16H (ống dài
2,9m)</td><td>ống</td><td></td><td></td><td></td><td></td><td></td><td></td><td>26.540</td></tr><tr><td></td><td></td><td>Ống luồn dây điện đàn hồi CAF16 (cuộn 50m)</td><td>cuộn</td><td></td><td></td><td></td><td></td><td></td><td></td><td>213.790</td></tr><tr><td></td><td></td><td>Ống luồn dây điện đàn hồi CAF20 (cuộn 50m)</td><td>cuộn</td><td></td><td></td><td></td><td></td><td></td><td></td><td>296.910</td></tr></tbody></table>

|<image_44>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,

### BAO CHE, VẬT TƯ NGÀNH ĐIỆN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD638</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: TRẦN VÁCH THẠCH CAO, VẬT LIỆU TẤM LỢP,
BAO CHE, VẬT TƯ NGÀNH ĐIỆN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật
liệu</th><th>Tên vật liệu/loại vật liệu xây dựng (*)</th><th>Đơn
vị
tính
(*)</th><th>Tiêu chuẩn kỹ
thuật</th><th>Quy
cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi
chú</th><th>Giá bán
chưa bao
gồm thuế giá
trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Cáp điện lực hạ thế chống cháy 0,6/1kV -
TCVN 5935/IEC 60331-21, IEC 60332-3
CAT C, BS 6387 CAT C (1 lõi, ruột đồng,
cách điện FR-PVC)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>CV/FR-1x25 - 0,6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>93.830</td></tr><tr><td></td><td></td><td>CV/FR-1x240 - 0,6/1kV</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>815.140</td></tr><tr><td></td><td></td><td>Cáp năng lượng mặt trời H1Z2Z2-K-1,5kV
DC</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>H1Z2Z2-K-4-1,5kV DC</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>22.040</td></tr><tr><td></td><td></td><td>H1Z2Z2-K-6-1,5kV DC</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>31.420</td></tr><tr><td></td><td></td><td>H1Z2Z2-K-300-1,5kV DC</td><td>m</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.207.880</td></tr></tbody></table>

|<image_45>|


