# Public_470

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>HƯỚNG DẪN KHAI BÁO QOS CHO
THIẾT BỊ TRUYỀN DẪN VIBA</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Thuộc tính</th><th></th><th>Đối chiếu TCVN 7980:</th><th></th><th>Đối chiếu AGRMS</th></tr></thead><tbody><tr><td></td><td></td><td>2008</td><td></td><td></td></tr><tr><td>1. Phân loại bề mặt</td><td></td><td></td><td></td><td>Face Category</td></tr><tr><td>2. Phân loại vật thể</td><td></td><td></td><td></td><td>Category</td></tr><tr><td>3. Định danh</td><td>Định danh (bổ sung thêm
thuộc tính con chuỗi định
danh, giá trị định danh)</td><td></td><td></td><td>Identifier</td></tr><tr><td>4. Tiêu đề</td><td>Tiêu đề (tương thích toàn
bộ)</td><td></td><td></td><td>Name</td></tr><tr><td>5. Tác giả</td><td>Tác giả (tương thích toàn
bộ)</td><td></td><td></td><td></td></tr><tr><td>6. Chủ đề</td><td>Chủ đề (tương thích toàn
bộ)</td><td></td><td></td><td>Keyword</td></tr><tr><td>7. Mô tả</td><td>Mô tả (tương thích toàn bộ)</td><td></td><td></td><td>Description</td></tr><tr><td>8. Ngày</td><td>Ngày tháng (bổ sung thêm
thuộc tính con ngày bắt
đầu, ngày kết thúc)</td><td></td><td></td><td>Date Range</td></tr><tr><td>9. Loại bảo mật</td><td>Security Classification</td><td></td><td></td><td></td></tr><tr><td>10. Quyền</td><td>Quyền (bổ sung thêm
thuộc tính con kiểu quyền,
trạng thái quyền)</td><td></td><td></td><td>Rights</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>HƯỚNG DẪN KHAI BÁO QOS CHO
THIẾT BỊ TRUYỀN DẪN VIBA</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>11. Ngôn ngữ</th><th>Ngôn ngữ (tương thích
toàn bộ)</th><th>Language</th></tr></thead><tbody><tr><td>12. Phạm vi</td><td>Phạm vi (bổ sung thêm
thuộc tính con phạm vi
thẩm quyền, phạm vi thời
gian, phạm vi không gian)</td><td>Coverage</td></tr><tr><td>13. Loại bỏ</td><td>Disposal</td><td></td></tr><tr><td>14. Định dạng</td><td>Định dạng (bổ sung thêm
thuộc tính con tên định
dạng, phiên bản định dạng,
tên ứng dụng, phiên bản
ứng dụng)</td><td>Format</td></tr><tr><td>15. Độ lớn</td><td></td><td>Extent</td></tr><tr><td>16. Phương tiện lưu
trữ</td><td></td><td>Medium</td></tr><tr><td>17. Vị trí</td><td></td><td>Location</td></tr><tr><td>18. Kiểu</td><td>Kiểu (tương thích toàn bộ)</td><td>Document Form</td></tr><tr><td>19. Loại máy quét
3D</td><td></td><td></td></tr><tr><td>20. Chất liệu đối
tượng</td><td></td><td></td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>HƯỚNG DẪN KHAI BÁO QOS CHO
THIẾT BỊ TRUYỀN DẪN VIBA</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th></tr></thead><tbody><tr><td></td></tr></tbody></table>

|<image_3>|

|<image_4>|

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>HƯỚNG DẪN KHAI BÁO QOS CHO
THIẾT BỊ TRUYỀN DẪN VIBA</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>HƯỚNG DẪN KHAI BÁO QOS CHO
THIẾT BỊ TRUYỀN DẪN VIBA</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Nghĩa
vụ</th><th>Quá trình số
hóa 3D</th><th>Các thuộc tính đánh chỉ số số hóa 3D</th></tr></thead><tbody><tr><td>Bắt buộc</td><td>Quét dữ liệu
3D</td><td>- Đối tượng, dữ liệu 3D liên quan;
- Ngày và thời gian số hóa 3D (Lưu ý: thời gian
được khuyến khích, nhưng không bắt buộc);
- Số lượng vật thể được số hóa;
- Người vận hành máy quét 3D và tên, nhãn hiệu,
quốc gia sản xuất máy quét 3D;
- Thông tin tham khảo chéo về dữ liệu 3D.</td></tr><tr><td></td><td>Quét lại (nếu
quá trình này
là cần thiết)</td><td>- Đối tượng, dữ liệu 3D liên quan;
- Ngày và thời gian số hóa 3D (Lưu ý: thời gian
được khuyến khích, nhưng không bắt buộc);
- Số lượng vật thể được số hóa;
- Người vận hành máy quét 3D và tên, nhãn hiệu,
quốc gia sản xuất máy quét 3D;
- Thông tin tham khảo chéo về dữ liệu 3D.</td></tr><tr><td></td><td>Đảm bảo chất
lượng (khi</td><td>- Tài liệu tham khảo hàng loạt (bắt buộc cho hàng
loạt đầu vào);</td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>HƯỚNG DẪN KHAI BÁO QOS CHO
THIẾT BỊ TRUYỀN DẪN VIBA</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>hoàn thành)</th><th>- Người thực hiện đảm bảo chất lượng;
- Ngày phê duyệt kiểm tra đảm bảo chất lượng.</th></tr></thead><tbody><tr><td>Bắt buộc
nếu có
thể</td><td>Chuyển dữ liệu
3D</td><td>- Ngày chuyển
- Tiêu đề chuyển
- Chuyển mô tả
- Lý do chuyển
- Tiếp nhận chuyển</td></tr></tbody></table>

|<image_8>|


