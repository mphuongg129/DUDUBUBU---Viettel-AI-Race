# Public_648

## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>1</td><td></td><td></td><td>Đồ gá</td><td></td><td></td><td>7219</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>Bằng thép không gỉ. Kích thước 2,5 x 138,4 x 48 mm.</td><td></td></tr><tr><td></td><td>2</td><td></td><td></td><td>Kết cấu thép cơ khí các loại</td><td></td><td></td><td>7308</td><td></td><td></td><td>40</td><td></td><td></td><td>10</td><td></td><td></td><td>Chế tạo thiết bị sử dụng trong hầm lò</td><td></td></tr><tr><td></td><td>3</td><td></td><td></td><td>Giàn phản xạ VOR</td><td></td><td></td><td>7308</td><td></td><td></td><td>20</td><td></td><td></td><td>29</td><td></td><td></td><td>Tiêu chuẩn ICAO</td><td></td></tr><tr><td>4</td><td></td><td></td><td>Thùng phuy đựng phốt pho</td><td></td><td></td><td>7310</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Bằng sắt hoặc thép. Kích thước 500 x 800 mm, áp suất thử kín 30 kPa, áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>suất thử thủy lực 250 kPa, dung tích đến 157 lít.</td><td></td></tr><tr><td>5</td><td></td><td></td><td>Bồn áp lực hình trụ nằm ngang đặt trên xe
chuyên dụng</td><td></td><td></td><td>7311</td><td></td><td></td><td>0</td><td></td><td></td><td>99</td><td></td><td></td><td>Dung tích chứa đến 40 m3, áp suất làm việc đến 40 kg/cm3. Chuyên chứa
LPG, NH3, Cl2, O2.</td><td></td><td></td></tr><tr><td>6</td><td></td><td></td><td>Máng cào tải than, đá hầm lò</td><td></td><td></td><td>7325</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 02:2016/CKMK, năng suất đến 150 t/h, chiều dài vận chuyển đến 100</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>m, công suất đến 40 kW, vận tốc xích đến 0,88 m/s.</td><td></td></tr><tr><td>7</td><td></td><td></td><td></td><td>Thiết bị làm kín đầu lò quay xi măng (Kiln Inlet</td><td></td><td>7326</td><td></td><td></td><td>90</td><td></td><td></td><td>99</td><td></td><td></td><td>Dùng cho lò quay công suất 3.000 tấn xi măng/năm</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Seal)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td></td><td></td><td>Giàn chống mềm</td><td></td><td></td><td>7380</td><td></td><td></td><td>40</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>TCCS 15:2018/CKMK. Chiều dày khai thác than từ 2500 mm đến 3500 mm,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chiều rộng xà giàn 320 mm, khoảng cách giữa tâm của giàn chống 350-390</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mm. Kích thủy lực xà đuôi F100 mm, góc điều chỉnh xà đuôi 70°.</td><td></td></tr><tr><td>9</td><td></td><td></td><td>Giàn chống mềm GM16/34 (tương đương
ZRY16/34L)</td><td></td><td></td><td>7380</td><td></td><td></td><td>40</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>TCCS 12:2018/CKMK, hành trình chống giữ trong khoảng 2.400 – 3.400</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mm, góc dốc lò chợ 45°-75°, áp lực trạm dịch đến 20 Mpa, chiều cao giàn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chống khi làm việc ≥ 1.891 mm.</td><td></td></tr><tr><td>10</td><td></td><td></td><td>Giàn chống khám</td><td></td><td></td><td>7380</td><td></td><td></td><td>40</td><td></td><td></td><td>90</td><td></td><td></td><td>TCCS 21:2019/CKMK. Chiều dày khai thác từ 1.600 mm đến 3.500 mm,
chiều rộng xà giàn 320 mm, khoảng cách giữa tâm của giàn chống 350-370
mm. Kích thủy lực xà đuôi F100 mm, góc điều chỉnh xà đuôi 70oC.</td><td>TCCS 21:2019/CKMK. Chiều dày khai thác từ 1.600 mm đến 3.500 mm,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chiều rộng xà giàn 320 mm, khoảng cách giữa tâm của giàn chống 350-370</td><td></td></tr><tr><td>11</td><td></td><td></td><td>Giá chống thủy lực phân thể</td><td></td><td></td><td>7380</td><td></td><td></td><td>40</td><td></td><td></td><td>90</td><td></td><td></td><td>TCCS 01:2020/CKMK. Chiều cao làm việc từ 1.600 mm đến 2.400 mm,
chiều dài giàn 2.700 mm, chiều rộng giàn 840 mm. Tải trọng định mức 1.600
kN, bước tiến giàn 800 mm. Sử dụng dầu nhũ hóa MDT hoặc M10 nồng độ
3-5%, 04 cột chống với đường kính cột 110/98 mm, lực chống ban đầu 950
kN, cường độ chống giữ 0,59 MPa, áp lực làm việc định mức 42 MPa.</td><td></td><td></td></tr><tr><td>12</td><td></td><td></td><td>Động cơ diesel</td><td></td><td></td><td>8408</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Động cơ RV145-2 loại 4 kỳ, 1 xi lanh nằm ngang (đường kính xi lanh
400mm, hành trình piston 94 mm, thể tích 738 cm3), công suất cực đại 10,8
kW (14,5 mã lực), tốc độ tối đa 2.400 vòng/phút, suất tiêu hao nhiên liệu &lt;
195 g/mã lực.giờ. Khối lượng 115 kg. Sử dụng cho máy công nghiệp (hàn,
bơm nước, máy phát điện).</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Bồn áp lực hình trụ nằm ngang đặt trên xe</th></tr></thead><tbody><tr><td>chuyên dụng</td></tr></tbody></table>

<table><thead><tr><th>Dung tích chứa đến 40 m3, áp suất làm việc đến 40 kg/cm3. Chuyên chứa</th></tr></thead><tbody><tr><td>LPG, NH3, Cl2, O2.</td></tr></tbody></table>

<table><thead><tr><th>Giàn chống mềm GM16/34 (tương đương</th></tr></thead><tbody><tr><td>ZRY16/34L)</td></tr></tbody></table>

<table><thead><tr><th>chiều dài giàn 2.700 mm, chiều rộng giàn 840 mm. Tải trọng định mức 1.600</th></tr></thead><tbody><tr><td>kN, bước tiến giàn 800 mm. Sử dụng dầu nhũ hóa MDT hoặc M10 nồng độ</td></tr><tr><td>3-5%, 04 cột chống với đường kính cột 110/98 mm, lực chống ban đầu 950</td></tr><tr><td>kN, cường độ chống giữ 0,59 MPa, áp lực làm việc định mức 42 MPa.</td></tr></tbody></table>

<table><thead><tr><th>Động cơ RV145-2 loại 4 kỳ, 1 xi lanh nằm ngang (đường kính xi lanh</th></tr></thead><tbody><tr><td>400mm, hành trình piston 94 mm, thể tích 738 cm3), công suất cực đại 10,8</td></tr><tr><td>kW (14,5 mã lực), tốc độ tối đa 2.400 vòng/phút, suất tiêu hao nhiên liệu &lt;</td></tr><tr><td>195 g/mã lực.giờ. Khối lượng 115 kg. Sử dụng cho máy công nghiệp (hàn,</td></tr><tr><td>bơm nước, máy phát điện).</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td></td><td></td><td>Quạt gió lò phòng nổ các loại</td><td></td><td></td><td>8414</td><td></td><td></td><td>59</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td>Quạt đơn công suất đến 45 kW; quạt kép công suất đến 2×45 kW, điện áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>660 V.</td><td></td></tr><tr><td>14</td><td></td><td></td><td>Máy nén khí</td><td></td><td></td><td>8414</td><td></td><td></td><td>80</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Áp suất đến 32 atm, 18 m3/h. Trừ máy nén lạnh dùng cho ô tô và điều hòa ô</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tô.</td><td></td></tr><tr><td>15</td><td></td><td></td><td>Máy bơm chịu mài mòn cao phục vụ thải tro xỉ</td><td></td><td></td><td>8414</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Công suất 185 kW, số vòng quay 980 vòng/phút, lưu lượng &gt; 420 m3/giờ.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cột áp &gt; 65 m. Hiệu suất máy bơm (ɳbmax) &gt; 55%.</td><td></td></tr><tr><td></td><td>16</td><td></td><td></td><td>Quạt hộp thông gió</td><td></td><td></td><td>8414</td><td></td><td></td><td>51</td><td></td><td></td><td>10</td><td></td><td></td><td>Điện áp 220 V, công suất 35W, kèm dây cắm điện.</td><td></td></tr><tr><td>17</td><td></td><td></td><td>Buồng thổi khí</td><td></td><td></td><td>8414</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Dùng trong phòng sạch, công suất động cơ 1,13 kW, 3 pha 380 V/50 Hz.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Kích thước bên trong 900 x 4.000 x 1.950 mm, vỏ bằng thép.</td><td></td></tr><tr><td>18</td><td></td><td></td><td>Máy điều hòa chuyên dụng</td><td></td><td></td><td>8415</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Công suất đến 24.000 BTU/h, dùng để làm mát tủ điều khiển, trạm biến áp,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trạm phát sóng di động, đầu máy toa xe</td><td></td></tr><tr><td>19</td><td></td><td></td><td></td><td>Máy điều hòa không khí sử dụng trên toa xe</td><td></td><td>8415</td><td></td><td></td><td>81</td><td></td><td></td><td>29</td><td></td><td></td><td>Công suất đến 36.000 kcal/h.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>khách</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>20</td><td></td><td></td><td>Dàn lạnh điều hòa trung tâm</td><td></td><td></td><td>8415</td><td></td><td></td><td>82</td><td></td><td></td><td>99</td><td></td><td></td><td>Công suất 100.000 kcal/h, dùng điện 3 pha 380 V/50 Hz, động cơ 1,5 kW.</td><td></td></tr><tr><td></td><td>21</td><td></td><td></td><td>Điều hòa trung tâm</td><td></td><td></td><td>8415</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td>Công suất giàn lạnh 600.000 kcal/h, công suất giàn nóng 107.500 kcal/h.</td><td></td></tr><tr><td>22</td><td></td><td></td><td>Cấp liệu rung</td><td></td><td></td><td>8417</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 09:2016/CKMK.Năng suất 60 ± 20 tấn/h, động cơ rung 2×2,2kW, tần</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>số rung 980 lần/phút.</td><td></td></tr><tr><td>23</td><td></td><td></td><td>Máy cấp liệu lắc</td><td></td><td></td><td>8417</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Năng suất đến 1.000 m3/h, tần số lắc 0-70 lần/phút, hành trình lắc 0-240 mm,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>công suất động đến 30 kW.</td><td></td></tr><tr><td></td><td>24</td><td></td><td></td><td>Lò đốt chất thải rắn y tế</td><td></td><td></td><td>8417</td><td></td><td></td><td>80</td><td></td><td></td><td>0</td><td></td><td></td><td>QCVN 02:2012/BTNMT, công suất 30 kg/h.</td><td></td></tr><tr><td></td><td>25</td><td></td><td></td><td>Lò đốt chất thải rắn sinh hoạt</td><td></td><td></td><td>8417</td><td></td><td></td><td>80</td><td></td><td></td><td>0</td><td></td><td></td><td>QCVN 61-MT:2016/BTNMT, công suất 500 kg/h.</td><td></td></tr><tr><td></td><td>26</td><td></td><td></td><td>Lò đốt chất thải công nghiệp</td><td></td><td></td><td>8417</td><td></td><td></td><td>80</td><td></td><td></td><td>0</td><td></td><td></td><td>QCVN 30:2012/BTNMT, công suất 100 kg/h.</td><td></td></tr><tr><td></td><td>27</td><td></td><td></td><td>Dây chuyền sản xuất gạch nung các loại</td><td></td><td></td><td>8417</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Năng suất đến 20 triệu viên/năm</td><td></td></tr><tr><td>28</td><td></td><td></td><td>Máy làm đá từ nước biển</td><td></td><td></td><td>8418</td><td></td><td></td><td>21</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Năng suất đến 10 tấn/24h, công suất lạnh đến 32,5 kW; môi chất R404A;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tổng công suất tiêu thụ điện đến 19,65 kW; công suất máy nén đến 16,6 kW;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>công suất máy bơm nguyên liệu đến 1,5 kW; công suất động cơ dao gạt đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2,2 kW; công suất bơm làm mát đến 0,25 kW; chế độ làm mát bằng nước.</td><td></td></tr><tr><td></td><td>29</td><td></td><td></td><td>Máy làm lạnh nước</td><td></td><td></td><td>8418</td><td></td><td></td><td>69</td><td></td><td></td><td>49</td><td></td><td></td><td>Công suất đến 500 kW.</td><td></td></tr><tr><td>30</td><td></td><td></td><td>Dàn bay hơi (Dàn lạnh)</td><td></td><td></td><td>8418</td><td></td><td></td><td>99</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Công suất đến 500 kW, sử dụng trong kho bảo quản mát hoặc cấp đông từ -</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>50°C đến +15°C.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>31</td><td></td><td></td><td>Dàn ngưng tụ (Dàn nóng)</td><td></td><td></td><td>8418</td><td></td><td></td><td>99</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Công suất đến 1.000 kW, sử dụng cho tất cả các kho lạnh công nghiệp, hệ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thống điều hòa không khí, hệ thống làm lạnh nước, hệ thống sản xuất nước</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đá.</td><td></td></tr><tr><td>32</td><td></td><td></td><td>Máy sấy tầng sôi tạo hạt</td><td></td><td></td><td>8419</td><td></td><td></td><td>39</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td>Sấy dược liệu, bao phim hạt pellet và tạo hạt tầng sôi. Sử dụng trong dây</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuyền sản xuất dược phẩm cho gia súc, năng suất đến 100 kg/h, thể tích</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nồi sấy 400 lít, công suất nhiệt 45 kW, nhiệt độ sấy đến 80°C.</td><td></td></tr><tr><td></td><td>33</td><td></td><td></td><td>Máy phát tia plasma lạnh điều trị vết thương</td><td></td><td></td><td>8419</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Công suất đến 110W.</td><td></td></tr><tr><td>34</td><td></td><td></td><td>Tủ sấy dược phẩm</td><td></td><td></td><td>8419</td><td></td><td></td><td>39</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td>Dung tích đến 4.000 lít. Điều khiển nhiệt độ bằng vi xử lý tích hợp P.I.D. Dải</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhiệt độ sấy từ nhiệt độ môi trường +5°C đến 120°C.</td><td></td></tr><tr><td>35</td><td></td><td></td><td>Tủ an toàn sinh học cấp 2</td><td></td><td></td><td>8419</td><td></td><td></td><td>89</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td>Điều khiển bằng vi xử lý. Hiển thị bằng màn hình LED. Dùng cấy vi khuẩn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trong phòng xét nghiệm, phòng thí nghiệm y tế.</td><td></td></tr><tr><td>36</td><td></td><td></td><td>Tủ cấy vi sinh</td><td></td><td></td><td>8419</td><td></td><td></td><td>89</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td>Điều khiển bằng vi xử lý. Hiển thị bằng màn hình LED. Chức năng dùng nuôi</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cấy vi sinh, vi khuẩn trong phòng xét nghiệm, phòng thí nghiệm. Dùng trong</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>y tế và nông nghiệp.</td><td></td></tr><tr><td>37</td><td></td><td></td><td>Máy lọc không khí</td><td></td><td></td><td>8421</td><td></td><td></td><td>39</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td>Lưu lượng khí &lt; 150 m3/h, lọc bụi mịn 99,95%, UV diệt khuẩn, than hoạt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tính.</td><td></td></tr><tr><td></td><td>38</td><td></td><td></td><td>Hộp mặt lọc khí</td><td></td><td></td><td>8421</td><td></td><td></td><td>39</td><td></td><td></td><td>90</td><td></td><td></td><td>Dùng lọc không khí phòng sạch, khung nhôm, lưu lượng lọc 28 m3/phút.</td><td></td></tr><tr><td></td><td>39</td><td></td><td></td><td>Hệ thống lọc nước sinh hoạt</td><td></td><td></td><td>8421</td><td></td><td></td><td>21</td><td></td><td></td><td>22</td><td></td><td></td><td>Công suất đến 5 m3/giờ.</td><td></td></tr><tr><td>40</td><td></td><td></td><td>Máy ép gói tự động</td><td></td><td></td><td>8422</td><td></td><td></td><td>40</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Năng suất tối đa 300 gói/phút, cấp bột bằng phương pháp định lượng thể</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tích với sai số 1-2%.</td><td></td></tr><tr><td></td><td>41</td><td></td><td></td><td>Dây chuyền máy ép vỉ và đóng hộp tự động</td><td></td><td></td><td>8422</td><td></td><td></td><td>40</td><td></td><td></td><td>0</td><td></td><td></td><td>Đóng gói vỉ hoặc chai/lọ thuốc vào các hộp giấy.</td><td></td></tr><tr><td></td><td>42</td><td></td><td></td><td>Máy đóng viên nang tự động</td><td></td><td></td><td>8422</td><td></td><td></td><td>40</td><td></td><td></td><td>0</td><td></td><td></td><td>Năng suất đến 72.000 viên/giờ.</td><td></td></tr><tr><td>43</td><td></td><td></td><td>Máy lau viên (viên nang/viên nén)</td><td></td><td></td><td>8422</td><td></td><td></td><td>40</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Thực hiện chức năng lau nang, có thể chạy độc lập hoặc kết nối sau máy</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đóng nang.</td><td></td></tr><tr><td></td><td>44</td><td></td><td></td><td>Máy ép vỉ thuốc tự động</td><td></td><td></td><td>8422</td><td></td><td></td><td>40</td><td></td><td></td><td>0</td><td></td><td></td><td>Đóng gói các viên, chai, lọ, ống tiêm thành các vỉ.</td><td></td></tr><tr><td>45</td><td></td><td></td><td>Hệ thống kết nối 2 máy ép vỉ và máy đóng hộp</td><td></td><td></td><td>8422</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Kết nối đầu ra của máy ép vỉ thuốc tự động với đầu vào của máy đóng hộp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>giấy tự động tạo thành dây chuyền ép vỉ – đóng hộp tự động.</td><td></td></tr><tr><td>46</td><td></td><td></td><td>Cân ô tô điện tử</td><td></td><td></td><td>8423</td><td></td><td></td><td>89</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Giới hạn cân trọng tải đến 100 tấn, kích thước bàn cân 3 x (12-18) m, cấp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chính xác III, số đầu đo 4-8, số modul bàn cân: 1-3, khả năng quá tải 125%.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>47</td><td></td><td></td><td>Cân tàu hỏa điện tử</td><td></td><td></td><td>8423</td><td></td><td></td><td>89</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Dùng cho loại đường ray 1.000 mm hoặc 1.435 mm, G7, EU, cấp chính xác</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1, sai số &lt; 1% theo tiêu chuẩn Quốc tế OIML-R106, giới hạn cân trọng tải</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đến 120 tấn, số đầu đo 4 chiếc, khả năng quá tải 125%.</td><td></td></tr><tr><td>48</td><td></td><td></td><td>Máy phun sương cao áp dập bụi</td><td></td><td></td><td>8424</td><td></td><td></td><td>30</td><td></td><td></td><td>0</td><td></td><td></td><td>Khả năng phun xa đến 180 m. Lượng gió 305 – 2.473 (m3/phút). Áp suất (áp
lực gió) trong khoảng 500-870MP. Công suất động cơ quạt đến 150 kW.
Công suất động cơ bơm đến 15kW.Lượng nước tiêu hao đến 12 m3/giờ.</td><td></td><td></td></tr><tr><td></td><td>49</td><td></td><td></td><td>Máy bao viên tự động</td><td></td><td></td><td>8424</td><td></td><td></td><td>89</td><td></td><td></td><td>50</td><td></td><td></td><td>Bao phim và/hoặc bao đường viên thuốc.</td><td></td></tr><tr><td>50</td><td></td><td></td><td>Trạm rửa</td><td></td><td></td><td>8424</td><td></td><td></td><td>89</td><td></td><td></td><td>50</td><td></td><td></td><td></td><td>Được sử dụng chung cho mục đích vệ sinh các máy pha chế, tiết kiệm chi</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phí đầu tư riêng lẻ cho từng máy.</td><td></td></tr><tr><td>51</td><td></td><td></td><td>Tời điện</td><td></td><td></td><td>8425</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 05:2016/CĐUB. Lực kéo đến 10 kN. Chiều dài cáp 400 m, đường kính</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cáp Ø12,5 mm. Tốc độ cáp min/max (m/s) 0,437/1,13. Động cơ điện P =</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>11,4 kW, n = 1.460 vòng/phút, U = 380 V/660V.</td><td></td></tr><tr><td>52</td><td></td><td></td><td>Tời kéo</td><td></td><td></td><td>8425</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Lực kéo của tời đến 170 kN, công suất động cơ đến 5,5 kW, tốc độ kéo đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>750 vòng/phút.</td><td></td></tr><tr><td>53</td><td></td><td></td><td>Tời dồn toa</td><td></td><td></td><td>8425</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Lực kéo của tời 180 kN, công suất động cơ 22 kW, tốc độ kéo 0,05 – 3,16</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>m/s, khối lượng 3.770 kg.</td><td></td></tr><tr><td>54</td><td></td><td></td><td>Tời cáp treo chở người</td><td></td><td></td><td>8425</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Chiều dài đến 1.000 m, số lượng người chở đến 360 ng/h, vận tốc cáp: 0,3-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1,2 m/s, góc dốc lắp đặt 0-23o, công suất động cơ 55 kW.</td><td></td></tr><tr><td>55</td><td></td><td></td><td>Tời hỗ trợ người đi bộ</td><td></td><td></td><td>8425</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 03/2016 CKOTUB. Lực kéo tối đa 01 tấn, chiều dài vận tải đến 800 m,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>công suất 18,5 kW, tốc độ động cơ 1.470 vòng/phút; sử dụng hỗ trợ người đi</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bộ trên địa hình dốc &gt; 15o, số lượng người tối đa 180.</td><td></td></tr><tr><td>56</td><td></td><td></td><td>Tời điện phòng nổ</td><td></td><td></td><td>8425</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td>Công suất động cơ dẫn động đến 45 kW. Lực kéo đến 90 kN. Trọng tải làm
việc 6-25 tấn. Chiều dài cáp 400-600 m. Góc dốc làm việc đến 23o. Tốc độ
0,15-1,2 (m/s). Công suất đến 75 kW. Dùng trong mỏ than hầm lò.</td><td></td><td></td></tr><tr><td></td><td>57</td><td></td><td></td><td>Kết cấu thép xây dựng các loại</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td>20</td><td></td><td></td><td>Phi tiêu chuẩn có khẩu độ đến 70 m.</td><td></td></tr><tr><td></td><td>58</td><td></td><td></td><td>Cần trục, cẩu trục</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td>30</td><td></td><td></td><td>Thiết bị nâng hạ làm bằng thép, trọng tải lớn, công suất lớn.</td><td></td></tr><tr><td>59</td><td></td><td></td><td>Cột chống thủy lực di động</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 32:2016/VMC. Chiều dài làm việc tối đa 2.272 mm, tối thiểu 1.491</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mm. Áp suất làm việc đến 38,2 MPa, đường kính xi lanh 100 mm.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Khả năng phun xa đến 180 m. Lượng gió 305 – 2.473 (m3/phút). Áp suất (áp</th></tr></thead><tbody><tr><td>lực gió) trong khoảng 500-870MP. Công suất động cơ quạt đến 150 kW.</td></tr><tr><td>Công suất động cơ bơm đến 15kW.Lượng nước tiêu hao đến 12 m3/giờ.</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>60</td><td></td><td></td><td>Cột chống thủy lực đơn</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 03:2015/VMC. Áp lực làm việc cao nhất 300 kN, nhỏ nhất 115 kN. Áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>suất dung dịch đến 38,2 Mpa. Áp lực trạm bơm dung dịch đến 20 Mpa. Độ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cao lớn nhất của cột 3.500 mm, nhỏ nhất 1.000 mm. Đường kính xi lanh 100</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mm. Dùng trong mỏ than hầm lò.</td><td></td></tr><tr><td>61</td><td></td><td></td><td>Cột chống thủy lực 2 chiều</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 32:2016/VMC. Áp suất làm việc 38,2 ÷ 40 Mpa. Đường kính xi lanh</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>110 mm và 125mm, dùng trong mỏ than hầm lò.</td><td></td></tr><tr><td></td><td>62</td><td></td><td></td><td>Cẩu tháp</td><td></td><td></td><td>8426</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Chiều cao nâng tối đa 200 m, sử dụng trong công trình xây dựng.</td><td></td></tr><tr><td></td><td>63</td><td></td><td></td><td>Cổng trục</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td>30</td><td></td><td></td><td>Sức nâng đến 700 tấn.</td><td></td></tr><tr><td>64</td><td></td><td></td><td>Cẩu bốc dỡ container chạy ray</td><td></td><td></td><td>8426</td><td></td><td></td><td>19</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Loại RMQC, chiều cao 68-78 m, rộng 26-28 m, dài 115-145m. Loại RMGC,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chiều cao 21m, rộng 24 m, dài 64 m</td><td></td></tr><tr><td>65</td><td></td><td></td><td>Hệ thống vận chuyển vật tư vật liệu dạng ray
treo sử dụng khí nén</td><td></td><td></td><td>8428</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 11:2016/CKMK, lực kéo lớn nhất 8 kN, lực phanh 20 kN, tốc độ vận</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuyển 24 m/phút, áp suất khí sử dụng 0,4-0,6 Mpa, chiều dài hệ thống 400-</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>800 m.</td><td></td></tr><tr><td></td><td>66</td><td></td><td></td><td>Vận thăng nâng hạ loại 1 lồng/2 lồng</td><td></td><td></td><td>8428</td><td></td><td></td><td>10</td><td></td><td></td><td>39</td><td></td><td></td><td>Tải trọng nâng đến 2 tấn, sử dụng trong công trình xây dựng.</td><td></td></tr><tr><td></td><td>67</td><td></td><td></td><td>Hệ thống băng tải</td><td></td><td></td><td>8428</td><td></td><td></td><td>10</td><td></td><td></td><td>39</td><td></td><td></td><td>Các hệ thống băng tải: kín, uốn, ống.</td><td></td></tr><tr><td>68</td><td></td><td></td><td>Băng tải xuống dốc</td><td></td><td></td><td>8428</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Tốc độ vận chuyển 1,2-2 m/s; góc dốc đến 16o; năng suất vận chuyển đến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>500 tấn/h; kích thước lớn nhất của vật liệu 500 mm.</td><td></td></tr><tr><td>69</td><td></td><td></td><td>Băng tải dốc BTD (lòng máng sâu)</td><td></td><td></td><td>8428</td><td></td><td></td><td>31</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Tốc độ vận chuyển 1,2-1,5 m/s, góc dốc tối đa 25o, tổng công suất động cơ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đến 1.000 kW, kích thước lớn nhất của vật liệu 300 mm.</td><td></td></tr><tr><td>70</td><td></td><td></td><td>Gầu ngoạm thủy lực điều khiển từ xa</td><td></td><td></td><td>8428</td><td></td><td></td><td>32</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 19:2016/VMC. Dung tích gầu từ 5 đến 10 m3, điều khiển từ xa bằng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sóng radio.</td><td></td></tr><tr><td>71</td><td></td><td></td><td></td><td>Gầu xúc trọn bộ dùng cho máy xúc điện, thủy</td><td></td><td>8428</td><td></td><td></td><td>32</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 24:2016/VMC. Dung tích gầu từ 3,5 đến 12 m3. Vật liệu: Hợp kim đúc,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lực</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chịu mài mòn.</td><td></td></tr><tr><td>72</td><td></td><td></td><td>Hệ thống nâng hạ và quay</td><td></td><td></td><td>8428</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Dùng để xoay/sửa nguyên liệu, loại thay đầu dùng cho cả 3 loại: nghiền búa,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sàng hạt li tâm, sửa hạt khô.</td><td></td></tr><tr><td>73</td><td></td><td></td><td>Thiết bị nâng và quay</td><td></td><td></td><td>8428</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Dùng để xả cốm/bột từ nồi chứa cốm của máy sấy tầng sôi/từ thùng chứa
IBC/từ thùng chứa khác với sự kết nối kín giữa các bộ phận đảm bảo hạn
chế tối đa hiện tượng thoát bụi ra ngoài môi trường. Dùng để cấp cốm/bột từ
IBC/từ thùng chứa vào thiết bị khác (máy đóng nang, máy dập viên, máy
đóng gói sachet). Dùng để cấp viên từ IBC/từ thùng chứa vào thiết bị khác
(máy ép vỉ thuốc, máy bao viên, máy ép vỉ xé).</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống vận chuyển vật tư vật liệu dạng ray</th></tr></thead><tbody><tr><td>treo sử dụng khí nén</td></tr></tbody></table>

<table><thead><tr><th>Dùng để xả cốm/bột từ nồi chứa cốm của máy sấy tầng sôi/từ thùng chứa</th></tr></thead><tbody><tr><td>IBC/từ thùng chứa khác với sự kết nối kín giữa các bộ phận đảm bảo hạn</td></tr><tr><td>chế tối đa hiện tượng thoát bụi ra ngoài môi trường. Dùng để cấp cốm/bột từ</td></tr><tr><td>IBC/từ thùng chứa vào thiết bị khác (máy đóng nang, máy dập viên, máy</td></tr><tr><td>đóng gói sachet). Dùng để cấp viên từ IBC/từ thùng chứa vào thiết bị khác</td></tr><tr><td>(máy ép vỉ thuốc, máy bao viên, máy ép vỉ xé).</td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>74</td><td></td><td></td><td></td><td>Thang máy chở người, chở giường bệnh</td><td></td><td>8428</td><td></td><td></td><td>10</td><td></td><td></td><td>10</td><td></td><td></td><td>Tải trọng đến 1.600 kg, tốc độ đến 150 m/phút.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nhân</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>75</td><td></td><td></td><td>Máy xúc đá</td><td></td><td></td><td>8429</td><td></td><td></td><td>51</td><td></td><td></td><td>0</td><td></td><td></td><td>TCCS 02/2016/CĐUB. Năng suất máy đến 1,25m3/phút. Trọng lượng 9 tấn,
cương cự 1.100 mm, tốc độ tiến 0,78 m/s, tốc độ lùi 0,57 m/s, dung tích gầu
xúc 0,32 m3, động cơ chính 14 kW, động cơ băng tải 7,5 kW.</td><td></td><td></td></tr><tr><td></td><td>76</td><td></td><td></td><td>Máy xúc lật hông mini</td><td></td><td></td><td>8429</td><td></td><td></td><td>51</td><td></td><td></td><td>0</td><td></td><td></td><td>Tự hành, dùng xúc than trong hầm lò có diện tích ≥ 5,3 m2.</td><td></td></tr><tr><td></td><td>77</td><td></td><td></td><td>Máy đào chuyển tải đất đá, than trong hầm lò</td><td></td><td></td><td>8430</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Dùng xúc đào than, đá trong hầm lò có diện tích &gt; 8,7 m2.</td><td></td></tr><tr><td>78</td><td></td><td></td><td>Xe khoan</td><td></td><td></td><td>8430</td><td></td><td></td><td>50</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS: 01-2020/CKOTUB. Tốc độ khoan 0,72 m/phút, sử dụng trong hầm lò</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>có tiết diện &gt; 9,6 m2.</td><td></td></tr><tr><td>79</td><td></td><td></td><td>Máy xúc đá thủy lực trong hầm lò</td><td></td><td></td><td>8430</td><td></td><td></td><td>50</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>TCCS 16:2019/CĐUB. Năng suất 1-1,25 m3/phút, vận tốc máy 0,84-1,36</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>m/s, loại điều khiển thủy lực, dung tích thùng dầu 400 (520) lít, dung tích gầu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0,15-0,32 m3, góc bốc xúc ± 350, động cơ điện phòng nổ P=22-30kW,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>n=1.470 vòng/phút, điện áp 380/660 V, hệ thống làm mát dầu thủy lực ≥ 180</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>l/p.</td><td></td></tr><tr><td>80</td><td></td><td></td><td>Máy xúc đá trong hầm lò</td><td></td><td></td><td>8430</td><td></td><td></td><td>50</td><td></td><td></td><td>0</td><td></td><td></td><td>TCCS 15:2016/VMC. Dung tích gầu xúc 0,5 ÷ 0,6 m3, độ cao dỡ tải lớn nhất
1.765 mm, góc quay cần gầu ± 250o, góc dốc làm việc ±16o, lực kéo định
mức 35 kN, lực kéo lớn nhất 50 kN, tốc độ di chuyển 2,2 km/h, áp lực của
xích trên nền 0,09 MPa, áp suất động cơ di chuyển b21 MPa, áp suất cơ cấu
công tác 16 MPa; công suất đến 45 kW; tốc độ quay 1.470 vòng/phút; dòng
điện định mức 84,2/48,6 A.</td><td></td><td></td></tr><tr><td>81</td><td></td><td></td><td>Máy gieo hạt chân không 6 trong 1 tự động</td><td></td><td></td><td>8432</td><td></td><td></td><td>39</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Máy đóng đất tự động vào khay xốp, sàng đất, tạo lỗ, gieo hạt, lấp hạt, xếp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khay tự động (8-9 khay/1 lần). Năng suất 320-360 khay/h tương đương</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.560-2.880 khay và gieo được 215.040 – 241.920 hạt/ngày (loại khay 84 lỗ).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Năng lượng tiêu thụ 2 kW/h, điện nguồn 220V, 1 pha.</td><td></td></tr><tr><td>82</td><td></td><td></td><td>Máy thái bèo (băm bèo)</td><td></td><td></td><td>8432</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Sử dụng động cơ điện xoay chiều 1 pha, điện thế 220 V, tần số 50 Hz được</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chế tạo liền với khung máy. Phần máy: Gồm chân máy; khay tiếp liệu; hộp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>công tác; miếng hướng liệu; hệ thống dao gồm 03 cặp, mỗi cặp 02 dao; gạt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sản phẩm ra gồm hai cánh đối xứng nhau.</td><td></td></tr><tr><td>83</td><td></td><td></td><td>Máy tẽ ngô</td><td></td><td></td><td>8432</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Sử dụng động cơ điện xoay chiều 1 pha, điện thế 220V, tần số 50 Hz được</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bắt chặt với khung máy. Phần máy: Gồm khung máy; khay tiếp liệu; hộp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>công tác; máng hướng liệu; hệ thống puly truyền động giảm tốc, trục truyền</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>động và hệ thống lu cán.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>TCCS 02/2016/CĐUB. Năng suất máy đến 1,25m3/phút. Trọng lượng 9 tấn,</th></tr></thead><tbody><tr><td>cương cự 1.100 mm, tốc độ tiến 0,78 m/s, tốc độ lùi 0,57 m/s, dung tích gầu</td></tr><tr><td>xúc 0,32 m3, động cơ chính 14 kW, động cơ băng tải 7,5 kW.</td></tr></tbody></table>

<table><thead><tr><th>TCCS 15:2016/VMC. Dung tích gầu xúc 0,5 ÷ 0,6 m3, độ cao dỡ tải lớn nhất</th></tr></thead><tbody><tr><td>1.765 mm, góc quay cần gầu ± 250o, góc dốc làm việc ±16o, lực kéo định</td></tr><tr><td>mức 35 kN, lực kéo lớn nhất 50 kN, tốc độ di chuyển 2,2 km/h, áp lực của</td></tr><tr><td>xích trên nền 0,09 MPa, áp suất động cơ di chuyển b21 MPa, áp suất cơ cấu</td></tr><tr><td>công tác 16 MPa; công suất đến 45 kW; tốc độ quay 1.470 vòng/phút; dòng</td></tr><tr><td>điện định mức 84,2/48,6 A.</td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>84</td><td></td><td></td><td>Máy tách vỏ xanh macca</td><td></td><td></td><td>8437</td><td></td><td></td><td>80</td><td></td><td></td><td>51</td><td></td><td></td><td>Công suất 1HP, năng suất 250 kg/ giờ. Hoạt động bằng điện.</td><td></td></tr><tr><td>85</td><td></td><td></td><td>Sàng rung dùng để phân loại than, khoáng
sản</td><td></td><td></td><td>8437</td><td></td><td></td><td>80</td><td></td><td></td><td>59</td><td></td><td></td><td></td><td>TCCS 04:2016/CKMK. Năng suất đến 850 tấn/h, công suất đến 44 kW, tần</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>số rung 730-980 lần/phút, gây rung bằng hộp tạo rung cơ khí hoặc trục lệch</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tâm.</td><td></td></tr><tr><td>86</td><td></td><td></td><td>Sàng rung</td><td></td><td></td><td>8437</td><td></td><td></td><td>80</td><td></td><td></td><td>59</td><td></td><td></td><td></td><td>Năng suất 500 tấn/ca, số lưới sàng 2 tầng, biên độ dao động 6 mm, độ dốc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>15o, tần số 980 vòng/phút, động cơ điện 380 V, 11 kW.</td><td></td></tr><tr><td>87</td><td></td><td></td><td>Dây chuyền chế biến gạo</td><td></td><td></td><td>8437</td><td></td><td></td><td>80</td><td></td><td></td><td>10</td><td></td><td></td><td>Dây chuyền đồng bộ gồm:- Các thiết bị chính: máy bóc vỏ, máy tách sạn,
máy xát trắng, máy đánh bóng, máy tách thóc tinh.- Các thiết bị phụ trợ: bồ
đài, băng tải, thiết bị sấy, silo, cân điện tử và các thiết bị công tác khác.- Dây
chuyền có khả năng thu thập dữ liệu và giám sát tự động. Các thông số vận
hành của 5 thiết bị chính được điều khiển số.- Năng suất 10-12 tấn thóc/giờ
hoặc bội số của năng suất này;- Tỷ lệ thu hồi gạo nguyên đạt 70%- Tiêu thụ
năng lượng 40 kWh/tấn thóc.</td><td></td><td></td></tr><tr><td></td><td>88</td><td></td><td></td><td>Máy giặt công nghiệp</td><td></td><td></td><td>8450</td><td></td><td></td><td>12</td><td></td><td></td><td></td><td></td><td></td><td>Công suất đến 4 kW, năng suất 45 kg/mẻ.</td><td></td></tr><tr><td></td><td>89</td><td></td><td></td><td>Máy vắt khô công nghiệp</td><td></td><td></td><td>8450</td><td></td><td></td><td>12</td><td></td><td></td><td></td><td></td><td></td><td>Công suất 5,5 kW, năng suất45 kg/mẻ.</td><td></td></tr><tr><td>90</td><td></td><td></td><td>Hệ thống sấy lúa dạng tháp tuần hoàn</td><td></td><td></td><td>8451</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Dung lượng một mẻ 30 tấn, độ ẩm nguyên liệu tối đa, mức giảm ẩm lúa
thường 0,8-1,2% độ ẩm/giờ, lúa thơm 0,6-1% độ ẩm/giờ, nhiệt độ sấy 30-
40oC, mức rạn gãy lúa thơm 0-3%, lúa thường 0-2%, độ ẩm đầu ra 13,5-
14oC; mức tiêu hao điện năng sấy lúa tươi 12-15 kW/tấn, mức tiêu hao trấu
sấy lúa tươi8-10 kg/tấn.</td><td></td><td></td></tr><tr><td></td><td>91</td><td></td><td></td><td>Máy tiện vạn năng phổ thông</td><td></td><td></td><td>8458</td><td></td><td></td><td>99</td><td></td><td></td><td>90</td><td></td><td></td><td>Đường kính vật gia công đến 650 mm, chiều dài đến 3.000 mm.</td><td></td></tr><tr><td></td><td>92</td><td></td><td></td><td>Máy cắt vật liệu nhựa PE</td><td></td><td></td><td>8459</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cắt máng che mưa cho miệng cạo cây cao su.</td><td></td></tr><tr><td></td><td>93</td><td></td><td></td><td>Máy bào ngang</td><td></td><td></td><td>8461</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td>Hành trình đến 650 mm.</td><td></td></tr><tr><td></td><td>94</td><td></td><td></td><td>Máy ép thủy lực</td><td></td><td></td><td>8462</td><td></td><td></td><td>91</td><td></td><td></td><td>0</td><td></td><td></td><td>Từ 50 tấn đến 500 tấn.</td><td></td></tr><tr><td>95</td><td></td><td></td><td></td><td>Dây chuyền thiết bị đồng bộ sản xuất gạch bê</td><td></td><td>8464</td><td></td><td></td><td>90</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Công suất thiết kế theo các module có thể sản xuất được (triệu viên/năm) ≤</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>20.</td><td></td></tr><tr><td></td><td>96</td><td></td><td></td><td>Xi lanh kích chân chống máy khấu than</td><td></td><td></td><td>8466</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đường kính xi lanh F140 – F 160 mm. Chiều dài xi lanh 600 – 1.000 mm.</td><td></td></tr><tr><td>97</td><td></td><td></td><td></td><td>Xi lanh nâng đầu khấu máy khấu than trong</td><td></td><td>8466</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đường kính xi lanh F150 – F 160 mm. Chiều dài xi lanh 800 – 1.200 mm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hầm lò</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Sàng rung dùng để phân loại than, khoáng</th></tr></thead><tbody><tr><td>sản</td></tr></tbody></table>

<table><thead><tr><th>Dây chuyền đồng bộ gồm:- Các thiết bị chính: máy bóc vỏ, máy tách sạn,</th></tr></thead><tbody><tr><td>máy xát trắng, máy đánh bóng, máy tách thóc tinh.- Các thiết bị phụ trợ: bồ</td></tr><tr><td>đài, băng tải, thiết bị sấy, silo, cân điện tử và các thiết bị công tác khác.- Dây</td></tr><tr><td>chuyền có khả năng thu thập dữ liệu và giám sát tự động. Các thông số vận</td></tr><tr><td>hành của 5 thiết bị chính được điều khiển số.- Năng suất 10-12 tấn thóc/giờ</td></tr><tr><td>hoặc bội số của năng suất này;- Tỷ lệ thu hồi gạo nguyên đạt 70%- Tiêu thụ</td></tr><tr><td>năng lượng 40 kWh/tấn thóc.</td></tr></tbody></table>

<table><thead><tr><th>Dung lượng một mẻ 30 tấn, độ ẩm nguyên liệu tối đa, mức giảm ẩm lúa</th></tr></thead><tbody><tr><td>thường 0,8-1,2% độ ẩm/giờ, lúa thơm 0,6-1% độ ẩm/giờ, nhiệt độ sấy 30-</td></tr><tr><td>40oC, mức rạn gãy lúa thơm 0-3%, lúa thường 0-2%, độ ẩm đầu ra 13,5-</td></tr><tr><td>14oC; mức tiêu hao điện năng sấy lúa tươi 12-15 kW/tấn, mức tiêu hao trấu</td></tr><tr><td>sấy lúa tươi8-10 kg/tấn.</td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>98</td><td></td><td></td><td></td><td>Xi lanh nâng mâm vơ máy khấu than trong</td><td></td><td>8466</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đường kính xi lanh F120 – F 150 mm. Chiều dài xi lanh 100 – 500 mm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hầm lò</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>99</td><td></td><td></td><td>Phụ tùng vật tư hệ thống thủy lực giàn mềm</td><td></td><td></td><td>8466</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Xi lanh thủy lực hai chiều: F100 đến F200 mm; Van thủy lực điều khiển: Loại</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3 tay, 7 tay. Ống mềm thủy lực các loại F10 – F32 mm.</td><td></td></tr><tr><td>100</td><td></td><td></td><td>Chòng khoan than các loại</td><td></td><td></td><td>8466</td><td></td><td></td><td>10</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Kích thước 2.500 mm, chiều dài đuôi chòng 60 mm, đường kính đuôi chòng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>F18, đường kính chòng F38, độ thẳng ≤ 3 mm, bước xoắn 60 mm.</td><td></td></tr><tr><td></td><td>101</td><td></td><td></td><td>Hệ thống chuyển tiếp điện văn AMSS/AMHS</td><td></td><td></td><td>8471</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td>Tiêu chuẩn ICAO, Euro Control Community.</td><td></td></tr><tr><td>102</td><td></td><td></td><td>Thiết bị chuyên dụng cho giao thông
Telematics Car</td><td></td><td></td><td>8471</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Bao gồm các Module chính:</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Cảm biến vị trí GPS.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Các tính năng tương tác hệ thống vệ tinh định vị toàn cầu GNSS (Global</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Navigation Sateilite System) trong đó có GPS (Global Position System).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Các tính năng tương tác với Server của Hệ thống Giao thông thông minh</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ITS nhằm cung cấp các thông tin trực tuyến về quãng đường, sự cố tai nạn,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ùn tắc giao thông hoặc thời tiết xấu. Tích hợp với IP Camera trên đường cao</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tốc.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Có khả năng liên kết với hệ thống cảm biến điện từ trên xe ô tô (chẳng hạn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>như cảm biến phát hiện va chạm).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Thực hiện chức năng thông tin liên lạc qua hệ thống GPRS/GSM/3G.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>+ Chức năng thu phí mô phỏng sử dụng công nghệ truyền thông không dây.</td><td></td></tr><tr><td>103</td><td></td><td></td><td>Bộ thu RTK GPS/GNSS độ chính xác cao
Trạm tham chiếu cơ sở Network RTK</td><td></td><td></td><td>8471</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đa hệ thống: GPS/GLONASS. Đa băng tần số: L1 và L2. Định dạng dữ liệu:
RINEX, RTCM, NMEA. Chức năng: trạm tham chiếu (base Station) và bộ thu
hiện trường (rover). Phương thức định vị: RTK, PPK, PPP. Tần suất dữ liệu
ra; 1-10 Hz. Hỗ trợ giao thức cung cấp dữ liệu cải chính NTRIP, bao gồm:
NTREP Client (tại bộ thu), NTRIP Server (tại trạm tham chiếu), và NTRIP
caster (tại trung tâm dữ liệu). Phần mềm NTRIP cung cấp dữ liệu cải chính
định vị ở định dạng RTCM.</td><td></td><td></td></tr><tr><td>104</td><td></td><td></td><td>Trạm trộn bê tông thương phẩm</td><td></td><td></td><td>8474</td><td></td><td></td><td>31</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Năng suất đến 120 m3/h, số thành phần cốt liệu: 2-6, cân cốt liệu: 1.200 –</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.000 kg, cân xi măng: 300 – 1.200 kg, cân nước: 200 – 600 lít.</td><td></td></tr><tr><td>105</td><td></td><td></td><td></td><td>Dây chuyền sản xuất tấm sóng, tấm phang</td><td></td><td>8474</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tiêu chuẩn JIS A 5430:2004 và ISO 8336: 2009, công suất 3 triệu m2/năm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>không amiăng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyên dụng cho giao thông</th></tr></thead><tbody><tr><td>Telematics Car</td></tr></tbody></table>

<table><thead><tr><th>Đa hệ thống: GPS/GLONASS. Đa băng tần số: L1 và L2. Định dạng dữ liệu:</th></tr></thead><tbody><tr><td>RINEX, RTCM, NMEA. Chức năng: trạm tham chiếu (base Station) và bộ thu</td></tr><tr><td>hiện trường (rover). Phương thức định vị: RTK, PPK, PPP. Tần suất dữ liệu</td></tr><tr><td>ra; 1-10 Hz. Hỗ trợ giao thức cung cấp dữ liệu cải chính NTRIP, bao gồm:</td></tr><tr><td>NTREP Client (tại bộ thu), NTRIP Server (tại trạm tham chiếu), và NTRIP</td></tr><tr><td>caster (tại trung tâm dữ liệu). Phần mềm NTRIP cung cấp dữ liệu cải chính</td></tr><tr><td>định vị ở định dạng RTCM.</td></tr></tbody></table>

<table><thead><tr><th>Bộ thu RTK GPS/GNSS độ chính xác cao</th></tr></thead><tbody><tr><td>Trạm tham chiếu cơ sở Network RTK</td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>106</td><td></td><td></td><td>Thiết bị trộn bột khô bằng IBC</td><td></td><td></td><td>8479</td><td></td><td></td><td>82</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Dùng để trộn cốm trong thùng IBC, có thể có chức năng nâng hạ hoặc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>không.</td><td></td></tr><tr><td></td><td>107</td><td></td><td></td><td>Máy trộn bột khô dạng lập phương</td><td></td><td></td><td>8479</td><td></td><td></td><td>82</td><td></td><td></td><td>10</td><td></td><td></td><td>Sử dụng để trộn hoàn tất bột dược liệu/cốm khô dược liệu.</td><td></td></tr><tr><td>108</td><td></td><td></td><td>Máy trộn và tạo hạt cao tốc</td><td></td><td></td><td>8479</td><td></td><td></td><td>82</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Trộn và tạo hạt bột ướt cho dược liệu. Loại hệ thống dẫn động nằm ở dưới</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc nằm ở trên.</td><td></td></tr><tr><td></td><td>109</td><td></td><td></td><td>Máy xát hạt trục đứng</td><td></td><td></td><td>8479</td><td></td><td></td><td>82</td><td></td><td></td><td>10</td><td></td><td></td><td>Xát hạt khô hoặc ướt theo nhiều cỡ lưới.</td><td></td></tr><tr><td>110</td><td></td><td></td><td>Máy nghiền và trộn dung dịch màu</td><td></td><td></td><td>8479</td><td></td><td></td><td>82</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Máy thích hợp dùng để tán, nghiền tạo nhũ tương đồng thời pha trộn đều</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>các loại nguyên liệu với nhau tạo thành hỗn hợp dịch đồng nhất. Được ứng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dụng rộng rãi trong ngành dược phẩm, thực phẩm, hóa chất để chuẩn bị dịch</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bao cho các máy bao phim.</td><td></td></tr><tr><td>111</td><td></td><td></td><td>Dây chuyền pha chế tạo hạt kết nối kín</td><td></td><td></td><td>8479</td><td></td><td></td><td>90</td><td></td><td></td><td>39</td><td></td><td></td><td>Làm kín và điều khiển tích hợp toàn bộ các máy tạo thành dây chuyền tạo
hạt tích hợp kín (bao gồm các máy: Máy trộn và tạo hạt cao tốc, Máy sấy và
tạo hạt tầng sôi, Thiết bị nâng và quay, Thiết bị trộn bột khô bằng IBC) nhằm
hạn chế sự tiếp xúc của người vận hành máy với sản phẩm, gia tăng hiệu
suất sản xuất thông qua quá trình tự động hóa, giảm thiểu thời gian chờ và
thao tác máy. Chức năng làm kín chống độc. Quá trình hút cấp liệu, trộn và
tạo hạt, sấy, xả liệu, hoàn toàn không sinh bụi.</td><td></td><td></td></tr><tr><td>112</td><td></td><td></td><td>Máy rửa chai</td><td></td><td></td><td>8479</td><td></td><td></td><td>89</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td>Máy dùng để súc rửa các chai lọ, vệ sinh theo tiêu chuẩn GMP cho ngành</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dược, thực phẩm.</td><td></td></tr><tr><td>113</td><td></td><td></td><td>Máy đùn và tạo hạt cải</td><td></td><td></td><td>8479</td><td></td><td></td><td>89</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td>Dành cho việc tạo hạt cải bằng phương pháp đùn ve từ hỗn hợp bột ướt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thành hạt cải.</td><td></td></tr><tr><td></td><td>114</td><td></td><td></td><td>Đế khuôn ép</td><td></td><td></td><td>8480</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td>Bằng gỗ, nhựa, thép không gỉ.</td><td></td></tr><tr><td></td><td>115</td><td></td><td></td><td>Van điều tiết đường ống gió</td><td></td><td></td><td>8481</td><td></td><td></td><td>80</td><td></td><td></td><td>99</td><td></td><td></td><td>Bằng thép, đường kính từ 500-650 mm.</td><td></td></tr><tr><td></td><td>116</td><td></td><td></td><td>Van tay gạt RVD 300</td><td></td><td></td><td>8481</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Dày 0,6 mm bằng thép.</td><td></td></tr><tr><td>117</td><td></td><td></td><td>Tổ máy phát điện</td><td></td><td></td><td>8502</td><td></td><td></td><td>12, 13</td><td></td><td></td><td>90</td><td></td><td></td><td>Điện áp 380/220 Volt AC, 3 pha, 4 dây. Tần số 50 Hz, tốc độ 1.500
vòng/phút. Động cơ Perkins. Đầu phát Leroysomer. Bộ điều khiển
Deeepsea.Công suất liên tục từ 75 kVA đến 375 kVA, từ 375 kVA đến 1.000
kVA và từ 1.100kVA đến 2.500 kVA. Sử dụng động cơ đốt trong.</td><td></td><td></td></tr><tr><td>118</td><td></td><td></td><td>Máy phát điện dầu</td><td></td><td></td><td>8502</td><td></td><td></td><td></td><td>11, 12,</td><td></td><td></td><td>00, 10,</td><td></td><td>Sử dụng động cơ MTU, FPT – đầu phát Mecc Atle.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>13</td><td></td><td></td><td>20, 90</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>119</td><td></td><td></td><td>Máy phát điện xăng</td><td></td><td></td><td>8502</td><td></td><td></td><td>20</td><td></td><td></td><td>10</td><td></td><td></td><td>Công suất định mức đến 10kVA/11kVA; điện áp-số pha 220/230V-1.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Làm kín và điều khiển tích hợp toàn bộ các máy tạo thành dây chuyền tạo</th></tr></thead><tbody><tr><td>hạt tích hợp kín (bao gồm các máy: Máy trộn và tạo hạt cao tốc, Máy sấy và</td></tr><tr><td>tạo hạt tầng sôi, Thiết bị nâng và quay, Thiết bị trộn bột khô bằng IBC) nhằm</td></tr><tr><td>hạn chế sự tiếp xúc của người vận hành máy với sản phẩm, gia tăng hiệu</td></tr><tr><td>suất sản xuất thông qua quá trình tự động hóa, giảm thiểu thời gian chờ và</td></tr><tr><td>thao tác máy. Chức năng làm kín chống độc. Quá trình hút cấp liệu, trộn và</td></tr><tr><td>tạo hạt, sấy, xả liệu, hoàn toàn không sinh bụi.</td></tr></tbody></table>

<table><thead><tr><th>vòng/phút. Động cơ Perkins. Đầu phát Leroysomer. Bộ điều khiển</th></tr></thead><tbody><tr><td>Deeepsea.Công suất liên tục từ 75 kVA đến 375 kVA, từ 375 kVA đến 1.000</td></tr><tr><td>kVA và từ 1.100kVA đến 2.500 kVA. Sử dụng động cơ đốt trong.</td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>120</td><td></td><td></td><td>Giá nạp đèn mỏ</td><td></td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 03: 2009/CKUB; Điện áp nguồn 220V, điện áp nạp 5,3±0,1V; Dòng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>điện nạp 0,6±0,1A, số lượng đèn nạp trên giá 120 đèn, sử dụng nạp điện</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cho đèn mỏ ĐM-10K.3.</td><td></td></tr><tr><td>121</td><td></td><td></td><td>Tủ nạp ắc quy tàu điện</td><td></td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>TCCS 03: 2009/CKUB, điện áp nguồn 380 V/660V, tần số 50Hz; điện áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nguồn ra 1 chiều đến 280V, dòng điện đầu ra 1 chiều đến 150 A, dòng điện</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đầu vào 33,4A/19,2A, sử dụng nạp điện ắc quy tầu điện trong mỏ hầm lò.</td><td></td></tr><tr><td></td><td>122</td><td></td><td></td><td>Hệ thống nguồn DC-48V</td><td></td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td>30</td><td></td><td></td><td>Dòng điện từ 10 A đến 600 A.</td><td></td></tr><tr><td>123</td><td></td><td></td><td></td><td>Kết cấu dầm trung tâm máy nghiền clinke xi</td><td></td><td>8474</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Cho máy nghiền công suất 12.000 tấn/năm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>măng (Central Grinder)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>124</td><td></td><td></td><td></td><td>Mắt cắt chân không TV1 (Vacuum Circuit</td><td></td><td>8535</td><td></td><td></td><td></td><td>21, 29,</td><td></td><td></td><td></td><td></td><td>Tiêu chuẩn IEC 62271-100, điện áp đến 40 kV.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Breaker TV1)</td><td></td><td></td><td></td><td></td><td></td><td>30</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>125</td><td></td><td></td><td>Thiết bị nguồn -48VDC dùng cho hệ thống
viễn thông.</td><td></td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td>30</td><td></td><td></td><td>Hệ thống chỉnh lưu từ nguồn AC sang nguồn DC: Điện áp AC và 70-300
VAC. Tần số làm việc 45 – 66 Hz. Hiệu suất đầu vào ≥ 0,99 (50% ~100%
tải). Điện áp DC đầu ra 53,5 VDC. Dải điện áp điều chỉnh 41,5V ~ 58,5V.
Công suất đầu ra 15kW. Dòng điện đầu ra lớn nhất 300A. Hiệu suất ≥
95,5%. Bộ chỉnh lưu lắp sẵn 3 bộ ZXD 3000 (tối đa 5 bộ). Nguồn vào 70 ~
300 VAC. Nguồn ra 41,5 V ~ 58,5 VDC. Công suất lớn nhất 3.000W/bộ. Bộ
giám sát tập trung CSU501B: Giám sát và điều khiển các thiết bị ắc quy, bộ
chỉnh lưu, nguồn điện, môi trường làm việc. Cài đặt các thông số. Hiện thị
các thông số, lỗi, chế độ làm việc tại chỗ hoặc từ xa qua trình duyệt WEB. Tỷ
lệ chi phí sản xuất trong nước 35,36%.</td><td></td><td></td></tr><tr><td>126</td><td></td><td></td><td>Máy biến áp 1 pha, 3 pha</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td>Điện áp đến 220kV, công suất 1 pha đến 200MVA, 3 pha đến 600 MVA. Loại</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>22/0,1kV, dùng để lấy tín hiệu điều khiển cho máy cắt tự đóng.</td><td></td></tr><tr><td></td><td>127</td><td></td><td></td><td>Trạm biến áp hợp bộ các loại</td><td></td><td></td><td>8504</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Điện áp đến 35kV, công suất đến 4.000kVA.</td><td></td></tr><tr><td>128</td><td></td><td></td><td>Trạm biến áp phòng nổ</td><td></td><td></td><td>8504</td><td></td><td></td><td>33</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td>TCVN 10888-2015. Công suất đến 1.600kVA. Điện áp 6/1,2 (0,69)kV và 6/0,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>69(0,4) kV.</td><td></td></tr><tr><td>129</td><td></td><td></td><td>Trạm sạc nhanh cho xe ô tô điện</td><td></td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td>90</td><td></td><td></td><td>Tương thích CHAdeMO/GBT 20234/CCS type 2/Tesla (thông qua adapter).
Có khả năng đạt 80% pin trong vòng 30-40 phút tùy vào dung lượng pin của
xe. Nguồn cung cấp: 380 VAC, 3 pha 4 dây. Dòng sạc tối đa 80A. Công suất
ra 60kW. Hiệu suất tối thiểu 90%. Hệ số công suất tối thiểu 0,98. Cấp bảo vệ
chống bụi &amp; nước IP54.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Hệ thống chỉnh lưu từ nguồn AC sang nguồn DC: Điện áp AC và 70-300</th></tr></thead><tbody><tr><td>VAC. Tần số làm việc 45 – 66 Hz. Hiệu suất đầu vào ≥ 0,99 (50% ~100%</td></tr><tr><td>tải). Điện áp DC đầu ra 53,5 VDC. Dải điện áp điều chỉnh 41,5V ~ 58,5V.</td></tr><tr><td>Công suất đầu ra 15kW. Dòng điện đầu ra lớn nhất 300A. Hiệu suất ≥</td></tr><tr><td>95,5%. Bộ chỉnh lưu lắp sẵn 3 bộ ZXD 3000 (tối đa 5 bộ). Nguồn vào 70 ~</td></tr><tr><td>300 VAC. Nguồn ra 41,5 V ~ 58,5 VDC. Công suất lớn nhất 3.000W/bộ. Bộ</td></tr><tr><td>giám sát tập trung CSU501B: Giám sát và điều khiển các thiết bị ắc quy, bộ</td></tr><tr><td>chỉnh lưu, nguồn điện, môi trường làm việc. Cài đặt các thông số. Hiện thị</td></tr><tr><td>các thông số, lỗi, chế độ làm việc tại chỗ hoặc từ xa qua trình duyệt WEB. Tỷ</td></tr><tr><td>lệ chi phí sản xuất trong nước 35,36%.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị nguồn -48VDC dùng cho hệ thống</th></tr></thead><tbody><tr><td>viễn thông.</td></tr></tbody></table>

<table><thead><tr><th>Có khả năng đạt 80% pin trong vòng 30-40 phút tùy vào dung lượng pin của</th></tr></thead><tbody><tr><td>xe. Nguồn cung cấp: 380 VAC, 3 pha 4 dây. Dòng sạc tối đa 80A. Công suất</td></tr><tr><td>ra 60kW. Hiệu suất tối thiểu 90%. Hệ số công suất tối thiểu 0,98. Cấp bảo vệ</td></tr><tr><td>chống bụi &amp; nước IP54.</td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>130</td><td></td><td></td><td>Biến điện áp đo lường một pha trung thế khô
ngoài trời</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>13</td><td></td><td></td><td></td><td>Điện áp định mức: 6, 15, 24 kV. Dòng điện sơ cấp định mức 2,5-800 A. Dòng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>điện thứ cấp định mức: 1A, 5A. Cấp chính xác 0,5; 1. Tải 10-30 VA. Chiều</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dài đường rò 15 mm/kV. Khối lượng 28 kg. Sử dụng trong vùng nhiễm mặn.</td><td></td></tr><tr><td>131</td><td></td><td></td><td>Biến điện áp đo lường một pha trung thế khô
trong nhà</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>13</td><td></td><td></td><td></td><td>Điện áp định mức: 6, 15, 22 kV. Điện áp thứ cấp định mức: (60-120) V. Cấp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chính xác 0,5. Tải 10-50 VA. Chiều dài đường rò 15 mm/kV. Khối lượng 31</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kg. Sử dụng trong vùng nhiễm mặn.</td><td></td></tr><tr><td>132</td><td></td><td></td><td>Biến dòng điện đo lường một pha khô ngoài
trời</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>24</td><td></td><td></td><td></td><td>Điện áp định mức: 6, 15, 24, 32 kV. Dòng điện sơ cấp định mức 2,5-800 A.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dòng điện thứ cấp định mức 1A, 5A. Cấp chính xác 0,5. Tải 10-30 VA. Chiều</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dài đường rò 25 mm/kV. Khối lượng 32 kg. Sử dụng trong vùng nhiễm mặn.</td><td></td></tr><tr><td>133</td><td></td><td></td><td>Biến dòng điện đo lường một pha khô trong
nhà</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>24</td><td></td><td></td><td></td><td>Điện áp định mức: 6, 15, 24, 32 kV. Dòng điện sơ cấp định mức (2,5-800) A.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dòng điện thứ cấp định mức: 1A, 5A. Cấp chính xác 0,5, 1. Tải (10-30) VA.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chiều dài đường rò: 15 mm/kV. Khối lượng 28 kg. Sử dụng trong vùng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhiễm mặn.</td><td></td></tr><tr><td>134</td><td></td><td></td><td>Biến dòng hạ thế</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td>Điện áp định mức &lt; 1.000V. Dòng điện sơ cấp định mức 50-4.000 A. Dòng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>điện thứ cấp định mức 5A. Cấp chính xác: 0,5; 1. Tải 5-15VA.</td><td></td></tr><tr><td></td><td>135</td><td></td><td></td><td>Máy điều dòng</td><td></td><td></td><td>8504</td><td></td><td></td><td>32</td><td></td><td></td><td>30</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA.</td><td></td></tr><tr><td>136</td><td></td><td></td><td></td><td>Máy biến áp cấp nguồn một pha trung thế khô</td><td></td><td>8504</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Điện áp định mức: 6; 15; 22 kV. Điện áp thứ cấp định mức 100-240 V. Tải</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>ngoài trời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>50-1500 VA. Chiều dài đường rò 31 mm/kV. Khối lượng 39 kg.</td><td></td></tr><tr><td>137</td><td></td><td></td><td>Máy biến áp 110kV</td><td></td><td></td><td>8504</td><td></td><td></td><td>23</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td>TCVN 6306:2006; IEC 60076, IEC 60551, IEC 60354, IEC 60296. Công suất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>định mức đến 63MVA. Điện áp định mức: cuộn cao áp 115kV, cuộn rung áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>38,5 kV, cuộn hạ áp 23 (10) kV. Tỷ số biến: 115±9×1,78%/ 38,5/23(10)kV.</td><td></td></tr><tr><td>138</td><td></td><td></td><td></td><td>Bộ lưu điện không gián đoạn (Bộ cấp nguồn</td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td>11</td><td></td><td></td><td>Đến 2.000 VA.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>liên tục)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>139</td><td></td><td></td><td>Thiết bị biến đổi dòng điện (biến dòng) hạ thế</td><td></td><td></td><td>8504</td><td></td><td></td><td>31</td><td></td><td></td><td>99</td><td></td><td></td><td>Biến dòng 700/5A, mức cách điện 1,15 kV (4 kV – 1 phút).</td><td></td></tr><tr><td></td><td>140</td><td></td><td></td><td>Biến tần</td><td></td><td></td><td>8504</td><td></td><td></td><td>40</td><td></td><td></td><td>90</td><td></td><td></td><td>Điện áp 380-480 V, công suất 37 kW.</td><td></td></tr><tr><td>141</td><td></td><td></td><td>Ắc quy tầu điện a xít phòng nổ</td><td></td><td></td><td>8507</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 02:2013/CKOTUB, dung lượng định mức 450 Ah, dung dịch</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>H2SO4 đến 8 lít, trọng lượng đến 23,7 kg, sử dụng cho tầu điện mỏ hầm lò.</td><td></td></tr><tr><td>142</td><td></td><td></td><td>Ắc quy axít</td><td></td><td></td><td>8507</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 02:2013/CKOTUB, dung dịch H2SO4, sử dụng cho xe nâng điện các</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>loại.</td><td></td></tr><tr><td>143</td><td></td><td></td><td>Ắc quy kiềm</td><td></td><td></td><td>8507</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS01:2009/CKOTUB, dung lượng đến 350 Ah, sử dụng cho tầu điện</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trong hầm lò.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Biến điện áp đo lường một pha trung thế khô</th></tr></thead><tbody><tr><td>ngoài trời</td></tr></tbody></table>

<table><thead><tr><th>Biến điện áp đo lường một pha trung thế khô</th></tr></thead><tbody><tr><td>trong nhà</td></tr></tbody></table>

<table><thead><tr><th>Biến dòng điện đo lường một pha khô ngoài</th></tr></thead><tbody><tr><td>trời</td></tr></tbody></table>

<table><thead><tr><th>Biến dòng điện đo lường một pha khô trong</th></tr></thead><tbody><tr><td>nhà</td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>144</td><td>Ắc quy chì axit bản cực ống</td><td>8507</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td>Chuyên dùng cho xe nâng hàng chạy điện: dung lượng từ 2V-100Ah đến 2V-
1000Ah; Chuyên dùng cho tàu điện mỏ: dung lượng từ 2V-330Ah đến 2V-
650Ah; Chuyên dùng cho đầu máy xe lửa dung lượng từ 12V-160Ah đến
12V – 420Ah; Chuyên dùng cho xe điện sân golf, nhà ga, bến cảng, dung
lượng 6V-130Ah đến 12V-225Ah.</td><td></td><td></td></tr><tr><td>145</td><td>Tấm bản cực ắc quy axít</td><td>8507</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td>Tấm cực CA-450, L=288 mm, sử dụng để lắp ráp bình ắc quy tầu điện và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bình ắc quy xe nâng các loại.</td><td></td></tr><tr><td>146</td><td>Ắc quy axit – chì</td><td>8507</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td>1. Nhóm CP: Ắc quy axit chì sử dụng cho bộ lưu điện văn phòng; Điện áp 1
chiều 12V, dung lượng từ 5Ah đến 65Ah. 2. Nhóm 6FM: Ắc quy axit chì sử
dụng cho Viễn thông, điện lực, văn phòng lớn. Điện áp 1 chiều 12V, dung
lượng từ 33Ah đến 230Ah. 3. Nhóm CG/CGT: Ắc quy axit chì dùng cho năng
lượng mặt trời và viễn thông, điện lực (chịu được nhiệt độ ngoài trời); Điện
áp 1 chiều 2V, dung lượng từ 200Ah đến 3000Ah; Điện áp 1 chiều 12V, dung
lượng từ 50Ah đến 250Ah; Điện áp 1 chiều 12V, dung lượng từ 50Ah đến
180Ah. 4. Nhóm CT: Ắc quy axit chì dùng cho viễn thông, điện lực, UPS với
điện áp 1 chiều 12V, dung lượng từ 50Ah đến 200 Ah. 5. Nhóm CL: Ắc quy
axit chì dung lượng lớn, dùng cho viễn thông, điện lực, các trạm nguồn cần
lưu điện lâu với điện áp 1 chiều 2V, dung lượng từ 100Ah đến 3000 Ah. 6.
Nhóm HF/HP: Ắc quy axit chì dùng cho bộ lưu điện lớn, cần dòng diện lớn ở
các Trung tâm dữ liệu tài chính, ngân hàng. Điện áp 1 chiều 12V, dung
lượng từ 5Ah đến 230Ah. 7. Loại ký hiệu Ắc quy PLG 300AL, PLG 12150: Ắc
quy khô kín, loại axit chì, công nghệ GEL 100% chất điện phân ở dạng keo
phủ đầy thể tích của bình. Ắc quy không cần bảo dưỡng, vỏ bình bằng chất
liệu ABS. Điện áp, dung lượng: 2V đến 12V, 150Ah đến 300Ah.</td><td></td><td></td></tr><tr><td>147</td><td>Ắc quy Lithium</td><td>8507</td><td></td><td></td><td>60</td><td></td><td>90</td><td></td><td></td><td>Nhóm V-LFP, dùng cho viễn thông, điện lực, lưu điện với điện áp 1 chiều</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>48V, dung lượng từ 10Ah đến 100Ah.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>1000Ah; Chuyên dùng cho tàu điện mỏ: dung lượng từ 2V-330Ah đến 2V-</th></tr></thead><tbody><tr><td>650Ah; Chuyên dùng cho đầu máy xe lửa dung lượng từ 12V-160Ah đến</td></tr><tr><td>12V – 420Ah; Chuyên dùng cho xe điện sân golf, nhà ga, bến cảng, dung</td></tr></tbody></table>

<table><thead><tr><th>1. Nhóm CP: Ắc quy axit chì sử dụng cho bộ lưu điện văn phòng; Điện áp 1</th></tr></thead><tbody><tr><td>chiều 12V, dung lượng từ 5Ah đến 65Ah. 2. Nhóm 6FM: Ắc quy axit chì sử</td></tr><tr><td>dụng cho Viễn thông, điện lực, văn phòng lớn. Điện áp 1 chiều 12V, dung</td></tr><tr><td>lượng từ 33Ah đến 230Ah. 3. Nhóm CG/CGT: Ắc quy axit chì dùng cho năng</td></tr><tr><td>lượng mặt trời và viễn thông, điện lực (chịu được nhiệt độ ngoài trời); Điện</td></tr><tr><td>áp 1 chiều 2V, dung lượng từ 200Ah đến 3000Ah; Điện áp 1 chiều 12V, dung</td></tr><tr><td>lượng từ 50Ah đến 250Ah; Điện áp 1 chiều 12V, dung lượng từ 50Ah đến</td></tr><tr><td>180Ah. 4. Nhóm CT: Ắc quy axit chì dùng cho viễn thông, điện lực, UPS với</td></tr><tr><td>điện áp 1 chiều 12V, dung lượng từ 50Ah đến 200 Ah. 5. Nhóm CL: Ắc quy</td></tr><tr><td>axit chì dung lượng lớn, dùng cho viễn thông, điện lực, các trạm nguồn cần</td></tr><tr><td>lưu điện lâu với điện áp 1 chiều 2V, dung lượng từ 100Ah đến 3000 Ah. 6.</td></tr><tr><td>Nhóm HF/HP: Ắc quy axit chì dùng cho bộ lưu điện lớn, cần dòng diện lớn ở</td></tr><tr><td>các Trung tâm dữ liệu tài chính, ngân hàng. Điện áp 1 chiều 12V, dung</td></tr><tr><td>lượng từ 5Ah đến 230Ah. 7. Loại ký hiệu Ắc quy PLG 300AL, PLG 12150: Ắc</td></tr><tr><td>quy khô kín, loại axit chì, công nghệ GEL 100% chất điện phân ở dạng keo</td></tr><tr><td>phủ đầy thể tích của bình. Ắc quy không cần bảo dưỡng, vỏ bình bằng chất</td></tr><tr><td>liệu ABS. Điện áp, dung lượng: 2V đến 12V, 150Ah đến 300Ah.</td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>148</td><td></td><td></td><td>Thiết bị thông tin băng siêu rộng (UWB)</td><td></td><td></td><td>8517</td><td></td><td></td><td>62</td><td></td><td></td><td>59</td><td></td><td></td><td>QCVN 47:2015/BTTTT, QCVN 94:2015/BTTTT. Dùng để ứng dụng cố định
trong nhà hoặc di động và xách tay, bao gồm: Các thiết bị vô tuyến độc lập
có hoặc không có phần điều khiển kèm theo, Các thiết bị vô tuyến cắm thêm
(plug-in) dạng mô- đun được sử dụng để cắm vào các đối tượng thiết bị chủ
khác nhau, như máy tính cá nhân, thiết bị đầu cuối cầm tay. Các thiết bị vô
tuyến cắm thêm được dùng trong thiết bị tổ hợp, ví dụ như các modem cáp,
set-top box, điểm truy nhập, Thiết bị tổ hợp hoặc tổ hợp của thiết bị vô tuyến
cắm thêm và một thiết bị chủ cụ thể, Thiết bị dùng trong các phương tiện
đường bộ và đường sắt.</td><td></td><td></td></tr><tr><td>149</td><td></td><td></td><td>Thiết bị vô tuyến lưu động mặt đất</td><td></td><td></td><td>8517</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 37:2018/BTTTT, QCVN 44:2018/BTTTT. Thiết bị cầm tay vô tuyến số</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc vô tuyến kết hợp tương tự/số dùng ăng ten rời/liền để truyền số liệu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>và/hoặc thoại.</td><td></td></tr><tr><td>150</td><td></td><td></td><td>Trạm wifi phòng nổ</td><td></td><td></td><td>8517</td><td></td><td></td><td>62</td><td></td><td></td><td>51</td><td></td><td></td><td></td><td>Điện áp làm việc:U = 127/220/380/660 VAC, tần số fmax 50-60 Hz, phủ sóng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bán kính 70-150 m, cổng truyền thông Internet đến các thiết bị khác.</td><td></td></tr><tr><td>151</td><td></td><td></td><td>Cụm đầu cộng hưởng</td><td></td><td></td><td>8517</td><td></td><td></td><td>70</td><td></td><td></td><td>99</td><td></td><td></td><td></td><td>Gồm đầu cộng hưởng bằng thép, thanh dẫn truyền tín hiệu bằng đồng mạ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bạc, dùng trong sản xuất bộ lọc anten.</td><td></td></tr><tr><td>152</td><td></td><td></td><td>Thiết bị âm thanh không dây</td><td></td><td></td><td>8518</td><td></td><td></td><td>10</td><td></td><td></td><td>19</td><td></td><td></td><td></td><td>QCVN 91:2015/BTTTT. Công suất phát vô tuyến dưới 10 mW, dải tần</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>25MHz đến 2.000MHz.</td><td></td></tr><tr><td>153</td><td></td><td></td><td>Bộ loa</td><td></td><td></td><td>8518</td><td></td><td></td><td>29</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Gồm loa thanh công suất 47 W, loa trầm công suất 8W, loa phụ công suất 25</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>W.</td><td></td></tr><tr><td></td><td>154</td><td></td><td></td><td>Máy ghi âm chuyên dụng hàng không</td><td></td><td></td><td>8519</td><td></td><td></td><td>89</td><td></td><td></td><td>20</td><td></td><td></td><td>TCCS của Nhà sản xuất (Tổng công ty quản lý bay).</td><td></td></tr><tr><td></td><td>155</td><td></td><td></td><td>Thẻ điều hướng</td><td></td><td></td><td>8523</td><td></td><td></td><td>52</td><td></td><td></td><td>0</td><td></td><td></td><td>Bằng nhựa, điện áp 380V.</td><td></td></tr><tr><td></td><td>156</td><td></td><td></td><td>Thiết bị camera giám sát tầm gần</td><td></td><td></td><td>8525</td><td></td><td></td><td>80</td><td></td><td></td><td>99</td><td></td><td></td><td>Camera ngày và nhiệt, độ phân giải ≥ 640 x 480.</td><td></td></tr><tr><td>157</td><td></td><td></td><td></td><td>Đài quan sát điện tử tầm xa trang bị cho tàu</td><td></td><td>8525</td><td></td><td></td><td>80</td><td></td><td></td><td>99</td><td></td><td></td><td>Camera ngày, độ phân giải≥ 640 x 480, bước sóng MWIR.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>biển</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>158</td><td></td><td></td><td>Camera phòng nổ</td><td></td><td></td><td>8525</td><td></td><td></td><td>80</td><td></td><td></td><td>99</td><td></td><td></td><td>Tầm nhìn 30-80 m, vùng áp dụng: Zone 1, Zone 2.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>QCVN 47:2015/BTTTT, QCVN 94:2015/BTTTT. Dùng để ứng dụng cố định</th></tr></thead><tbody><tr><td>trong nhà hoặc di động và xách tay, bao gồm: Các thiết bị vô tuyến độc lập</td></tr><tr><td>có hoặc không có phần điều khiển kèm theo, Các thiết bị vô tuyến cắm thêm</td></tr><tr><td>(plug-in) dạng mô- đun được sử dụng để cắm vào các đối tượng thiết bị chủ</td></tr><tr><td>khác nhau, như máy tính cá nhân, thiết bị đầu cuối cầm tay. Các thiết bị vô</td></tr><tr><td>tuyến cắm thêm được dùng trong thiết bị tổ hợp, ví dụ như các modem cáp,</td></tr><tr><td>set-top box, điểm truy nhập, Thiết bị tổ hợp hoặc tổ hợp của thiết bị vô tuyến</td></tr><tr><td>cắm thêm và một thiết bị chủ cụ thể, Thiết bị dùng trong các phương tiện</td></tr><tr><td>đường bộ và đường sắt.</td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>159</td><td></td><td></td><td>Thiết bị giám sát hành trình tàu cá</td><td></td><td></td><td>8526</td><td></td><td></td><td>91</td><td></td><td></td><td>10</td><td></td><td></td><td>QCVN 18:2014/BTTTT, QCVN 47:2015/BTTTT. Các thiết bị VHK-S, VHK-
SL:1. GPS: tần số trung tâm (CF): 1575,42±3MHz, độ rộng CF±5MHz, phân
cực RHCP, VSWR: &lt; 2 Max, độ lợi 5 dBi (Zenith); 2. Vệ tinh: dải tần số 1616
MHz-1626,5 MHz, phân cực RHCP, SWP 1,5 Max, công suất phát 1,6 W
(Max); 3. Màn hình 7-10 Inch Touch Screen; 4. Nguồn điện đầu vào: 13,8
VDC; 5. Dòng điện tiêu thụ: 300 mA- 1,1A (max); 6. Pin Lithium 3,7V, 20 Ah;
7. Khả năng chống nước IP68.</td><td></td><td></td></tr><tr><td>160</td><td></td><td></td><td></td><td>Thiết bị thu tín hiệu truyền hình số vệ tinh</td><td></td><td>8527</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN 80:2014/BTTTT</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>DVB-S và DVB-S2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>161</td><td></td><td></td><td>Máy thu hình</td><td></td><td></td><td>8528</td><td></td><td></td><td>72</td><td></td><td></td><td>92</td><td></td><td></td><td></td><td>Độ phân giải WXGA 1366 x 768 điểm ảnh, hệ màu chọn tự động: PAL,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>SECAM, NTSC 3,58 &amp; 4,43 MHz, độ tương phản 50000:1, tần số quét 50</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Hz, tính năng Full HD.</td><td></td></tr><tr><td></td><td>162</td><td></td><td></td><td>Đèn chớp tuần tự hàng không</td><td></td><td></td><td>8530</td><td></td><td></td><td>80</td><td></td><td></td><td>0</td><td></td><td></td><td>Tiêu chuẩn ICAO, FAA</td><td></td></tr><tr><td>163</td><td></td><td></td><td>Tụ điện trung thế một pha</td><td></td><td></td><td>8532</td><td></td><td></td><td>29</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Điện áp định mức (6,6 – 22) kV. Dòng điện (4,5-30,3) A. Công suất đến 200</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kVar.</td><td></td></tr><tr><td></td><td>164</td><td></td><td></td><td>Cầu chì tự rơi</td><td></td><td></td><td>8535</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Cách điện Polymer hoặc gốm sứ tráng men, đến 200 A – 38,5 kV.</td><td></td></tr><tr><td></td><td>165</td><td></td><td></td><td>Cầu chì tự rơi cắt có tải</td><td></td><td></td><td>8535</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Cách điện Polymer hoặc gốm sứ tráng men, đến 200 A – 27 kV.</td><td></td></tr><tr><td></td><td>166</td><td></td><td></td><td>Cầu dao phụ tải, cầu dao cách ly</td><td></td><td></td><td>8535</td><td></td><td></td><td>29</td><td></td><td></td><td>10</td><td></td><td></td><td>Đến 22kV và 630A. Bộ ngắt kết nối lưới điện ngoài trời 3 pha.</td><td></td></tr><tr><td></td><td>167</td><td></td><td></td><td>Dao cắt có tải, Recloser</td><td></td><td></td><td>8535</td><td></td><td></td><td>30</td><td></td><td></td><td>11</td><td></td><td></td><td>Đến 24 kV, 630 A. Máy cắt tự đóng 3 pha.</td><td></td></tr><tr><td></td><td>168</td><td></td><td></td><td>Cầu dao tự động</td><td></td><td></td><td>8535</td><td></td><td></td><td>30</td><td></td><td></td><td>90</td><td></td><td></td><td>Dạng khối EBN 103/75, dòng định mức 75A, điện áp 220-460V.</td><td></td></tr><tr><td>169</td><td></td><td></td><td>Máy cắt tự động</td><td></td><td></td><td>8536</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Các loại 1 pha – 2 cực, 1 pha – 2 cực, 3 pha – 3 cực, 3 pha – 4 cực đến 63</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>A.</td><td></td></tr><tr><td></td><td>170</td><td></td><td></td><td>Cầu chì dùng cho xe nâng có động cơ</td><td></td><td></td><td>8536</td><td></td><td></td><td>10</td><td></td><td></td><td>93</td><td></td><td></td><td>Cường độ dòng điện đến 10 A.</td><td></td></tr><tr><td></td><td>171</td><td></td><td></td><td>Aptomat</td><td></td><td></td><td>8536</td><td></td><td></td><td>20</td><td></td><td></td><td>99</td><td></td><td></td><td>Loại ABS 203/150, dùng điện định mức 203 A, điện áp 150V.</td><td></td></tr><tr><td></td><td>172</td><td></td><td></td><td>Rơ le bảo vệ quá dòng</td><td></td><td></td><td>8536</td><td></td><td></td><td>49</td><td></td><td></td><td>90</td><td></td><td></td><td>Dải điều chỉnh 150 A.</td><td></td></tr><tr><td></td><td>173</td><td></td><td></td><td>Công tắc đa chiều, 1 chiều</td><td></td><td></td><td>8536</td><td></td><td></td><td>50</td><td></td><td></td><td>61</td><td></td><td></td><td>Điện áp 15A/250 V, chất liệu plastic.</td><td></td></tr><tr><td></td><td>174</td><td></td><td></td><td>Khởi động từ</td><td></td><td></td><td>8536</td><td></td><td></td><td>50</td><td></td><td></td><td>69</td><td></td><td></td><td>Dòng điện định mức 330 A, điện áp 200 V.</td><td></td></tr><tr><td></td><td>175</td><td></td><td></td><td>Công tắc chênh áp dùng cho bộ lọc</td><td></td><td></td><td>8536</td><td></td><td></td><td>50</td><td></td><td></td><td>99</td><td></td><td></td><td>Dải áp 0,2-50 mbar, điện áp 5 V.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>QCVN 18:2014/BTTTT, QCVN 47:2015/BTTTT. Các thiết bị VHK-S, VHK-</th></tr></thead><tbody><tr><td>SL:1. GPS: tần số trung tâm (CF): 1575,42±3MHz, độ rộng CF±5MHz, phân</td></tr><tr><td>cực RHCP, VSWR: &lt; 2 Max, độ lợi 5 dBi (Zenith); 2. Vệ tinh: dải tần số 1616</td></tr><tr><td>MHz-1626,5 MHz, phân cực RHCP, SWP 1,5 Max, công suất phát 1,6 W</td></tr><tr><td>(Max); 3. Màn hình 7-10 Inch Touch Screen; 4. Nguồn điện đầu vào: 13,8</td></tr><tr><td>VDC; 5. Dòng điện tiêu thụ: 300 mA- 1,1A (max); 6. Pin Lithium 3,7V, 20 Ah;</td></tr><tr><td>7. Khả năng chống nước IP68.</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>176</td><td></td><td></td><td>Biến áp khoan phòng nổ</td><td></td><td></td><td>8537</td><td></td><td></td><td>21, 31</td><td></td><td></td><td></td><td>10, 90,</td><td></td><td></td><td>TCVN 10888-2015. Dạng bảo vệ nổ ExdIMb, công suất đến 4 kVA, điện áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>02</td><td></td><td></td><td>đến 1.200/133 V.</td><td></td></tr><tr><td>177</td><td></td><td></td><td>Tủ lắp thiết bị ngoài trời.</td><td></td><td></td><td>8537</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Độ dày khung thép 1.5 mm;Tải trọng chịu đựng 600 kg. Thành tủ 3 lớp, lớp
cách nhiệt dày 40 mm. Cánh tủ khóa an toàn kết cấu 3 điểm; Ổ cắm nguồn
máy phát: 63A, 230V, chuẩn IP67. Khung giá lắp thiết bị chuẩn 19″; Tải trọng
300kg. Giám sát cảnh báo: nhiệt độ môi trường, cháy nổ, cửa mở, ngập
nước. Nhiệt độ làm việc -20oC~+70oC. Độ ẩm 10% ~ 95%.</td><td></td><td></td></tr><tr><td>178</td><td></td><td></td><td>Tủ điện các loại (trên bờ)</td><td></td><td></td><td>8537</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Vỏ tủ bằng sắt sơn tĩnh điện và lắp đặt các thiết bị điện. Điện áp không quá</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.000V.</td><td></td></tr><tr><td></td><td>179</td><td></td><td></td><td>Tủ điện hạ áp, tủ điều khiển các loại</td><td></td><td></td><td>8537</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td><td></td><td>Điện áp đến 600 V, dòng điện 75-2500 A.</td><td></td></tr><tr><td></td><td>180</td><td></td><td></td><td>Tủ điện trung thế</td><td></td><td></td><td>8537</td><td></td><td></td><td>20</td><td></td><td></td><td></td><td></td><td></td><td>Tủ điện đóng cắt và điều khiển cao áp. Dòng điện định mức đến 2500 A.</td><td></td></tr><tr><td></td><td>181</td><td></td><td></td><td>Tủ tiếp địa</td><td></td><td></td><td>8537</td><td></td><td></td><td>10</td><td></td><td></td><td>99</td><td></td><td></td><td>Dùng để bảo vệ con người, không có công suất và điện áp.</td><td></td></tr><tr><td>182</td><td></td><td></td><td>Biến áp chiếu sáng phòng nổ</td><td></td><td></td><td>8538</td><td></td><td></td><td>21, 32</td><td></td><td></td><td></td><td>10, 90,</td><td></td><td></td><td>TCVN 10888-2015. Dạng bảo vệ nổ ExdIMb, công suất đến 20 kVA, điện áp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>03</td><td></td><td></td><td>đến 1.200/ 220(127) V.</td><td></td></tr><tr><td>183</td><td></td><td></td><td>Bản mạch đã lắp ráp của loa</td><td></td><td></td><td>8542</td><td></td><td></td><td>39</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bản mạch đã lắp ráp của loa, dùng cho model HW-Q60T/KR, kích thước:</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>303,26 x 93,8 x 34,81 mm.</td><td></td></tr><tr><td></td><td>184</td><td></td><td></td><td>Hệ thống điều khiển đèn hiệu</td><td></td><td></td><td>8543</td><td></td><td></td><td>70</td><td></td><td></td><td>20</td><td></td><td></td><td>Tiêu chuẩn ICAO, FAA</td><td></td></tr><tr><td></td><td>185</td><td></td><td></td><td>Đầu máy truyền động thủy lực</td><td></td><td></td><td>8602</td><td></td><td></td><td>90</td><td></td><td></td><td>0</td><td></td><td></td><td>Di chuyển trên đường ray</td><td></td></tr><tr><td>186</td><td></td><td></td><td>Giá thủy lực di động liên kết xích</td><td></td><td></td><td>8607</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 05:2015/VMC. Gồm các giá thủy lực phân thể/di động dùng trong các</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mỏ than hầm lò như GK 1600/1.6/2.4/HTD. Áp lực làm việc định mức 42</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MPa; đường kính xi lanh F60 – F200 (mm), chiều dài xi lanh: 400-2.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(mm). Van điểu khiển 7 tay.</td><td></td></tr><tr><td>187</td><td></td><td></td><td>Giá khung thủy lực</td><td></td><td></td><td>8607</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCCS 04:2015/VMC, TCCS 06:2015/VMC. Áp lực làm việc định mức 42
Mpa, áp lực nền 0,44 Mpa, góc giới hạn dốc lò chợ ≤ 45o. Dùng trong mỏ
than hầm lò.</td><td>TCCS 04:2015/VMC, TCCS 06:2015/VMC. Áp lực làm việc định mức 42</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Mpa, áp lực nền 0,44 Mpa, góc giới hạn dốc lò chợ ≤ 45o. Dùng trong mỏ</td><td></td></tr><tr><td></td><td>188</td><td></td><td></td><td>Cột gió có chiếu sáng</td><td></td><td></td><td>8608</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td><td></td><td>Tiêu chuẩn ICAO, FAA.</td><td></td></tr><tr><td></td><td>189</td><td></td><td></td><td>Máy kéo</td><td></td><td></td><td>8701</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dung tích (động cơ) dưới 1.100 cc.</td><td></td></tr><tr><td></td><td>190</td><td></td><td></td><td>Máy kéo dùng trong nông nghiệp</td><td></td><td></td><td>8701</td><td></td><td></td><td>92</td><td></td><td></td><td>10</td><td></td><td></td><td>Máy kéo trục đơn, cầm tay, công suất không quá 37 kW.</td><td></td></tr><tr><td>191</td><td></td><td></td><td>Bơm tiêm tự khóa</td><td></td><td></td><td>9018</td><td></td><td></td><td>31</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>K1- 0,5 ml, 1 ml, 3 ml, 5 ml kèm kim ISO 7886 – 3: 2005. PQS E8/26. Tiêu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chuẩn của WHO.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Độ dày khung thép 1.5 mm;Tải trọng chịu đựng 600 kg. Thành tủ 3 lớp, lớp</th></tr></thead><tbody><tr><td>cách nhiệt dày 40 mm. Cánh tủ khóa an toàn kết cấu 3 điểm; Ổ cắm nguồn</td></tr><tr><td>máy phát: 63A, 230V, chuẩn IP67. Khung giá lắp thiết bị chuẩn 19″; Tải trọng</td></tr><tr><td>300kg. Giám sát cảnh báo: nhiệt độ môi trường, cháy nổ, cửa mở, ngập</td></tr><tr><td>nước. Nhiệt độ làm việc -20oC~+70oC. Độ ẩm 10% ~ 95%.</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>192</td><td></td><td></td><td>Bơm tiêm Insulin</td><td></td><td></td><td>9018</td><td></td><td></td><td>31</td><td></td><td></td><td>10</td><td></td><td></td><td>ISO 8537: 2007.</td><td></td></tr><tr><td></td><td>193</td><td></td><td></td><td>Bơm tiêm điện</td><td></td><td></td><td>9018</td><td></td><td></td><td>31</td><td></td><td></td><td>10</td><td></td><td></td><td>ISO 7886-2: 1996.</td><td></td></tr><tr><td>194</td><td></td><td></td><td>Bộ dây lọc thận</td><td></td><td></td><td>9018</td><td></td><td></td><td>39</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Bộ dây lọc máu TMC được làm bằng chất liệu PVC, có độ đàn hồi tốt, hạn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chế bị thắt nút hoặc xoắn. Thành bộ dây trong suốt, mềm dẻo giúp quan sát</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tốt lượng máu đi qua bộ dây. Đường kính dây bơm 8 x 12 mm, dài 350 mm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc 410 mm. Tiệt trùng khí E.O.</td><td></td></tr><tr><td>195</td><td></td><td></td><td>Bộ kim AVF 16G</td><td></td><td></td><td>9018</td><td></td><td></td><td>39</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Phần dây của kim AVF có độ đàn hồi cực tốt, dây chống xoắn. Kim đầu vát,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>có back eye. Chiều dài kim 2,5 cm, độ dài dây 30 cm. Tiệt trùng khí E.O.</td><td></td></tr><tr><td>196</td><td></td><td></td><td>Máy rửa dụng cụ y tế</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Đa kết hợp: siêu âm – phun xoáy dòng áp lực và khử khuẩn bậc cao. Model:</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>AMC-21C, AMC-60, AMC-154, AMC-156, AMC-180, AMC-220, AMC-250.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tần số siêu âm ≥ 35 kHz.</td><td></td></tr><tr><td></td><td>197</td><td></td><td></td><td>Máy sấy dụng cụ y tế</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td>Model: AMD-165, AMD-168, AMD-180, AMD-220, AMD-250, AMD-300.</td><td></td></tr><tr><td>198</td><td></td><td></td><td>Máy hấp nhiệt độ thấp dụng cụ y tế</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Model: ASP-30, ASP-60, ASP-90, ASP-120, ASP-150, ASP-170</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Ứng dụng: Hấp tiệt trùng các dụng cụ y tế nhạy cảm với nhiệt độ cao</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Điều khiển hoàn toàn tự động bằng PLC.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Sử dụng nguồn vào là oxy y tế để tạo ra ozone plasma lạnh ở nhiệt độ
thấp (60C ÷ 100C), giải phóng ôxy nguyên tử là tác nhân tiệt khuẩn.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thấp (60C ÷ 100C), giải phóng ôxy nguyên tử là tác nhân tiệt khuẩn.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Công nghệ plasma lạnh, đóng gói vô khuẩn tự động. Không sử dụng hóa</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>chất để tiệt khuẩn.</td><td></td></tr><tr><td>199</td><td></td><td></td><td>Máy phun khử khuẩn phòng mổ</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Model: OZPRO-1000, OZPRO-3000, OZPRO-5000. Sử dụng nguồn vào là</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>20% oxy từ không khí trong phòng để tạo ra ozone plasma nồng độ cao giải</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phóng ôxy nguyên tử để khử khuẩn phòng mổ, phòng chăm sóc đặc biệt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ICU, phòng thay đồ bệnh viện, phòng kho sạch trước và sau ca phẫu thuật.</td><td></td></tr><tr><td>200</td><td></td><td></td><td>Máy rửa siêu âm</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Model: UC-1018, UC-1018S, UC-2218, UC-2218S, UC-3518, UC-3518S,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>UC-9618, UC-9618S. Máy rửa siêu âm sử dụng sóng siêu âm tần số 40 kHz</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kết hợp với dung môi (là nước và chất tẩy rửa chuyên dụng) để làm sạch,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khử khuẩn các dụng cụ y tế.</td><td></td></tr><tr><td>201</td><td></td><td></td><td>Tủ bảo quản rác thải y tế</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>HP-360C. Dung tích 300 lít. Phạm vi sử dụng: Bảo quản rác thải ở nhiệt độ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thấp y tế trước khi đưa đi xử lý. Kết cấu: ngăn tủ Inox 304, dàn lạnh nhôm,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cấp đông nhanh.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>202</td><td></td><td></td><td>Thiết bị hấp chất thải y tế lây nhiễm</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>QCVN 55:2013/BTNMT.</td><td></td></tr><tr><td>203</td><td></td><td></td><td>Hệ thống xử lý nước thải y tế</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Công suất đến 2000 m³/ngày đêmNước thải sau xử lý đạt tiêu chuẩn: Cột A</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>QCVN28:2010/ BTNMT.</td><td></td></tr><tr><td>204</td><td></td><td></td><td>Tủ sấy tĩnh (điện/hơi)</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Thực hiện chức năng sấy tĩnh, sấy đối lưu bằng điện trở hoặc hơi nước để</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sấy nguyên liệu, chai lọ với nhiệt độ cao, phân bố nhiệt độ đồng đều.</td><td></td></tr><tr><td></td><td>205</td><td></td><td></td><td>Thiết bị laser châm</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Model A302 Plus.</td><td></td></tr><tr><td></td><td>206</td><td></td><td></td><td>Thiết bị tổ hợp điện điều trị</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Model E699 Plus.</td><td></td></tr><tr><td></td><td>207</td><td></td><td></td><td>Thiết bị laser nội mạch</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Model LS216.</td><td></td></tr><tr><td></td><td>208</td><td></td><td></td><td>Thiết bị laser ngoài</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Model SL517.</td><td></td></tr><tr><td></td><td>209</td><td></td><td></td><td>Thiết bị kéo giãn trị liệu</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Model T518.</td><td></td></tr><tr><td></td><td>210</td><td></td><td></td><td>Thiết bị phẫu thuật laser CO2 45W</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>KC01-06/MTC Super.</td><td></td></tr><tr><td></td><td>211</td><td></td><td></td><td>Thiết bị laser Ho:YAG tán sỏi nội soi</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Ho-LS05 Laser Holmium.</td><td></td></tr><tr><td></td><td>212</td><td></td><td></td><td>Thiết bị laser thẩm mỹ Nd-Yag</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Thiết bị Laser Nd:YAG.</td><td></td></tr><tr><td></td><td>213</td><td></td><td></td><td>Thiết bị tán sỏi ngoài cơ thể</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>LIMED ESWL 98/LTTD.</td><td></td></tr><tr><td>214</td><td></td><td></td><td></td><td>Thiết bị phẫu thuật quang đông cầm máu</td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>APC – Meldic 08.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>argon plasma</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>215</td><td></td><td></td><td>Thiết bị từ – nhiệt – cơ</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Thiết bị ứng dụng năng lượng từ trường kết hợp với các tác nhân vật lý khác</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phục vụ công tác điều trị, trị liệu một số bệnh: đau vai gáy cổ.</td><td></td></tr><tr><td>216</td><td></td><td></td><td>Thiết bị trị liệu ngoài da kết hợp liệu pháp
laser và kỹ thuật tạo áp suất âm</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Thiết bị trị liệu ngoài da kết hợp liệu pháp laser và kỹ thuật tạo áp suất âm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>được kết hợp hai phương pháp trị liệu trong một máy gồm áp lực âm và</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>laser diode trị liệu.</td><td></td></tr><tr><td>217</td><td></td><td></td><td>Thiết bị led điều trị và chăm sóc da</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Thiết bị sử dụng hiệu ứng ánh sáng phi nhiệt của LED ở các bước sóng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trong vùng nhìn thấy màu xanh và màu đỏ để điều trị và chăm sóc da.</td><td></td></tr><tr><td>218</td><td></td><td></td><td>Tủ bảo quản hóa chất</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td>Dung tích đến 1000 lít. Tốc độ dòng khí lưu thông: ~ 0,5 m/s. Lưu lượng
thông khí ~ 234 m3/h. Có thể lấy mẫu cho các thử nghiệm về mức độ bão
hòa của bộ lọc với mã màu ống phản ứng. Thiết bị hoạt động bằng điện.
Điều khiển các thông số nhiệt độ, dòng khí bằng vi xử lý kỹ thuật số Thiết bị
được thiết kế để bảo vệ người. Sử dụng và bảo vệ môi trường khỏi các hóa
chất độc, hơi độc của dung môi và axít.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị trị liệu ngoài da kết hợp liệu pháp</th></tr></thead><tbody><tr><td>laser và kỹ thuật tạo áp suất âm</td></tr></tbody></table>

<table><thead><tr><th>Dung tích đến 1000 lít. Tốc độ dòng khí lưu thông: ~ 0,5 m/s. Lưu lượng</th></tr></thead><tbody><tr><td>thông khí ~ 234 m3/h. Có thể lấy mẫu cho các thử nghiệm về mức độ bão</td></tr><tr><td>hòa của bộ lọc với mã màu ống phản ứng. Thiết bị hoạt động bằng điện.</td></tr><tr><td>Điều khiển các thông số nhiệt độ, dòng khí bằng vi xử lý kỹ thuật số Thiết bị</td></tr><tr><td>được thiết kế để bảo vệ người. Sử dụng và bảo vệ môi trường khỏi các hóa</td></tr><tr><td>chất độc, hơi độc của dung môi và axít.</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>219</td><td></td><td></td><td>Tủ bảo quản tài liệu</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Dùng để bảo quản lâu dài các tài liệu, giấy tờ, các thiết bị và dụng cụ quan</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trọng trong các lĩnh vực liên quan. Model HOV- TBQ.</td><td></td></tr><tr><td>220</td><td></td><td></td><td>Tủ bảo quản máu</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Dung tích đến 1.000 lít. Nhiệt độ hoạt động từ 2°C đến 8°C. Điều khiển nhiệt</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>độ bằng vi xử lý có độ chính xác cao.</td><td></td></tr><tr><td>221</td><td></td><td></td><td>Thiết bị xử lý rác thải phòng thí nghiệm</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>30</td><td></td><td></td><td></td><td>Công nghệ NASA, điều khiển bằng vi xử lý. Hiển thị bằng màn hình LED, có</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thể ngăn chặn sự rò rỉ của khí aerosol, kích thước 350 x 300 x 450 mm.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dùng trong phòng thí nghiệm y tế.</td><td></td></tr><tr><td>222</td><td></td><td></td><td>Thiết bị siêu âm trị liệu</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Công suất siêu âm từ 1 mW/cm2 – 4 mW/cm2. Tần số siêu âm: 880 KHz; 1,1</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MHz; 2 MHz.</td><td></td></tr><tr><td></td><td>223</td><td></td><td></td><td>Thiết bị laser bán dẫn châm cứu</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Bước sóng 760 nm, công suất 4 mW/đầu châm, 8 – 10 kênh châm.</td><td></td></tr><tr><td></td><td>224</td><td></td><td></td><td>Thiết bị từ trường trị liệu</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Cường độ đến 50 mT.</td><td></td></tr><tr><td>225</td><td></td><td></td><td>Monitor theo dõi bệnh nhân</td><td></td><td></td><td>9018</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Xử lý, phân tích và trình bày dữ liệu 5 thông số khác nhau: ECG, số lần đập
của tim (HR), NIBP, SpO2, nhiệt độ và 5 dòng khí gây mê cho người lớn, trẻ
em, trẻ sơ sinh.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>của tim (HR), NIBP, SpO2, nhiệt độ và 5 dòng khí gây mê cho người lớn, trẻ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>em, trẻ sơ sinh.</td><td></td></tr><tr><td>226</td><td></td><td></td><td>Máy trợ thở áp lực dương liên tục</td><td></td><td></td><td>9019</td><td></td><td></td><td>20</td><td></td><td></td><td>0</td><td></td><td></td><td></td><td>Máy trợ thở áp lực dương liên tục CPAP là thiết bị tạo ra một áp lực dương</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>liên tục lên đường thở kể cả thời gian hít vào và thở ra để hỗ trợ cho trẻ suy</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hô hấp còn tự thở được.</td><td></td></tr><tr><td>227</td><td></td><td></td><td>Máy hiệu ứng nhiệt</td><td></td><td></td><td>9019</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>TCVN 5699-1:2010, IEC 60335-1:2010. Điện áp danh định 220 V. Tần suất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>danh định 50 Hz – 60 Hz. Công suất danh định đến 66W. Nhiệt xung 3 mức</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhiệt độ từ 50 ~ 75°C. Tạo nhiệt, tạo xung dùng kết hợp với thuốc thảo dược</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>để tăng khả năng thẩm thấu thuốc qua da.</td><td></td></tr><tr><td>228</td><td></td><td></td><td>Máy vật lý trị liệu</td><td></td><td></td><td>9019</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>TCVN 5699-1:2010, IEC 60335-1:2010. Điện áp danh định 220 VAC. Tần
suất danh định 50Hz-60Hz. Công suất danh định đến 60W. Laser bước sóng
từ 600-650 nm. Ion âm điện áp âm từ -340V – 600V. Nhiệt xung: 8 mức nhiệt
độ từ 56,9 ~ 115,2oC. Tạo nhiệt, tạo xung, tạo ion, tạo laser dùng kết hợp
thuốc thảo dược để tăng khả năng thẩm thấu thuốc qua da.</td><td></td><td></td></tr><tr><td>229</td><td></td><td></td><td>Công tơ 1 pha</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Cấp chính xác 1,0. Điện áp 220 VAC. Dòng điện: 5(80)A, 5(60)A, 20(80)A,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>10(40) A. Dòng điện khởi động (Ist)&lt; 0,4% Ib. Tần số làm việc 50 Hz. Hằng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>số công tơ 1.600 xung/kWh. Cấp cách điện 2. Sơ đồ đấu dây 1 pha 2 dây.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tích hợp công nghệ truyền chỉ số công tơ từ xa bằng sóng vô tuyến.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>TCVN 5699-1:2010, IEC 60335-1:2010. Điện áp danh định 220 VAC. Tần</th></tr></thead><tbody><tr><td>suất danh định 50Hz-60Hz. Công suất danh định đến 60W. Laser bước sóng</td></tr><tr><td>từ 600-650 nm. Ion âm điện áp âm từ -340V – 600V. Nhiệt xung: 8 mức nhiệt</td></tr><tr><td>độ từ 56,9 ~ 115,2oC. Tạo nhiệt, tạo xung, tạo ion, tạo laser dùng kết hợp</td></tr><tr><td>thuốc thảo dược để tăng khả năng thẩm thấu thuốc qua da.</td></tr></tbody></table>

|<image_18>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>230</td><td></td><td></td><td>Công tơ 1 pha nhiều biểu giá</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Cấp chính xác 1,0 (Điện năng tác dụng) và 2,0 (Điện năng phản kháng).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Điện áp: 220VAC. Dòng điện: 5(80) A, 5(10) A. Dòng điện khởi động(Ist):</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0,4% Ib (CCX 1,0), 0,1% Ib (CCX 0,5S), 0,5% Ib (CCX 2,0), 0,5% Ib (CCX</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2,0). Tần số làm việc: 50Hz. Hằng số công tơ đến 5.000 xung/kWh, 5.000</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>xung/ kvarh. Cấp cách điện: 2. Sơ đồ đấu dây: 1 pha 2 dây, Loại trực tiếp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc gián tiếp. Tích hợp công nghệ truyền chỉ số công tơ từ xa bằng sóng vô</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tuyến.</td><td></td></tr><tr><td>231</td><td></td><td></td><td>Tủ đo đếm điện năng phòng nổ các loại</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>TCVN 10888-2017. Dạng bảo vệ nổ ExdI. Dòng điện đến 400 A, điện áp 690</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>V.</td><td></td></tr><tr><td></td><td>232</td><td></td><td></td><td>Máy đo kiểm điện tổng hợp</td><td></td><td></td><td>9028</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Đo động cơ điện &lt; 50 W, đo điện áp, công suất tiêu thụ.</td><td></td></tr><tr><td>233</td><td></td><td></td><td>Công tơ 3 pha</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td>Điện áp: 3 x 230/400 V, 3 x 57,7/100 – 240/415 V. Dòng điện: 3 x 10(100) A.
Cấp chính xác: 1,0 (Điện năng tác dụng) và 2,0 (Điện năng phản kháng).
Dòng điện khởi động (Ist)≤ 0,4% Idm (CCX: 0,5S),≤ 0,5% Idm (CCX: 2,0).
Tần số làm việc: 50 Hz. Hằng số công tơ đến 5.000 imp/kW.h. Cấp cách
điện: 2. Sơ đồ đấu dây: 3 pha 4 dây. Tích hợp công nghệ truyền chỉ số công
tơ từ xa bằng sóng vô tuyến.</td><td></td><td></td></tr><tr><td>234</td><td></td><td></td><td>Công tơ 3 pha nhiều biểu giá</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td>Điện áp 3 x (57,7/100 – 240/415) V. Dòng điệ 3×1 (1,2)A, 3 x 5 (10) A. Cấp
chính xác 0,5S (Điện năng tác dụng) và 2,0 (Điện năng phản kháng). Dòng
điện khởi động(Ist): 0,1% Ib (CCX: 0,5S), 0,5% Ib (CCX: 2,0). Tần số làm
việc 50 Hz. Hằng số công tơ đến 25.000 xung/kWh, 25.000 xung/kvarh. Cấp
cách điện 2. Sơ đồ đấu dây 3 pha 4 dây. Loại trực tiếp hoặc gián tiếp. Tích
hợp công nghệ truyền chỉ số công tơ từ xa bằng sóng vô tuyến.</td><td></td><td></td></tr><tr><td></td><td>235</td><td></td><td></td><td>Tủ điều khiển phòng nổ các loại</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td>TCVN 6734, TCVN-7079: 2002, TCVN 10888-2017. Dạng bảo vệ nổ ExdI.</td><td></td></tr><tr><td>236</td><td></td><td></td><td>Công tơ điện tử và hệ thống thu thập dữ liệu</td><td></td><td></td><td>9028</td><td></td><td></td><td>30</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td>Công tơ điện tử cấp chính xác 1% phù hợp cho hộ gia đình. Có khả năng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>truyền dữ liệu đi xa qua giao thức PLC hoặc RF. Hệ thống thu thập dữ liệu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lấy dữ liệu tối đã lên đến 1.000 công tơ (qua PLC hoặc RF), gửi dữ liệu về</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>server qua SIM.</td><td></td></tr><tr><td></td><td>237</td><td></td><td></td><td>Thiết bị kiểm định công tơ</td><td></td><td></td><td>9031</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td>1 pha 12 vị trí, 1 pha 40 vị trí.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Điện áp: 3 x 230/400 V, 3 x 57,7/100 – 240/415 V. Dòng điện: 3 x 10(100) A.</th></tr></thead><tbody><tr><td>Cấp chính xác: 1,0 (Điện năng tác dụng) và 2,0 (Điện năng phản kháng).</td></tr><tr><td>Dòng điện khởi động (Ist)≤ 0,4% Idm (CCX: 0,5S),≤ 0,5% Idm (CCX: 2,0).</td></tr><tr><td>Tần số làm việc: 50 Hz. Hằng số công tơ đến 5.000 imp/kW.h. Cấp cách</td></tr><tr><td>điện: 2. Sơ đồ đấu dây: 3 pha 4 dây. Tích hợp công nghệ truyền chỉ số công</td></tr><tr><td>tơ từ xa bằng sóng vô tuyến.</td></tr></tbody></table>

<table><thead><tr><th>Điện áp 3 x (57,7/100 – 240/415) V. Dòng điệ 3×1 (1,2)A, 3 x 5 (10) A. Cấp</th></tr></thead><tbody><tr><td>chính xác 0,5S (Điện năng tác dụng) và 2,0 (Điện năng phản kháng). Dòng</td></tr><tr><td>điện khởi động(Ist): 0,1% Ib (CCX: 0,5S), 0,5% Ib (CCX: 2,0). Tần số làm</td></tr><tr><td>việc 50 Hz. Hằng số công tơ đến 25.000 xung/kWh, 25.000 xung/kvarh. Cấp</td></tr><tr><td>cách điện 2. Sơ đồ đấu dây 3 pha 4 dây. Loại trực tiếp hoặc gián tiếp. Tích</td></tr><tr><td>hợp công nghệ truyền chỉ số công tơ từ xa bằng sóng vô tuyến.</td></tr></tbody></table>

|<image_19>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>238</td><td></td><td></td><td>Thiết bị chỉ thị và cảnh báo sự cố trên lưới
điện trung thế SRFI</td><td></td><td></td><td>9031</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td>Có khả năng phát hiện các sự cố pha-pha hay pha-đất cho đường dây trên
không. Cảnh báo bằng đèn tại thiết bị và cảnh báo từ xa qua tin nhắn SMS.
Cho phép cài đặt thay đổi thông số cơ bản về dòng điện và thời gian. Tự
động thiết lập sau sự cố (reset) và có chức năng điều khiển từ xa. Điện áp
định mức 24 kV. Tần số định mức 50 Hz. Khả năng chịu đựng dòng ngắn
mạch: 10 kA/170 ms. Mức bảo vệ chống sự xâm nhập từ môi trường bên
ngoài IP54.</td><td></td><td></td></tr><tr><td>239</td><td></td><td></td><td>Máy đếm khuẩn lạc</td><td></td><td></td><td>9031</td><td></td><td></td><td>80</td><td></td><td></td><td>90</td><td></td><td></td><td></td><td>Điều khiển bằng vi xử lý. Hiển thị bằng màn hình LED, bút đếm với bộ cảm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>biến tiên tiến, nhạy. Chức năng đếm khuẩn lạc. Dùng trong y tế và phòng thí</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nghiệm.</td><td></td></tr><tr><td></td><td>240</td><td></td><td></td><td>Bộ đồng hồ thời gian chuẩn GPS</td><td></td><td></td><td>9106</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>TCCS của nhà sản xuất – Tổng công ty quản lý bay Việt Nam.</td><td></td></tr><tr><td></td><td>241</td><td></td><td></td><td>Tủ thuốc có ngăn thuốc độc</td><td></td><td></td><td>9402</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Sử dụng trong y tế.</td><td></td></tr><tr><td></td><td>242</td><td></td><td></td><td>Giường bệnh nhân các loại</td><td></td><td></td><td>9402</td><td></td><td></td><td>90</td><td></td><td></td><td>90</td><td></td><td></td><td>Sử dụng trong y tế, bằng điện hoặc không bằng điện (TCVN hoặc TCCS).</td><td></td></tr><tr><td></td><td>243</td><td></td><td></td><td>Tủ hút độc</td><td></td><td></td><td>9403</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Sử dụng trong y tế.</td><td></td></tr><tr><td></td><td>244</td><td></td><td></td><td>Kệ trung tải độc lập 4 tầng</td><td></td><td></td><td>9403</td><td></td><td></td><td>10</td><td></td><td></td><td>0</td><td></td><td></td><td>Kích thước (CxDxR) 2.000 x 2.350 x 800 (mm). Chất liệu bằng thép.</td><td></td></tr><tr><td>245</td><td></td><td></td><td></td><td>Đèn pha một hướng lắp nổi (đèn tiếp cận,</td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>70</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thềm, giới hạn)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>246</td><td></td><td></td><td>Đèn lề đường CHC hai hướng lắp nổi</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>70</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA</td><td></td></tr><tr><td></td><td>247</td><td></td><td></td><td>Đèn lề đường lăn lắp nổi</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>70</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA. công nghệ Halogen/LED.</td><td></td></tr><tr><td></td><td>248</td><td></td><td></td><td>Đèn pha xoay</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>70</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA</td><td></td></tr><tr><td></td><td>249</td><td></td><td></td><td>Đèn chóp lắp nổi và Bộ điều khiển đèn chớp</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>99</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA</td><td></td></tr><tr><td></td><td>250</td><td></td><td></td><td>Đèn cao không</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>99</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA, TCVN. Công nghệ LED.</td><td></td></tr><tr><td></td><td>251</td><td></td><td></td><td>Đèn cao không LED cấu trúc kép</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>99</td><td></td><td></td><td>Tiêu chuẩn: ICAO, FAA, TCVN</td><td></td></tr><tr><td></td><td>252</td><td></td><td></td><td>Đèn tín hiệu ánh sáng</td><td></td><td></td><td>9405</td><td></td><td></td><td>40</td><td></td><td></td><td>99</td><td></td><td></td><td>Tiêu chuẩn ICAO</td><td></td></tr><tr><td></td><td>253</td><td></td><td></td><td>Máy báo vùng cấm</td><td></td><td></td><td>9405</td><td></td><td></td><td>60</td><td></td><td></td><td>90</td><td></td><td></td><td>Sử dụng trong an ninh – quốc phòng</td><td></td></tr><tr><td></td><td>254</td><td></td><td></td><td>Phòng đặt thiết bị (Shelter)</td><td></td><td></td><td>9406</td><td></td><td></td><td>0</td><td></td><td></td><td>94</td><td></td><td></td><td>Tiêu chuẩn: ICAO, TCVN</td><td></td></tr><tr><td>255</td><td></td><td></td><td>Khởi động mềm, tủ biến tần phòng nổ các loại</td><td></td><td></td><td></td><td>8535</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Dạng bảo vệ nổ Exd[ib]IMb. Dòng điện đến 630A, công suất đến 1.000 kVA,
điện áp đến 6.000V.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Có khả năng phát hiện các sự cố pha-pha hay pha-đất cho đường dây trên</th></tr></thead><tbody><tr><td>không. Cảnh báo bằng đèn tại thiết bị và cảnh báo từ xa qua tin nhắn SMS.</td></tr><tr><td>Cho phép cài đặt thay đổi thông số cơ bản về dòng điện và thời gian. Tự</td></tr><tr><td>động thiết lập sau sự cố (reset) và có chức năng điều khiển từ xa. Điện áp</td></tr><tr><td>định mức 24 kV. Tần số định mức 50 Hz. Khả năng chịu đựng dòng ngắn</td></tr><tr><td>mạch: 10 kA/170 ms. Mức bảo vệ chống sự xâm nhập từ môi trường bên</td></tr><tr><td>ngoài IP54.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chỉ thị và cảnh báo sự cố trên lưới</th></tr></thead><tbody><tr><td>điện trung thế SRFI</td></tr></tbody></table>

|<image_20>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>256</td><td>Áp tô mát phòng nổ</td><td></td><td>8535</td><td></td><td></td><td>21</td><td></td><td></td><td>0</td><td></td><td>TCVN 10888-2015. Dạng bảo vệ nổ ExdIMb, dòng điện đến 630 A, có điện
áp đến 1.200 V.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8536</td><td></td><td></td><td>29</td><td></td><td></td><td>10</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>90</td><td></td><td></td><td></td><td></td></tr><tr><td>257</td><td>Khởi động từ phòng nổ các loại</td><td></td><td>8535/</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 10888-2018. Dạng bảo vệ nổ Exd[ib]IMb. Dòng điện đến 630A loại
đơn, 2×500 A loại kép, có điện áp đến 1.200 V.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>258</td><td>Cầu chì</td><td></td><td>8535/</td><td></td><td>10</td><td></td><td></td><td>92</td><td></td><td></td><td>TDPH – 3, TKMP – I . TCVN 6734, TCVN-7079: 2002, TCVN 10888-2019.
Dạng bảo vệ nổ Exd[ib]IMb. Dòng điện điện đến 630 A, điện áp đến 6.000 V.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8536</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>259</td><td>Bộ công cụ phát triển ứng dụng dựa trên vi
điều khiển</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng cho giáo dục – đào tạo. Model SMART-SEN69. Bao</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>gồm:</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1. Mô đun hạ áp DC-DC (2A, 4-36V) đầu ra có điều chỉnh từ 1.25-36 VDC.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2. Mô đun cảm biến nhiệt độ (± 0.5oC), độ ẩm (± 2%RH). Dải đo nhiệt độ: -
40-80oC, sai số ± 0.5oC. Dải đo độ ẩm: 0 -100% RH, sai số ± 2% RH.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3. Mô đun cảm biến ánh sáng.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>4. Mô đun đo khí gas.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>5. Mô đun cảm biến chuyển động.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>6. Mô đun cảm biến khoảng cách.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7. Nút nhấn 4 chân.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8. Bảng mạch lập trình vi điều khiển.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>9. Mô đun giao tiếp Bluetooth và Wifi, mô đun RFID.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>10. Hệ thống động cơ điện, còi báo.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>11. Mạch cầu, mạch điều khiển, rơ le. Và các sản phẩm phụ trợ kèm theo.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>TCVN 10888-2015. Dạng bảo vệ nổ ExdIMb, dòng điện đến 630 A, có điện</th></tr></thead><tbody><tr><td>áp đến 1.200 V.</td></tr></tbody></table>

<table><thead><tr><th>2. Mô đun cảm biến nhiệt độ (± 0.5oC), độ ẩm (± 2%RH). Dải đo nhiệt độ: -</th></tr></thead><tbody><tr><td>40-80oC, sai số ± 0.5oC. Dải đo độ ẩm: 0 -100% RH, sai số ± 2% RH.</td></tr></tbody></table>

<table><thead><tr><th>Bộ công cụ phát triển ứng dụng dựa trên vi</th></tr></thead><tbody><tr><td>điều khiển</td></tr></tbody></table>

|<image_21>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th></th><th></th><th>Tên mặt hàng</th><th></th><th></th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>260</td><td></td><td></td><td>Biến áp nguồn</td><td></td><td></td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng phục vụ cho đào tạo. Vỏ nguồn bằng tôn sơn tính điện.
Kích thước (dxrxc) 270x100x100 mm. Nắp vỏ nguồn có quai xách bằng
nhựa mềm. Điện áp đầu vào 220V – 50Hz. Điện áp ra: (1) Điện áp xoay
chiều (5A): 3, 6, 9, 12, 15, 24 V; (2) Điện áp một chiều (3A): điều chỉnh từ 0 –
24V. Có đồng hồ chỉ thị số điện tử hiển thị điện áp đầu ra một chiều. Núm
chỉnh điện áp một chiều toàn dải từ 1,25 – 24VDC. Có mạch tự động đóng
ngắt và bảo vệ quá tải cho cả dòng điện xoay chiều và một chiều.</td><td></td><td></td></tr><tr><td>261</td><td></td><td></td><td>Bộ dụng cụ chế tạo nam châm điện</td><td></td><td></td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng cho giáo dục, đào tạo. Bao gồm: 04 bin cuộn dây đồng
emay dùng để quấn nam châm, 01 máy quấn dây điện bằng động cơ 12V
một chiều, máy có gắn bộ đếm số vòng dây, hiển thị số, 03 bộ lõi thép nam
châm điện bằng bu-long M8 dài 40 mm với ecu mũ kín bịt đầu bu-lông, 03
bin nhựa ABS quấn dây đồng tạo cuộn hút nam châm, 03 hộp vỏ nam châm
điện bằng nhựa ABS.</td><td></td><td></td></tr><tr><td>262</td><td></td><td></td><td>Bộ dụng cụ cơ khí</td><td></td><td></td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Thước lá, thước
cặp cơ, đầu vạch dấu, thước đo góc, thước đo mặt phẳng, dao dọc giấy, dao
cắt nhựa Acrylic, ê tô nhỏ (khẩu độ 50 mm), dũa (dẹt, tròn) mỗi loại một
chiếc, cưa tay, bộ tuốc nơ vít đa năng, mỏ lết cỡ nhỏ, kìm mỏ vuông, súng
bắn keo (loại 10mm, công suất 60 W).</td><td></td><td></td></tr><tr><td>263</td><td></td><td></td><td>Bộ dụng cụ điện</td><td></td><td></td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: sạc pin Lithium</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(khay sạc đôi, dòng sạc 600 mA), đồng hồ vạn năng số, bút thử điện, kìm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tuốt dây điện, kìm mỏ nhọn, kìm cắt, tuốc nơ vít kỹ thuật điện, mỏ hàn thiếc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(AC 220V, 60W), kèm đế mỏ hàn.</td><td></td></tr><tr><td>264</td><td></td><td></td><td>Bộ dụng cụ đo các đại lượng không điện</td><td></td><td></td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Thiết bị thu thập,
xử lý và trình diễn dữ liệu (Datalogger) (Broadcom BCM2711, quad-core
Cortex-A72 (ARM v8) 64-bit SoC @ 1.5GHz/ RAM: 4GB LPDDR4-2400
SDRAM, có kết nối wifi, bluetooth, USB, Type C, HDMI, có màn hình cảm
ứng, thẻ nhớ 128 GB), Các modun cảm biến đo nhiệt độ từ -50 đến 200oC,
mô-đun cảm biến đo áp suất khí quyển 0-250kPa, mô-đun cảm biến đo độ
PH 0 -14pH, mô-đun cảm biến đo điện thế ±6V, môđun cảm biến đo dòng
điện dải đo ±3A, môđun cảm biến đo độ dẫn điện 0-20.000 uS/cm.</td><td></td><td></td></tr><tr><td></td><td>265</td><td></td><td></td><td>Bộ giá đỡ thí nghiệm</td><td></td><td></td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng phục vụ cho giáo dục, đào tạo.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyên dùng phục vụ cho đào tạo. Vỏ nguồn bằng tôn sơn tính điện.</th></tr></thead><tbody><tr><td>Kích thước (dxrxc) 270x100x100 mm. Nắp vỏ nguồn có quai xách bằng</td></tr><tr><td>nhựa mềm. Điện áp đầu vào 220V – 50Hz. Điện áp ra: (1) Điện áp xoay</td></tr><tr><td>chiều (5A): 3, 6, 9, 12, 15, 24 V; (2) Điện áp một chiều (3A): điều chỉnh từ 0 –</td></tr><tr><td>24V. Có đồng hồ chỉ thị số điện tử hiển thị điện áp đầu ra một chiều. Núm</td></tr><tr><td>chỉnh điện áp một chiều toàn dải từ 1,25 – 24VDC. Có mạch tự động đóng</td></tr><tr><td>ngắt và bảo vệ quá tải cho cả dòng điện xoay chiều và một chiều.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyên dùng cho giáo dục, đào tạo. Bao gồm: 04 bin cuộn dây đồng</th></tr></thead><tbody><tr><td>emay dùng để quấn nam châm, 01 máy quấn dây điện bằng động cơ 12V</td></tr><tr><td>một chiều, máy có gắn bộ đếm số vòng dây, hiển thị số, 03 bộ lõi thép nam</td></tr><tr><td>châm điện bằng bu-long M8 dài 40 mm với ecu mũ kín bịt đầu bu-lông, 03</td></tr><tr><td>bin nhựa ABS quấn dây đồng tạo cuộn hút nam châm, 03 hộp vỏ nam châm</td></tr><tr><td>điện bằng nhựa ABS.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Thước lá, thước</th></tr></thead><tbody><tr><td>cặp cơ, đầu vạch dấu, thước đo góc, thước đo mặt phẳng, dao dọc giấy, dao</td></tr><tr><td>cắt nhựa Acrylic, ê tô nhỏ (khẩu độ 50 mm), dũa (dẹt, tròn) mỗi loại một</td></tr><tr><td>chiếc, cưa tay, bộ tuốc nơ vít đa năng, mỏ lết cỡ nhỏ, kìm mỏ vuông, súng</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Thiết bị thu thập,</th></tr></thead><tbody><tr><td>xử lý và trình diễn dữ liệu (Datalogger) (Broadcom BCM2711, quad-core</td></tr><tr><td>Cortex-A72 (ARM v8) 64-bit SoC @ 1.5GHz/ RAM: 4GB LPDDR4-2400</td></tr><tr><td>SDRAM, có kết nối wifi, bluetooth, USB, Type C, HDMI, có màn hình cảm</td></tr><tr><td>ứng, thẻ nhớ 128 GB), Các modun cảm biến đo nhiệt độ từ -50 đến 200oC,</td></tr><tr><td>mô-đun cảm biến đo áp suất khí quyển 0-250kPa, mô-đun cảm biến đo độ</td></tr><tr><td>PH 0 -14pH, mô-đun cảm biến đo điện thế ±6V, môđun cảm biến đo dòng</td></tr><tr><td>điện dải đo ±3A, môđun cảm biến đo độ dẫn điện 0-20.000 uS/cm.</td></tr></tbody></table>

|<image_22>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Chân đế bằng kim loại, sơn tĩnh điện màu tối, khối lượng khoảng 2,5 kg,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bền chắc, ổn định, đường kính lỗ 10mm và vít M6 thẳng góc với lỗ để giữ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>trục đường kính 10mm, có hệ vít chỉnh cân bằng.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Thanh trụ bằng inox, ɸ 10mm gồm 3 loại: Loại dài 500mm và 1000mm;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Loại dài 360mm, một đầu vê tròn, đầu kia có ren M5 dài 15mm, có êcu hãm;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Loại dài 200mm, 2 đầu vê tròn: 5 cái;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– 10 khớp nối bằng nhôm đúc, (43x20x18) mm, có vít hãm, tay vặn bằng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thép.</td><td></td></tr><tr><td>266</td><td>Bộ dụng cụ thí nghiệm về sóng âm</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Bộ thu nhận số</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>liệu, cảm biến âm thanh 20Hz-20kHz, mô đun điều khiển, loa mini, ống dẫn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hướng âm thanh bằng nhựa trong acrylic tròn, đường kính 40 mm, dài 62</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cm. Ống được gắn nằm dọc dựa trên cột nhôm định hình là giá đỡ.</td><td></td></tr><tr><td>267</td><td>Bộ học liệu điện tử</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Thông tư số 37/2021/TT-BGDĐT , Thông tư số</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>38/2021/ TT-BGDĐT, Thông tư số 39/2021/TT-BGDĐT. Cài đặt trên hệ điều hành</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Window 7, Window 10, Window 11. Quy cách sản phẩm: 01 USB, 01 sách hướng dẫn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sử dụng.</td><td></td></tr><tr><td>268</td><td>Bộ lực kế</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Lực kế ống tròn dài 160 mm,</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bằng nhựa trong acrylic đường kính 20 mm có móc treo ở 2 đầu; 01 lực kế</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>với dải đo 0 – 2,5 N, độ chia 0,05 N; 01 lực kế với dải đo 0 – 5 N, độ chia 0,1</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>N; 01 lực kế với dải đo 0 – 1 N, độ chia 0,02 N; Hộp đựng lực kế.</td><td></td></tr><tr><td>269</td><td>Bộ thí nghiệm thu năng lượng ánh sáng</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Đế gỗ (145×217) cm dùng để
gắn thiết bị; 01 pin mặt trời có thể tạo ra điện áp đến 1V, đầu ra dạng ổ cắm
tương thích với dây nối. Tấm đế mica để gắn pin vào đế gỗ; 01 Bóng đèn led
và 01 quạt gió mini (2×60)mm; Động cơ DC 3V, tay quấn dây nguồn; Công
tắc gạt 6 chân đảo chiều và dây dẫn.</td><td></td><td></td></tr><tr><td>270</td><td>Bộ thiết bị chứng minh độ giãn lò xo</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Đế gỗ cao su ghép thanh
(200×250) mm; Cột nhôm định hình 600mm; Cột trượt nhôm Φ10: 400mm;
Lực kế lò xo có thân hình trụ Φ20 mm làm bằng nhựa trong có vạch chia độ
với độ chia nhỏ nhất 0,1 N, hai đầu có móc treo bằng kim loại không rỉ, một
đầu lò xo cố định, giới hạn đo (0 – 5)N; Quả nặng có móc treo bằng kim loại
không rỉ, 04 quả khối lượng 50g/quả; Độ giãn của lò xo treo thẳng đứng tỷ lệ
với khối lượng của vật treo.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>gắn thiết bị; 01 pin mặt trời có thể tạo ra điện áp đến 1V, đầu ra dạng ổ cắm</th></tr></thead><tbody><tr><td>tương thích với dây nối. Tấm đế mica để gắn pin vào đế gỗ; 01 Bóng đèn led</td></tr><tr><td>và 01 quạt gió mini (2×60)mm; Động cơ DC 3V, tay quấn dây nguồn; Công</td></tr><tr><td>tắc gạt 6 chân đảo chiều và dây dẫn.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Đế gỗ cao su ghép thanh</th></tr></thead><tbody><tr><td>(200×250) mm; Cột nhôm định hình 600mm; Cột trượt nhôm Φ10: 400mm;</td></tr><tr><td>Lực kế lò xo có thân hình trụ Φ20 mm làm bằng nhựa trong có vạch chia độ</td></tr><tr><td>với độ chia nhỏ nhất 0,1 N, hai đầu có móc treo bằng kim loại không rỉ, một</td></tr><tr><td>đầu lò xo cố định, giới hạn đo (0 – 5)N; Quả nặng có móc treo bằng kim loại</td></tr><tr><td>không rỉ, 04 quả khối lượng 50g/quả; Độ giãn của lò xo treo thẳng đứng tỷ lệ</td></tr><tr><td>với khối lượng của vật treo.</td></tr></tbody></table>

|<image_23>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>271</td><td>Bộ thiết bị chứng minh lực cản của nước</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Cụm đế thiết bị, cụm xe cố</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>định có động cơ điện, cụm xe di động được nối với xe cố định bằng dây treo.</td><td></td></tr><tr><td>272</td><td>Máy in 3D cỡ nhỏ</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Kích thước khổ in 200x200x200 mm;
Đùn nhựa gián tiếp 0,4 mm; Công nghệ in FDM; Định dạng file in: STL, OBJ,
AMF; Vật liệu in: PLA, PETG, PLAF; Độ phân giải lớp cắt 0,15 – 0,32 mm;
Tốc độ in tối đa Min/ Max: 40 – 80 mm/s; Dung sai khi in 0.8%; Màn hình
điều khiển LCD 128×64; Phương thức kết nối USB, SD card, thẻ nhớ; Trọng
lượng 9,5 kg.</td><td></td><td></td></tr><tr><td>273</td><td>Bộ vật liệu cơ khí</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Tấm nhựa formex (khổ A3,
loại dày 3 mm và 5 mm), số lượng 10 tấm, mỗi loại. Tấm nhựa acrylic (A4,
trong suốt, dày 3mm), số lượng 10 tấm. Thanh keo nhiệt (đường kính
10mm), số lượng 10 thanh. Vít ren và đai ốc M3: 100 cái. Vít gỗ các loại 100
cái. Mũi khoan (đường kính 3mm): 5 mũi. Bánh xe (đường kính 65mm, trục
5mm) 10 cái.</td><td></td><td></td></tr><tr><td>274</td><td>Bộ thiết bị đo kỹ thuật số tích hợp</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: (1) Ray nhôm định hình có
thước, độ chia nhỏ nhất 1 mm; có chân đế vít chỉnh thăng bằng; máng ray có
thể trượt lên xuống để thay đổi độ nghiêng của máng; (2) 02 xe kỹ thuật số
có thân xe bằng nhôm. Các trục bánh xe được đỡ bằng vòng bi. Thân xe có
các rãnh để gắn kết các phụ kiện; (3) Xe kỹ thuật số được tích hợp bộ cảm
biến đo: Khoảng cách (qua góc lăn của bánh); Đo gia tốc và đo lực, với các
thông số cơ bản: (i) Đo lực: dải đo ± 100 N, độ phân giải 0,1 N, độ chính xác
± 1%; (ii) Xác định vị trí: độ phân giải ± 0,2 mm; (iii)Đo vận tốc: dải đo ± 3
m/s; (iv) Đo gia tốc: dải đo ± 16g (g = 9,8 m/s2); (4) Các thông số đo được
kết nối với thiết bị thu thập dữ liệu (TBDC – thiết bị dùng chung đã mua)
bằng phương pháp không dây. – 02 gia trọng bằng kim loại, khối lượng mỗi
vật 250g.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Kích thước khổ in 200x200x200 mm;</th></tr></thead><tbody><tr><td>Đùn nhựa gián tiếp 0,4 mm; Công nghệ in FDM; Định dạng file in: STL, OBJ,</td></tr><tr><td>AMF; Vật liệu in: PLA, PETG, PLAF; Độ phân giải lớp cắt 0,15 – 0,32 mm;</td></tr><tr><td>Tốc độ in tối đa Min/ Max: 40 – 80 mm/s; Dung sai khi in 0.8%; Màn hình</td></tr><tr><td>điều khiển LCD 128×64; Phương thức kết nối USB, SD card, thẻ nhớ; Trọng</td></tr><tr><td>lượng 9,5 kg.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Tấm nhựa formex (khổ A3,</th></tr></thead><tbody><tr><td>loại dày 3 mm và 5 mm), số lượng 10 tấm, mỗi loại. Tấm nhựa acrylic (A4,</td></tr><tr><td>trong suốt, dày 3mm), số lượng 10 tấm. Thanh keo nhiệt (đường kính</td></tr><tr><td>10mm), số lượng 10 thanh. Vít ren và đai ốc M3: 100 cái. Vít gỗ các loại 100</td></tr><tr><td>cái. Mũi khoan (đường kính 3mm): 5 mũi. Bánh xe (đường kính 65mm, trục</td></tr><tr><td>5mm) 10 cái.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: (1) Ray nhôm định hình có</th></tr></thead><tbody><tr><td>thước, độ chia nhỏ nhất 1 mm; có chân đế vít chỉnh thăng bằng; máng ray có</td></tr><tr><td>thể trượt lên xuống để thay đổi độ nghiêng của máng; (2) 02 xe kỹ thuật số</td></tr><tr><td>có thân xe bằng nhôm. Các trục bánh xe được đỡ bằng vòng bi. Thân xe có</td></tr><tr><td>các rãnh để gắn kết các phụ kiện; (3) Xe kỹ thuật số được tích hợp bộ cảm</td></tr><tr><td>biến đo: Khoảng cách (qua góc lăn của bánh); Đo gia tốc và đo lực, với các</td></tr><tr><td>thông số cơ bản: (i) Đo lực: dải đo ± 100 N, độ phân giải 0,1 N, độ chính xác</td></tr><tr><td>± 1%; (ii) Xác định vị trí: độ phân giải ± 0,2 mm; (iii)Đo vận tốc: dải đo ± 3</td></tr><tr><td>m/s; (iv) Đo gia tốc: dải đo ± 16g (g = 9,8 m/s2); (4) Các thông số đo được</td></tr><tr><td>kết nối với thiết bị thu thập dữ liệu (TBDC – thiết bị dùng chung đã mua)</td></tr><tr><td>bằng phương pháp không dây. – 02 gia trọng bằng kim loại, khối lượng mỗi</td></tr><tr><td>vật 250g.</td></tr></tbody></table>

|<image_24>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>275</td><td>Bộ thu nhận dữ liệu</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thiết bị chuyên dùng cho đào tạo. Model SMART-VDA0040. Sử dụng chíp
xử lý tiên tiến Broadcom BCM2711, quad-core Cortex-A72 (ARM v8) 64-bit
SoC @ 1.5GHz, RAM: 4GB LPDDR4-2400 SDRAM, Wifi chuẩn 2.4GHz và
5.0 GHz IEEE 802.11ac. Bluetooth 5.0, BLE, sử dụng cổng mạng Gigabit
Ethernet, 2 cổng USB 2.0 và 2 cổng USB 3.0 (trong đó 1 cổng USB dành cho
màn hình cảm ứng), 2 cổng USB-Type C sử dụng giao tiếp cảm biến theo
chuẩn Modbus RTU, 1 cổng mở rộng HDMI, sử dụng màn hình cảm ứng
điện dung HDMI LCD 10.1 inch, hỗ trợ kết nối với màn hình HDMI mở rộng
với độ phân dải 4K, sử dụng thẻ nhớ 128G cho hệ điều hành và lưu trữ,
adapter nguồn DC 12V – 3A.</td><td></td><td></td></tr><tr><td>276</td><td>Bộ vật liệu điện</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Pin lithium loại 3.7 V, 1.200
maH, 9 pin; đế pin Lithium (loại đế ba) 03 cái; dây điện màu đen, mầu đỏ
(đường kính 0,3 mm), 20 m cho mỗi mầu, dây kẹp cá sấu 2 đầu (dài 300
mm) 30 sợi, gen co nhiệt (đường kính 2mm và 3 mm), mỗi loại 2 m; băng
dính cách điện: 05 cuộn, phíp đồng một mặt (A4, dày 1,2 mm) 5 tấm, muối
FeCl3 500 g, thiếc hàn cuộn (loại 100 g) 03 cuộn, nhựa thông 300g.</td><td></td><td></td></tr><tr><td>277</td><td>Dây nối dẫn điện làm thí nghiệm</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: 20 dây nối dẫn điện dài 500
mm, tiết diện 0,75 mm2, có phích cắm kiểu quả chuối Φ4 mm có tính đàn hồi
tương thích với giắc cắm mạch điện trên các thiết bị, 02 mỏ kẹp cá sấu được
tích hợp sẵn tại 1 đầu của dây nối, thuận tiện cho việc kết nối khi thực hiện
các thí nghiệm.</td><td></td><td></td></tr><tr><td>278</td><td>Cảm biến độ ẩm</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: điện áp hoạt động 3,5 ~ 5,5
V, đầu ra số giao tiếp I2C, dải đo độ ẩm: 0 ~ 100% RH, độ phân dải 0,1%
RH, dải đo nhiệt độ -40 ~ 80oC, độ phân dải 0,1oC. Môđun sử dụng vi điều
khiển 8-bit, xung nhịp 20MHz, bộ nhớ ROM 32 KB, RAM 1.5 Kx8, bộ nhớ dữ
liệu EEPROM 256×8, giao tiếp RS485 theo giao thức Modbus RTU. Nguồn
cấp 5 Vdc/3A. Phần mềm tiếng Việt STEMe. Cổng kết nối USB Type C.</td><td></td><td></td></tr><tr><td>279</td><td>Cảm biến đo điện thế</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: dải đo ± 12V, độ phân dải ±</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>0.01 V. Môđun sử dụng vi điều khiển 8-bit, xung nhịp 20MHz, bộ nhớ ROM</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>32KB, RAM 1.5 Kx8, bộ nhớ dữ liệu EEPROM 256×8, giao tiếp RS485 theo</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>giao thức Modbus RTU. Nguồn cấp 5 V dc/3A. Phần mềm tiếng Việt STEMe.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Cổng kết nối USB Type C.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị chuyên dùng cho đào tạo. Model SMART-VDA0040. Sử dụng chíp</th></tr></thead><tbody><tr><td>xử lý tiên tiến Broadcom BCM2711, quad-core Cortex-A72 (ARM v8) 64-bit</td></tr><tr><td>SoC @ 1.5GHz, RAM: 4GB LPDDR4-2400 SDRAM, Wifi chuẩn 2.4GHz và</td></tr><tr><td>5.0 GHz IEEE 802.11ac. Bluetooth 5.0, BLE, sử dụng cổng mạng Gigabit</td></tr><tr><td>Ethernet, 2 cổng USB 2.0 và 2 cổng USB 3.0 (trong đó 1 cổng USB dành cho</td></tr><tr><td>màn hình cảm ứng), 2 cổng USB-Type C sử dụng giao tiếp cảm biến theo</td></tr><tr><td>chuẩn Modbus RTU, 1 cổng mở rộng HDMI, sử dụng màn hình cảm ứng</td></tr><tr><td>điện dung HDMI LCD 10.1 inch, hỗ trợ kết nối với màn hình HDMI mở rộng</td></tr><tr><td>với độ phân dải 4K, sử dụng thẻ nhớ 128G cho hệ điều hành và lưu trữ,</td></tr><tr><td>adapter nguồn DC 12V – 3A.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Pin lithium loại 3.7 V, 1.200</th></tr></thead><tbody><tr><td>maH, 9 pin; đế pin Lithium (loại đế ba) 03 cái; dây điện màu đen, mầu đỏ</td></tr><tr><td>(đường kính 0,3 mm), 20 m cho mỗi mầu, dây kẹp cá sấu 2 đầu (dài 300</td></tr><tr><td>mm) 30 sợi, gen co nhiệt (đường kính 2mm và 3 mm), mỗi loại 2 m; băng</td></tr><tr><td>dính cách điện: 05 cuộn, phíp đồng một mặt (A4, dày 1,2 mm) 5 tấm, muối</td></tr><tr><td>FeCl3 500 g, thiếc hàn cuộn (loại 100 g) 03 cuộn, nhựa thông 300g.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: 20 dây nối dẫn điện dài 500</th></tr></thead><tbody><tr><td>mm, tiết diện 0,75 mm2, có phích cắm kiểu quả chuối Φ4 mm có tính đàn hồi</td></tr><tr><td>tương thích với giắc cắm mạch điện trên các thiết bị, 02 mỏ kẹp cá sấu được</td></tr><tr><td>tích hợp sẵn tại 1 đầu của dây nối, thuận tiện cho việc kết nối khi thực hiện</td></tr><tr><td>các thí nghiệm.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: điện áp hoạt động 3,5 ~ 5,5</th></tr></thead><tbody><tr><td>V, đầu ra số giao tiếp I2C, dải đo độ ẩm: 0 ~ 100% RH, độ phân dải 0,1%</td></tr><tr><td>RH, dải đo nhiệt độ -40 ~ 80oC, độ phân dải 0,1oC. Môđun sử dụng vi điều</td></tr><tr><td>khiển 8-bit, xung nhịp 20MHz, bộ nhớ ROM 32 KB, RAM 1.5 Kx8, bộ nhớ dữ</td></tr><tr><td>liệu EEPROM 256×8, giao tiếp RS485 theo giao thức Modbus RTU. Nguồn</td></tr><tr><td>cấp 5 Vdc/3A. Phần mềm tiếng Việt STEMe. Cổng kết nối USB Type C.</td></tr></tbody></table>

|<image_25>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>280</td><td>Cảm biến đo dòng điện</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: (1) Dải đo ± 1A, độ phân dải ±
1mA; (2) Môđun: Sử dụng vi điều khiển 8-bit, xung nhịp 20MHz, bộ nhớ
ROM 32 KB, RAM 1.5 Kx8, bộ nhớ dữ liệu EEPROM 256×8; giao tiếp RS485
theo giao thức Modbus RTU; (3) Nguồn cấp 5Vdc/3A; (4) Phần mềm tiếng
Việt STEMe; (5) Cổng kết nối USB Type C.</td><td></td><td></td></tr><tr><td>281</td><td>Cảm biến độ pH</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: (1) Điện áp hoạt động 5V,
đầu ra tương tự 1,6~3,4V, dải đo 0~14pH, độ phân dải 0.01 pH, nhiệt độ
hoạt động: 0-60oC, (2) Môđun sử dụng vi điều khiển 8-bit, xung nhịp 20MHz,
bộ nhớ ROM 32 KB, RAM 1.5 Kx8, bộ nhớ dữ liệu EEPROM 256×8, bộ
chuyển đổi tương tự – số ADC 12 bít, giao tiếp RS485 theo giao thức
Modbus RTU, (3) Nguồn cấp 5Vdc/3A, (4) Phần mềm tiếng Việt STEMe, (4)
Cổng kết nối USBType C.</td><td></td><td></td></tr><tr><td>282</td><td>Cảm biến lực</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Điện áp hoạt động 3,3~5 V,
đầu ra số 24-Bít, thang đo ±50 N (độ phân dải ±0,01 N), độ phân giải ±0.01
N. Môđun sử dụng vi điều khiển 8-bit, xung nhịp 20MHz, bộ nhớ ROM 32
KB, RAM 1.5 K x 8, bộ nhớ dữ liệu EEPROM 25 6x 8, giao tiếp RS485 theo
giao thức Modbus RTU. Nguồn cấp 5V DC/3A. Phần mềm tiếng Việt STEMe.
Cổng kết nối USB Type C.</td><td></td><td></td></tr><tr><td>283</td><td>Hộp quả treo</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: 12 vật gia trọng bằng thép với</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khối lượng mỗi vật 50 g được được mạ Crôm chống rỉ, có 2 móc treo cố định</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tại 2 đầu đối xứng. Trên vật gia trọng có dập chìm giá trị khối lượng (50g).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Hộp nhựa đựng 12 vật gia trọng.</td><td></td></tr><tr><td>284</td><td>Cảm biến nhiệt độ</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Cảm biến đầu dò nhiệt PT100
type B, dải đo từ -50 đến 200oC, độ phân giải 0,1oC, chiều dài 0,5m, vật liệu
nhôm/thép, chống thấm nước. Môđun sử dụng vi điều khiển 8-bit, tốc độ lên
tới 64 MHz, bộ nhớ ROM 32 kB, RAM 1,5 K x 8, bộ nhớ dữ liệu EEPROM
256 x 8, giao tiếp RS485 theo giao thức Modbus RTU, bộ chuyển đổi tương
tự số 15 bít với thời gian đáp ứng 21 ms. Nguồn cấp5 Vdc/3A. Phần mềm
tiếng Việt STEMe. Cổng kết nối USB Type C.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>1mA; (2) Môđun: Sử dụng vi điều khiển 8-bit, xung nhịp 20MHz, bộ nhớ</th></tr></thead><tbody><tr><td>ROM 32 KB, RAM 1.5 Kx8, bộ nhớ dữ liệu EEPROM 256×8; giao tiếp RS485</td></tr><tr><td>theo giao thức Modbus RTU; (3) Nguồn cấp 5Vdc/3A; (4) Phần mềm tiếng</td></tr><tr><td>Việt STEMe; (5) Cổng kết nối USB Type C.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: (1) Điện áp hoạt động 5V,</th></tr></thead><tbody><tr><td>đầu ra tương tự 1,6~3,4V, dải đo 0~14pH, độ phân dải 0.01 pH, nhiệt độ</td></tr><tr><td>hoạt động: 0-60oC, (2) Môđun sử dụng vi điều khiển 8-bit, xung nhịp 20MHz,</td></tr><tr><td>bộ nhớ ROM 32 KB, RAM 1.5 Kx8, bộ nhớ dữ liệu EEPROM 256×8, bộ</td></tr><tr><td>chuyển đổi tương tự – số ADC 12 bít, giao tiếp RS485 theo giao thức</td></tr><tr><td>Modbus RTU, (3) Nguồn cấp 5Vdc/3A, (4) Phần mềm tiếng Việt STEMe, (4)</td></tr><tr><td>Cổng kết nối USBType C.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Điện áp hoạt động 3,3~5 V,</th></tr></thead><tbody><tr><td>đầu ra số 24-Bít, thang đo ±50 N (độ phân dải ±0,01 N), độ phân giải ±0.01</td></tr><tr><td>N. Môđun sử dụng vi điều khiển 8-bit, xung nhịp 20MHz, bộ nhớ ROM 32</td></tr><tr><td>KB, RAM 1.5 K x 8, bộ nhớ dữ liệu EEPROM 25 6x 8, giao tiếp RS485 theo</td></tr><tr><td>giao thức Modbus RTU. Nguồn cấp 5V DC/3A. Phần mềm tiếng Việt STEMe.</td></tr><tr><td>Cổng kết nối USB Type C.</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Cảm biến đầu dò nhiệt PT100</th></tr></thead><tbody><tr><td>type B, dải đo từ -50 đến 200oC, độ phân giải 0,1oC, chiều dài 0,5m, vật liệu</td></tr><tr><td>nhôm/thép, chống thấm nước. Môđun sử dụng vi điều khiển 8-bit, tốc độ lên</td></tr><tr><td>tới 64 MHz, bộ nhớ ROM 32 kB, RAM 1,5 K x 8, bộ nhớ dữ liệu EEPROM</td></tr><tr><td>256 x 8, giao tiếp RS485 theo giao thức Modbus RTU, bộ chuyển đổi tương</td></tr><tr><td>tự số 15 bít với thời gian đáp ứng 21 ms. Nguồn cấp5 Vdc/3A. Phần mềm</td></tr><tr><td>tiếng Việt STEMe. Cổng kết nối USB Type C.</td></tr></tbody></table>

|<image_26>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>285</td><td>Con lắc lò xo, con lắc đơn</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: đế thiết bị, trụ đỡ bằng nhôm,
đầu trụ nhôm có gắn thanh kèo (conson) có móc treo lò xo (Thanh kèo có
hình dáng và kích thước cùng kết cấu đồng nhất với cảm biến lực. Cảm biến
lực có thể thay thế thanh kèo khi thí nghiệm với bộ thu thập dữ liệu), thước
dài, lò xo mạ kẽm;</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đầu trụ nhôm có gắn thanh kèo (conson) có móc treo lò xo (Thanh kèo có</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hình dáng và kích thước cùng kết cấu đồng nhất với cảm biến lực. Cảm biến</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lực có thể thay thế thanh kèo khi thí nghiệm với bộ thu thập dữ liệu), thước</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dài, lò xo mạ kẽm;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Máy đo thời gian hiện số;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cổng quang chữ U có đế trượt gắn với trụ nhôm. Cổng quang có dây tín</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hiệu.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Bộ thu thập dữ liệu với phần mềm đo và hiển thị tương ứng.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cảm biến khoảng cách có dây.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Mô-đun điều khiển và Modbus RTU.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nguồn cấp 5Vdc/3A.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Phần mềm tiếng Việt STEMe.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Cổng kết nối: USB-Type C.</td><td></td></tr><tr><td>286</td><td>Cổng quang</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Máng nhôm có rãnh dẫn
hướng cho xe lăn có thước đo góc, thước chỉnh thăng bằng; 01 Xe lăn nhôm
có phay rãnh để gắn các thiết bị phụ, có cờ cản quang để xác định vị trí và
tốc độ chuyển động khi đi qua cảm biến quang học; 01 nam châm điều khiển
điện có dây nối tín hiệu; 01 cản chặn xe mềm cuối hành trình; 02 cổng quang
dạng khung khép kín bằng nhựa. Cổng quang có dây nối tín hiệu dài 1,5 m
với 1 đầu giắc cắm 5 chân để kết nối với cổng “A” hoặc “B” của đồng hồ đo
thời gian hiện số.</td><td></td><td></td></tr><tr><td>287</td><td>Đồng hồ đo thời gian hiện số</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng phục vụ cho giáo dục, đào tạo.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Vỏ đồng hồ bằng tôn sơn tĩnh điện.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Nắp vỏ có quai xách bằng nhựa mềm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Điện áp sử dụng 220 V – 50 Hz.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Đồng hồ đo thời gian hiện số có đồng hồ chỉ thị LED 4 chữ số; có 2 thang</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>đo 9,999 s và 99,99 s; tự động chuyển thang đo.</td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Máng nhôm có rãnh dẫn</th></tr></thead><tbody><tr><td>hướng cho xe lăn có thước đo góc, thước chỉnh thăng bằng; 01 Xe lăn nhôm</td></tr><tr><td>có phay rãnh để gắn các thiết bị phụ, có cờ cản quang để xác định vị trí và</td></tr><tr><td>tốc độ chuyển động khi đi qua cảm biến quang học; 01 nam châm điều khiển</td></tr><tr><td>điện có dây nối tín hiệu; 01 cản chặn xe mềm cuối hành trình; 02 cổng quang</td></tr><tr><td>dạng khung khép kín bằng nhựa. Cổng quang có dây nối tín hiệu dài 1,5 m</td></tr><tr><td>với 1 đầu giắc cắm 5 chân để kết nối với cổng “A” hoặc “B” của đồng hồ đo</td></tr><tr><td>thời gian hiện số.</td></tr></tbody></table>

|<image_27>|


## VIETTEL AI RACE

## TD648

## DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ

## TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Số
TT</th><th>Tên mặt hàng</th><th>Mã số theo biểu thuế
nhập khẩu</th><th></th><th></th><th></th><th></th><th></th><th></th><th>Ký hiệu quy cách, mô tả đặc tính kỹ thuật</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Nhóm</td><td></td><td></td><td>Phân nhóm</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Chuyển mạch xoay dùng để chuyển đổi 5 phương thức đo: A, B, A+B, A&lt;–</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>&gt;B, T.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>– Có 5 chân cắm với các chế độ đo khác nhau.</td><td></td></tr><tr><td>288</td><td>Lò xo</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: 03 Lò xo bằng thép mạ kẽm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>với độ cứng khác nhau, đường kính vòng cuốn lò xo Φ20 mm, dài 80 mm;</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Có độ cứng trong khoảng 3-4-5 N/m. 2 đầu lò xo uốn móc để móc treo các</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>vật thí nghiệm. Tại một đầu lò xo có gẵn sẵn mũi vạch chỉ vị trí.</td><td></td></tr><tr><td>289</td><td>Thiết bị dạy học mầm non, tiểu học</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: Bàn ghế học sinh, bàn ghế giáo viên, hàng rào phân góc, góc học</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tập, góc xây dựng, góc nghệ thuật, giá vẽ, bộ đèn tín hiệu giao thông, giá</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sách. Vật liệu bằng gỗ công nghiệp MFC, gỗ tự nhiên.</td><td></td></tr><tr><td>290</td><td>Thiết bị chứng minh các định luật vật lý</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng cho giáo dục, đào tạo. Bao gồm: Thiết bị chứng minh định luật</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Boyle, Thiết bị chứng minh định luật Hooke, Thiết bị chứng minh định luật</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Charles.</td><td></td></tr><tr><td>291</td><td>Máy phát âm tần</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Vỏ máy phát bằng tôn
sơn tĩnh điện, nắp vỏ có quai xách bằng nhựa mềm, điện áp sử dụng 220V –
50Hz, cửa hiển thị tần số có đồng hồ đếm chỉ thị LED 4 chữ so, dải phát tần
số của máy từ 0,1 Hz đến 1.000 Hz được chia bằng chuyển mạch xoay 4
bậc: 0,1 Hz – 1 Hz/1 Hz – 10 Hz/10 Hz – 100 Hz/100 Hz – 1 KHz. Điện áp
đầu ra Max 15V, công suất tiêu thụ Max 20W; Cả 3 giắc cắm lỗ Φ4 mm cấp
tín hiệu được bố trí phía trước mặt máy (đồng bộ với tất cả các nút chức
năng khác) thuận lợi cho việc thao tác làm thí nghiệm.</td><td></td><td></td></tr><tr><td>292</td><td>Thiết bị day học môn Giáo dục thể chất</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Tiêu chuẩn Quốc tế gồm: Tiêu chuẩn ISO 9001 về hệ thống quản lý chất</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lượng. Tiêu chuẩn ISO 14001 về hệ thống quản lý môi trường. Tiêu chuẩn</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ISO 45001 về hệ thống quản lý an toàn và sức khỏe nghề nghiệp.</td><td></td></tr><tr><td>293</td><td>Bảng thép</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Độ dày 0,5 mm, kích thước (400×550) mm, sơn tĩnh điện màu trắng, nẹp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>viền xung quanh. Mặt sau có lắp 2 ke nhôm kích thước (20x30x30) mm để</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>lắp vào giá, đảm bảo cứng và phẳng. Chuyên dùng cho giáo dục, đào tạo.</td><td></td></tr><tr><td>294</td><td>Thiết bị dạy học môn Vật lý</td><td>9023</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bao gồm: Thiết bị đo độ dịch chuyển, tốc độ, vận tốc, Thiết bị đo gia tốc,
Thiết bị đo nhiệt dung riêng, Thiết bị đo tần số sóng âm, Thiết bị đo tốc độ
truyền âm, Thiết bị đo vận tốc và gia tốc của vật rơi tự do, Thiết bị khảo sát
động lượng, Thiết bị khảo sát năng lượng trong va chạm, Thiết bị tạo sóng
dừng, Thiết bị tổng hợp hai lực đồng quy và song song.</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Mã số theo biểu thuế</th></tr></thead><tbody><tr><td>nhập khẩu</td></tr></tbody></table>

<table><thead><tr><th>Số</th></tr></thead><tbody><tr><td>TT</td></tr></tbody></table>

<table><thead><tr><th>Chuyên dùng phục vụ giáo dục, đào tạo. Bao gồm: Vỏ máy phát bằng tôn</th></tr></thead><tbody><tr><td>sơn tĩnh điện, nắp vỏ có quai xách bằng nhựa mềm, điện áp sử dụng 220V –</td></tr><tr><td>50Hz, cửa hiển thị tần số có đồng hồ đếm chỉ thị LED 4 chữ so, dải phát tần</td></tr><tr><td>số của máy từ 0,1 Hz đến 1.000 Hz được chia bằng chuyển mạch xoay 4</td></tr><tr><td>bậc: 0,1 Hz – 1 Hz/1 Hz – 10 Hz/10 Hz – 100 Hz/100 Hz – 1 KHz. Điện áp</td></tr><tr><td>đầu ra Max 15V, công suất tiêu thụ Max 20W; Cả 3 giắc cắm lỗ Φ4 mm cấp</td></tr><tr><td>tín hiệu được bố trí phía trước mặt máy (đồng bộ với tất cả các nút chức</td></tr><tr><td>năng khác) thuận lợi cho việc thao tác làm thí nghiệm.</td></tr></tbody></table>

<table><thead><tr><th>Thiết bị đo nhiệt dung riêng, Thiết bị đo tần số sóng âm, Thiết bị đo tốc độ</th></tr></thead><tbody><tr><td>truyền âm, Thiết bị đo vận tốc và gia tốc của vật rơi tự do, Thiết bị khảo sát</td></tr><tr><td>động lượng, Thiết bị khảo sát năng lượng trong va chạm, Thiết bị tạo sóng</td></tr><tr><td>dừng, Thiết bị tổng hợp hai lực đồng quy và song song.</td></tr></tbody></table>

|<image_28>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD648</th></tr></thead><tbody><tr><td></td><td>DANH MỤC MÁY MÓC, THIẾT BỊ, DÂY CHUYỀN CÔNG NGHỆ
TRONG NƯỚC ĐÃ SẢN XUẤT ĐƯỢC</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_29>|


