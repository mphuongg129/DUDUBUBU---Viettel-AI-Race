# Public_465

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_4>|


### Tiến hành lắp đặt hệ thống Điện mặt trời cho gia đình

## Bảng giá thi công lắp đặt hệ thống điện mặt trời tại

## Việt Nam (tham khảo)

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th>Đơn vị thi</th><th></th><th></th><th>Công suất hệ</th><th></th><th></th><th>Chi phí ước tính / trọn</th><th></th><th>Ghi chú</th></tr></thead><tbody><tr><td></td><td>công</td><td></td><td></td><td>thống</td><td></td><td></td><td>gói</td><td></td><td></td></tr><tr><td>Techpal
Solar</td><td></td><td></td><td>5 kWp</td><td></td><td></td><td>40 – 45 triệu đồng</td><td></td><td></td><td>Hòa lưới, sản lượng ~550
kWh/tháng, mái ~30 m²</td></tr><tr><td></td><td></td><td></td><td>8 kWp</td><td></td><td></td><td>65 – 75 triệu đồng</td><td></td><td></td><td>Hòa lưới, mái ~50 m²</td></tr><tr><td></td><td></td><td></td><td>10 kWp</td><td></td><td></td><td>75 – 85 triệu đồng</td><td></td><td></td><td>Hòa lưới, mái ~60 m²</td></tr><tr><td>BntechSolar</td><td></td><td></td><td>3 kWp</td><td></td><td></td><td>45 – 56 triệu đồng</td><td></td><td></td><td>Áp mái cho hộ gia đình</td></tr><tr><td></td><td></td><td></td><td>5 kWp</td><td></td><td></td><td>75 – 86 triệu đồng</td><td></td><td></td><td>Sản lượng ~600 kWh/tháng</td></tr><tr><td></td><td></td><td></td><td>10 kWp</td><td></td><td></td><td>155 – 190 triệu đồng</td><td></td><td></td><td>Không lưu trữ</td></tr><tr><td></td><td></td><td></td><td>15 kWp</td><td></td><td></td><td>200 – 250 triệu đồng</td><td></td><td></td><td>Công suất lớn, yêu cầu thiết bị
tốt hơn</td></tr><tr><td>Lithaco</td><td></td><td></td><td>10 kWp +
Battery 5.3 kWh</td><td></td><td></td><td>130 triệu đồng</td><td></td><td></td><td>Có lưu trữ, chi phí cao hơn hệ
hòa lưới</td></tr><tr><td>SunPower /
AE Solar</td><td></td><td></td><td>6.2 kWp</td><td></td><td></td><td>84 triệu đồng (khuyến
mại)</td><td></td><td></td><td>Pin AE Solar Mono 400W,
inverter
Growatt/GoodWe/INVT</td></tr><tr><td></td><td></td><td></td><td>8 kWp</td><td></td><td></td><td>110 triệu đồng (khuyến
mại)</td><td></td><td></td><td>Hòa lưới, thiết bị tương tự</td></tr><tr><td>DHC Solar</td><td></td><td></td><td>50 – 100 kWp</td><td></td><td></td><td>13 – 15 triệu đồng/kWp</td><td></td><td></td><td>Hệ doanh nghiệp, mái xưởng</td></tr><tr><td></td><td></td><td></td><td>500 – 1000 kWp</td><td></td><td></td><td>10 – 12 triệu đồng/kWp</td><td></td><td></td><td>Quy mô lớn, đơn giá thấp hơn</td></tr><tr><td>Vũ Phong
Energy
Group</td><td></td><td></td><td>100 – 500 kWp</td><td></td><td></td><td>15 – 16 triệu đồng/kWp
(tiêu chuẩn)
16 – 18 triệu đồng/kWp
(cao cấp)</td><td></td><td></td><td>Mái nhà máy, dự án thương
mại</td></tr><tr><td></td><td></td><td></td><td>&gt;1 MWp</td><td></td><td></td><td>14 – 15 triệu đồng/kWp
(tiêu chuẩn)
15 – 17 triệu đồng/kWp</td><td></td><td></td><td>Dự án quy mô cực lớn</td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>(cao cấp)</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_6>|

|<image_7>|

|<image_8>|


