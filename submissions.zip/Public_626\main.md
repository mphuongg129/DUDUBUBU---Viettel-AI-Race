# Public_626

### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td>A</td><td>1- Hạng mục: Phần móng</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Đào móng băng bằng máy đào &lt;= 0.8m3
Chiều rộng móng &lt;= 6m, Đất cấp III
(90%)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>241,696</td><td>1 m3</td></tr><tr><td>2</td><td>Đào móng băng bằng thủ công có chiều
rộng&lt;=3m Chiều sâu &lt;=2m , Đất cấp III
(10%)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>26,855</td><td>1 m3</td></tr><tr><td>3</td><td>Bê tông đá dăm lót móng, R&lt;=250cm
Vữa bê tông đá 4x6 M100</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>24,346</td><td>1 m3</td></tr><tr><td>4</td><td>Gia công cốt thép móng Đường kính cốt
thép d&lt;=10mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,052</td><td>Tấn</td></tr><tr><td>5</td><td>Gia công cốt thép móng Đường kính cốt
thép d&lt;=18mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,773</td><td>Tấn</td></tr><tr><td>6</td><td>Gia công cốt thép móng Đường kính cốt
thép d&gt;18mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,657</td><td>Tấn</td></tr><tr><td>7</td><td>Ván khuôn móng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>112,665</td><td>1 m2</td></tr><tr><td>8</td><td>Bê tông móng chiều rộng R&lt;=250cm Vữa
bê tông đá 1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>76,366</td><td>1 m3</td></tr><tr><td>9</td><td>Xây móng tường gạch KN (6x9.5x20)
Dày &lt;= 30 cm,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>23,404</td><td>1 m3</td></tr><tr><td>10</td><td>Gia công cốt thép xà, dầm, giằng móng
Đường kính cốt thép d&lt;=10 mm,cao&lt;=4m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,105</td><td>Tấn</td></tr><tr><td>11</td><td>Gia công cốt thép xà, dầm, giằng móng
Đường kính cốt thép d&lt;=18 mm,cao&lt;=4m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,691</td><td>Tấn</td></tr><tr><td>12</td><td>Gia công cốt thép xà, dầm, giằng móng
Đường kính cốt thép d&gt;18 mm,cao&lt;=4m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,981</td><td>Tấn</td></tr><tr><td>13</td><td>Ván khuôn dầm, giằng móng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>115,27</td><td>1 m2</td></tr><tr><td>14</td><td>Bê tông xà, dầm, giằng móng Vữa bê tông
đá 1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>11,725</td><td>1 m3</td></tr><tr><td>15</td><td>Đắp đất hoàn trả móng công trình bằng
đầm cóc Độ chặt yêu cầu K=0.90 (đất tận
dụng)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>144,438</td><td>1 m3</td></tr></tbody></table>

|<image_1>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>16</th><th>Vận chuyển đất bằng ô tô tự đổ Cự ly 1km
đầu,ô tô 7T,Đất cấp III</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>140,248</th><th>1 m3</th></tr></thead><tbody><tr><td>17</td><td>Vận chuyển đất tiếp bằng ô tô tự đổ Cự ly
3km, ô tô 7T, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>140,248</td><td>1 m3</td></tr><tr><td>18</td><td>Đắp đất tôn nền bằng đầm cóc Độ chặt
yêu cầu K=0.90 (có mua đất)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>130,403</td><td>1 m3</td></tr><tr><td>19</td><td>Mua đất để đắp</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>130,403</td><td>1 m3</td></tr><tr><td>20</td><td>Vận chuyển đất bằng ô tô tự đổ Cự ly 1km
bằng ô tô 10T,Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>147,355</td><td>1 m3</td></tr><tr><td>21</td><td>Vận chuyển đất tiếp bằng ô tô tự đổ Cự ly
4km, bằng ô tô 10T, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>147,355</td><td>1 m3</td></tr><tr><td>22</td><td>Vận chuyển đất tiếp bằng ô tô tự đổ Cự ly
7km cuối , ô tô 10T, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>147,355</td><td>1 m3</td></tr><tr><td>23</td><td>Bê tông nền Vữa bê tông đá 4x6 M100</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>27,963</td><td>1 m3</td></tr><tr><td>B</td><td>2- Hạng mục: Phần thân</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Gia công cốt thép cột, trụ Đường kính cốt
thép d&lt;=10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,571</td><td>Tấn</td></tr><tr><td>2</td><td>Gia công cốt thép cột, trụ Đường kính cốt
thép d&lt;=18 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,875</td><td>Tấn</td></tr><tr><td>3</td><td>Gia công cốt thép cột, trụ Đường kính cốt
thép d&gt;18 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,256</td><td>Tấn</td></tr><tr><td>4</td><td>Ván khuôn cột vuông, chữ nhật</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>325,752</td><td>1 m2</td></tr><tr><td>5</td><td>Bê tông cột có tiết diện &lt;= 0.1 m2 Cao
&lt;=4m,vữa bê tông đá 1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>11,212</td><td>1 m3</td></tr><tr><td>6</td><td>Bê tông cột có tiết diện &lt;= 0.1 m2 Cao &lt;=
16m,vữa bê tông đá 1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>9,363</td><td>1 m3</td></tr><tr><td>7</td><td>Ván khuôn xà dầm, giằng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>507,794</td><td>1 m2</td></tr><tr><td>8</td><td>Gia công cốt thép xà, dầm, giằng Đường
kính cốt thép d&lt;=10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,346</td><td>Tấn</td></tr><tr><td>9</td><td>Gia công cốt thép xà, dầm, giằng Đường
kính cốt thép d&lt;=18 mm</td><td>Theo chỉ dẫn kỹ thuật
đính kèm</td><td>4,727</td><td>Tấn</td></tr><tr><td>10</td><td>Gia công cốt thép xà, dầm, giằng Đường
kính cốt thép d&gt;18 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,226</td><td>Tấn</td></tr><tr><td>11</td><td>Bê tông xà, dầm, giằng Vữa bê tông đá
1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>46,739</td><td>1 m3</td></tr></tbody></table>

|<image_2>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>12</th><th>Ván khuôn thép, khung xương thép ...
Ván khuôn sàn</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>870,032</th><th>1 m2</th></tr></thead><tbody><tr><td>13</td><td>Gia công cốt thép sàn Đường kính cốt
thép d&lt;=10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>11,147</td><td>Tấn</td></tr><tr><td>14</td><td>Gia công cốt thép sàn Đường kính cốt
thép d&gt; 10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,595</td><td>Tấn</td></tr><tr><td>15</td><td>Bê tông sàn mái Vữa bê tông đá 1x2
M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>100,95</td><td>1 m3</td></tr><tr><td>16</td><td>Ván khuôn cầu thang thường</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>21,95</td><td>1 m2</td></tr><tr><td>17</td><td>Gia công cốt thép cầu thang Đường kính
cốt thép d&lt;=10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,085</td><td>Tấn</td></tr><tr><td>18</td><td>Gia công cốt thép cầu thang Đường kính
cốt thép d&gt; 10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,229</td><td>Tấn</td></tr><tr><td>19</td><td>Bê tông cầu thang thường Vữa bê tông đá
1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,872</td><td>1 m3</td></tr><tr><td>20</td><td>Gia công cốt thép lanh tô liền mái hắt...
Đường kính cốt thép d&lt;=10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,79</td><td>Tấn</td></tr><tr><td>21</td><td>Gia công cốt thép lanh tô liền mái hắt...
Đường kính cốt thép d&gt; 10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,049</td><td>Tấn</td></tr><tr><td>22</td><td>Ván khuôn lanh tô,lanh tô liền mái hắt,
máng nước</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>120,372</td><td>1 m2</td></tr><tr><td>23</td><td>Bê tông lanh tô mái hắt máng nước,tấm
đan, ô văng,VM250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>8,202</td><td>1 m3</td></tr><tr><td>C</td><td>3- Hạng mục: Phần hoàn thiện</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Xây tường ngoài gạch đặc KN
(6x9.5x20)cm Cao&lt;= 4m,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>19,317</td><td>1 m3</td></tr><tr><td>2</td><td>Xây tường ngoài gạch đặc KN
(6x9.5x20)cm ,Cao&lt;=16m,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>28,253</td><td>1 m3</td></tr><tr><td>3</td><td>Xây tường trong bằng gạch KN 6
lỗ(9.5x13.5x20) Dày 20cm, Cao &lt;= 4
m,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13,382</td><td>1 m3</td></tr><tr><td>4</td><td>Xây tường trong bằng gạch KN 6
lỗ(9.5x13.5x20) Dày 20cm, Cao &lt;= 16 m,
vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>22,324</td><td>1 m3</td></tr><tr><td>5</td><td>Xây tường thu hồi gạch đặc KN
(6x9.5x20)cm ,Cao&lt;=16m,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13,084</td><td>1 m3</td></tr></tbody></table>

|<image_3>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>6</th><th>Xây tường lan can gạch đặc KN
(6x9.5x20)cm Dày &lt;=11cm,Cao&lt;=
4m,vữa XM M75</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>2,848</th><th>1 m3</th></tr></thead><tbody><tr><td>7</td><td>Xây tường lan can gạch đặc KN
(6x9.5x20)cm Dày&lt;=11cm,Cao
&lt;=16m,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,533</td><td>1 m3</td></tr><tr><td>8</td><td>Xây bậc cấp cầu thang bằng gạch đặc KN
6x9.5x20cm,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,792</td><td>1 m3</td></tr><tr><td>9</td><td>Xây cột, trụ gạch đặc KN (6x9.5x20) Cao
&lt;= 50 m,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10,644</td><td>1 m3</td></tr><tr><td>10</td><td>Lát đá tự nhiên khò nhám mặt ram dốc</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>8</td><td>1 m2</td></tr><tr><td>11</td><td>Lát đá Granite tự nhiên bậc tam cấp</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>19,584</td><td>1 m2</td></tr><tr><td>12</td><td>Lát gạch bậc cấp Gạch Terazzo
30x30,VM75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5,28</td><td>1 m2</td></tr><tr><td>13</td><td>Tấm nhôm Alunium liên kết bằng vít D5</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>17,8</td><td>m</td></tr><tr><td>14</td><td>Lát đá Granite tự nhiên bậc cầu thang</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>26,29</td><td>1 m2</td></tr><tr><td>15</td><td>Lắp đặt tấm INOX hình OMEGA dày
0.3mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>7,6</td><td>m</td></tr><tr><td>16</td><td>Ôp tường chân móng bằng đá phiến tự
nhiên</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>33,63</td><td>1 m2</td></tr><tr><td>17</td><td>Trát tường ngoài, bề dày 1.5 cm Vữa XM
M75#, có hồ dầu</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>476,265</td><td>1 m2</td></tr><tr><td>18</td><td>Trát tường trong, bề dày 1.5 cm Vữa XM
M75#</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>554,665</td><td>1 m2</td></tr><tr><td>19</td><td>Trát trụ, cột và lam đứng cầu thang Dày
1.5 cm, Vữa XM M75#</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>340,154</td><td>1 m2</td></tr><tr><td>20</td><td>Trát xà dầm, có hồ dầu Vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>429,557</td><td>1 m2</td></tr><tr><td>21</td><td>Trát trần, có hồ dầu Vữa XM M75</td><td>Theo chỉ dẫn kỹ</td><td>770,442</td><td>1 m2</td></tr><tr><td>22</td><td>Trát gờ chỉ Vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>645,66</td><td>1 m</td></tr><tr><td>23</td><td>Quét Sika chống thấm tường thu hồi</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>39,846</td><td>1 m2</td></tr><tr><td>24</td><td>Ngâm nước xi măng chống thấm mái, sê
nô, ô văng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>89,22</td><td>m2</td></tr></tbody></table>

|<image_4>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>25</th><th>Quét Sika chống thấm mái sê nô, văng</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>89,22</th><th>1 m2</th></tr></thead><tbody><tr><td>26</td><td>Láng sê nô, mái hắt, máng nước dày 1.5
cm, Vữa M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>89,22</td><td>1 m2</td></tr><tr><td>27</td><td>Láng Ô văn dày 2 cm, Vữa M75#</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>48,38</td><td>1 m2</td></tr><tr><td>28</td><td>Xây tường thông gió,vữa XM M75 Gạch
thông gió 20x20 cm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>9,6</td><td>1m2</td></tr><tr><td>29</td><td>Sơn tường trong nhà 1 nước lót,2 nước
phủ,k bả sơn JOTON</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>554,665</td><td>1m2</td></tr><tr><td>30</td><td>Sơn tường ngoài nhà, k bả sơn 1 nước lót,
2 nước phủ JOTON</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>476,265</td><td>1m2</td></tr><tr><td>31</td><td>Sơn dầm, trần, cột 1 nước lót,2 nước
phủ,k bả sơn JOTON</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1.540,153</td><td>1m2</td></tr><tr><td>32</td><td>Ngâm nước xi măng chống thấm khu vệ
sinh</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13,32</td><td>m2</td></tr><tr><td>33</td><td>Quét Sika 3 nước chống thấm khu vệ sinh</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13,32</td><td>1 m2</td></tr><tr><td>34</td><td>Lát nền, sàn Gạch Granite 30x30cm,
chống trượt</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>62,38</td><td>1 m2</td></tr><tr><td>35</td><td>Làm trần thạch cao+ khung nổi chống ẩm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>62,38</td><td>1 m2</td></tr><tr><td>36</td><td>Ôp tường, trụ, cột khu WC Gạch Ceramic
30x60cm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>126,72</td><td>1 m2</td></tr><tr><td>37</td><td>Lắp dựng vách ngăn, cửa bằng tấm
compact dày 12mm + Phụ kiện lắp đặt
kèm theo</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>77,3</td><td>1 m2</td></tr><tr><td>38</td><td>Lắp đặt khung dàn cố định vách ngăn và
cửa tấm Compact bằng hộp Inox 30x30</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5,8</td><td>m</td></tr><tr><td>39</td><td>Lát đá mặt bệ các loại Bệ bếp, bệ bàn, bệ
Lavabo...</td><td>Theo chỉ dẫn kỹ thuật
đính kèm</td><td>1,12</td><td>1 m2</td></tr><tr><td>40</td><td>Lát nền, sàn Gạch Granite 60x60cm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>624,04</td><td>1 m2</td></tr><tr><td>41</td><td>Ôp chân tường,viền tường,viền trụ,cột Cắt
từ Gạch Granite nền 10x60cm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>20,66</td><td>1 m2</td></tr><tr><td>42</td><td>Lát đá Granite tự nhiên các len cửa đi</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>7,113</td><td>1 m2</td></tr><tr><td>43</td><td>Lát đá Granite bục giảng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>15,6</td><td>1 m2</td></tr></tbody></table>

|<image_5>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>44</th><th>Lát đá Granite lan can</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>15,408</th><th>1 m2</th></tr></thead><tbody><tr><td>45</td><td>SXLD cửa đi 2 cánh mở quay uPVC, kính
đơn 6.38ly</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>42,12</td><td>m2</td></tr><tr><td>46</td><td>Phụ kiện GQ cửa đi 2 cánh mở quay
uPVC</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>15</td><td>Bộ</td></tr><tr><td>47</td><td>SXLD cửa đi 2 cánh mở quay uPVC, kính
đơn 6.38ly loại kính mờ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>6,48</td><td>m2</td></tr><tr><td>48</td><td>SXLD cửa sổ 2 cánh mở trượt uPVC, kính
đơn 6.38ly</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>59,94</td><td>m2</td></tr><tr><td>49</td><td>Phụ kiện GQ cửa sổ 2 cánh mở trượt
uPVC</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>37</td><td>Bộ</td></tr><tr><td>50</td><td>SXLD cửa sổ mở hất uPVC, kính đơn
6.38ly</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,88</td><td>m2</td></tr><tr><td>51</td><td>Phụ kiện GQ cửa sổ mở hất uPVC</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Bộ</td></tr><tr><td>52</td><td>SXLắp dựng hoa sắt cửa thép hộp
14x14x1.2 VXM 75# (khoán gọn)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>59,94</td><td>m2</td></tr><tr><td>53</td><td>Sơn sắt thép các loại, 3 nước</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>59,94</td><td>1 m2</td></tr><tr><td>54</td><td>SXLắp dựng lan can sắt cầu thang thép
hộp mạ kẽm 20x40x1.4mm, VXM 75#
(khoán gọn)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>11,394</td><td>m2</td></tr><tr><td>55</td><td>Gia công và đóng tay vịn cầu thang bằng
gỗ N2 kích thước D60 cm + Sơn PU
(khoán gọn)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>12,66</td><td>1 m</td></tr><tr><td>56</td><td>SX Lắp dựng lan can ram dốc bằng INOX
304 VXM 75# (khoán gọn)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>4,77</td><td>m2</td></tr><tr><td>57</td><td>SXLắp dựng lan can bậc cấp bằng INOX
304 VXM 75# (khoán gọn)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,43</td><td>m2</td></tr><tr><td>58</td><td>Sơn sắt thép bằng sơn Expoxy 2 thành
phần 1 nước lót, 2 nước phủ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>17,091</td><td>1m2</td></tr><tr><td>59</td><td>SXLắp dựng tay vịn lan can INOX D60
dày 1.4mm Vữa XM cát vàng M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>91</td><td>m</td></tr><tr><td>60</td><td>Sản xuất xà gồ bằng thép hộp mạ kẽm
60x120x1.8 Trọng lượng: 4.965kg/m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,742</td><td>Tấn</td></tr><tr><td>61</td><td>Sản xuất cầu phong bằng thép hộp mạ
kẽm 30x60x1.2 (Trọng lượng:1.64kg/m)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,595</td><td>Tấn</td></tr></tbody></table>

|<image_6>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>62</th><th>Sản xuất cầu li tô bằng thép hộp mạ kẽm
20x20x1.2 (Trọng lượng: 0.7kg/m)</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>1,452</th><th>Tấn</th></tr></thead><tbody><tr><td>63</td><td>Lắp dựng xà gồ thép hộp mạ kẽm
60x120x1.8</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,742</td><td>Tấn</td></tr><tr><td>64</td><td>Lắp dựng cầu phong bằng thép hộp mạ
kẽm 30x60x1.2</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,594</td><td>Tấn</td></tr><tr><td>65</td><td>Lắp dựng Li tô bằng thép hộp mạ kẽm
20x20x1.2</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,452</td><td>Tấn</td></tr><tr><td>66</td><td>Lợp mái ngói 22 V/m2 Chiều cao &lt;=16m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>465,12</td><td>1 m2</td></tr><tr><td>67</td><td>Xối âm bằng INOX 304 KT 600mm, dày
1.2ly</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>12</td><td>m</td></tr><tr><td>68</td><td>SXLD nắp tôn lên mái KT 0.8x0.8
(K.gon)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>1 Cái</td></tr><tr><td>69</td><td>Tấm Inox úp khe nhiệt, dày 0.3mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,99</td><td>1 m2</td></tr><tr><td>70</td><td>Phá dỡ bằng máy khoan cầm tay kết cấu
bê tông Có cốt thép, sê nô nhà cũ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,274</td><td>m3</td></tr><tr><td>71</td><td>Lắp đặt máng xối INOX dày 0.4mm (k/g)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>8,2</td><td>m</td></tr><tr><td>72</td><td>Bê tông nền Vữa bê tông đá 2x4M150</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>3,12</td><td>1 m3</td></tr><tr><td>73</td><td>Lắp các loại Lắp móc gió cửa đi</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>30</td><td>bộ</td></tr><tr><td>74</td><td>Phá dỡ kết cấu bê tông cốt thép bằng búa
căn, khu WC cải tạo</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,324</td><td>m3</td></tr><tr><td>75</td><td>Phá dỡ kết cấu gạch đá bằng búa căn, khu
WC cải tạo</td><td>Theo chỉ dẫn kỹ thuật
đính kèm</td><td>8,24</td><td>m3</td></tr><tr><td>76</td><td>Tháo dỡ kết cấu gạch ốp tường WC cải
tạo</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>31,8</td><td>1 m2</td></tr><tr><td>77</td><td>Phá dỡ nền gạch khu vệ sinh cải tạo</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>27,84</td><td>1 m2</td></tr><tr><td>78</td><td>Tháo dỡ lan can khối nhà cũ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>14,4</td><td>m</td></tr><tr><td>79</td><td>Bốc xếp phế thải các loại</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>9,838</td><td>m3</td></tr><tr><td>80</td><td>V/chuyển phế thải trong cự ly 1km bằng
ôtô 7 tấn</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>9,838</td><td>1m3</td></tr></tbody></table>

|<image_7>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>81</th><th>V/chuyển phế thải tiếp cự ly 5km cuối
bằng ô tô 7T</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>9,838</th><th>1m3</th></tr></thead><tbody><tr><td>D</td><td>4- Hạng mục: Phần cấp thoát nước</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Lắp đặt chậu xí bệt + Hang xịt + Pk</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13</td><td>1 Bộ</td></tr><tr><td>2</td><td>Lắp hộp đựng xà phòng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13</td><td>Cái</td></tr><tr><td>3</td><td>Lắp hộp đựng giấy vệ sinh</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13</td><td>Cái</td></tr><tr><td>4</td><td>Lắp đặt chậu tiểu nữ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>1 Bộ</td></tr><tr><td>5</td><td>Lắp đặt chậu tiểu treo +PK</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>7</td><td>1 Bộ</td></tr><tr><td>6</td><td>Lắp phễu thu sàn d200 Inox</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>Cái</td></tr><tr><td>7</td><td>Lắp đặt lavabo + PK (người lớn)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>7</td><td>1 Bộ</td></tr><tr><td>8</td><td>Lắp gương soi</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>7</td><td>Cái</td></tr><tr><td>9</td><td>Lắp đặt vòi tắm hương sen Loại 1 vòi, 1
hương sen</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2</td><td>1 Bộ</td></tr><tr><td>10</td><td>Lắp đặt ống nhựa PPR nối bằng PP hàn
Đkính ống 20x2.3mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>1 m</td></tr><tr><td>11</td><td>Lắp đặt đấu nối ren trong ĐK 20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>70</td><td>Cái</td></tr><tr><td>12</td><td>Lắp đặt đấu nối ren ngoài ĐK 20mm</td><td>Theo chỉ dẫn kỹ</td><td>70</td><td>Cái</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td></td><td></td><td>thuật đính kèm</td><td></td><td></td></tr><tr><td>13</td><td>Lắp đặt tê nhựa PPR nối = PP hàn Đkính
D20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>35</td><td>Cái</td></tr><tr><td>14</td><td>Lắp đặt cút nhựa PPR nối = PP hàn Đkính
cút D20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>35</td><td>Cái</td></tr><tr><td>15</td><td>Lắp đặt ống nhựa PPR nối bằng PP hàn
Đkính ống 25x2.8mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>70</td><td>1 m</td></tr></tbody></table>

|<image_8>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>16</th><th>Lắp đặt cút nhựa PPR nối = PP hàn Đkính
cút D25mm</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>30</th><th>Cái</th></tr></thead><tbody><tr><td>17</td><td>Lắp đặt tê nhựa PPR nối = PP hàn Đkính
D25mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cái</td></tr><tr><td>18</td><td>Lắp đặt tê thu hẹp PPR nhựa nối = PP hàn
Đkính D25/20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>Cái</td></tr><tr><td>19</td><td>Lắp đặt co thu hẹp PPR nhựa nối = PP
hàn Đkính D25/20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>20</td><td>Cái</td></tr><tr><td>20</td><td>Lắp đặt ống nhựa PPR nối bằng PP hàn
Đkính ống 32x2.9mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>1 m</td></tr><tr><td>21</td><td>Lắp đặt cút nhựa PPR nối = PP hàn Đkính
cút D32mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cái</td></tr><tr><td>22</td><td>Lắp đặt tê nhựa PPR nối = PP hàn Đkính
D32mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>Cái</td></tr><tr><td>23</td><td>Lắp đặt thu hẹp PPR nhựa nối = PP hàn
Đkính D32/25mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>Cái</td></tr><tr><td>24</td><td>Lắp đặt ống nhựa PPR nối bằng PP hàn
Đkính ống D50x4.6mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>1 m</td></tr><tr><td>25</td><td>Lắp đặt cút nhựa PPR nối = PP hàn Đkính
cút 50mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>Cái</td></tr><tr><td>26</td><td>Lắp đặt thu hẹp nhựa PPR nối = PP hàn
Đkính D50/32mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cái</td></tr><tr><td>27</td><td>Lắp đặt tê nhựa PPR nối = PP hàn Đkính
D50mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2</td><td>Cái</td></tr><tr><td>28</td><td>Lắp đặt van khóa Đkính van D25mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>3</td><td>Cái</td></tr><tr><td>29</td><td>Cùm treo ống + ty ren mạ kẽm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>20</td><td>Bộ</td></tr><tr><td>30</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống 114x5mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>70</td><td>1 m</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td>31</td><td>LĐ Y nhựa PVC mbát nối=PP dán keo
Đkính D114mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>Cái</td></tr><tr><td>32</td><td>LĐ cút nhựa PVC mbát nối=PP dán keo
Đkính cút 114mm -135 độ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>70</td><td>Cái</td></tr></tbody></table>

|<image_9>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>33</th><th>LĐ tê nhựa PVC mbát nối=PP dán keo
Đkính D114mm</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>5</th><th>Cái</th></tr></thead><tbody><tr><td>34</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống D90x3.5mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>280</td><td>1 m</td></tr><tr><td>35</td><td>LĐ cút nhựa PVC mbát nối=PP dán keo
Đkính cút D90mm -135 độ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>80</td><td>Cái</td></tr><tr><td>36</td><td>LĐ Y nhựa PVC mbát nối=PP dán keo
Đkính D90mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>20</td><td>Cái</td></tr><tr><td>37</td><td>LĐ Tê nhựa PVC mbát nối=PP dán keo
Đkính D90mm -135 độ</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cái</td></tr><tr><td>38</td><td>LĐ thu hẹp nhựa PVC mbát nối=PP dán
keo Đkính D90/42mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>Cái</td></tr><tr><td>39</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống D42x3.5mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>15</td><td>1 m</td></tr><tr><td>40</td><td>LĐ cút nhựa PVC mbát nối=PP dán keo
Đkính cút 42mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>Cái</td></tr><tr><td>41</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống 140x4mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>90</td><td>1 m</td></tr><tr><td>42</td><td>LĐ cút nhựa PVC mbát nối=PP dán keo
Đkính cút D140mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cái</td></tr><tr><td>43</td><td>LĐ tê nhựa PVC mbát nối=PP dán keo
Đkính D140mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>Cái</td></tr><tr><td>44</td><td>Cùm treo ống + ty ren mạ kẽm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>Bộ</td></tr><tr><td>45</td><td>Hút hầm vệ sinh hiện trạng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Hầm</td></tr><tr><td>46</td><td>Đào đất đặt đường ống, đường cáp Có mở
mái taluy, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>27</td><td>1 m3</td></tr><tr><td>47</td><td>Đắp đất móng đường ống, đường cống Độ
chặt yêu cầu K=0.90</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>27</td><td>1 m3</td></tr><tr><td>E</td><td>5- Hạng mục: Thoát nước mái</td><td></td><td></td><td></td></tr><tr><td>1</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống D90x3.5mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>160</td><td>1 m</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody></tbody></table>

|<image_10>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>2</th><th>COLIE giữ ống</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>170</th><th>Cái</th></tr></thead><tbody><tr><td>3</td><td>LĐ cút nhựa PVC mbát nối=PP dán keo
Đkính cút D90mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>21</td><td>Cái</td></tr><tr><td>4</td><td>LĐ Y nhựa PVC mbát nối=PP dán keo
Đkính D90mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>21</td><td>Cái</td></tr><tr><td>5</td><td>LĐ chếch nhựa PVC mbát nối=PP dán
keo Đkính D90mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>42</td><td>Cái</td></tr><tr><td>6</td><td>LĐ măng xông nhựa PVC mbát nối=PP
dán keo Đkính tê 90mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>21</td><td>Cái</td></tr><tr><td>7</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống D60x3.0mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10</td><td>1 m</td></tr><tr><td>8</td><td>LĐ ống nhựa PVC mbát nối = PP dán keo
Đkính ống D34x3.0mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>1 m</td></tr><tr><td>9</td><td>SXLD Cầu chắn rác</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>42</td><td>Cái</td></tr><tr><td>F</td><td>6- Hạng mục: Hệ thống điện chiếu sáng</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Lắp đặt đèn Led T8 đôi máng tán xạ
2x1.2m-20w 2x1.2m-20w + Ty treo đèn</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>49</td><td>1 Bộ</td></tr><tr><td>2</td><td>Lắp đặt đèn Led T8 đơn 1x1.2m-20w +
Ty treo đèn</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>12</td><td>1 Bộ</td></tr><tr><td>3</td><td>Lắp đặt đèn Led T8 đơn 1x1.2m-20w</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>9</td><td>1 Bộ</td></tr><tr><td>4</td><td>Lắp đặt đèn Led panel 300x300 CS 10W</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>30</td><td>1 Bộ</td></tr><tr><td>5</td><td>Lắp đặt quạt hút WC + mặt che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>4</td><td>Cái</td></tr><tr><td>6</td><td>Lắp đặt quạt đảo 360 độ + PK</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>33</td><td>Cái</td></tr><tr><td>7</td><td>Lắp đặt quạt treo tường</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>6</td><td>Cái</td></tr><tr><td>8</td><td>Lắp đặt ổ cắm Loại ổ cắm đơn 3 chấu +
mặt che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>6</td><td>Cái</td></tr><tr><td>9</td><td>Lắp đặt ổ cắm Loại ổ cắm đôi 3 chấu
+mặt che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>28</td><td>Cái</td></tr><tr><td>10</td><td>Lắp đặt công tắc Loại công tắc 1 hạt+mặt
che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>6</td><td>Cái</td></tr></tbody></table>

|<image_11>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td>11</td><td>Lắp đặt công tắc Loại công tắc 2 hạt</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>7</td><td>Cái</td></tr><tr><td>12</td><td>Lắp đặt công tắc+mặt che Loại công tắc 3
hạt+mặt che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13</td><td>Cái</td></tr><tr><td>13</td><td>Lắp đặt công tắc Loại công tắc đảo chiều
+mặt che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2</td><td>Cái</td></tr><tr><td>14</td><td>Lắp đặt Automat 1 pha + mặt che MCB -
1P-20A</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>13</td><td>Cái</td></tr><tr><td>15</td><td>Lắp đặt dây đơn Loại dây CV(1x1.5mm2)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1.200</td><td>1m</td></tr><tr><td>16</td><td>Lắp đặt dây đơn Loại dây CV(1x2.5mm2)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>800</td><td>1m</td></tr><tr><td>17</td><td>Lắp đặt dây đơn Loại dây CV(1x4mm2)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>600</td><td>1m</td></tr><tr><td>18</td><td>Lắp đặt dây đơn Loại dây CV(1x6mm2)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>300</td><td>1m</td></tr><tr><td>19</td><td>Lắp đặt dây dẫn 2 ruột Loại dây CVV
2x10mm2</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>20</td><td>1m</td></tr><tr><td>20</td><td>Lắp đặt dây dẫn 2 ruột Loại dây CVV
2x16mm2</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>60</td><td>1m</td></tr><tr><td>21</td><td>LĐ ống nhựa SP đặt chìm bảo hộ dây dẫn
Đường kính ống D20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>300</td><td>1 m</td></tr><tr><td>22</td><td>LĐ ống nhựa SP đặt chìm bảo hộ dây dẫn
Đường kính ống D25mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>150</td><td>1 m</td></tr><tr><td>23</td><td>LĐ ống nhựa xoắn HDPE bảo hộ dây dẫn
Đường kính ống D50/40mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>1 m</td></tr><tr><td>24</td><td>Lđặt tủ điện tổng KT 600x500x200</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Tủ</td></tr><tr><td>25</td><td>Lắp đặt Automat 2 pha MCB-2P-63A</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Cái</td></tr><tr><td>26</td><td>Lắp đặt Automat 2 pha MCB - 2P-50A</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2</td><td>Cái</td></tr><tr><td>27</td><td>Lđặt tủ điện tầng KT 520x350x170</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Tủ</td></tr><tr><td>28</td><td>Lắp đặt Automat 2 pha MCB - 2P-50A</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2</td><td>Cái</td></tr></tbody></table>

|<image_12>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>29</th><th>Lắp đặt Automat 2 pha MCB - 2P-16A</th><th>Theo chỉ dẫn kỹ</th><th>3</th><th>Cái</th></tr></thead><tbody></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td></td><td></td><td>thuật đính kèm</td><td></td><td></td></tr><tr><td>30</td><td>Lắp đặt Automat 2 pha MCB - 2P-32A</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>6</td><td>Cái</td></tr><tr><td>31</td><td>Lắp đặt dây đơn Loại dây CXV 1x25mm2</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>60</td><td>1m</td></tr><tr><td>32</td><td>Gia công và đóng cọc tiếp địa D14.2/2.4m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>8</td><td>Cọc</td></tr><tr><td>33</td><td>Kéo rải dây chống sét theo tường,cột Dây
thép d16mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>30</td><td>m</td></tr><tr><td>34</td><td>Đo điện trở nối đất R&lt;=4 OMH</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Điểm</td></tr><tr><td>35</td><td>Đào đất đặt đường ống, đường cáp Có mở
mái taluy, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>1 m3</td></tr><tr><td>36</td><td>Đắp đất móng đường ống, đường cống Độ
chặt yêu cầu K=0.90</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>1 m3</td></tr><tr><td>G</td><td>7- Hạng mục: Hệ thống chống sét</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Lắp đặt kim thu sét D16 mạ kẽm Chiều
dài kim 1m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cái</td></tr><tr><td>2</td><td>Kéo rải dây chống sét đi trên mái Dây
thép d12mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>70</td><td>m</td></tr><tr><td>3</td><td>Kéo rải dây chống sét theo tường,cột Dây
thép d16mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>30</td><td>m</td></tr><tr><td>4</td><td>Gia công và đóng cọc chống sét
D14.2/2.4m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>8</td><td>Cọc</td></tr><tr><td>5</td><td>Thép lá 4ly</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>40</td><td>m</td></tr><tr><td>6</td><td>Chân bật hàn chống bão</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>27</td><td>m</td></tr><tr><td>7</td><td>Đo điện trở nối đất R&lt;=10 OMH</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Điểm</td></tr><tr><td>8</td><td>Đào đất đặt đường ống, đường cáp Có mở
mái taluy, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>1 m3</td></tr></tbody></table>

|<image_13>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>9</th><th>Đắp đất móng đường ống, đường cống Độ
chặt yêu cầu K=0.90</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>5</th><th>1 m3</th></tr></thead><tbody><tr><td>H</td><td>8-Hạng mục: INTERNET</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Lắp đặt thiết bị SWitch 8port</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>1Bộ</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td>2</td><td>Lắp đặt MODEM Wifi 4port</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>1Bộ</td></tr><tr><td>3</td><td>Lắp đặt ổ cắm internet+ mặt che</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>9</td><td>Cái</td></tr><tr><td>4</td><td>Lắp đặt cáp INTERNET CAT 6</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>80</td><td>1m</td></tr><tr><td>5</td><td>LĐ ống nhựa SP đặt chìm bảo hộ dây dẫn
Đường kính ống D20mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>50</td><td>1 m</td></tr><tr><td>I</td><td>9- Hạng mục: Bể tự hoại</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Đào móng bằng máy đào &lt;= 0.8m3 Chiều
rộng móng &lt;= 6m, Đất cấp III (90%)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>24,987</td><td>1 m3</td></tr><tr><td>2</td><td>Đào móng bằng thủ công có chiều
rộng&lt;=3m Chiều sâu &lt;=2m , Đất cấp III
(10%)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,776</td><td>1 m3</td></tr><tr><td>3</td><td>Bê tông đá dăm lót móng, R&lt;=250cm
Vữa bê tông đá 4x6 M100</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,048</td><td>1 m3</td></tr><tr><td>4</td><td>Ván khuôn móng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>2,4</td><td>1 m2</td></tr><tr><td>5</td><td>Gia công cốt thép đáy bể Đường kính cốt
thép d&lt;=10mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,149</td><td>Tấn</td></tr><tr><td>6</td><td>Bê tông móng chiều rộng R&gt;250cm Vữa
bê tông đá 1x2 M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,672</td><td>1 m3</td></tr><tr><td>7</td><td>Xây BTH gạch KN đặc (6x9.5x20) Dày
&lt;= 30 cm,vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>4,472</td><td>1 m3</td></tr><tr><td>8</td><td>Ván khuôn xà dầm, giằng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>6,76</td><td>1 m2</td></tr><tr><td>9</td><td>Gia công cốt thép xà, dầm, giằng Đường
kính cốt thép d&lt;=10 mm,cao&lt;=4m</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,054</td><td>Tấn</td></tr></tbody></table>

|<image_14>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>10</th><th>Bê tông xà, dầm, giằng nhà Vữa bê tông
đá 1x2 M250</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>0,488</th><th>1 m3</th></tr></thead><tbody><tr><td>11</td><td>Trát tường trong, bề dày 1 cm Vữa XM
M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>21,9</td><td>1 m2</td></tr><tr><td>12</td><td>Trát tường trong, bề dày 1.5 cm Vữa XM
M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>21,9</td><td>1 m2</td></tr><tr><td>13</td><td>Trát xà dầm, có hồ dầu Vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>4,52</td><td>1 m2</td></tr><tr><td>14</td><td>Láng nền, sàn không đánh màu Dày 3 cm</td><td>Theo chỉ dẫn kỹ</td><td>6,12</td><td>1 m2</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td></td><td>, Vữa M75</td><td>thuật đính kèm</td><td></td><td></td></tr><tr><td>15</td><td>Sản xuất cấu kiện bê tông đúc sẵn tấm
đan, mái hắt, lanh tô, vữa M250</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,767</td><td>1 m3</td></tr><tr><td>16</td><td>Sản xuất, lắp dựng và tháo dỡ ván khuôn
nắp đan, tấm chớp</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>4,24</td><td>1 m2</td></tr><tr><td>17</td><td>Cốt thép tấm đan, hàng rào,cửa sổ lá chớp,
nan hoa, con sơn</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,078</td><td>1 tấn</td></tr><tr><td>18</td><td>Lắp các loại cấu kiện bê tông đúc sẵn
bằng thủ công, Pck&lt;=50 Kg</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1</td><td>Cái</td></tr><tr><td>19</td><td>LĐ cấu kiện bê tông đúc sẵn = cần cẩu
Trọng lượng &gt;50Kg</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>12</td><td>1
c/kiện</td></tr><tr><td>20</td><td>Đắp đất công trình bằng đầm cóc Độ chặt
yêu cầu K=0.90</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>10,83</td><td>1 m3</td></tr><tr><td>21</td><td>Vận chuyển đất bằng ô tô tự đổ Cự ly 1km
đầu,ô tô 7T,Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>19,133</td><td>1 m3</td></tr><tr><td>22</td><td>Vận chuyển đất tiếp bằng ô tô tự đổ Cự ly
3km, ô tô 7T, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>19,133</td><td>1 m3</td></tr><tr><td>J</td><td>10- Hạng mục: Mương thoát nước ngoài nhà</td><td></td><td></td><td></td></tr><tr><td>1</td><td>Đào móng mương bằng máy đào &lt;=
0.8m3 Chiều rộng móng &lt;= 6m, Đất cấp
III (90%)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>112,175</td><td>1 m3</td></tr><tr><td>2</td><td>Đào móng mương bằng thủ công có chiều
rộng&lt;=3m Chiều sâu &lt;=1m , Đất cấp III
(10%)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>12,464</td><td>1 m3</td></tr></tbody></table>

|<image_15>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>3</th><th>Bê tông móng chiều rộng R&lt;=250cm Vữa
bê tông đá 2x4M150</th><th>Theo chỉ dẫn kỹ
thuật đính kèm</th><th>11,315</th><th>1 m3</th></tr></thead><tbody><tr><td>4</td><td>Xây tường mương bờ lô 10x20x40 cao
&lt;=4m, vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>33,282</td><td>1 m3</td></tr><tr><td>5</td><td>Ván khuôn xà dầm, giằng</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>77,92</td><td>1 m2</td></tr><tr><td>6</td><td>Gia công cốt thép xà, dầm, giằng Đường
kính cốt thép d&lt;=10 mm</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,055</td><td>Tấn</td></tr><tr><td>7</td><td>Bê tông xà, dầm, giằng nhà Vữa bê tông
đá 1x2 M200</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5,872</td><td>1 m3</td></tr><tr><td>8</td><td>Láng nền, sàn có đánh màu Dày 2 cm ,
Vữa M75#</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>46,88</td><td>1 m2</td></tr><tr><td>9</td><td>Trát tường ngoài, bề dày 1.5 cm Vữa XM</td><td>Theo chỉ dẫn kỹ</td><td>166,663</td><td>1 m2</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td></td><td>M75</td><td>thuật đính kèm</td><td></td><td></td></tr><tr><td>10</td><td>Trát xà giằng hố ga, mương Vữa XM M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>77,92</td><td>1 m2</td></tr><tr><td>11</td><td>Sản xuất cấu kiện bê tông đúc sẵn tấm
đan, mái hắt, lanh tô, vữa M200</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5,648</td><td>1 m3</td></tr><tr><td>12</td><td>Sản xuất, lắp dựng và tháo dỡ ván khuôn
nắp đan, tấm chớp</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>30,496</td><td>1 m2</td></tr><tr><td>13</td><td>Cốt thép tấm đan, hàng rào,cửa sổ lá chớp,
nan hoa, con sơn</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,239</td><td>1 tấn</td></tr><tr><td>14</td><td>LĐ cấu kiện bê tông đúc sẵn = cần cẩu
Trọng lượng &gt;50Kg</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>120</td><td>1
c/kiện</td></tr><tr><td>15</td><td>Đắp đất công trình = đầm đất cầm tay
70kg Độ chặt yêu cầu K=0.90</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>74,17</td><td>1 m3</td></tr><tr><td>16</td><td>Vận chuyển đất bằng ô tô tự đổ Cự ly 1km
đầu,ô tô 7T,Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>57,028</td><td>1 m3</td></tr><tr><td>17</td><td>Vận chuyển đất tiếp bằng ô tô tự đổ Cự ly
3km, ô tô 7T, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>57,028</td><td>1 m3</td></tr><tr><td>18</td><td>Bê tông nền Vữa bê tông đá 2x4M150
(hoàn trả)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>4,32</td><td>1 m3</td></tr><tr><td>19</td><td>Lát gạch sân, nền đường, vỉa hè Gạch
Terazzo 30x30,VM75 (hoàn trả)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>36</td><td>1 m2</td></tr></tbody></table>

|<image_16>|


### BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD626</th></tr></thead><tbody><tr><td></td><td>BẢNG CHI TIẾT HẠNG MỤC XÂY LẮP</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>K</th><th>11- Hạng mục: Sân vườn</th><th></th><th></th><th></th></tr></thead><tbody><tr><td>1</td><td>Đào san đất bằng máy đào &lt;= 1.25m3 Đất
cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>75,2</td><td>1 m3</td></tr><tr><td>2</td><td>Bê tông nền Vữa bê tông đá 2x4M150</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>60,16</td><td>1 m3</td></tr><tr><td>3</td><td>Lát gạch sân, nền đường, vỉa hè Gạch
Terazzo 30x30,VM75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>376</td><td>1 m2</td></tr><tr><td>4</td><td>Vận chuyển đất bằng ô tô tự đổ Cự ly 1km
đầu,ô tô 7T,Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>75,2</td><td>1 m3</td></tr><tr><td>5</td><td>Vận chuyển đất tiếp bằng ô tô tự đổ Cự ly
3km, ô tô 7T, Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>75,2</td><td>1 m3</td></tr><tr><td>6</td><td>Cắt thấp tán, khống chế chiều cao</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cây</td></tr><tr><td>7</td><td>Bứng, di dời, vận chuyển, đào hố, trồng
cây bóng bóng mát (bầu 60x60x60cm)</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>5</td><td>Cây</td></tr><tr><td>8</td><td>Duy trì cây bóng mát mới trồng (12 tháng)</td><td>Theo chỉ dẫn kỹ</td><td>5</td><td>Cây</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Mô tả công việc mời thầu</th><th>Yêu cầu kỹ
thuật/Chỉ dẫn kỹ
thuật chính</th><th>Khối lượng
mời thầu</th><th>Đơn
vị tính</th></tr></thead><tbody><tr><td></td><td></td><td>thuật đính kèm</td><td></td><td></td></tr><tr><td>9</td><td>Đào móng bồn hoa có chiều rộng&lt;=3m
Chiều sâu &lt;=1m , Đất cấp III</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>1,836</td><td>1 m3</td></tr><tr><td>10</td><td>Bê tông đá dăm lót móng, R&lt;=250cm
Vữa bê tông đá 4x6 M100</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,612</td><td>1 m3</td></tr><tr><td>11</td><td>Xây móng đá chẻ (10x20x30) Vữa XM
cát vàng M75</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,408</td><td>1 m3</td></tr><tr><td>12</td><td>Đắp đất công trình bằng đầm cóc Độ chặt
yêu cầu K=0.90</td><td>Theo chỉ dẫn kỹ
thuật đính kèm</td><td>0,612</td><td>1 m3</td></tr></tbody></table>

|<image_17>|


