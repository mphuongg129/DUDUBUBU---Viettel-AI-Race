# Public_441

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>A</td><td>Mô tả chung tính năng kỹ thuật của sản phẩm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Hệ thống Giám sát điều hành dịch vụ khách hàng (vCOC) được xây dựng mục đích giám sát, cảnh báo và điều hành
toàn trình mọi hoạt động xử lý, chăm sóc khách hàng (CSKH) của tất cả các lĩnh vực mà Viettel đang triển khai cho khách
hàng (di động, cố định, SME, VDS…). Luồng điều hành realtime, nhìn toàn trình từ mạng lưới tới các hoạt động thu cước,
CSKH…để nhận diện đúng vấn đề mà Khách hàng (KH) đang gặp phải và đưa ra phương án xử lý phù hợp (thay thế công
tác điều hành đơn lẻ theo nghiệp vụ, offline không có tính tức thời…đang làm thủ công). Hệ thống được xây dựng do Trung
tâm Dịch vụ khách hàng (TT.DVKH-VTT) là đơn vị nghiệp vụ và Trung tâm Phân tích dữ liệu (TT.PTDL-VTT) là đơn vị
phát triển.
Các hình thức sử dụng dịch vụ: truy cập website, chọn các tính năng theo menu được phân quyền trên VSA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>B</td><td>Chỉ tiêu kỹ thuật chi tiết cho Hệ thống giám sát điều hành dịch vụ khách hàng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>I</td><td>Chỉ tiêu tính năng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.1</td><td>Tính phù hợp chức năng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.1.1</td><td>Tính
phù hợp
chức
năng</td><td>Phân hệ điều hành giải
đáp_tỷ lệ kết nối</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm chức năng tỷ
lệ kết nối
B4: Hiển thị thông tin về kết
nối cuộc gọi</td><td>Kiểm tra thông tin kết nối
cuộc gọi hiển thị đầy đủ, phù
hợp với nhu cầu của người
dùng.</td><td>10</td><td></td></tr><tr><td>1.1.2</td><td></td><td>Phân hệ điều hành giải
đáp_nhu cầu khách hàng</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp</td><td>Kiểm tra thông tin nhu cầu
gọi lên của khách hàng hiển
thị đầy đủ, phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th></tr></thead><tbody><tr><td></td></tr><tr><td>1.1.3</td></tr><tr><td>1.1.4</td></tr><tr><td>1.1.5</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td>B3: Chọn nhóm chức năng tỷ
lệ kết nối
B4: Chọn chức năng nhu cầu
B5: Hiển thị thông tin về nhu
cầu giải đáp</td><td></td><td></td><td></td></tr><tr><td>Phân hệ điều hành giải
đáp_lưu lượng theo kênh</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm chức năng
lưu lượng theo kênh
B4: Hiển thị thông tin về lưu
lượng giải đáp theo từng
kênh (Thoại, chat&amp;MXH,
App)</td><td>Kiểm tra thông tin lưu lượng
giải đáp theo từng kênh của
khách hàng hiển thị đầy đủ,
phù hợp với nhu cầu của
người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ điều hành giải
đáp_quân số</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm chức năng
quân số
B4: Hiển thị thông tin về
nhân sự trực (online, thừa,
thiếu)</td><td>Kiểm tra thông tin quân số
trực để điều hành giải đáp
khách hàng hiển thị đầy đủ,
phù hợp với nhu cầu của
người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ điều hành giải
đáp_điều hành quân số</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm chức năng
quân số</td><td>Kiểm tra thông tin agent
available, not available và
quân số cần bổ sung theo
từng nhóm queue và đối tác
hiển thị đầy đủ, phù hợp với
nhu cầu của người dùng.</td><td>10</td><td></td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th></tr></thead><tbody><tr><td></td></tr><tr><td>1.1.6</td></tr><tr><td>1.1.7</td></tr><tr><td>1.1.8</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td>B4: Chọn chức năng điều
hành quân số
B5: Hiển thị thông tin điều
phối nhân sự</td><td></td><td></td><td></td></tr><tr><td>Phân hệ điều hành giải
đáp_phản ánh lặp</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm phản ánh lặp
B4: Hiển thị thông tin về
phản ánh lặp theo từng khung
giờ</td><td>Kiểm tra thông tin phản ánh
lặp theo từng khung giờ hiển
thị đầy đủ, phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ điều hành giải
đáp_tỷ lệ hài lòng dịch vụ</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm tỷ lệ hài lòng
dịch vụ
B4: Hiển thị thông tin về tỷ
lệ hài lòng dịch vụ theo từng
khung giờ
B5: Click vào biểu đồ để xem
chi tiết các cuộc gọi không
hài lòng</td><td>Kiểm tra thông tin tỷ lệ hài
long dịch vụ theo từng khung
giờ hiển thị đầy đủ, phù hợp
với nhu cầu của người dung,
có thể thực hiện nghe lại
cuộc gọi, xem text nội dung
cuộc gọi và callout lại cho
khách hàng hoặc các đầu mối
để xử lý.</td><td>10</td><td></td></tr><tr><td>Phân hệ điều hành giải
đáp_xử lý tại bàn</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng điều
hành giải đáp
B3: Chọn nhóm xử lý tại bàn</td><td>Kiểm tra thông tin tỷ lệ xử lý
tại bàn hiển thị đầy đủ, phù
hợp với nhu cầu của người
dùng.</td><td>10</td><td></td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th></tr></thead><tbody><tr><td></td></tr><tr><td>1.1.9</td></tr><tr><td>1.1.10</td></tr><tr><td>1.1.11</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td>B4: Hiển thị thông tin về tỷ
lệ xử lý tại bàn theo từng
khung giờ</td><td></td><td></td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_tiếp nhận và
xử lý</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm tiếp nhận và
xử lý
B4: Hiển thị thông tin về tỷ
lệ tiếp nhận và xử lý sự cố
theo từng khung giờ
B5: Click xem chi tiết phản
ánh quá hạn</td><td>Kiểm tra thông tin tỷ lệ tiếp
nhận và xử lý sự cố, chi tiết
phản ánh quá hạn đầy đủ,
phù hợp với nhu cầu của
người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_tiến độ xử lý</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm tiếp nhận và
xử lý
B4: Hiển thị thông tin về tiến
độ xử lý theo từng khung giờ
B5: Click xem thống kê chi
tiết theo tỉnh</td><td>Kiểm tra thông tin tiến độ xử
lý theo từng loại phản ánh
hot, vip, thường, khách hang
hẹn và xem thống kê chi tiết
theo tỉnh đầy đủ, phù hợp với
nhu cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_nguy cơ rời
mạng</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm nguy cơ rời
mạng</td><td>Kiểm tra thông tin phản ánh
lặp khách hàng có nguy cơ
rời mạng và thống kê chi tiết
trong vòng 30 ngày đầy đủ,</td><td>10</td><td></td></tr></tbody></table>

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th></tr></thead><tbody><tr><td></td></tr><tr><td>1.1.12</td></tr><tr><td>1.1.13</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td>B4: Hiển thị thông tin về
phản ánh lặp khách hàng có
nguy cơ rời mạng theo từng
khung giờ
B5: Click xem thống kê chi
tiết bảng phản ánh lặp trong
30 ngày</td><td>phù hợp với nhu cầu của
người dùng.</td><td></td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_hài lòng</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm nguy cơ rời
mạng
B4: Hiển thị thông tin về
phản ánh lặp khách hàng có
nguy cơ rời mạng theo từng
khung giờ
B5: Click xem thống kê chi
tiết bảng phản ánh lặp trong
30 ngày</td><td>Kiểm tra thông tin phản ánh
lặp khách hàng có nguy cơ
rời mạng và thống kê chi tiết
trong vòng 30 ngày đầy đủ,
phù hợp với nhu cầu của
người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_tỷ lệ phản
ánh/10k thuê bao</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm tỷ lệ phản
ánh/10k thuê bao
B4: Hiển thị thông tin các
tỉnh không đạt KPI theo ngày
B5: Click xem chi tiết</td><td>Kiểm tra thông tin thông tin
các tỉnh không đạt KPI theo
ngày đầy đủ, phù hợp với
nhu cầu của người dùng.</td><td>10</td><td></td></tr></tbody></table>

|<image_5>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th></tr></thead><tbody><tr><td>1.1.14</td></tr><tr><td>1.1.15</td></tr><tr><td>1.1.16</td></tr><tr><td>1.1.17</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_nguyên nhân
phản ánh</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm nguyên nhân
phản ánh
B4: Hiển thị thông tin các
nguyên nhân chính mà người
dùng phản ánh</td><td>Kiểm tra thông tin nguyên
nhân phản ánh đầy đủ, phù
hợp với nhu cầu của người
dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_tiếp nhận và
xử lý tồn khiếu nại</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm tiếp nhận và
xử lý tồn khiếu nại
B4: Hiển thị thông tin số
lượng phản ánh được tiếp
nhận và tồn theo từng loại
khách hàng</td><td>Kiểm tra thông tin tiếp nhận
và xử lý tồn khiếu nại đầy
đủ, phù hợp với nhu cầu của
người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ xử lý phản ánh
khách hàng_vi phạm trục
lợi cước đóng trước</td><td>O</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng xử lý
phản ánh
B3: Chọn nhóm vi phạm trục
lợi cước đóng trước
B4: Hiển thị thông tin danh
sách vi phạm trục lợi cước
đóng trước</td><td>Kiểm tra thông tin danh sách
vi phạm trục lợi cước đóng
trước đầy đủ, phù hợp với
nhu cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>Phân hệ giám sát chất
lượng mạng toàn mạng</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống</td><td>Kiểm tra thông tin về số
lượng thuê bao tỷ lệ tồi , tỷ lệ</td><td>10</td><td></td></tr></tbody></table>

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th></tr></thead><tbody><tr><td></td></tr><tr><td>1.1.18</td></tr><tr><td>1.1.19</td></tr><tr><td>1.1.20</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td>B2: Chọn chức năng giám sát
chất lượng mạng chủ động
toàn mạng
B3: Chọn chức giám sát chất
lượng mạng theo tỉnh, huyện,
xã, trạm
B4: Hiển thị thông tin số
lượng thuê bao tồi, tỷ lệ tồi</td><td>tồi, danh sách các tỉnh, trạm,
huyện toàn mạng</td><td></td><td></td></tr><tr><td>Phân hệ giám sát chất
lượng dịch vụ thoại</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng giám sát
chất lượng mạng chủ động
dịch vụ thoại
B3: Chọn chức giám sát chất
lượng mạng theo tỉnh, huyện,
xã, trạm
B4: Hiển thị thông tin số
lượng thuê bao tồi, tỷ lệ tồi</td><td>Kiểm tra thông tin toàng
mạng về số lượng thuê bao
tỷ lệ tồi , tỷ lệ tồi, danh sách
các tỉnh, trạm, huyện cho
dịch vụ thoại</td><td>10</td><td></td></tr><tr><td>Phân hệ giám sát chất
lượng dịch vụ data</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng giám sát
chất lượng mạng chủ động
dịch vụ data
B3: Chọn chức giám sát chất
lượng mạng theo tỉnh, huyện,
xã, trạm
B4: Hiển thị thông tin số
lượng thuê bao tồi, tỷ lệ tồi</td><td>Kiểm tra thông tin toàng
mạng về số lượng thuê bao tỷ
lệ tồi , tỷ lệ tồi, danh sách các
tỉnh, trạm, huyện cho dịch vụ
data</td><td>10</td><td></td></tr><tr><td>Phân hệ Dashboard điều
hành giải đáp CĐBR</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám</td><td>Kiểm tra thông tin các
Dashboard điều hành giải đáp</td><td>10</td><td></td></tr></tbody></table>

|<image_7>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>sát điều hành
B3: Chọn cụm màn hình
TV1-4
B4: Hiển thị thông tin
Dashboard điều hành giải đáp
CĐBR</td><td>CĐBR hiển thị đầy đủ,đúng
số liệu và phù hợp với nhu
cầu của người dùng.</td><td></td><td></td></tr><tr><td>1.1.21</td><td></td><td>Phân hệ Dashboard điều
hành giải đáp Di Động</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình
dhgd-dd
B4: Hiển thị thông tin
Dashboard điều hành giải đáp
CĐBR</td><td>Kiểm tra thông tin các
Dashboard điều hành giải đáp
CĐBR hiển thị đầy đủ,đúng
số liệu và phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>1.1.22</td><td></td><td>Phân hệ Dashboard điều
hành giải đáp SME</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình
dhgd-sme
B4: Hiển thị thông tin
Dashboard điều hành giải đáp
CĐBR</td><td>Kiểm tra thông tin các
Dashboard điều hành giải đáp
CĐBR hiển thị đầy đủ,đúng
số liệu và phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>1.1.23</td><td></td><td>Phân hệ Dashboard điều
hành giải đáp 1789</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình
dhgd-1789
B4: Hiển thị thông tin</td><td>Kiểm tra thông tin các
Dashboard điều hành giải đáp
CĐBR hiển thị đầy đủ,đúng
số liệu và phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr></tbody></table>

|<image_8>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>Dashboard điều hành giải đáp
CĐBR</td><td></td><td></td><td></td></tr><tr><td>1.1.24</td><td></td><td>Phân hệ Dashboard điều
hành giải đáp VTS - VDS</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình
dhgd-vts-vds
B4: Hiển thị thông tin
Dashboard điều hành giải đáp
CĐBR</td><td>Kiểm tra thông tin các
Dashboard điều hành giải đáp
CĐBR hiển thị đầy đủ,đúng
số liệu và phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>1.1.25</td><td></td><td>Phân hệ Dashboard điều
hành giải đáp VHT</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình
dhgd_vht
B4: Hiển thị thông tin
Dashboard điều hành giải đáp
CĐBR</td><td>Kiểm tra thông tin các
Dashboard điều hành giải đáp
CĐBR hiển thị đầy đủ,đúng
số liệu và phù hợp với nhu
cầu của người dùng.</td><td>10</td><td></td></tr><tr><td>1.1.26</td><td></td><td>Phân hệ Dashboard màn
hình chính</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình mhc
B4: Hiển thị thông tin các chỉ
số chung điều hành giải đáp,
xử lý phản ánh, giám sát chất
lượng, chăm sóc khách hàng
và hiển thị từng chỉ số qua
chu kỳ tháng và chu kỳ ngày</td><td>Kiểm tra thông tin các chỉ số
KPI chính hiển thị đầy
đủ,đúng số liệu và phù hợp
với nhu cầu của người dùng.</td><td>10</td><td></td></tr></tbody></table>

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>1.1.27</td><td></td><td>Phân hệ Dashboard thu
thập thông tin</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình tttt
B4: Hiển thị thông tin
Dashboard thu thập thông tin</td><td>Kiểm tra thông tin các nghiệp
vụ thu thập thông tin hiển thị
đầy đủ,đúng số liệu và phù
hợp với nhu cầu của người
dùng.</td><td>10</td><td></td></tr><tr><td>1.1.28</td><td></td><td>Phân hệ Dashboard bảo
hành</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình bh
B4: Hiển thị thông tin liên
quan tới bảo hành: hợp đồng
có chủng loại thiết bị vượt
KPI lỗi, tỷ lệ lỗi</td><td>Kiểm tra thông tin các chỉ số
liên quan tới nghiệp vụ Bảo
hành hiển thị đầy đủ,đúng số
liệu và phù hợp với nhu cầu
của người dùng.</td><td>10</td><td></td></tr><tr><td>1.1.29</td><td></td><td>Phân hệ Dashboard Chăm
sóc khách hàng</td><td>M</td><td></td><td>B1: Đăng nhập hệ thống
B2: Chọn chức năng Giám
sát điều hành
B3: Chọn cụm màn hình cskh
B4: Hiển thị thông tin
Dashboard Chăm sóc khách
hàng</td><td>Kiểm tra thông tin các nghiệp
vụ chăm sóc khách hàng hiển
thị đầy đủ,đúng số liệu và phù
hợp với nhu cầu của người
dùng.</td><td>10</td><td></td></tr><tr><td>1.2</td><td>Tính chính xác</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.2.1</td><td></td><td>Các thông tin của chỉ tiêu
được lấy chính xác: thực
hiện, cùng kỳ, lũy kế bằng
với dữ liệu của nguồn cung
cấp</td><td>M</td><td></td><td>-B1: Truy cập vào chức năng
hiển thỉ chỉ tiêu về công tác
chăm sóc khách hàng
-B2: Click vào từng nhóm chức
năng</td><td>Kiểm tra các thông tin hiển thị
đúng với thực tế</td><td>10</td><td></td></tr></tbody></table>

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>-B3: Xem thông tin nội dung chỉ
tiêu</td><td></td><td></td><td></td></tr><tr><td>1.2.2</td><td></td><td>Thông tin SMS/Email gửi tự
động chính xác</td><td>M</td><td></td><td>Kiểm tra nội dung SMS/Email
trong CSDL được gửi cho
người dùng được cấu hình</td><td>Đầu mối nhận tin nhắn, email
nội dung đúng với thực tế được
cấu hình</td><td>10</td><td></td></tr><tr><td>1.2.3</td><td></td><td>Tính chính xác các thông tin
đầu mối callout/sms/email
thủ công</td><td>M</td><td></td><td>-B1: Truy cập vào chức năng
hiển thỉ chỉ tiêu về công tác
chăm sóc khách hàng
-B2: Click vào từng nhóm chức
năng
-B3: Truy cập vào chức năng
callout/sms/email bằng tay
-B5: Nhập thông tin người được
call/sms/email</td><td>Đầu mối nhận cuộc gọi, tin
nhắn, nội dung email đúng đầu
mối và đúng nội dung được
nhập thủ công</td><td>10</td><td></td></tr><tr><td>1.3</td><td>Khả năng tương tác</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.3.1</td><td></td><td>- Hệ thống có tương tác
với các hệ thống khác
như VSA admin,
Passport, IPCC, BCCS,
Data lake…
- Phương thức trao đổi,
tương tác với các hệ
thống khác thông qua
tương tác với các
webservice có sẵn</td><td>M</td><td></td><td>Kiểm tra khi các module
service khi giao tiếp và thực
thi thì có xác thực không.
Kiểm tra khi trace log và xử
lý sử cố khác nhau giữa hai
hệ thống thì có log không.
Lịch sử giao dịch giữa các hệ
thống có thể kiểm tra lại
không.</td><td>Nhiều module/service khi
kết nối đến đều phải có xác
thực khi giao tiếp và gửi lệnh
thực thi.
Thực hiện được đối soát,
trace log và xử lý sự cố giữa
hai hệ thống khác nhau.
Thường xuyên yêu cầu các
đơn vị tương tác bổ sung mã
lỗi mới, mã lệnh mới vào file
xử lý
Lưu lịch sử giao dịch vào
DB, người dùng có thể tìm</td><td>1</td><td></td></tr></tbody></table>

|<image_11>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>được nội dung request và
response của từng giao dịch</td><td></td><td></td></tr><tr><td>1.3.2</td><td></td><td>Các giao tiếp với các hệ
thống bên ngoài phải
tuân theo chuẩn thế giới:
SOAP v1.1, v1.2;
RESTful; XML version
1.0, 1.1, 2.0; FTP</td><td>M</td><td></td><td></td><td></td><td>1</td><td></td></tr><tr><td>1.4</td><td>Tính bảo mật</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.4.1</td><td>Quản lý
xác thực</td><td>Đáp ứng các yêu cầu xác
thực, phân quyền: Đáp
ứng cơ chế xác thực
VSA/Passport, phân
quyền theo chức năng,
theo component, theo dữ
liệu nhạy cảm.</td><td>M</td><td></td><td>Kiểm tra source code theo tiêu
chuẩn quy định</td><td>Source code đảm bảo an toàn
thông tin theo tiêu chuẩn</td><td>1</td><td></td></tr><tr><td>1.4.2</td><td>ATTT
ứng
dụng
web</td><td>Tuân thủ theo tiêu chuẩn
ATTT cho lập trình ứng
dụng web của Tập đoàn
TC.CNVTQĐ.CNTT.16.1
0</td><td>M</td><td></td><td>Kiểm tra source code theo
tiêu chuẩn quy định</td><td>Source code đảm bảo an toàn
thông tin theo tiêu chuẩn</td><td>1</td><td></td></tr><tr><td>1.4.3</td><td>Mã hóa</td><td>Hỗ trợ tùy chọn mã hóa
thông tin user/password
truy cập Database, File
server.</td><td>M</td><td></td><td>Kiểm tra source code theo
tiêu chuẩn quy định</td><td>Source code đảm bảo an toàn
thông tin theo tiêu chuẩn</td><td>1</td><td></td></tr></tbody></table>

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>1.4.4</td><td>ATTT
Webserv
er</td><td>Tuân thủ theo tiêu chuẩn
ATTT cho webserver của
Tập đoàn
TC.CNVTQĐ.CNTT.17.1
6</td><td>M</td><td></td><td>Kiểm tra source code theo
tiêu chuẩn quy định</td><td>Source code đảm bảo an toàn
thông tin theo tiêu chuẩn</td><td>1</td><td></td></tr><tr><td>1.4.5</td><td>ATTT
Cơ sở
dữ liệu</td><td>Tuân thủ theo tiêu chuẩn
ATTT cho hệ quản trị
CSDL của Tập đoàn
TC.CNVTQĐ.CNTT.18.1
2</td><td>M</td><td></td><td>Kiểm tra source code theo
tiêu chuẩn quy định</td><td>Source code đảm bảo an toàn
thông tin theo tiêu chuẩn</td><td>1</td><td></td></tr><tr><td>II</td><td>Chỉ tiêu phi chức năng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.1</td><td>Kiến trúc và công nghệ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.1.1</td><td>Kiến
trúc hệ
thống</td><td>Hệ thống có tài liệu
HSKT (profile)</td><td>M</td><td></td><td>- Mô tả chức năng của các
thành phần
- Mô tả các giao thức kết nối</td><td></td><td>1</td><td></td></tr><tr><td>2.1.2</td><td></td><td>Hệ thống được phân chia
thành nhiều module xử lý
độc lập</td><td>M</td><td></td><td>- Review tài liệu thiết kế
profile hệ thống, sizing.
- Kiểm tra mô hình triên khai
thực tế.</td><td>Kiến trúc hệ thống có tính độc
lập và khả năng chịu lỗi cao</td><td>1</td><td></td></tr><tr><td>2.1.3</td><td></td><td>Hệ thống có sử dụng thiết
bị phân tải Load Balancer
(LB) để thực hiện phân tải
và kiểm soát các ứng
dụng, module có sống hay
chết để quyết định việc đổ
request vào.</td><td>M</td><td></td><td>Thực hiện tắt tiến trình, công
cụ giám sát sẽ phát hiện tiến
trình bị chết, công cụ sẽ tự
động khởi động lại tiến trình
đã tắt.</td><td>Hiện tại các tiến trình được
theo dõi bằng công cụ giám
sát tiến trình tự động, tự động
được khởi động lại tiến trình
nếu gặp sự cố.</td><td>1</td><td></td></tr></tbody></table>

|<image_13>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>2.1.4</td><td>Kiến
trúc lập
trình</td><td>Được chia thành 2 lớp</td><td>M</td><td></td><td>Thực hiện review source
code để xem xét kiến trúc hệ
thống</td><td>Lớp service và lớp
application hoạt động riêng
biệt</td><td>1</td><td></td></tr><tr><td>2.1.5</td><td>Công
nghệ áp
dụng</td><td>Hệ thống thực hiện các
lớp service để tăng khả
năng mở rộng, linh động</td><td>M</td><td></td><td>Review các lớp service</td><td>Các lớp service hoạt động
hiệu quả và chính xác</td><td>1</td><td></td></tr><tr><td>2.1.6</td><td></td><td>Thực hiện cài đặt partition
và index trên DB Maria để
giảm thời gian truy cập dữ
liệu</td><td>M</td><td></td><td>Review phiên bản MariaDB,
các bảng dữ liệu lớn trên DB</td><td>Phiên bản Maria có khả năng
đảm bảo chống lỗi. Các bản
dữ liệu lớn được cài đặt
partition và index để làm
tăng hiệu năng truy cập dữ
liệu</td><td>1</td><td></td></tr><tr><td>2.1.7</td><td></td><td>Có cơ chế in memory cho
các dữ liệu thường xuyên
được sử dụng và đáp ứng
xử lý thời gian thực</td><td>M</td><td></td><td>Thực hiện review source
code</td><td></td><td>1</td><td></td></tr><tr><td>2.1.8</td><td></td><td>Hệ thống chạy được trên
nền tảng cloud</td><td>M</td><td></td><td></td><td></td><td>1</td><td></td></tr><tr><td>2.1.9</td><td></td><td>Hệ thống hỗ trợ sử dụng
CSDL mã nguồn mở</td><td>M</td><td></td><td></td><td></td><td>1</td><td></td></tr></tbody></table>

|<image_14>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>2.2</td><td>Tính tin cậy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.2.1</td><td>Tính tin
cậy</td><td>Cho phép cấu hình ngưỡng
kiểm soát được TPS của
các Service</td><td>M</td><td></td><td>Thực hiện review source code</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>Hệ thống có cơ chế
timeout. Những yêu cầu
quá thời gian timeout thì
giải phóng, reject những
yêu cầu vượt quá khả năng
tiếp nhận</td><td>M</td><td></td><td>Thực hiện review source code</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>Có cơ chế tự bảo vệ và tự
động từ chối tiếp nhận
thêm các giao dịch nếu
vượt quá ngưỡng theo từng
module như cho phép giới
hạn khả năng xử lý của ứng
dụng, số lượng yêu cầu xử
lý được trong 1 khoảng
thời gian. Đảm bảo mỗi
lượt retry được chuyển
hướng tới node xử lý khác
với node đang cao tải</td><td>M</td><td></td><td>Thực hiện review source code</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>-Có xử lý timeout: Khi
người dùng đăng nhập vào
hệ thống bằng trình duyệt
hoặc ứng dụng thì sau một
khoảng thời gian nhất</td><td>M</td><td></td><td>Không tác động vào hệ thống
trong vòng tối thiểu 30 phút</td><td>Hệ thống yêu cầu người dùng
đăng nhập lại để vào hệ thống</td><td>1</td><td></td></tr></tbody></table>

|<image_15>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>định hệ thống sẽ tự động
logout tài khoản và bắt
buộc người dùng phải
đăng nhập lại để sử dụng.
- Có cơ chế cô lập các
dịch vụ đang bị lỗi khi
giao tiếp với các hệ thống
khác, không làm gián
đ oạn 100% dịch vụ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Có giải pháp đảm bảo tài
nguyên dùng chung không
bị xung đột: Connection:
DB connection, FTP
connection, File hander,
Socket connection
(WS,…)</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>Đảm bảo cơ chế dự phòng
toàn bộ hệ thống theo quy
định của tập đoàn. Các cơ
chế dự phòng Active-
Standby trở lên đều có cơ
chế lật mặt tự động khi
phát hiện lỗi. Các thiết bị,
kết nối đảm bảo dự phòng
1+1 về dung lượng</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>Hệ thống tự động phát
hiện và điều tiết lưu lượng</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr></tbody></table>

|<image_16>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>thông qua bộ cân bằng tải/
Load balancer</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Giới hạn số lượt retry
được phép thực hiện theo
- Tính trên request. Ví dụ:
tối đa 1 request được retry
3 lần
- Tính trên client. Ví dụ:
một client được phép retry
tối đã 10% số lượng
request
- Giám sát số lần retry trên
từng tác vụ, khi số lượng
retry tăng đến một ngưỡng</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>Hệ thống cung cấp khả
năng từ chối yêu cầu theo
ngưỡng phản hồi trên
client</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>Các ứng dụng, CSDL có
sự phân cách sử dụng tài
nguyên.</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>Hệ thống có giải pháp
tránh xung đột tài nguyên
dùng chung giữa các tiến
trình</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>Hệ thống có thiết lập các
tham số giới hạn dung</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr></tbody></table>

|<image_17>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>lượng log tạo ra trên mỗi
hệ thống nhằm hạn chế
hiện tượng quá tải lưu trữ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ thống có cơ chế giám
sát, cảnh báo trong các
tình huống khi vượt
ngưỡng, khi có lỗi xảy ra</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>2.2.3</td><td>Khả
năng
phục
hồi</td><td>Khi phát hiện tiến trình
treo/chậm/cao tải, cho
phép cấu hình thực hiện
hành động: Restart tiến
trình</td><td>M</td><td></td><td>Thực hiện tắt tiến trình, công
cụ giám sát sẽ phát hiện tiến
trình bị chết, công cụ sẽ tự
động khởi động lại tiến trình
đã tắt.</td><td>Hiện tại các tiến trình được
theo dõi bằng công cụ giám
sát tiến trình tự động, tự động
được khởi động lại tiến trình
nếu gặp sự cố.</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Khả năng sao lưu dữ liệu</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>Có khả năng chạy lại tiến
trình lỗi</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>Cho phép khôi phục dữ
liệu từ các bản sao lưu gần
nhất.</td><td>M</td><td></td><td>Kiểm tra thực tế triển khai hệ
thống.</td><td></td><td>1</td><td></td></tr><tr><td>2.3</td><td>Tính khả dụng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.3.1</td><td>Tính dễ
hiểu/ dễ
học</td><td>Giao diện thiết kế phải
nhất quán.</td><td>M</td><td></td><td>Đáp ứng theo các tiêu chí
trong quy định về UI/UX của
Viettel có mã văn bản
290/QĐ-VITM-UIUX</td><td>Lập testcase kiểm tra</td><td>1</td><td></td></tr></tbody></table>

|<image_18>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>Có giám sát và cảnh báo tự
động đối với các chỉ tiêu về
vận hành: treo, quá tải, thời
gian đáp ứng vượt ngưỡng.</td><td>M</td><td></td><td>- Kiểm tra cấu hình hệ thống
đặt cảnh báo giám sát
- Hệ thống quá tải khi vượt
ngưỡng</td><td>- Đã cấu hình công cụ
- Xuất hiện cảnh báo khi quá
tải</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Giám sát được mức ứng
dụng: Trạng thái tiến trình,
thời gian xử lý,…</td><td>M</td><td></td><td>Đo bằng cách đánh giá của
chuyên gia
Kiểm tra hệ thống triển khai</td><td>Theo quy định của Tập đoàn</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Tích hợp hệ thống lên hệ
thống NetKPI phục vụ việc
theo dõi giám sát toàn bộ
KPI cho các giao dịch
chính của ứng dụng thể
hiện được ngưỡng trên
dưới và cảnh báo khi KPI
sụt giảm hoặc tăng vọt so
với ngưỡng, có các báo cáo
KPI phân tích xu thế chất
lượng hệ thống để cảnh
báo sớm.</td><td>M</td><td></td><td>Kiểm tra hệ thống triển khai</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>Quản lý lỗi/cảnh báo/log:
Toàn bộ các cảnh
báo/lỗi/log được phân
loại/lọc để dễ dàng theo
dõi.</td><td>M</td><td></td><td>Đo bằng cách đánh giá của
chuyên gia
Kiểm tra hệ thống triển khai</td><td>Theo quy định của Tập đoàn</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Quản lý lỗi/cảnh báo/log:
Các cảnh báo được cung
cấp với độ trễ &lt;3 phút. Hỗ
trợ cảnh báo bằng sms</td><td>M</td><td></td><td>Đo bằng cách đánh giá của
chuyên gia
Kiểm tra hệ thống triển khai</td><td>Theo quy định của Tập đoàn</td><td>1</td><td></td></tr></tbody></table>

|<image_19>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>Quản lý lỗi/cảnh báo/log:
Lưu log hệ thống, tiến trình
và log tác động của người
dùng</td><td>M</td><td></td><td>Đo bằng cách đánh giá của
chuyên gia
Kiểm tra hệ thống triển khai</td><td>Theo quy định của Tập đoàn</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Quản lý tập trung cho việc
thực hiện toàn bộ các công
việc cấu hình, tác động hệ
thống bao gồm: Start, stop
tiến trình, cấu hình tham số
tiến tình, ứng dụng.</td><td>M</td><td></td><td>Đo bằng cách đánh giá của
chuyên gia
Kiểm tra hệ thống triển khai</td><td>Theo quy định của Tập đoàn</td><td>1</td><td></td></tr><tr><td>2.3.3</td><td>Khả
năng
hạn chế
lỗi
người
dùng</td><td>Có tính năng kiểm tra dữ
liệu, cung cấp các ràng
buộc để người dùng không
thể lựa chọn sai
Hỗ trợ cảnh báo thời gian
thực (vd: kiểm tra trùng
thông tin)
Tuân thủ theo các thông lệ
Có tính năng xác nhận đối
với các tác vụ quan trọng,
đảm bảo người dùng hiểu
đúng trước khi thực hiện.</td><td>M</td><td></td><td>Kiểm tra thực tế chức năng
hệ thống</td><td>Theo quy định của Tập đoàn</td><td>1</td><td></td></tr><tr><td>2.4</td><td>Tính hiệu quả</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>M</td><td></td><td>- Đăng nhập vào hệ thống
- Vào lần lượt các chức năng</td><td></td><td>5</td><td></td></tr></tbody></table>

|<image_20>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung
Thời
gian xử
lý</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>Các chức năng thông
thường &lt; 15s</td><td>M</td><td></td><td>- Kiểm tra lần lượt chức năng
với các trường hợp:
+ 5000 CCU, RAM &lt;=90%,
CPU &lt;=70
+ 10000 CCU, RAM &lt;=90%,
CPU &lt;=70
+ 15000 CCU, RAM &lt;=90%,
CPU &lt;=70
+ 20000 CCU, RAM &lt;=90%,
CPU &lt;=70</td><td>- Thời gian đánh giá là thời
gian tính trung bình tất cả
các lần đo.</td><td></td><td></td></tr><tr><td></td><td></td><td>Các chức năng truy cập dữ
liệu lớn &lt; 60s</td><td>M</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Các chức năng giao tiếp
và gửi file đến các API
bên ngoài &lt; 3 mins</td><td>M</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.4.2</td><td>Sử dụng
tài
nguyên</td><td>Máy chủ ứng dụng :
CPU trung bình &lt;=75%,
RAM &lt;= 90%
Tải ổ cứng &lt; 80%</td><td>M</td><td></td><td>Kiểm tra Log hệ thống của
đơn vị vận hành</td><td>Đúng theo chỉ tiêu</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Máy chủ CSDL :
Dung lượng sử dụng và
hiệu năng thiết bị &lt; 80%
Riêng Máy chủ CSDL
Redis hiệu năng sử dụng
RAM &lt;=30%</td><td>M</td><td></td><td>Kiểm tra Log hệ thống của
đơn vị vận hành</td><td>Đúng theo chỉ tiêu</td><td>1</td><td></td></tr><tr><td>2.4.3</td><td>Khả
năng
đáp ứng</td><td>Số lượng người dùng tối
đa: 15.000</td><td>M</td><td></td><td>- Kiểm tra theo log hệ thống
do Trung tâm công nghệ và
quản lý chất lượng cung cấp
(số lượng truy cập, số lượng
người dùng tối đa)</td><td>Kết quả theo đúng chỉ tiêu kỹ
thuật đặt ra.</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Tổng số người dùng cấp
quản lý đồng thời tại một</td><td></td><td></td><td>- Kiểm tra theo log hệ thống
do Trung tâm công nghệ và
quản lý chất lượng cung cấp</td><td>- Thời gian đăng nhập &lt; 5s
- Số lượng đăng nhập không
thành công &lt; 5% (% CCU</td><td>1</td><td></td></tr></tbody></table>

|<image_21>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>thời điểm tối đa
(concurrent user): 1045</td><td></td><td></td><td>(số lượng truy cập, số lượng
người dùng tối đa)</td><td>đăng nhập không thành
công)
- RAM đáp ứng: 90%, Redis
&lt;=30%
- CPU: 75%</td><td></td><td></td></tr><tr><td>2.5</td><td>Khả năng bảo trì</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.5 .1</td><td>Khả
năng
phân
tích</td><td>Ghi log theo quy định của
Tập đoàn. Đảm bảo ghi
log theo đúng cấu trúc,
theo từng mức, log được
ghi trên tất cả các Module
của hệ thống, đẩy log lên
hệ thống lưu trữ log tập
trung</td><td>M</td><td></td><td>Kiểm tra source code</td><td>Đã được ghi log trên tất cả
các chức năng có sự thay đổi
dữ liệu trên hệ thống. Đã đẩy
log lên hệ thống lưu trữ log
tập trung</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Có module tập trung để
quản trị, khai báo các thay
đổi trong hệ thống</td><td>M</td><td></td><td>Kiểm tra thực tế chức năng
hệ thống</td><td></td><td>1</td><td></td></tr><tr><td></td><td></td><td>Đối với từng Module
trong hệ thống, giám sát
online được các thông số
tại từng thời điểm: số
lượng giao dịch tải đầu
vào/khả năng đáp ứng,
thời gian xử lý từng giao
dịch/KPI cho phép, tổng
số giao dịch xử lý lỗi/tổng
giao dịch vào, tổng số</td><td>M</td><td></td><td>Kiểm tra thực tế chức năng
hệ thống</td><td></td><td>1</td><td></td></tr></tbody></table>

|<image_22>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>giao dịch xử lý thành
công/tổng giao dịch vào</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.5.2</td><td>Khả
năng
thay đổi
được</td><td>Quản trị hệ thống có thể
thay đổi được các tham số
nghiệp vụ hệ thống,
ngưỡng đáp ứng của hệ
thống, đa ngôn ngữ, tiền
tệ</td><td>M</td><td></td><td>Kiểm tra thực tế chức năng
hệ thống</td><td>Đúng theo chỉ tiêu</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Hệ thống tích hợp với một
số hệ thống giám sát, quản
lý tập trung của VTNet
như AOM, MM, IIM</td><td>M</td><td></td><td>Kiểm tra hệ thống triển khai</td><td>Đúng theo chỉ tiêu</td><td>1</td><td></td></tr><tr><td>2.6</td><td>Tính khả chuyển</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.6.1</td><td>Khả
năng
tương
thích</td><td>+ Hệ thống hỗ trợ đa ngôn
ngữ
+ Hệ thống hỗ trợ các loại
trình duyệt phổ biến
+ Hệ thống hỗ trợ đa hệ
điều hành bao gồm tối
thiểu: Windows/ViettelOS
+ Hệ thống hỗ trợ sử dụng
trên các nền tảng Android,
iOS
+ Hệ thống hỗ trợ phiên
bản mới của hệ điều hành
mobile</td><td>M</td><td></td><td>Kiểm tra hệ thống triển khai</td><td>Đúng theo chỉ tiêu</td><td>1</td><td></td></tr></tbody></table>

|<image_23>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>+ Hệ thống Website thiết
kế tương thích đa thiết bị
(PC, Tablet, Mobile...)</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.6.2</td><td>Khả
năng cài
đặt
phần
mềm</td><td>+ Hệ thống được thiết kế
để dễ dàng cài đặt, cập
nhật phần mềm khi có
thay đổi
+ Có đầy đủ các tài liệu
HDCĐ, Sizing, HSTK</td><td>M</td><td></td><td>Kiểm tra tài liệu và thực hiện
cài đặt mới theo tài liệu</td><td>Hệ thống cài đặt và hoạt
động được bình thường.</td><td>1</td><td></td></tr><tr><td>2.7</td><td>Tính bảo mật</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.7.1</td><td>ATTT</td><td>Đảm bảo tính bảo mật liên
quan đến mức mã nguồn,
hạ tầng, hệ Quản trị CSDL</td><td>M</td><td></td><td></td><td></td><td>1</td><td></td></tr><tr><td>III</td><td>Chỉ tiêu về quản trị dữ liệu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.1</td><td>Quản trị
dữ liệu</td><td>Xác định dữ liệu trọng
yếu và chủ sở hữu của dữ
liệu</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Đảm bảo dữ liệu được
phân cấp bảo mật</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Đảm bảo dữ liệu được
phân loại theo danh mục
dữ liệu</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr></tbody></table>

|<image_24>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>Đảm bảo dữ liệu được
phân quyền theo vai trò</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Đảm bảo dữ liệu được mã
hóa theo phân cấp bảo mật</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Ghi log các luồng chia sẻ
dữ liệu: nguồn, đích, thời
gian, tần suất, hình thức
chia sẻ, phân cách nhau
bởi dấu '|', mỗi phiên một
dòng</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Ghi log tác động truy cập
dữ liệu gồm thông tin IP,
tài khoản, thời gian, dữ
liệu truy cập, phân cách
nhau bởi dấu '|', mỗi phiên
một dòng</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Ghi log và có cảnh báo
giao dịch bất thường: số
lượng tài khoản truy cập
dữ liệu vượt ngưỡng, số
lượng giao dịch biến động
bất thường…</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Toàn vẹn dữ liệu</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr></tbody></table>

|<image_25>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>Dữ liệu thỏa mãn theo
logic tính toán trong cùng
bảng</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Dữ liệu thỏa mãn theo
logic tính toán khác bảng</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Đảm dữ liệu luôn đầy đủ,
không có giá trị null</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Dữ liệu nhất quán ở các
bảng khác nhau</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Dữ liệu nhất quán trong
cùng 01 bản ghi</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Dữ liệu nhất quán giữa
các bản ghi khác nhau
trong cùng bảng</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Xu hướng dữ liệu nhóm
đối tượng nhất quán theo
thời gian</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Xu hướng dữ liệu cả
dataset nhất quán theo
thời gian</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Thời gian có dữ liệu trong
bảng đúng thời gian quy
định</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr></tbody></table>

|<image_26>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td>Thời gian có dữ liệu trong
bảng đúng thời gian quy
định theo từng nhóm đối
tượng</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Thời gian của bảng phải
thỏa mãn thời gian quy
định trong 1 khoảng thời
gian so với bảng nguồn</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Không có bản ghi trùng
khóa chính trong dataset</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Loại dữ liệu của các
trường phải hợp lệ</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Format định dạng của
trường dữ liệu phải hợp lệ</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Format định dạng của
trường dữ liệu phải tuân
theo theo format định
dạng của một trường dữ
liệu khác</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>Giá trị trường dữ liệu nằm
trong phạm vi hợp lệ</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr></tbody></table>

|<image_27>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>Giá trị trường dữ liệu nằm
trong phạm vi hợp lệ của
trường dữ liệu khác, trong
cùng bảng dữ liệu</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Giá trị trường dữ liệu nằm
trong phạm vi hợp lệ của
trường dữ liệu khác, trong
các bảng dữ liệu khác
nhau</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Xây dựng kho lưu trữ dữ
liệu trọng yếu gồm 2 chức
năng:
- Bảng thuật ngữ nghiệp
vụ
- Từ điển dữ liệu</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Kho siêu dữ liệu của đơn
vị có thể lựa chọn các kiến
trúc:
- Kiến trúc tập trung
- Kiến trúc phân tán
- Kiến trúc hỗn hợp
- Kiến trúc hai chiều</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Phải đảm bảo lưu trữ đủ
các thuộc tính: Thông tin
đối tượng dữ liệu, Thông
tin hệ thống, Thông tin
luồng dữ liệu, Thông tin
thuật ngữ nghiệp vụ</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr></tbody></table>

|<image_28>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>Phải có quy tắc đặt tên
(ứng với các hệ thống tập
trung &amp; các hệ thống phát
triển mới), việc đặt tên
phải tuân theo quy tắc đặt
tên</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Định nghĩa dữ liệu phải
được đặt theo tiêu chuẩn</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Database chạy cơ chế dự
phòng active-active, ứng
dụng kết nối đảm bảo khả
năng load balance và fail-
over trên database</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Thực hiện backup hàng
ngày, lưu tối thiểu 03
bản/03 ngày
Bản backup phải lưu ở
disk group khác hoặc lưu
ở FTP, hay server khác</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Với các hệ thống DBQT,
RQT: phải có DB DR. DB
DR phải đặt ở site khác
với site của DB chạy
chính</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Các tablespace lớn, lưu dữ
liệu log phải chia partition
và tự động truncate dữ</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr></tbody></table>

|<image_29>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD441</th></tr></thead><tbody><tr><td></td><td>BỘ CHỈ TIÊU KỸ THUẬT CHO HỆ THỐNG vCOC</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>TT</th><th>Nội
dung</th><th>Chỉ tiêu kỹ thuật</th><th>Loại yêu
cầu
(M-Bắt
buộc/ O-
Tùy chọn)</th><th>Chuẩn
tham
chiếu
(nếu có)</th><th>Bài đo</th><th></th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Bước thực hiện</td><td>Kết quả mong muốn</td><td>Số
lần
đo</td><td>Môi trường</td></tr><tr><td></td><td></td><td>liệu cũ (xoay vòng dữ
liệu)</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Định dạng tên partition
đối với các bảng đánh
partition theo thời gian
DATAyyyy,
DATAyyyymm hoặc
DATAyyyymmdd tùy
theo loại partition theo
năm, tháng hay ngày</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td></td><td></td><td>Drop tất cẩ các bảng
không sử dụng, các bảng
của user cá nhân cần đặt</td><td>M</td><td></td><td>Lập KBKT kiểm tra theo
QT.00.CNTT.28 hoặc bộ kịch
bản kiểm thử nghiệm thu</td><td>Theo kết quả mong muốn
trong KBKT</td><td>1</td><td></td></tr><tr><td>IV</td><td>Chỉ tiêu về cam kết, dịch vụ và các yêu cầu khác</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.1</td><td>Yêu cầu
tài liệu</td><td>Tài liệu về vận hành, khai
thác hệ thống</td><td>M</td><td></td><td>Kiểm tra chi tiết tài liệu</td><td>Tài liệu đầy đủ các bước
thực hiện</td><td></td><td></td></tr><tr><td>4.2</td><td></td><td>Tài liệu hướng dẫn sử
dụng</td><td>M</td><td></td><td>Kiểm tra chi tiết tài liệu</td><td>Tài liệu đầy đủ các bước
thực hiện</td><td></td><td></td></tr><tr><td>4.3</td><td></td><td>Tài liệu về khắc phục, xử lý
sự cố hệ thống</td><td>M</td><td></td><td>Kiểm tra chi tiết tài liệu</td><td>Tài liệu đầy đủ các bước
thực hiện</td><td></td><td></td></tr><tr><td>4.4</td><td></td><td>Tài liệu thiết kế tổng thể</td><td>M</td><td></td><td>Kiểm tra chi tiết tài liệu</td><td>Tài liệu đầy đủ thiết kế tổng
thể hệ thống</td><td></td><td></td></tr><tr><td>4.5</td><td></td><td>Tài liệu đặc tả yêu cầu</td><td>M</td><td></td><td>Kiểm tra chi tiết tài liệu</td><td>Tài liệu đầy đủ theo đúng
yêu cầu khách hàng</td><td></td><td></td></tr></tbody></table>

|<image_30>|


