# Public_468

### VIETTEL AI RACE

### Mỏ cắt Plasma

### Khái niệm Plasma và nguyên lý hoạt động của mỏ cắt Plasma

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Mỏ cắt Plasma</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|

|<image_2>|


### VIETTEL AI RACE

### Mỏ cắt Plasma

## Chọn khí sử dụng trong cắt Plasma

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Mỏ cắt Plasma</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_3>|

|<image_4>|


### VIETTEL AI RACE

### Mỏ cắt Plasma

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Mỏ cắt Plasma</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Plasma Gas /</th><th>Thép Carbon</th><th>Thép không gỉ</th><th>Nhôm</th></tr></thead><tbody><tr><td>Shield</td><td></td><td></td><td></td></tr><tr><td>Air / Air</td><td>Chất lượng cắt/tốc độ cắt
tốt. Kinh tế</td><td>Chất lượng cắt/tốc độ
cắt tốt. Kinh tế</td><td>Chất lượng cắt/tốc độ cắt
tốt. Kinh tế</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>Oxygen (O2) /</td><td>Chất lượng cắt/tốc độ cắt</td><td>Không nên dùng</td><td></td></tr><tr><td>Air</td><td>tốt nhất. Rất ít xỉ</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>Nitrogen (N2)</td><td>Chất lượng cắt bình
thường ít xỉ. Tuổi thọ
thiết bị cao</td><td>Chất lượng cắt xuất
sắc. Tuổi thọ thiết bị
cao</td><td>Chất lượng cắt xuất sắc.
Tuổi thọ thiết bị cao</td></tr><tr><td>/ CO2</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>Nitrogen (N2)</td><td></td><td>Chất lượng cắt tốt. Tuổi thọ thiết bị cao</td><td></td></tr><tr><td>/ Air</td><td></td><td></td><td></td></tr><tr><td>Nitrogen (N2)</td><td></td><td>Chất lượng cắt xuất</td><td>Chất lượng cắt xuất sắc.</td></tr><tr><td>/ H20</td><td></td><td>sắc. Tuổi thọ thiết bị</td><td>Tuổi thọ thiết bị cao</td></tr><tr><td></td><td></td><td>cao</td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_5>|

|<image_6>|

|<image_7>|


## Video kỹ thuật cắt plasma cơ bản

## Kỹ thuật cơ bản khi cắt plasma

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Mỏ cắt Plasma</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_8>|


### VIETTEL AI RACE

### Mỏ cắt Plasma

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Mỏ cắt Plasma</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_9>|


