# Public_637

### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

### STT

### Nhóm

### vật liệu

### Tên vật liệu/loại

### vật liệu xây dựng

### (*)

### Đơn vị

### tính (*)

### Tiêu chuẩn

### kỹ thuật

### Quy cách

### Nhà sản

### xuất

### Xuất

### xứ

### Vận

### chuyển

### (*)

### Ghi chú

### Giá bán chưa bao gồm

### thuế giá trị gia tăng)

### (*)

### Thành phố Cao Bằng

### <1>

### <2>

### <3>

### <4>

### <5>

### <6>

### <7>

### <8>

### <9>

### <10>

### <11>

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>&lt;1&gt;</td><td>&lt;2&gt;</td><td>&lt;3&gt;</td><td>&lt;4&gt;</td><td>&lt;5&gt;</td><td>&lt;6&gt;</td><td>&lt;7&gt;</td><td>&lt;8&gt;</td><td>&lt;9&gt;</td><td>&lt;10&gt;</td><td>&lt;11&gt;</td></tr><tr><td>1</td><td>Cát xây
dựng</td><td>- Cát xây</td><td>m3</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Mỏ cát sỏi
Kéo Thin,
xã Bạch
Đằng</td><td></td><td>Giá bán
tại mỏ</td><td></td><td>320.000</td></tr><tr><td></td><td></td><td>- Cát bê tông (Cát
nghiền)</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>320.000</td></tr><tr><td></td><td></td><td>- Cát trát</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>380.000</td></tr><tr><td></td><td></td><td>- Cát san lấp</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>100.000</td></tr><tr><td>2</td><td>Cát xây
dựng</td><td>- Cát xây</td><td>m3</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Mỏ cát núi
Cải Chắp,
xã Lê
Chung</td><td></td><td>Giá bán
tại mỏ</td><td></td><td>300.000</td></tr><tr><td></td><td></td><td>- Cát bê tông</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>300.000</td></tr><tr><td></td><td></td><td>- Cát trát</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>350.000</td></tr><tr><td>3</td><td>Cát xây
dựng</td><td>- Cát xây</td><td>m3</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Mỏ cát đồi
Đồng Tâm</td><td></td><td>Giá bán
tại mỏ</td><td></td><td>320.000</td></tr><tr><td></td><td></td><td>- Cát bê tông</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>320.000</td></tr><tr><td></td><td></td><td>- Cát trát</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>350.000</td></tr><tr><td></td><td></td><td>- Đất đắp</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>50.000</td></tr><tr><td>4</td><td>Đá xây
dựng</td><td>Đá hộc</td><td>m3</td><td></td><td></td><td>Mỏ đá Xóm
8, Duyệt
Trung, TP.
Cao Bằng
(Công ty
TNHH
Toàn
Trung)</td><td></td><td>Giá bán
tại mỏ</td><td></td><td>160.000</td></tr><tr><td></td><td></td><td>Đá dăm 0,5</td><td>m3</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td></td><td></td><td></td><td></td><td>180.000</td></tr><tr><td></td><td></td><td>Đá dăm 2 x 4</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>180.000</td></tr><tr><td></td><td></td><td>Đá dăm 1 x 2</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>180.000</td></tr><tr><td>5</td><td></td><td>Bột đá</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr></tbody></table>

|<image_1>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

### STT

### Nhóm

### vật liệu

### Tên vật liệu/loại

### vật liệu xây dựng

### (*)

### Đơn vị

### tính (*)

### Tiêu chuẩn

### kỹ thuật

### Quy cách

### Nhà sản

### xuất

### Xuất

### xứ

### Vận

### chuyển

### (*)

### Ghi chú

### Giá bán chưa bao gồm

### thuế giá trị gia tăng)

### (*)

### Thành phố Cao Bằng

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu
Đá xây
dựng</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật
Quy chuẩn
16:2019/QCVN</th><th>Quy cách</th><th>Nhà sản
xuất
Mỏ Khưa
Vặn, xã Chu
Trinh, tp
Cao Bắng
(Công ty
TNHH Thọ
Hoàng)</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)
Giá bán
tại mỏ</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Đá dăm 0,5</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá dăm 1 x 2</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá dăm 2 x 4</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá dăm 4 x 6</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá hộc</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>180.000</td></tr><tr><td></td><td></td><td>Base B</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>160.000</td></tr><tr><td>6</td><td>Đá xây
dựng</td><td>Đá dăm 0,5</td><td>m3</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Mỏ Xóm 5,
xã Chu
Trinh, TP
Cao Bằng
(Công ty
Khoáng sản
và thương
mại Thành
Phát)</td><td></td><td>Giá bán
tại mỏ</td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá dăm 1 x 2</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá dăm 2 x 4</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá dăm 4 x 6</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá hộc</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Bột đá</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá Base A</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>Đá Base B</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td>7</td><td>Đá xây
dựng</td><td>Đá dăm 0,5</td><td>m3</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Công ty Cổ
phần Sea
Holdings</td><td></td><td>Giá bán
tại mỏ</td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Đá dăm 1 x 2</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Đá dăm 2 x 4</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Đá dăm 4 x 6</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Đá hộc</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>168.182</td></tr></tbody></table>

|<image_2>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th></th><th></th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Đá Base A</td><td></td><td></td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.909</td></tr><tr><td></td><td></td><td>Đá Base B</td><td></td><td></td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>159.091</td></tr><tr><td></td><td></td><td>Bột đá</td><td></td><td></td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>181.818</td></tr><tr><td>8</td><td>Cửa khung
nhựa/nhôm</td><td>1. Nhôm Singhal hệ
55 vát cạnh</td><td></td><td></td><td></td><td></td><td></td><td>CÔNG TY
CP TẬP
ĐOÀN
SINGHAL</td><td>Việt
Nam</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Vách cố định</td><td></td><td></td><td>m2</td><td>Quy chuẩn
QCVN
16:2019/BXD
TCVN197-
1:2014
TCVN12513-
7:2018</td><td>Dày 1.0mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>950.000</td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh mở
hất/ quay</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.500.000</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh mở
hất/ quay</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.500.000</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh mở
lùa</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.500.000</td></tr><tr><td></td><td></td><td>Cửa sổ 4 cánh mở
lùa</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.500.000</td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh/2
cánh mở hất/ quay
+ fix</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.500.000</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh/4
cánh mở lùa + fix</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.500.000</td></tr><tr><td></td><td></td><td></td><td>Bộ phụ kiện cửa sổ</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>950.000</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 4 cánh mở</th></tr></thead><tbody><tr><td>lùa</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 1 cánh/2</th></tr></thead><tbody><tr><td>cánh mở hất/ quay</td></tr><tr><td>+ fix</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 2 cánh/4</th></tr></thead><tbody><tr><td>cánh mở lùa + fix</td></tr></tbody></table>

|<image_3>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th></th><th></th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td></td><td>Cửa đi 2 cánh mở</td><td></td><td>m2</td><td>Quy chuẩn
QCVN
16:2019/BXD
TCVN197-
1:2014
TCVN12513-
7:2018</td><td>Dày 1.2mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>1.800.000
1.800.000
1.800.000
1.800.000</td></tr><tr><td></td><td></td><td></td><td>quay.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa di 2 cánh mở
lùa.</td><td>Cửa di 2 cánh mở</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>lùa.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa di 4 cánh mở
lùa.</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Cửa đi 1 cánh/2</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>cánh mở quay+ fix</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa di 2 cánh/4
cánh mở lùa + fix</td><td>Cửa di 2 cánh/4</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.800.000</td></tr><tr><td></td><td></td><td></td><td>cánh mở lùa + fix</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Bộ phụ kiện cửa đi</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>950.000</td></tr><tr><td></td><td>Cửa khung
nhựa/nhôm</td><td>2. Nhôm Singhal
hệ 55 mặt cắt
XINGFA</td><td>2. Nhôm Singhal</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hệ 55 mặt cắt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>XINGFA</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Vách cố định.</td><td></td><td>m2</td><td>Quy chuẩn
QCVN
16:2019/BXD
TCVN197-
1:2014</td><td>Dày 1.4mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>1.650.000</td></tr><tr><td></td><td></td><td>Cửa đi 1 cánh mở
quay.</td><td>Cửa đi 1 cánh mở</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.100.000</td></tr><tr><td></td><td></td><td></td><td>quay.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa đi 2 cánh mở
quay.</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.100.000</td></tr></tbody></table>

<table><thead><tr><th>Cửa di 4 cánh mở</th></tr></thead><tbody><tr><td>lùa.</td></tr></tbody></table>

<table><thead><tr><th>Cửa đi 2 cánh mở</th></tr></thead><tbody><tr><td>quay.</td></tr></tbody></table>

|<image_4>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th></th><th></th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật
TCVN12513-
7:2018</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Cửa đi 1 cánh/2
cánh mở quay +
fix</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.100.000</td></tr><tr><td></td><td></td><td>Cửa đi 2 cánh mở
lùa</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.100.000</td></tr><tr><td></td><td></td><td>Cửa đi 4 cánh mở
lùa</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.100.000</td></tr><tr><td></td><td></td><td>Cửa đi 2/4 cánh
cánh mở lùa + fix</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.100.000</td></tr><tr><td></td><td></td><td></td><td>Bộ phụ kiện cửa đi</td><td></td><td>Bộ</td><td></td><td></td><td></td><td></td><td></td><td></td><td>950.000</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh mở
hất/ quay.</td><td>Cửa sổ 2 cánh mở</td><td></td><td>m2</td><td>Quy chuẩn
QCVN
16:2019/BXD
TCVN197-
1:2014
TCVN12513-
7:2018</td><td>Dày 1.2mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>1.900.000</td></tr><tr><td></td><td></td><td></td><td>hất/ quay.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh mở
hất/ quay.</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.900.000</td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh/2
cánh mở hất/ quay
+ fix</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.900.000</td></tr></tbody></table>

<table><thead><tr><th>Cửa đi 1 cánh/2</th></tr></thead><tbody><tr><td>cánh mở quay +</td></tr><tr><td>fix</td></tr></tbody></table>

<table><thead><tr><th>Cửa đi 2 cánh mở</th></tr></thead><tbody><tr><td>lùa</td></tr></tbody></table>

<table><thead><tr><th>Cửa đi 4 cánh mở</th></tr></thead><tbody><tr><td>lùa</td></tr></tbody></table>

<table><thead><tr><th>Cửa đi 2/4 cánh</th></tr></thead><tbody><tr><td>cánh mở lùa + fix</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 1 cánh mở</th></tr></thead><tbody><tr><td>hất/ quay.</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 1 cánh/2</th></tr></thead><tbody><tr><td>cánh mở hất/ quay</td></tr><tr><td>+ fix</td></tr></tbody></table>

|<image_5>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th></th><th></th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh mở
lùa</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.900.000</td></tr><tr><td></td><td></td><td>Cửa sổ 4 cánh mở
lùa</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.900.000</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh/4
cánh mở lùa + fix</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.900.000</td></tr><tr><td></td><td></td><td></td><td>Bộ phụ kiện cửa sổ</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>950.000</td></tr><tr><td></td><td>Cửa khung
nhựa/nhôm</td><td></td><td>3. Nhôm Singhal</td><td></td><td></td><td>Quy chuẩn
QCVN
16:2019/BXD
TCVN197-
1:2014
TCVN12513-
7:2018</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hệ 56</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Vách cố định.</td><td></td><td>m2</td><td></td><td>Dày 1.2mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>1.435.000</td></tr><tr><td></td><td></td><td>Cửa đi 1 cánh mở
quay</td><td>Cửa đi 1 cánh mở</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.371.000</td></tr><tr><td></td><td></td><td></td><td>quay</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa đi 2 cánh mở
quay.</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.430.000</td></tr><tr><td></td><td></td><td></td><td>Cửa đi 1 cánh/2</td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.341.000</td></tr><tr><td></td><td></td><td></td><td>cánh mở quay +</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>fix</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh mở
hất/ quay.</td><td>Cửa sổ 1 cánh mở</td><td></td><td>m2</td><td></td><td>Dày 1.0mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>2.223.000</td></tr><tr><td></td><td></td><td></td><td>hất/ quay.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh mở
hất/ quay.</td><td></td><td></td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.637.000</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 2 cánh mở</th></tr></thead><tbody><tr><td>lùa</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 4 cánh mở</th></tr></thead><tbody><tr><td>lùa</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 2 cánh/4</th></tr></thead><tbody><tr><td>cánh mở lùa + fix</td></tr></tbody></table>

<table><thead><tr><th>Cửa đi 2 cánh mở</th></tr></thead><tbody><tr><td>quay.</td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 2 cánh mở</th></tr></thead><tbody><tr><td>hất/ quay.</td></tr></tbody></table>

|<image_6>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh/2
cánh mở hất/ quay
+ fix</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.198.000</td></tr><tr><td></td><td>Cửa khung
nhựa/nhôm</td><td>4. Nhôm Singhal
hệ vách dựng
65*90</td><td></td><td></td><td>Dày 2.0mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td>2.828.000
2.959.000
2.643.000</td></tr><tr><td></td><td></td><td>Hệ vách dựng nối
đố</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ vách dựng nối
đố + có cửa mở hất</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ vách dựng dấu
đố</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Cửa khung
nhựa/nhôm</td><td>5. Nhôm Singhal
hệ vách dựng
52*85</td><td></td><td></td><td>Dày 2.0mm
( ±5%.).</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ vách dựng nối
đố</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Hệ vách dựng nối
đố + có cửa mở hất</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Cửa sổ 1 cánh/2</th></tr></thead><tbody><tr><td>cánh mở hất/ quay</td></tr><tr><td>+ fix</td></tr></tbody></table>

<table><thead><tr><th>4. Nhôm Singhal</th></tr></thead><tbody><tr><td>hệ vách dựng</td></tr><tr><td>65*90</td></tr></tbody></table>

<table><thead><tr><th>5. Nhôm Singhal</th></tr></thead><tbody><tr><td>hệ vách dựng</td></tr><tr><td>52*85</td></tr></tbody></table>

|<image_7>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Hệ vách dựng dấu
đố + có cửa sổ 1
cánh mở hất.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.583.000</td></tr><tr><td></td><td>Cửa khung
nhựa/nhôm</td><td>6. Nhôm Singhal
hệ thủy lực</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Cửa đi 2/3/4/5/7
tấm: K200, SC180</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Cửa đi 2/3/4/5/7
tấm: K200, SC120</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Cửa đi 2/3/4/5/7
tấm: K200, SC140</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Cửa đi 2/3/4/5/7
tấm: SK120
, SC180</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Cửa đi 2/3/4/5/7
tấm: SK120,
SC120</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_8>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>- Cửa đi 2/3/4/5/7
tấm: SK120,
SC140</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.628.000</td></tr><tr><td></td><td>Cửa khung
nhựa/nhôm</td><td>7. Nhôm Singhal
hệ Châu Âu 60
SINGVRO</td><td></td><td>Quy chuẩn
QCVN
16:2019/BXD
TCVN197-
1:2014
TCVN12513-
7:2018</td><td>Dày 1.4mm
(±5%)
Dày 2.0mm
(±5%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Vách cố định.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.213.000</td></tr><tr><td></td><td></td><td>Cửa sổ 2 cánh mở
hất/ quay.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.708.000</td></tr><tr><td></td><td></td><td>Cửa sổ 1 cánh mở
hất/ quay.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.650.000</td></tr><tr><td></td><td></td><td>Cửa đi 1 cánh mở
quay.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.743.000</td></tr><tr><td></td><td></td><td>Cửa đi 2 cánh mở
quay.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>4.973.000</td></tr><tr><td></td><td></td><td>Cửa đi 4 cánh mở
quay.</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.318.000</td></tr><tr><td></td><td></td><td>8. CỬA CUỐN
SINGDOOR</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_9>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>Nan cửa cuốn
chống bão G91:
- Sơn màu nâu
vàng, giảm âm 2
chiều lên xuống.
- Day hộp U100
- Trục phi 141mm
dày 3,96 mm +
puli nhựa.</td><td>m2</td><td></td><td>Bản nan
70mm, lỗ
thoáng
hình ovan
to</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Nan cửa cuốn
S70:
- Kết hợp 2 nan,
sơn màu xanh nâu
+ vàng cát, giảm
âm 1chiều lên,
xuống.
- Day hộp U76
- Trục phi
113,5mm dày 1,8
mm + puli nhựa.</td><td>m2</td><td></td><td>Bản nan
50mm, lỗ
thoáng
hình ovan.</td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th></tr></thead><tbody><tr><td>Nan cửa cuốn
SE03:
- Sơn màu caphe,
4chân, 2 vít, giảm
âm 1 chiều lên,
xuống.
- Day hộp U76
- Trục phi
113,5mm dày 1,8
mm + puli nhựa.</td><td>m2</td></tr><tr><td>Nan cửa cuốn
G88:
- Kết hợp 2 nan,
sơn màu xanh
mint, giảm âm 2
chiều lên, xuống.
- Day hộp U76
- Trục phi
113,5mm dày 1,8
mm + puli nhựa.</td><td>m2</td></tr></tbody></table>

<table><thead><tr><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>Bản nan
88mm, lỗ
thoáng
hình hoa
văn</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Bản nan
60mm, lỗ
thoáng
hình kim
tiền</td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_11>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>Nan cửa cuốn
G61:
- Sơn màu cà phê
sáng, giảm âm 2
chiều lên, xuống.
- Day hộp U76
- Trục phi 113,5
mm dày 1,8 mm +
puli nhựa.</td><td>m2</td><td></td><td>Bản nan
60mm, lỗ
thoáng
hình kim
tiền</td><td></td><td></td><td></td><td></td><td>1.940.000
1.500.000</td></tr><tr><td>Nan cửa cuốn
G60 Plus:
- Sơn màu ghi
sáng, giảm âm 1
chiều lên, xuống.
- Day hộp U76
- Trục phi
113,5mm dày
1,8mm + puli nhựa</td><td>m2</td><td></td><td>Bản nan
60mm, lỗ
thoáng
hình kim
tiền</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9. Phụ trội kèm
theo</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_12>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú
Cộng thêm
vào đơn giá
trên</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn bảo hành 10
năm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>80.000</td></tr><tr><td></td><td></td><td>Sơn bảo hành 15
năm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>110.000</td></tr><tr><td></td><td></td><td>Kính dán an toàn
trắng trong
8.38mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>65.000</td></tr><tr><td></td><td></td><td>Kính dán an toàn
trắng trong
10.38mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>130.000</td></tr><tr><td></td><td></td><td>Kính dán an toàn
trắng trong
12.38mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr><tr><td></td><td></td><td>Kính dán an toàn
phản quang
8.38mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>390.000</td></tr><tr><td></td><td></td><td>Kính dán an toàn
phản quang
10.38mm</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>480.000</td></tr><tr><td></td><td></td><td>Kính cường lực 8
mm trắng trong</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>80.000</td></tr></tbody></table>

|<image_13>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Kính cường lực 10
mm trắng trong</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>150.000</td></tr><tr><td></td><td></td><td>Kính cường lực 12
mm trắng trong</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr><tr><td></td><td></td><td>Kính hộp cường
lực dày 19mm
(5+9+5)</td><td>m2</td><td></td><td></td><td></td><td></td><td></td><td></td><td>560.000</td></tr><tr><td>9</td><td>Gạch ốp
lát</td><td>Gạch ốp, lát
Ceramic Prime</td><td></td><td></td><td></td><td>Thành phố
Cao Bằng</td><td></td><td>Thành
phố Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Gạch lát nền 40cm x
40cm</td><td>m2</td><td></td><td>40x40cm</td><td></td><td></td><td></td><td></td><td>100.000</td></tr><tr><td></td><td></td><td>Gạch lát nền 50cm x
50cm</td><td>m2</td><td></td><td>50x50cm</td><td></td><td></td><td></td><td></td><td>110.000</td></tr><tr><td></td><td></td><td>Gạch lát nền 60cm x
60cm</td><td>m2</td><td></td><td>60x60cm</td><td></td><td></td><td></td><td></td><td>135.000</td></tr><tr><td></td><td></td><td>Gạch ốp tường 25cm
x 50cm</td><td>m2</td><td></td><td>25x50cm</td><td></td><td></td><td></td><td></td><td>140.000</td></tr><tr><td></td><td></td><td>Gạch ốp tường 30cm
x 60cm</td><td>m2</td><td></td><td>30x60cm</td><td></td><td></td><td></td><td></td><td>170.000</td></tr><tr><td></td><td></td><td>Gạch lát nền vệ sinh
chống trơn 30cm x
30cm</td><td>m2</td><td></td><td>30x30cm</td><td></td><td></td><td></td><td></td><td>150.000</td></tr></tbody></table>

|<image_14>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>10</td><td>Gạch ốp
lát</td><td>Sản phẩm gạch ốp
lát, ngói của Công
ty TNHH MTV
TM Đồng Tâm</td><td></td><td></td><td></td><td>Công ty
TNHH
MTV TM
Đồng Tâm</td><td></td><td>Giá đến
hiện
trường
xây
dựng
khu vực
trung
tâm
thành
phố và
các
huyện
trên địa
bàn tỉnh
Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>GẠCH ỐP/LÁT</td><td></td><td>TCVN 13113:
2020
BS EN
14411:2016</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Ceramic men bóng:
25x40cm</td><td>m2</td><td></td><td>25x40cm</td><td></td><td></td><td></td><td></td><td>156.400</td></tr><tr><td></td><td></td><td>Ceramic men bóng:
30x30cm</td><td>m2</td><td></td><td>30x30cm</td><td></td><td></td><td></td><td></td><td>162.525</td></tr><tr><td></td><td></td><td>Ceramic men mờ:
30x30cm</td><td>m2</td><td></td><td>30x30cm</td><td></td><td></td><td></td><td></td><td>177.273</td></tr><tr><td></td><td></td><td>Ceramic men bóng:
40x40cm</td><td>m2</td><td></td><td>40x40cm</td><td></td><td></td><td></td><td></td><td>157.500</td></tr><tr><td></td><td></td><td>Ceramic men mờ:
40x40cm</td><td>m2</td><td></td><td>40x40cm</td><td></td><td></td><td></td><td></td><td>157.500</td></tr><tr><td></td><td></td><td>Ceramic men bóng:
30x60cm</td><td>m2</td><td></td><td>30x60cm</td><td></td><td></td><td></td><td></td><td>244.444</td></tr><tr><td></td><td></td><td>Ceramic men mờ:
30x60cm</td><td>m2</td><td></td><td>30x60cm</td><td></td><td></td><td></td><td></td><td>244.444</td></tr><tr><td></td><td></td><td>Ceramic men bóng
kháng khuẩn:
40x80cm</td><td>m2</td><td></td><td>40x80cm</td><td></td><td></td><td></td><td></td><td>295.313</td></tr><tr><td></td><td></td><td>Porcelain men mờ
vân gỗ: 15x60cm</td><td>m2</td><td></td><td>15x60cm</td><td></td><td></td><td></td><td></td><td>281.000</td></tr></tbody></table>

|<image_15>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Porcelain men mờ:
30x30cm</td><td>m2</td><td></td><td>30x30cm</td><td></td><td></td><td></td><td></td><td>210.000</td></tr><tr><td></td><td></td><td>Porcelain men mờ:
30x60cm</td><td>m2</td><td></td><td>30x60cm</td><td></td><td></td><td></td><td></td><td>250.000</td></tr><tr><td></td><td></td><td>Porcelain men mờ
đồng chất: 30x60cm</td><td>m2</td><td></td><td>30x60cm</td><td></td><td></td><td></td><td></td><td>359.444</td></tr><tr><td></td><td></td><td>Porcelain men mờ:
40x40cm</td><td>m2</td><td></td><td>40x40cm</td><td></td><td></td><td></td><td></td><td>196.250</td></tr><tr><td></td><td></td><td>Porcelain muối tiêu:
40x40cm</td><td>m2</td><td></td><td>40x40cm</td><td></td><td></td><td></td><td></td><td>249.271</td></tr><tr><td></td><td></td><td>Porcelain men mờ:
40x80cm</td><td>m2</td><td></td><td>40x80cm</td><td></td><td></td><td></td><td></td><td>328.125</td></tr><tr><td></td><td></td><td>Porcelain men bóng:
60x60cm</td><td>m2</td><td></td><td>60x60cm</td><td></td><td></td><td></td><td></td><td>220.000</td></tr><tr><td></td><td></td><td>Porcelain men mờ:
60x60cm</td><td>m2</td><td></td><td>60x60cm</td><td></td><td></td><td></td><td></td><td>220.000</td></tr><tr><td></td><td></td><td>Porcelain bóng kính
2 da: 60x60cm</td><td>m2</td><td></td><td>60x60cm</td><td></td><td></td><td></td><td></td><td>288.889</td></tr><tr><td></td><td></td><td>Porcelain men mờ
đồng chất: 60x60cm</td><td>m2</td><td></td><td>60x60cm</td><td></td><td></td><td></td><td></td><td>368.333</td></tr><tr><td></td><td></td><td>Porcelain men mờ
kháng khuẩn:
80x80cm</td><td>m2</td><td></td><td>80x80cm</td><td></td><td></td><td></td><td></td><td>314.063</td></tr></tbody></table>

|<image_16>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Porcelain bóng kính
kháng khuẩn:
80x80cm</td><td>m2</td><td></td><td>80x80cm</td><td></td><td></td><td></td><td></td><td>344.531</td></tr><tr><td></td><td></td><td>Porcelain mài bóng
kháng khuẩn:
100x100cm</td><td>m2</td><td></td><td>100x100cm</td><td></td><td></td><td></td><td></td><td>447.909</td></tr><tr><td>11</td><td>Vật liệu
khác</td><td>NGÓI XI MĂNG</td><td></td><td>BS EN
490:2011 + sửa
đổi 1:2017</td><td></td><td>Công ty
TNHH
MTV TM
Đồng Tâm</td><td></td><td>Giá đến
hiện
trường
xây
dựng
khu vực
trung
tâm
thành
phố và
các
huyện
trên địa
bàn tỉnh
Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Ngói lợp lớn 1 màu</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>18.909</td></tr><tr><td></td><td></td><td>Ngói lợp lớn 2 màu</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>21.364</td></tr><tr><td></td><td></td><td>Ngói rìa/Ngói nóc
có gờ 1 màu - Đồng
Tâm, Việt Nam</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>29.727</td></tr><tr><td></td><td></td><td>Ngói rìa/Ngói nóc
có gờ 2 màu - Đồng
Tâm, Việt Nam</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>31.909</td></tr><tr><td></td><td></td><td>Ngói ốp cuối nóc
phải/ trái có gờ 1
màu
Ngói đuôi (cuối mái)
1 màu
Ngói ốp cuối rìa 1
màu</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>46.182</td></tr></tbody></table>

|<image_17>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Ngói ốp cuối nóc
phải/ trái có gờ 2
màu
Ngói đuôi (cuối mái)
2 màu
Ngói ốp cuối rìa 2
màu</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>50.636</td></tr><tr><td></td><td></td><td>Ngói chạc 2 (L phải
/ L trái) 1 màu
Ngói chạc ba 1 màu
Ngói chạc tư 1 màu
Ngói chữ T 1 màu</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>53.909</td></tr><tr><td></td><td></td><td>Ngói chạc 2 (L phải
/ L trái) 2 màu
Ngói chạc ba 2 màu
Ngói chạc tư 2 màu
Ngói chữ T 2 màu
Đồng Tâm – Việt
Nam</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>55.000</td></tr></tbody></table>

|<image_18>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Ngói nóc có gờ có
giá gắn ống 1 màu
Ngói lợp có giá gắn
ống 1 màu
Ngói chạc 3 có giá
gắn ống 1 màu
Ngói chạc 4 có giá
gắn ống 1 màu</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>220.000</td></tr><tr><td></td><td></td><td>NGÓI TRÁNG
MEN</td><td>Viên</td><td>TCVN
9133:2011</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Ngói lợp lớn</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>24.545</td></tr><tr><td></td><td></td><td>Ngói rìa</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>37.545</td></tr><tr><td></td><td></td><td>Ngói cuối rìa</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>62.545</td></tr><tr><td></td><td></td><td>Ngói nóc có gờ</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>36.364</td></tr><tr><td></td><td></td><td>Ngói ốp cuối nóc
trái</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>63.636</td></tr><tr><td></td><td></td><td>Ngói ốp cuối nóc
phải</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>63.636</td></tr><tr><td></td><td></td><td>Ngói chạc ba</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>86.364</td></tr><tr><td></td><td></td><td>Ngói chạc tư</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>104.545</td></tr><tr><td></td><td></td><td>Ngói chạc chữ T</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>86.364</td></tr><tr><td></td><td></td><td>Ngói chặn cuối nóc</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>27.273</td></tr><tr><td></td><td></td><td>Ngói chặn cuối rìa</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>25.000</td></tr></tbody></table>

|<image_19>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>12</td><td>Gạch ốp
lát</td><td>Danh mục sản
phẩm digital
GraniteViet Y Tile</td><td></td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Công ty Cổ
phần tập
đoàn đầu tư
Grand
Home</td><td></td><td>Giá trên
địa bàn
thành
phố Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 600x600mm -
Men Matt (MSP:
VY1-M66001, VY1-
M66002….,VY2-
M66001, …..,</td><td>m2</td><td></td><td>600x600mm</td><td></td><td></td><td></td><td></td><td>205.800</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 600x600mm -
Men Bóng (MSP:
VY1-P66001, VY2-
P66002,….)</td><td>m2</td><td></td><td>600x600mm</td><td></td><td></td><td></td><td></td><td>205.800</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 300x600mm -
Men Matt (MSP:
VY1-M36001, VY1-
M36002….,VY2-
M36001, …..)</td><td>m2</td><td></td><td>300x600mm</td><td></td><td></td><td></td><td></td><td>205.800</td></tr></tbody></table>

|<image_20>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 300x600mm -
Men Bóng (MSP:
VY1-P36001, VY2-
P36002,….)</td><td>m2</td><td></td><td>300x600mm</td><td></td><td></td><td></td><td></td><td>205.800</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 400x800mm -
Men Matt (MSP:
VY1-M48001, VY1-
M48002…..,VY2-
M48001, …..)</td><td>m2</td><td></td><td>400x800mm</td><td></td><td></td><td></td><td></td><td>320.850</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 400x800mm -
Men bóng (MSP:
VY1-P48001, VY2-
P48002,….)</td><td>m2</td><td></td><td>400x800mm</td><td></td><td></td><td></td><td></td><td>320.850</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 800x800mm -
Men Matt(MSP:
VY1-M88001, VY1-
M88002…..,VY2-
M8001, …..)</td><td>m2</td><td></td><td>800x800mm</td><td></td><td></td><td></td><td></td><td>327.980</td></tr></tbody></table>

|<image_21>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sản phẩm gạch kích
thước 800x800mm -
Men bóng (MSP:
VY1-P88001, VY2-
P88002,….)</td><td>m2</td><td></td><td>800x800mm</td><td></td><td></td><td></td><td></td><td>327.980</td></tr><tr><td>13</td><td>Gạch xây</td><td>Gạch chỉ tuy nen 2
lỗ loại A</td><td></td><td></td><td></td><td>Công ty CP
SXVL xây
dựng Cao
Bằng</td><td></td><td>Giao tại
kho nhà
máy sx</td><td></td><td></td></tr><tr><td></td><td></td><td>- 2 lỗ tròn đường
kính Ø30 KT:
210x95x55 mm</td><td>Viên</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td></td><td></td><td></td><td></td><td>1.444</td></tr><tr><td></td><td></td><td>- 2 lỗ tròn đường
kính Ø25 KT:
210x95x55 mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.296</td></tr><tr><td></td><td></td><td>- Gạch tuynel đặc
loại A KT:
210x95x55 mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.759</td></tr><tr><td></td><td></td><td>- Gạch tuynel loại A
4 lỗ KT:
220x105x135mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.333</td></tr><tr><td></td><td></td><td>- Gạch tuynel loại A
6 lỗ KT:
220x105x135mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.611</td></tr></tbody></table>

|<image_22>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Gạch 2 lỗ thông tâm
không nung KT:
220x105x65mm</td><td>Viên</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td></td><td></td><td></td><td></td><td>1.120</td></tr><tr><td></td><td></td><td>Gạch đặc không
nung (TC-M15-105-
TCCS 04:2013) KT:
216x104x61mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.120</td></tr><tr><td>13</td><td>Gạch xây</td><td>Loại A</td><td></td><td></td><td></td><td>Công ty CP
Gốm Tân
Phong</td><td></td><td>Giao tại
kho nhà
máy sx</td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 2 lỗ Ø25, KT
210x95x55mm</td><td>Viên</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td></td><td></td><td></td><td></td><td>1.200</td></tr><tr><td></td><td></td><td>- Gạch 2 lỗ Ø30, KT
220x105x60mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.450</td></tr><tr><td></td><td></td><td>- Gạch đặc, KT
210x95x55mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.550</td></tr><tr><td></td><td></td><td>- Gạch 4 lỗ vuông,
KT 220x105x130mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.300</td></tr><tr><td></td><td></td><td>- Gạch 6 lỗ Ø30, KT
220x105x150mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.600</td></tr><tr><td></td><td></td><td>- Gạch 8 lỗ Ø30, KT
400x105x180mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.000</td></tr><tr><td></td><td></td><td>- Gạch 8 lỗ vuông,
KT 340x120x180mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>8.000</td></tr></tbody></table>

|<image_23>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th></tr></thead><tbody><tr><td></td><td></td><td>- Gạch 10 lỗ Ø30,
KT 320x215x120mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 10 lỗ vuông,
KT 320x215x120mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Loại A1</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 2 lỗ Ø25, KT
210x95x55mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 2 lỗ Ø30, KT
220x105x60mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch đặc, KT
210x95x55mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 4 lỗ vuông,
KT 220x105x130mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 6 lỗ Ø30, KT
220x105x150mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 8 lỗ Ø30, KT
400x105x180mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 8 lỗ vuông,
KT 340x120x180mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Gạch 10 lỗ Ø30,
KT 320x215x120mm</td><td>Viên</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Viên</td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>8.000</td></tr><tr><td></td><td></td><td>8.000</td></tr><tr><td></td><td></td><td></td></tr><tr><td></td><td></td><td>900</td></tr><tr><td></td><td></td><td>1.100</td></tr><tr><td></td><td></td><td>1.200</td></tr><tr><td></td><td></td><td>2.200</td></tr><tr><td></td><td></td><td>2.200</td></tr><tr><td></td><td></td><td>5.500</td></tr><tr><td></td><td></td><td>5.500</td></tr><tr><td></td><td></td><td>5.500</td></tr><tr><td></td><td></td><td>5.500</td></tr></tbody></table>

|<image_24>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td>14</td><td>Gạch xây</td><td>Gạch bê tông 2 lỗ Ø28
KT: 220x105x65mm</td><td>Viên</td><td>Quy chuẩn
16:2019/QCVN</td><td></td><td>Công ty CP
xi măng -
XDCT Cao
Bằng</td><td>Việt
Nam</td><td>Giá bán
tại nhà
máy</td><td></td><td>1.019</td></tr><tr><td></td><td></td><td>Gạch bê tông đặc KT:
210x100x60mm</td><td>Viên</td><td></td><td></td><td></td><td></td><td></td><td></td><td>1.019</td></tr><tr><td>15</td><td>Gỗ xây
dựng</td><td>Hoành gỗ tạp xẻ 8 x
8 nhóm 4</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.000.000</td></tr><tr><td></td><td></td><td>Cầu phong, ly tô
nhóm 4</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.400.000</td></tr><tr><td></td><td></td><td>Gỗ ván cốp pha
nhóm 5,6</td><td>m3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.000.000</td></tr><tr><td>16</td><td>Nhựa
đường</td><td>Carboncor asphalt -
CA 9.5</td><td>Tấn</td><td></td><td></td><td>Công ty cổ
phần
CARBON
Việt Nam
(ĐT:
024.3795
8528)</td><td></td><td>Giá bán
tại thành
phố Cao
Bằng</td><td>Giá đã bao
gồm chi phí
vận tải từ nhà
máy Hà Nam
đến trung tâm
thành phố Cao
Bằng. Ngoài
địa điểm trên,
mỗi Km phụ
trội sẽ tính
thêm
3.000VNĐ/tấn</td><td>3.930.000</td></tr><tr><td></td><td>Nhựa
đường</td><td>Carboncor asphalt -
CA 12.5</td><td>Tấn</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.930.000</td></tr><tr><td></td><td>Nhựa
đường</td><td>Carboncor asphalt
- CA 19 (bê tông
nhựa rỗng Carbon)</td><td>Tấn</td><td></td><td></td><td></td><td></td><td></td><td></td><td>3.110.000</td></tr><tr><td>17</td><td>Nhựa
đường</td><td>Nhựa đường đặc
nóng 60/70:</td><td></td><td>TCVN:
13567:1-2022;</td><td></td><td>Công ty Cổ
phần nhựa</td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_25>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất
đường thiết
bị giao
thông</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường đặc
nóng 60/70
Singapore</td><td>kg</td><td></td><td></td><td></td><td></td><td></td><td>Giá tại Cảng
Vật Cách - Hải
Phòng</td><td>13.000</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường đặc
nóng 60/70
Singapore</td><td>kg</td><td></td><td></td><td></td><td></td><td></td><td>Giá bán tại
Thành phố
Cao Bằng</td><td>13.600</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường 60/70
Trung Đông đóng
thùng:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường 60/70
IRAN đóng thùng</td><td>kg</td><td></td><td></td><td></td><td></td><td></td><td>Giá tại Cảng
Vật Cách - Hải
Phòng</td><td>11.900</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường 60/70
IRAN đóng thùng</td><td>kg</td><td></td><td></td><td></td><td></td><td></td><td>Giá bán tại
Thành phố
Cao Bằng</td><td>12.400</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường 60/70
Singapore đóng
thùng:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_26>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường 60/70
Singapore đóng
thùng</td><td>kg</td><td></td><td></td><td></td><td></td><td></td><td>Giá tại Cảng
Vật Cách - Hải
Phòng</td><td>14.600</td></tr><tr><td></td><td>Nhựa
đường</td><td>Nhựa đường 60/70
Singapore đóng
thùng</td><td>kg</td><td></td><td></td><td></td><td></td><td></td><td>Giá bán tại
Thành phố
Cao Bằng</td><td>15.100</td></tr><tr><td>18</td><td>Sơn</td><td>Matít Kova</td><td></td><td>QCVN
16:2019/BXD</td><td></td><td>Công ty
TNHH Sơn
Kova</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Matit trong nhà
MTT- Gold</td><td>Kg</td><td></td><td></td><td></td><td>Việt
Nam</td><td>Không
có thông
tin</td><td></td><td>23.273</td></tr><tr><td></td><td></td><td>Bột bả trong nhà
MB-T</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>14.909</td></tr><tr><td></td><td></td><td>Matit ngoài trời
MTN- Gold</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>29.273</td></tr><tr><td></td><td></td><td>Bột bả ngoài trời
MB-N</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>19.273</td></tr><tr><td></td><td></td><td>Sơn nước trong
nhà Kova (Sơn
trắng chưa bao
gồm tiền màu)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Sơn lót kháng kiềm
cao cấp K-109</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>107.455</td></tr></tbody></table>

|<image_27>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>- Sơn trắng trần
trong nhà K-10</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>110.727</td></tr><tr><td></td><td></td><td>- Sơn bóng cao cấp
K-871</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>215.227</td></tr><tr><td></td><td></td><td>- Sơn bán bóng cao
cấp K-5500</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>153.091</td></tr><tr><td></td><td></td><td>- Sơn không bóng
K-771</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>59.600</td></tr><tr><td></td><td></td><td>- Sơn không bóng
K-260</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>73.727</td></tr><tr><td></td><td></td><td>Sơn nước ngoài
trời Kova (Sơn
trắng chưa bao
gồm tiền màu)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>- Sơn lót kháng kiềm
cao cấp K-209</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>176.455</td></tr><tr><td></td><td></td><td>- Sơn bóng cao cấp
K-360</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>285.455</td></tr><tr><td></td><td></td><td>- Sơn trang trí,
chống thấm cao cấp
ngoài trời CT - 04T</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>228.182</td></tr><tr><td></td><td></td><td>- Sơn bán bóng cao
cấp K-5800</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>201.818</td></tr></tbody></table>

|<image_28>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>- Sơn không bóng
cao cấp K-5501</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>146.182</td></tr><tr><td></td><td></td><td>- Sơn không bóng
K-261</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>95.000</td></tr><tr><td></td><td></td><td>Sơn màu Kova pha
sẵn sơn trong nhà K-
180</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>59.318</td></tr><tr><td></td><td></td><td>Sơn màu Kova pha
sẵn sơn ngoài trời
màu nhạt K-280</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>87.045</td></tr><tr><td></td><td></td><td>Sơn màu Kova pha
sẵn sơn ngoài trời
màu đậm K-280</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>113.409</td></tr><tr><td>19</td><td>Sơn</td><td>SƠN NỘI THẤT</td><td></td><td>QCVN
16:2019/BXD</td><td></td><td>Công ty
TNHH đầu
tư dịch vụ
thương mại
Thành Nam</td><td>Việt
Nam</td><td>Giá bán
tại địa
bàn
thành
phố Cao
Bằng
phạm vi
&lt;50Km</td><td></td><td></td></tr><tr><td></td><td></td><td>INPA - PLATINUM
Sơn siêu bóng nội
thất cao cấp 7 trong
1</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.000</td></tr><tr><td></td><td></td><td>INPA - PLATINUM
Sơn siêu bóng nội
thất cao cấp 7 trong
1</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.000</td></tr></tbody></table>

|<image_29>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>INPA - PLATINUM
Sơn siêu bóng nội
thất cao cấp 7 trong
1</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.000</td></tr><tr><td></td><td></td><td>INPA - PLATINUM
Sơn siêu bóng nội
thất cao cấp 7 trong
1</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.000</td></tr><tr><td></td><td></td><td>SƠN NGOẠI
THẤT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>INPA - EXTERIOR
ENAMEL Sơn siêu
bóng ngoại thất cao
cấp 7 trong 1</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>375.000</td></tr><tr><td></td><td></td><td>INPA - TITANIUM
EXT Sơn bóng
ngoại thất cao cấp 8
trong 1</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>260.000</td></tr><tr><td></td><td></td><td>INPA - GLOSSY
EXT Sơn bóng mờ
ngoại thất cap cấp
màng sơn láng mịn</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>205.000</td></tr></tbody></table>

|<image_30>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>INPA - BASIC EXT
Sơn mịn ngoại thất
cap cấp màng sơn
láng mịn</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>130.000</td></tr><tr><td></td><td></td><td>SƠN CÔNG
NGHIỆP</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>INPA - SHIELD
COLOR Sơn chống
thấm đa năng cao
cấp</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.000</td></tr><tr><td></td><td></td><td>INPA - EPOXY
PRIME Sơn lót
EPOXY PRIME khả
năng bám dính tuyệt
đối, thẩm thấu cao,
chống mài mòn,
kháng nước, kháng
kiềm, chịu độ ẩm
cao</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>372.000</td></tr></tbody></table>

|<image_31>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>INPA - EPOXY
FINISH Sơn lót
EPOXY FINISH
Bền màu, dễ làm
sạch, khả năng bám
dính tốt, chịu tải cao,
chống mài mòn cao</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>395.000</td></tr><tr><td></td><td></td><td>SƠN LÓT KIỀM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>INPA ALKALINE
INT Sơn lót chống
kiềm nội thất cao
cấp</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>155.000</td></tr><tr><td></td><td></td><td>INPA ALKALINE
INT Sơn lót chống
kiềm nội thất</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>120.000</td></tr><tr><td></td><td></td><td>INPA PRIMER
EXT Sơn lót chống
kiềm ngoại thất cao
cấp</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>190.000</td></tr><tr><td></td><td></td><td>INPA SEALLER
EXT Sơn lót chống
kiềm ngoại thất</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>133.000</td></tr><tr><td></td><td></td><td>BỘT BẢ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_32>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>INPA SANDY Bột
bả Nội - ngoại thất
cap cấp thấm thấm,
độ phủ cao, bề mặt
chai cứng, hỗ trợ
chống thấm, chống
rêu mốc</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>17.500</td></tr><tr><td></td><td></td><td>INPA SOFTY Bột
bả Nội - ngoại thất
cap cấp thấm thấm,
độ phủ cao, bề mặt
chai cứng, hỗ trợ
chống thấm, chống
rêu mốc</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>14.000</td></tr><tr><td>20</td><td>Sơn</td><td>Bột trét</td><td></td><td>QCVN
16:2019/BXD</td><td></td><td>Công ty
TNHH Sơn
NIPPON
PAINT Việt
Nam</td><td>Việt
Nam</td><td>Giá bán
tại địa
bàn
thành
phố Cao
Bằng</td><td></td><td></td></tr><tr><td></td><td></td><td>Bột trét ngoại thất
Nippon Weather –
Gard Skimcoat</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>7.727</td></tr><tr><td></td><td></td><td>Bột trét nội thất
Nippon Skimcoat
kinh tế</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>6.455</td></tr><tr><td></td><td></td><td>Sơn nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

|<image_33>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn lót nội thất cao
cấp Nippon Odour-
less Sealer</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>76.364</td></tr><tr><td></td><td></td><td>Sơn phủ nội thất
Nippon Vatex (màu
chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>30.000</td></tr><tr><td></td><td></td><td>Sơn phủ nội thất
chống nấm mốc
Nippon Matex (màu
chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>49.091</td></tr><tr><td></td><td></td><td>Sơn phủ nội thất
chịu chùi rửa
Nippon Odour-less
(màu chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>124.545</td></tr><tr><td></td><td></td><td>Sơn phủ nội thất
màng sơn mịn đẹp
Nippon Odour-less
All In One bóng
(màu chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>176.364</td></tr><tr><td></td><td></td><td>Sơn ngoại thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Sơn lót ngoại thất
cao cấp Nippon</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>131.818</td></tr></tbody></table>

|<image_34>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Weather-Gard
Sealer</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>Sơn lót ngoại thất
cao cấp gốc dầu
Nippon Hitex 5180
Sealer</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>134.545</td></tr><tr><td></td><td></td><td>Sơn phủ ngoại thất
Nippon Super Matex
(màu chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>79.091</td></tr><tr><td></td><td></td><td>Sơn phủ ngoại thất
chống thấm Nippon
Super-Gard (màu
chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>113.636</td></tr><tr><td></td><td></td><td>Sơn phủ ngoại thất
mang sơn bóng đẹp,
chống nóng, bền
màu Nippon
Weather-Gard (màu
chuẩn)</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>230.000</td></tr><tr><td></td><td></td><td>Chất chống thấm
Nippon WP 100
chống thấm</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>140.909</td></tr></tbody></table>

|<image_35>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn tạo gai Nippon
Texkote</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>37.273</td></tr><tr><td></td><td></td><td>Sơn lót gốc Alkyd
cho gỗ Nippon Bilac
Aluminum Wood
Primer</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>137.273</td></tr><tr><td>21</td><td>Sơn</td><td>Sơn màu tổng hợp</td><td>kg</td><td></td><td></td><td></td><td>Việt
nam</td><td></td><td></td><td>40.000</td></tr><tr><td>22</td><td>Sơn</td><td>JYMEC - SƠN LÓT
CHỐNG KIỀM NỘI
THẤT</td><td>Lít</td><td>TCVN
8652:2020</td><td></td><td>Công ty cổ
phần sơn
Jymec Việt
Nam</td><td>Việt
nam</td><td>Giá bán
tại địa
bàn tỉnh
Cao
Bằng</td><td></td><td>148.586</td></tr><tr><td></td><td></td><td>JYMEC - SƠN LÓT
CHỐNG KIỀM NỘI
THẤT ĐẶC BIỆT</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>156.456</td></tr><tr><td></td><td></td><td>JYMEC - SƠN LÓT
CHỐNG KIỀM
NGOẠI THẤT
CAO CẤP</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>210.505</td></tr><tr><td></td><td></td><td>JYMEC - SƠN LÓT
CHỐNG KIỀM
NGOẠI THẤT
ĐẶC BIỆT</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>232.828</td></tr></tbody></table>

|<image_36>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>SƠN BÓNG ÁNH
NGỌC TRAI NỘI
THẤT CAO CẤP</td><td>Lít</td><td>QCVN
16:2019/BXD</td><td></td><td></td><td></td><td></td><td></td><td>341.636</td></tr><tr><td></td><td></td><td>SƠN BÓNG NỘI
THẤT CAO CẤP</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>254.899</td></tr><tr><td></td><td></td><td>SƠN NỘI THẤT
CAO CẤP DỄ LAU
CHÙI</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>125.101</td></tr><tr><td></td><td></td><td>SƠN NƯỚC SIÊU
TRẮNG NỘI THẤT
CAO CẤP</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>108.990</td></tr><tr><td></td><td></td><td>SƠN NƯỚC NỘI
THẤT 3 IN 1</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>56.364</td></tr><tr><td></td><td></td><td>SƠN NƯỚC NỘI
THẤT ĐẸP HOÀN
HẢO</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>216.566</td></tr><tr><td></td><td></td><td>SƠN BÓNG
NGOẠI THẤT
CAO CẤP</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>291.717</td></tr><tr><td></td><td></td><td>SƠN BÓNG
CHỐNG NÓNG
NGOẠI THẤT
ĐẶC BIỆT</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>399.636</td></tr></tbody></table>

|<image_37>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>SƠN NGOẠI THẤT
CHỐNG PHAI
MÀU</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>200.909</td></tr><tr><td></td><td></td><td>SƠN NƯỚC
NGOẠI THẤT</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>161.616</td></tr><tr><td></td><td></td><td>SƠN NGOẠI THẤT
CLEAR PHỦ
BÓNG</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>226.000</td></tr><tr><td></td><td></td><td>SƠN NGOẠI THẤT
CHỐNG THẤM ĐA
NĂNG</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>222.879</td></tr><tr><td></td><td></td><td>SƠN NGOẠI THẤT
CHỐNG THẤM ĐA
MÀU</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>231.566</td></tr><tr><td></td><td></td><td>JYMEC - BỘT BẢ
NỘI VÀ NGOẠI
THẤT CAO CẤP</td><td>Kg</td><td>TCVN
7239:2014</td><td></td><td></td><td></td><td></td><td></td><td>11.545</td></tr><tr><td></td><td></td><td>JYMEC - BỘT BẢ
NGOẠI THẤT
CAO CẤP</td><td>Kg</td><td></td><td></td><td></td><td></td><td></td><td></td><td>13.023</td></tr><tr><td></td><td>Sơn</td><td>Popasealer - Sơn lót
kháng kiềm nội thất
cao cấp</td><td>Lít</td><td>TCVN
8652:2012</td><td></td><td>Công ty Cổ
phần Sản
xuất và</td><td>Việt
nam</td><td>Giá bán
tại địa
bàn tỉnh</td><td></td><td>110.000</td></tr></tbody></table>

|<image_38>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất
Thương mại
Sơn Popa
Việt Nam</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)
Cao
Bằng</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td>Supersealer - Sơn lót
kháng kiềm ngoại
thất cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>177.222</td></tr><tr><td></td><td>Popaguard Primer -
Sơn lót kháng kiềm
và kháng muối ngoại
thất cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>216.111</td></tr><tr><td></td><td>PopaEgg - Sơn phủ
nội thất</td><td>Lít</td><td>QCVN
16:2023/BXD</td><td></td><td></td><td></td><td></td><td></td><td>49.444</td></tr><tr><td></td><td>SuperWhite - Sơn
siêu trắng nội thất cao
cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>102.222</td></tr><tr><td></td><td>Popa Easy Clean -
Sơn lau chùi hiệu quả</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>120.000</td></tr><tr><td></td><td>Naturic - Sơn bóng
mờ nội thất cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>184.444</td></tr><tr><td></td><td>Puric - Sơn bóng
ngọc trai nội thất cao
cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>238.333</td></tr><tr><td></td><td>Greenic - Sơn siêu
bóng ngọc trai nội
thất cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>260.556</td></tr><tr><td></td><td>Hapex - Sơn ngoại
thất cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>142.222</td></tr></tbody></table>

|<image_39>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Qualitex - Sơn bóng
ngoại thất cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>293.889</td></tr><tr><td></td><td></td><td>Popaguard - Sơn siêu
bóng ngoại thất cao
cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>304.444</td></tr><tr><td></td><td></td><td>WaterGuard - Sơn
chống thấm trộn xi
măng cao cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>179.444</td></tr><tr><td></td><td></td><td>WaterShield - Sơn
chống thấm màu cao
cấp</td><td>Lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>205.000</td></tr><tr><td></td><td></td><td>Bột bả nội ngoại thất</td><td>kg</td><td>TCVN
7239:2014</td><td></td><td></td><td></td><td></td><td></td><td>13.750</td></tr><tr><td>24</td><td>Sơn</td><td>Sơn bán bóng ngoại
thất cao cấp E6000
nhãn hiệu Infor</td><td>lít</td><td>Quy chuẩn
16:2023 QCVN</td><td></td><td>CÔNG TY
CỔ PHẦN
INFOR
VIỆT NAM</td><td>Việt
Nam</td><td>Đã bao
gồm chi
phí vận
chuyển
đến
chân
công
trình</td><td></td><td>184.800</td></tr><tr><td></td><td></td><td>Sơn ngoại thất chống
thấm màu cao cấp
nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>156.500</td></tr><tr><td></td><td></td><td>Sơn bóng ngoại thất
cao cấp E8000 nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>229.800</td></tr></tbody></table>

|<image_40>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn bóng ngoại thất
Nano cao cấp nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>263.000</td></tr><tr><td></td><td></td><td>Sơn ngoại thất Clear
phủ bóng cao cấp
nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>144.000</td></tr><tr><td></td><td></td><td>Sơn mịn ngoại thất
cao cấp E500 nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>96.800</td></tr><tr><td></td><td></td><td>Sơn chống kiềm
ngoại thất cao cấp
nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>145.000</td></tr><tr><td></td><td></td><td>Sơn chống kiềm
ngoại thất ECO nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>97.900</td></tr><tr><td></td><td></td><td>Sơn chống kiềm
ngoại thất Nano cao
cấp nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>187.000</td></tr><tr><td></td><td></td><td>Sơn ngoại thất chống
thấm đa năng nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>155.600</td></tr><tr><td></td><td></td><td>Sơn bóng nội thất
E5000 nhãn hiệu
Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>189.500</td></tr></tbody></table>

|<image_41>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn bóng nội thất cao
cấp E7000 nhãn hiệu
Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>208.000</td></tr><tr><td></td><td></td><td>Sơn siêu bóng nội
thất Nano cao cấp
nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>235.000</td></tr><tr><td></td><td></td><td>Sơn nội thất bán bóng
A 68 nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>142.000</td></tr><tr><td></td><td></td><td>Sơn mịn nội thất
E100 nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>24.400</td></tr><tr><td></td><td></td><td>Sơn mịn nội thất
E200 nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>37.000</td></tr><tr><td></td><td></td><td>Sơn mịn nội thất cao
cấp E300 nhãn hiệu
Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>70.500</td></tr><tr><td></td><td></td><td>Sơn siêu trắng nội
thất Nano cao cấp
nhãn hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>82.300</td></tr><tr><td></td><td></td><td>Sơn chống kiềm nội
thất cao cấp nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>98.100</td></tr><tr><td></td><td></td><td>Sơn chống kiềm nội
thất Infor ECO nhãn
hiệu Infor</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>59.800</td></tr></tbody></table>

|<image_42>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn ngoại thất chống
thấm màu cao cấp
nhãn hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>162.900</td></tr><tr><td></td><td></td><td>Sơn bóng ngoại thất
cao cấp 7IN nhãn
hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>214.100</td></tr><tr><td></td><td></td><td>Sơn bán bóng ngoại
thất V800 nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>186.200</td></tr><tr><td></td><td></td><td>Sơn siêu bóng ngoại
thất Nano cao cấp
nhãn hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>254.000</td></tr><tr><td></td><td></td><td>Sơn ngoại thất Clear
phủ bóng cao cấp
nhãn hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>122.000</td></tr><tr><td></td><td></td><td>Sơn mịn ngoại thất
cao cấp V300 nhãn
hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>94.900</td></tr><tr><td></td><td></td><td>Sơn chống kiềm
ngoại thất cao cấp
nhãn hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>143.500</td></tr><tr><td></td><td></td><td>Sơn chống kiềm
ngoại thất ECO nhãn
hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>96.800</td></tr></tbody></table>

|<image_43>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn chống kiềm
ngoại thất Nano cao
cấp nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>225.100</td></tr><tr><td></td><td></td><td>Sơn ngoại thất chống
thấm đa năng nhãn
hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>145.100</td></tr><tr><td></td><td></td><td>Sơn bóng nội thất cao
cấp 5IN nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>174.000</td></tr><tr><td></td><td></td><td>Sơn bóng nội thất cao
cấp 7IN nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>191.400</td></tr><tr><td></td><td></td><td>Sơn siêu bóng nội
thất Nano cao cấp
nhãn hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>228.800</td></tr><tr><td></td><td></td><td>Sơn bán bóng nội thất
V600 nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>133.500</td></tr><tr><td></td><td></td><td>Sơn mịn nội thất
Sally S300 nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>24.400</td></tr><tr><td></td><td></td><td>Sơn mịn nội thất V50
nhãn hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>34.000</td></tr></tbody></table>

|<image_44>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th><th>Tiêu chuẩn
kỹ thuật</th><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr><tr><td></td><td></td><td>Sơn mịn nội thất cao
cấp V100 nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>71.000</td></tr><tr><td></td><td></td><td>Sơn nội thất chống
thấm sàn V209 nhãn
hiệu Visenlex</td><td>kg</td><td></td><td>25kg
( 1 bao 20kg
và 1 can
5lit)</td><td></td><td></td><td></td><td></td><td>30.300</td></tr><tr><td></td><td></td><td>Sơn siêu trắng nội
thất Nano cao cấp
Supe White nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>80.100</td></tr><tr><td></td><td></td><td>Sơn chống kiềm nội
thất ECO nhãn hiệu
Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>58.600</td></tr><tr><td></td><td></td><td>Sơn chống kiềm nội
thất cao cấp nhãn
hiệu Visenlex</td><td>lít</td><td></td><td></td><td></td><td></td><td></td><td></td><td>97.000</td></tr><tr><td>25</td><td>Sơn</td><td></td><td></td><td></td><td></td><td>Công ty Cổ
phần Quốc
tế AIG (Đ/c
cung cấp:
Công ty
TNHH</td><td>Việt
Nam</td><td></td><td></td><td>8.975</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>11.200</td></tr></tbody></table>

|<image_45>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th></tr></thead><tbody></tbody></table>

<table><thead><tr><th>Quy cách</th><th>Nhà sản
xuất
MTV
TVĐT
XD&amp;TM
Hồng Hà
Cao Bằng)</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr></tbody></table>

|<image_46>|


### VIETTEL AI RACE

### GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG

### QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP

### LÁT, NHỰA ĐƯỜNG, SƠN

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD637</th></tr></thead><tbody><tr><td></td><td>GIÁ VẬT LIỆU XÂY DỰNG TRÊN ĐỊA BÀN THÀNH PHỐ CAO BẰNG
QUÝ II NĂM 2025: CÁT, ĐÁ, CỬA/KHUNG CỬA NHÔM, GẠCH ỐP
LÁT, NHỰA ĐƯỜNG, SƠN</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Nhóm
vật liệu</th><th>Tên vật liệu/loại
vật liệu xây dựng
(*)</th><th>Đơn vị
tính (*)</th></tr></thead><tbody></tbody></table>

<table><thead><tr><th>Quy cách</th><th>Nhà sản
xuất</th><th>Xuất
xứ</th><th>Vận
chuyển
(*)</th><th>Ghi chú</th><th>Giá bán chưa bao gồm
thuế giá trị gia tăng)
(*)</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td>Thành phố Cao Bằng</td></tr></tbody></table>

|<image_47>|


