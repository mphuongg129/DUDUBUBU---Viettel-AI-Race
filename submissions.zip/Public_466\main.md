# Public_466

## Các bước lắp Điện Mặt trời

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_2>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_3>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tiêu chí</th><th>Điện mặt trời</th><th>Điện lưới nhà nước (EVN)</th></tr></thead><tbody><tr><td>Chi phí đầu tư
ban đầu</td><td>Cao (50 – 200 triệu tùy công
suất, thương hiệu, có/không
pin lưu trữ)</td><td>Không cần đầu tư, chỉ trả hóa đơn
hàng tháng</td></tr><tr><td>Chi phí vận
hành</td><td>Thấp (chủ yếu vệ sinh, bảo trì
định kỳ)</td><td>Thanh toán tiền điện hàng tháng, giá
có thể tăng theo chính sách</td></tr><tr><td>Tuổi thọ hệ
thống</td><td>20 – 25 năm (pin), 8 – 12
năm (inverter)</td><td>Phụ thuộc vào hạ tầng điện quốc gia</td></tr><tr><td>Tính ổn định</td><td>Bị ảnh hưởng bởi thời tiết
(mưa, nhiều mây sản lượng
giảm)</td><td>Ổn định, trừ khi mất điện cục bộ</td></tr><tr><td>Tính chủ động</td><td>Tự tạo điện, có thể kết hợp
pin lưu trữ để dùng khi mất
điện</td><td>Phụ thuộc vào hệ thống điện quốc gia</td></tr><tr><td>Môi trường</td><td>Năng lượng sạch, giảm CO₂,
thân thiện môi trường</td><td>Sản xuất điện từ nhiệt điện, thủy điện,
năng lượng hóa thạch gây phát thải</td></tr><tr><td>Khả năng mở
rộng</td><td>Có thể lắp thêm tấm pin nếu
còn diện tích mái</td><td>Không áp dụng cho cá nhân</td></tr><tr><td>Nhận xét chung</td><td>Điện mặt trời có lợi thế dài hạn về tiết kiệm chi phí và bảo vệ môi
trường, nhưng cần vốn đầu tư ban đầu lớn. Điện lưới nhà nước thuận</td><td></td></tr></tbody></table>

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tiêu chí</th><th>Điện mặt trời</th><th>Điện lưới nhà nước (EVN)</th></tr></thead><tbody><tr><td></td><td>tiện và ổn định hơn trong ngắn hạn, song chi phí phụ thuộc vào giá
điện và ít mang tính chủ động.</td><td></td></tr><tr><td></td><td></td><td></td></tr></tbody></table>

|<image_5>|

|<image_6>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD004</th></tr></thead><tbody><tr><td></td><td>Hướng dẫn tự lắp Điện Mặt Trời</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tiêu chí</th><th>Điện mặt trời</th><th>Điện lưới nhà nước (EVN)</th></tr></thead><tbody><tr><td></td><td></td><td></td></tr></tbody></table>

|<image_7>|

|<image_8>|


