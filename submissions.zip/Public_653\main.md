# Public_653

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Hệ điều hành</th><th>Tên hệ điều hành</th></tr></thead><tbody><tr><td>1</td><td></td><td>Windows 1.0 (1985)</td></tr><tr><td>2</td><td></td><td>Windows 2.0 (1987)</td></tr><tr><td>3</td><td></td><td>Windows 3.0 (1990)</td></tr><tr><td>4</td><td></td><td>Windows NT 3.1 (1993)</td></tr><tr><td>5</td><td></td><td>Windows 95 (1995)</td></tr><tr><td>6</td><td></td><td>Windows 98 (1998)</td></tr><tr><td>7</td><td></td><td>Windows 2000 (2000)</td></tr><tr><td>8</td><td></td><td>Windows XP (2001)</td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th></tr></thead><tbody><tr><td>9</td><td></td><td>Windows Vista (2007)</td></tr><tr><td>10</td><td></td><td>Windows 7</td></tr><tr><td>11</td><td></td><td>Windows 8
Windows 8.1</td></tr><tr><td>12</td><td></td><td>Windows 10 (2015)</td></tr><tr><td>13</td><td></td><td>Windows 11</td></tr></tbody></table>

|<image_5>|

|<image_6>|

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_11>|

|<image_12>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_13>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Bước 1</th><th>Chọn biểu tượng Windows hoặc nút Start (bắt đầu)</th><th></th></tr></thead><tbody><tr><td>Bước 2</td><td>Tìm biểu biểu tượng hình răng cưa nhỏ và nhấp chuột vào
biểu tượng</td><td></td></tr><tr><td>Bước 3</td><td>Cửa sổ cài dặt hệ thống sẽ được hiển thị để bạn lựa chọn</td><td></td></tr><tr><td>Bước 4</td><td>Nhấp chuột vào Hệ thống (System)</td><td></td></tr><tr><td>Bước 5</td><td>Nhấp chuột vào mục Hiển thị (Display)</td><td></td></tr><tr><td>Bước 6</td><td>Lựa chọn tính năng hiển thị</td><td></td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Minh hoạ</th><th>Tên gọi</th><th>Mô tả</th></tr></thead><tbody><tr><td>1</td><td></td><td>Brightness:
Điều chỉnh
độ sáng của
máy tính</td><td>Bạn có thể thấy một thanh trượt điều khiển</td></tr></tbody></table>

|<image_14>|

|<image_15>|

|<image_16>|

|<image_17>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th>Khi bạn kéo trượt sang phải, màu xanh hiển thị
nhiều hơn, màn hình sáng hơn; kéo trượt sang trái,
màu xanh hiển thị ít hơn, màn hình tối hơn.
Nếu bạn hoàn toàn không nhìn thấy thanh trượt
điều khiển, có nghĩa là máy tính của quý vị không
thể điều chỉnh độ sáng màn hình.
Nếu trường hợp này xảy ra, đừng lo lắng! Đây chỉ
là cách thiết lập ánh sáng phù hợp cho màn hình.
Bạn hãy kiểm tra và sử dụng các nút điều khiển
trên màn hình, rất nhiều màn hình đã thiết kế sẵn
các phím cơ, tìm và đọc hướng dẫn sử dụng đi
kèm với màn hình để tìm hiểu chính xác cách
chúng hoạt động.</th></tr></thead><tbody><tr><td>2</td><td></td><td>Night light:
Ánh sáng ban
đêm</td><td>Nhấn vào biểu tượng hoặc kéo thanh trượt để tăng
độ sáng màn hình, điều này sẽ giúp hạn chế tác
động tiêu cực khi bạn làm việc trong điều kiện
thiếu ánh sáng.</td></tr><tr><td>3</td><td></td><td>Scale: Tăng
giảm kích cỡ
của ký tự,
biểu tượng
ứng dụng và
các mục khác</td><td>Lựa chọn tỷ lệ kích cỡ sao cho bạn thấy thoải mái
nhất</td></tr></tbody></table>

|<image_18>|

|<image_19>|

|<image_20>|

|<image_21>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th>trên màn hình
destop</th><th></th></tr></thead><tbody><tr><td>4</td><td></td><td>Display
resolution:
Chỉnh sửa độ
phân giải
màn hình phù
hợp với kích
cỡ của thiết bị</td><td>Độ phân giải tốt nhất cho màn hình của bạn là độ
phân giải được khuyến nghị (được đánh dấu là
recommended). Độ phân giải này sẽ cung cấp
hình ảnh rõ ràng và sắc nét nhất.
Việc sử dụng độ phân giải thấp hơn có thể khiến
văn bản và hình ảnh bị mờ.
Việc sử dụng độ phân giải cao hơn có thể khiến
văn bản và hình ảnh trở nên nhỏ và khó đọc.</td></tr><tr><td>5</td><td></td><td>Display
orientation:
Tính năng
xoay màn
hình</td><td>Chế độ Landscape cung cấp nhiều không gian
hiển thị hơn so với chế độ Portrait, do đó bạn có
thể xem nhiều nội dung hơn cùng một lúc. Điều
này đặc biệt hữu ích cho các ứng dụng như bảng
tính, trình duyệt web và các công cụ chỉnh sửa văn
bản.</td></tr></tbody></table>

|<image_22>|

|<image_23>|

|<image_24>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>Minh họa</th><th>Tên gọi</th><th>Mô tả</th></tr></thead><tbody><tr><td>1</td><td></td><td>Date &amp; Time
(ngày và giờ)</td><td>Cài đặt ngày giờ tự động
- Tìm nút Cài đặt múi giờ tự động (Set
time zone automatically) trên màn hình.
Di chuyển hoặc lựa chọn để ở Bật (On).
Thiết bị của bạn sẽ chuyển sang On và
nút trượt có màu xanh dương.
- Máy tính sẽ tự động chuyển đổi múi giờ
khi bạn di chuyển đến quốc gia khác nếu
bạn đã bật cài đặt "Tự động đặt múi giờ".
- Bạn có thể chuyển sang chế độ Off để cài
đặt thủ công.
Cài đặt ngày giờ thủ công
- Bước 1: chọn Time Zone (Múi giờ) là
(ITC+ 07:00) Bangkok, Hanoi, Jakarta
khi bạn ở bất kỳ đâu trên lãnh thổ Việt
Nam.
- Bước 2: Tiếp tục kéo xuống và xem bên
dưới Cài đặt ngày và giờ thủ công (Set
the date and time manually) và nhấp vào
nút Thay đổi (Change). Một cửa sổ hội
thoại bật lên hiển thị ngày và giờ hiện tại.
- Bước 3: Nhấp chuột vào từng ô ngày,
tháng và năm để chọn ngày từ danh sách
xuất hiện.
- Bước 4: Nhấp vào ô giờ và phút để chọn
giờ.</td></tr></tbody></table>

|<image_25>|

|<image_26>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th>- Bước 5: Khi bạn đã hài lòng với ngày và
giờ được nhập, Nhấp thay đổi (Change)
để cài đặt hoặc nhấp hủy (Cancel) để hủy
việc cài đặt.</th></tr></thead><tbody><tr><td>2</td><td></td><td>Language &amp;
Region (Ngôn
ngữ và khu vực)</td><td>Trong menu bên phải, nhấp chuột vào Language
&amp; Region (Ngôn ngữ và khu vực)
Tại Ô bên cạnh hoặc bên dưới của Ngôn ngữ
hiển thị (Windows Display Language), bạn có
thể lựa chọn ngôn ngữ được gợi ý.
Để thay đổi nó sang một ngôn ngữ khác
- Tìm hình vuông có dấu cộng bên cạnh
Thêm một ngôn ngữ ưa thích (Add a
Preferred language) trong Windows 10
hoặc Thêm một ngôn ngữ (Add a
language) trong Windows 11 và nhấp
vào đó.
- Một hộp bật lên yêu cầu quý vị Chọn
ngôn ngữ để cài đặt (Choose a language
to install). Kéo xuống danh sách để tìm
tên ngôn ngữ hoặc nhập ngôn ngữ cần
tìm kiếm.
- Nhấp vào ngôn ngữ rồi nhấp vào nút
Tiếp theo (Next).
Trong ô tiếp theo, nhấp Cài đặt làm ngôn ngữ
hiển thị của tôi (Set as my Windows display</td></tr></tbody></table>

|<image_27>|

|<image_28>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th></th><th></th><th></th><th>language), để ấn định ngôn ngữ này sử dụng cho
máy tính của bạn. Sau đó nhấp Cài đặt (Install).</th></tr></thead><tbody><tr><td>3</td><td></td><td>Country or
Region: (Quốc
gia hoặc khu
vực)</td><td>Lựa chọn “Vietnam” hoặc bất kỳ quốc gia
nào bạn mong muốn</td></tr><tr><td>4</td><td></td><td>Regional format</td><td>Lựa chọn tiếng Việt (Vietnamese (Vietnam))
hoặc ngôn ngữ bạn muốn sử dụng
Để kiểm tra xem định dạng khu vực của bạn
đã thiết lập có đúng hay không, xem thông
tin bên dưới Định dạng khu vực (Regional
format data). Quý vị sẽ thấy rằng ngày và giờ
được viết theo cách của Việt Nam
ngày/tháng/năm. Ví dụ:</td></tr></tbody></table>

|<image_29>|

|<image_30>|

|<image_31>|

|<image_32>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_33>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD653</th></tr></thead><tbody><tr><td></td><td>HỆ ĐIỀU HÀNH WINDOWS</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_34>|


