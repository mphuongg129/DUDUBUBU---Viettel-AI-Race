# Public_668

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD668</th></tr></thead><tbody><tr><td></td><td>VẼ QUY ƯỚC LÒ XO</td><td>Lần ban hành: 1</td></tr></tbody></table>

|<image_1>|

|<image_2>|

|<image_3>|

|<image_4>|

|<image_5>|



<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD668</th></tr></thead><tbody><tr><td></td><td>VẼ QUY ƯỚC LÒ XO</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên gọi lò xo</th><th></th><th>Hình vẽ quy ước</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td>Hình chiếu</td><td>Hình cắt</td><td>Khi chiếu dây mặt
cắt của dây ≤ 2mm</td></tr><tr><td>Lò
xo
nén</td><td>Lò xo
nén, dây
tròn, ở
hai đầu
ép lại
3/4 vòng
và mài
bằng.</td><td></td><td></td><td></td></tr><tr><td></td><td>Lò xo
nén, dây
hình chữ
nhật, ở
hai đầu
ép lại
3/4 vòng
và mài
bằng.</td><td></td><td></td><td></td></tr><tr><td></td><td>Lò xo
nén hình
nón dây
tròn, ở
hai đầu
ép lại
3/4 vòng</td><td></td><td></td><td></td></tr></tbody></table>

|<image_6>|

|<image_7>|

|<image_8>|

|<image_9>|

|<image_10>|

|<image_11>|

|<image_12>|

|<image_13>|

|<image_14>|


<table><thead><tr><th>Tên gọi lò xo
và mài
bằng.
Lò xo
nén, dây
hình chữ
nhật, ở
hai đầu
mài
bằng.</th><th></th><th>Hình vẽ quy ước</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td>Hình chiếu</td><td>Hình cắt</td><td>Khi chiếu dây mặt
cắt của dây ≤ 2mm</td></tr><tr><td></td><td>và mài
bằng.</td><td></td><td></td><td></td></tr><tr><td></td><td>Lò xo
nén, dây
hình chữ
nhật, ở
hai đầu
mài
bằng.</td><td></td><td></td><td></td></tr><tr><td>Lò
xo
kéo</td><td>Lò xo
kéo, dây
tròn có
móc
nằm
trong hai
mặt
phẳng
vuông
góc với
nhau.</td><td></td><td></td><td></td></tr></tbody></table>

|<image_15>|

|<image_16>|

|<image_17>|

|<image_18>|

|<image_19>|

|<image_20>|


<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD668</th></tr></thead><tbody><tr><td></td><td>VẼ QUY ƯỚC LÒ XO</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>Tên gọi lò xo</th><th></th><th>Hình vẽ quy ước</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td>Hình chiếu</td><td>Hình cắt</td><td>Khi chiếu dây mặt
cắt của dây ≤ 2mm</td></tr><tr><td>Lò
xo
xoắn
ốc</td><td>Lò xo
xoắn ốc
phẳng
có hai
móc ở
hai đầu</td><td></td><td></td><td></td></tr><tr><td>Lò
xo
đĩa</td><td>Chồng
lò xo đĩa
đặt đối
nhau</td><td></td><td></td><td></td></tr><tr><td>Lò
xo lá</td><td>Lò xo lá</td><td></td><td></td><td></td></tr><tr><td>Lò
xo
nhíp</td><td>Lò xo
nhíp</td><td></td><td></td><td></td></tr></tbody></table>

|<image_21>|

|<image_22>|

|<image_23>|

|<image_24>|

|<image_25>|

|<image_26>|

|<image_27>|

|<image_28>|

|<image_29>|

|<image_30>|


