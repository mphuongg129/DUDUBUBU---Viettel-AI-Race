# Public_647

## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th></th><th></th><th>TÊN VẬT
LIỆU</th><th></th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>I</td><td></td><td></td><td>VẬT LIỆU XÂY DỰNG CƠ BẢN</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td></td><td></td><td>Xi măng</td><td></td><td></td><td>1. Xác định độ mịn</td><td></td><td></td><td>TCVN 4030:2003</td><td></td><td>TCVN 2682:2009
(Đối với xi măng poóc
lăng)/ TCVN 6260:2009
(Đối với xi măng poóc lăng
hỗn hơp)</td><td></td><td></td><td>- Xi măng bao: Lấy nguyên 01 bao
- Xi măng rời hoặc chứa trong silo: tối thiểu
10 kg</td><td>- Cứ một lô 50 tấn lấy mẫu một lần.
- Mỗi lô nhỏ hơn 50 tấn xem như một lô.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2. Khối lượng riêng</td><td></td><td></td><td>TCVN 4030:2003</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>3. Xác định độ dẻo tiêu chuẩn</td><td></td><td></td><td>TCVN 6017:2015</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>4. Xác định thời gian đông kết</td><td></td><td></td><td>TCVN 6017:2015</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>5. Xác định cường đ uốn và nén</td><td></td><td></td><td>TCVN 6016:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>6. Độ ổn định thể tích Le chatelier</td><td></td><td></td><td>TCVN 6017:2015</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>7. *Hàm lượng anhydric</td><td></td><td>TCVN 141:2008</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>sunphuric (SO3)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>8. *Hàm lượng magiê oxit (MgO)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>(Đối với xi măng poóc lăng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>9. *Hàm lượng mất khi nung</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>(MKN) (Đối với xi măng poóc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>lăng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>10. *Hàm lượng cặn không tan</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>(CKT) (Đối với xi măng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>poóc lăng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>11. *Hàm lượng kiềm quy đổi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>(Na2O qđ) (Đối với xi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>măng poóc lăng)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>12. *Độ nở autoclave (Đối với xi</td><td></td><td>TCVN 8877:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>măng poóc lăng hỗn hợp)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>1. *Tổng hàm lượng ôxit SiO2 +</td><td></td><td>TCVN 8262:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Al2O3 + Fe2O3</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2. Hàm lượng canxi ôxit tự do</td><td></td><td>TCVN 141:2008</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>(CaOtd)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>3. Hàm lượng lưu huỳnh, hợp chất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>lưu huỳnh tính quy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>đổi ra SO3</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td></td><td></td><td>Tro bay dùng
cho bê tông và
vữa xây</td><td></td><td></td><td>4. Hàm lượng mất khi nung</td><td></td><td>TCVN 8262:2009</td><td></td><td></td><td>TCVN 10302:2014</td><td></td><td></td><td>Mẫu đơn được lấy ở ít nhất 5 vị trí khác nhau
trong lô, mỗi vị trí lấy tối thiểu 2 kg. Mẫu thử
được lấy từ hỗn hợp các mẫu đơn theo
phương pháp chia tư</td><td>Tro bay cùng chủng loại, cùng cấp chất
lượng lĩnh vực sử dụng được tinh chế
theo cùng quy trình công nghệ và với cỡ
quy mô cung cấp liên tục 300 tấn/lần,
được coi là 1 lô sản phẩm. Trường hợp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>(MKN)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>5. Hàm lượng kiềm có hại (kiềm</td><td></td><td>TCVN 6882:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hòa tan)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>6. *Độ ẩm</td><td></td><td></td><td>TCVN 8262:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>TCVN 2682:2009</th></tr></thead><tbody><tr><td>(Đối với xi măng poóc</td></tr><tr><td>lăng)/ TCVN 6260:2009</td></tr><tr><td>(Đối với xi măng poóc lăng</td></tr><tr><td>hỗn hơp)</td></tr></tbody></table>

<table><thead><tr><th>- Xi măng bao: Lấy nguyên 01 bao</th></tr></thead><tbody><tr><td>- Xi măng rời hoặc chứa trong silo: tối thiểu</td></tr><tr><td>10 kg</td></tr></tbody></table>

<table><thead><tr><th>- Cứ một lô 50 tấn lấy mẫu một lần.</th></tr></thead><tbody><tr><td>- Mỗi lô nhỏ hơn 50 tấn xem như một lô.</td></tr></tbody></table>

<table><thead><tr><th>Tro bay cùng chủng loại, cùng cấp chất</th></tr></thead><tbody><tr><td>lượng lĩnh vực sử dụng được tinh chế</td></tr><tr><td>theo cùng quy trình công nghệ và với cỡ</td></tr><tr><td>quy mô cung cấp liên tục 300 tấn/lần,</td></tr></tbody></table>

<table><thead><tr><th>Mẫu đơn được lấy ở ít nhất 5 vị trí khác nhau</th></tr></thead><tbody><tr><td>trong lô, mỗi vị trí lấy tối thiểu 2 kg. Mẫu thử</td></tr><tr><td>được lấy từ hỗn hợp các mẫu đơn theo</td></tr><tr><td>phương pháp chia tư</td></tr></tbody></table>

<table><thead><tr><th>Tro bay dùng</th></tr></thead><tbody><tr><td>cho bê tông và</td></tr><tr><td>vữa xây</td></tr></tbody></table>

|<image_1>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>7. *Lượng sót sàng 45mm</td><td></td><td></td><td></td><td>Theo phụ lục A của</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cung cấp không đủ 300 tấn/lần thì vẫn
coi như là 1 lô đủ.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 8827:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8. *Lượng nước yêu cầu so với</td><td></td><td></td><td>Theo TCVN</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>mẫu đối chứng</td><td></td><td></td><td>8825:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>9. Hàm lượng ion clo (Cl-)</td><td></td><td></td><td>TCVN 8826:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10. Hoạt độ phóng xạ tự nhiên</td><td></td><td></td><td>Phụ lục A của</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Aeff</td><td></td><td></td><td>TCVN 10302:2014</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>Cát cho bê
tông và vữa</td><td>1. Thành phần hạt</td><td></td><td></td><td></td><td>TCVN 7572-2 :</td><td></td><td>TCVN 7570:2006</td><td></td><td></td><td>Căn cứ theo mục 4.1.2 TCVN 7572- 1:2006
(lấy tối thiều 20kg để thí nghiệm đủ các chỉ
tiêu).</td><td></td><td></td><td>Cứ một lô 350 m3 hoặc 500 tấn lấy mẫu
một lần.
(Căn cứ theo mục 3.2 TCVN 7572-
1:2006)</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Khối lượng riệng, khối lượng</td><td></td><td></td><td>TCVN 7572-4 :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>thể tích và độ hút nước.</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Khối lượng thể tích xốp và độ</td><td></td><td></td><td>TCVN 7572-6 :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hổng</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Hàm lượng các tạp chất (bùn,</td><td></td><td></td><td>TCVN 7572-8 :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>bụi, sét) và hàm lượng sét cục</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>5. *Tạp chất hữu cơ</td><td></td><td></td><td></td><td>TCVN 7572-9</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>6. *Hàm lượng ion clo (Cl-)</td><td></td><td></td><td></td><td>TCVN 7572-15</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. *Khả năng phản ứng kiềm -</td><td></td><td></td><td>TCVN 7572-14 :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>silic</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>Cát nghiền</td><td>1. Thành phần hạt</td><td></td><td></td><td></td><td>TCVN 7572-2:</td><td></td><td>TCVN 9205:2012</td><td></td><td></td><td>Căn cứ theo mục 4.1.2 TCVN 7572- 1:2006
(lấy tối thiều 20kg để thí nghiệm đủ các chỉ
tiêu).</td><td></td><td></td><td>Cứ một lô 350 m3 hoặc 500 tấn lấy mẫu
một lần. Mỗi lô nhỏ hơn 500 tấn xem
như một một lô
(Căn cứ theo mục 3.2 TCVN 7572-
1:2006)</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Hàm lượng hạt có kích thước</td><td></td><td>TCVN 9205: 2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nhỏ hơn 75µm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3 *Hàm lượng hạt sét</td><td></td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>8:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>4. *Hàm lượng ion clo (Cl-)</td><td></td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>15:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. *Khả năng phản ứng kiềm -</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>silic</td><td></td><td></td><td>14:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>Đá dăm đổ bê
tông</td><td>1. Xác định thành phần hạt</td><td></td><td></td><td></td><td>TCVN 7572-</td><td></td><td>TCVN 7570:2006</td><td></td><td></td><td></td><td>Lấy (50 - 250) kg tuỳ theo cỡ đá :</td><td></td><td>Cứ một lô 200 m3 lấy mẫu một lần. Mỗi
lô nhỏ hơn 200m3 xem như một một lô
(Căn cứ theo mục 3.2 TCVN 7572-</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2:2006</td><td></td><td></td><td></td><td></td><td></td><td>- Đá 5-10; 5-20: Lấy 50 kg</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Khối lượng riệng, khối lượng</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td>- Đá 5-40; 10-40:Lấy 110 kg</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>thể tích và độ hút nước</td><td></td><td></td><td>4:2006</td><td></td><td></td><td></td><td></td><td></td><td>- Đá 5-70; 10-70: Lấy 150 kg</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>cung cấp không đủ 300 tấn/lần thì vẫn</th></tr></thead><tbody><tr><td>coi như là 1 lô đủ.</td></tr></tbody></table>

<table><thead><tr><th>Cứ một lô 350 m3 hoặc 500 tấn lấy mẫu</th></tr></thead><tbody><tr><td>một lần.</td></tr><tr><td>(Căn cứ theo mục 3.2 TCVN 7572-</td></tr><tr><td>1:2006)</td></tr></tbody></table>

<table><thead><tr><th>Cát cho bê</th></tr></thead><tbody><tr><td>tông và vữa</td></tr></tbody></table>

<table><thead><tr><th>Căn cứ theo mục 4.1.2 TCVN 7572- 1:2006</th></tr></thead><tbody><tr><td>(lấy tối thiều 20kg để thí nghiệm đủ các chỉ</td></tr><tr><td>tiêu).</td></tr></tbody></table>

<table><thead><tr><th>Cứ một lô 350 m3 hoặc 500 tấn lấy mẫu</th></tr></thead><tbody><tr><td>một lần. Mỗi lô nhỏ hơn 500 tấn xem</td></tr><tr><td>như một một lô</td></tr><tr><td>(Căn cứ theo mục 3.2 TCVN 7572-</td></tr><tr><td>1:2006)</td></tr></tbody></table>

<table><thead><tr><th>Căn cứ theo mục 4.1.2 TCVN 7572- 1:2006</th></tr></thead><tbody><tr><td>(lấy tối thiều 20kg để thí nghiệm đủ các chỉ</td></tr><tr><td>tiêu).</td></tr></tbody></table>

<table><thead><tr><th>Cứ một lô 200 m3 lấy mẫu một lần. Mỗi</th></tr></thead><tbody><tr><td>lô nhỏ hơn 200m3 xem như một một lô</td></tr><tr><td>(Căn cứ theo mục 3.2 TCVN 7572-</td></tr></tbody></table>

<table><thead><tr><th>Đá dăm đổ bê</th></tr></thead><tbody><tr><td>tông</td></tr></tbody></table>

|<image_2>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Xác định khối lượng thể tích</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td>- Đá 20-70cm: Lấy 250 kg
(Căn cứ theo bảng 3 TCVN 7572- 1:2006)</td><td></td><td></td><td>1:2006) (Đối với đá dăm dùng cho bê
tông đổ tại chỗ)</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>xốp và độ hổng</td><td></td><td></td><td>6:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Xác định độ nén dập và hệ số</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hóa mềm của cốt liệu lớn</td><td></td><td></td><td>11:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Xác định hàm lượng hạt thoi</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>dẹt trong cốt liệu lớn</td><td></td><td></td><td>13:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>6. Xác định lượng bùn, bụi, sét</td><td></td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>8:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>7. *Hàm lượng ion clo (Cl-)</td><td></td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>15:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8. *Khả năng phản ứng kiềm -</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>silic</td><td></td><td></td><td>14:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>9. Xác định độ hao mòn khi va</td><td></td><td>TCVN 7572-
12:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>đập của cốt liệu lớn trong</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>máy Los Angeles</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>Gạch đất sét
nung</td><td></td><td>1. *Xác định kích thước hình học</td><td></td><td></td><td>TCVN 6355-</td><td></td><td>TCVN
1451:1998 (Đối với gạch
đặc); TCVN 1450:2009
(Đối với gạch rỗng)</td><td></td><td></td><td>Chỉ tiêu 1: cần 50 viên; các chỉ tiêu còn lại
cần 05 viên/chỉ tiêu).
(Căn cứ theo mục 5.1.2 TCVN 1451:1998 và
TCVN 1450:2009)</td><td></td><td></td><td>Cứ một lô 100.000 viên lấy mẫu một lần.
Mỗi lô nhỏ hơn 100.000 viên xem như
một lô.
(Căn cứ theo mục 5.1.1 TCVN
1451:1998 và TCVN 1450:2009</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>và khuyết tật ngoại quan</td><td></td><td></td><td>1:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2. Xác định cường độ bền nén</td><td></td><td></td><td></td><td>TCVN 6355-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Xác định cường độ bền uốn</td><td></td><td></td><td></td><td>TCVN 6355-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>3:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>4. Xác định độ hút nước</td><td></td><td></td><td></td><td>TCVN 6355-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>4:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>5. *Xác định khối lượng thể tích</td><td></td><td></td><td></td><td>TCVN 6355-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>5:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>6. *Xác định vết tróc do vôi</td><td></td><td></td><td></td><td>TCVN 6355-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>7:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. *Xác định độ rỗng (đối với</td><td></td><td></td><td>TCVN 6355-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>gạch rỗng)</td><td></td><td></td><td>6:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1.*Xác định kích thước hình học</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Lấy ngẫu nhiên 10 viên ở các vị trí</td><td></td><td></td><td>Đối với gạch có kích thước tương đương</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>và khuyết tật ngoại quan</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>Gạch bê tông
cốt liệu xi
măng</td><td></td><td>2. Xác định cường độ bền nén</td><td></td><td>TCVN 6477:2016</td><td></td><td></td><td>TCVN 6477:2016</td><td></td><td></td><td></td><td>khác nhau đại diện cho lô làm mẫu</td><td></td><td></td><td>thể tích lớn hơn 10 dm3/viên, cỡ lô quy</td><td></td></tr><tr><td></td><td></td><td></td><td>3. Xác định độ hút nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thử, đã đủ 28 ngày kể từ ngày sản xuất.</td><td></td><td></td><td>định là 50000 viên; đối với gạch có kích</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Không lấy những viên bị hư hại do quá trình</td><td></td><td></td><td>thước tương đương thể tích lớn hơn 2</td><td></td></tr><tr><td></td><td></td><td></td><td>4. Xác định độ rỗng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>vận chuyển để làm mẫu thử (Căn cứ theo mục</td><td></td><td></td><td>dm3/viên đến 10 dm3/viên, cỡ lô quy</td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>- Đá 20-70cm: Lấy 250 kg</th></tr></thead><tbody><tr><td>(Căn cứ theo bảng 3 TCVN 7572- 1:2006)</td></tr></tbody></table>

<table><thead><tr><th>1:2006) (Đối với đá dăm dùng cho bê</th></tr></thead><tbody><tr><td>tông đổ tại chỗ)</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7572-</th></tr></thead><tbody><tr><td>12:2006</td></tr></tbody></table>

<table><thead><tr><th>Cứ một lô 100.000 viên lấy mẫu một lần.</th></tr></thead><tbody><tr><td>Mỗi lô nhỏ hơn 100.000 viên xem như</td></tr><tr><td>một lô.</td></tr><tr><td>(Căn cứ theo mục 5.1.1 TCVN</td></tr><tr><td>1451:1998 và TCVN 1450:2009</td></tr></tbody></table>

<table><thead><tr><th>TCVN</th></tr></thead><tbody><tr><td>1451:1998 (Đối với gạch</td></tr><tr><td>đặc); TCVN 1450:2009</td></tr><tr><td>(Đối với gạch rỗng)</td></tr></tbody></table>

<table><thead><tr><th>Chỉ tiêu 1: cần 50 viên; các chỉ tiêu còn lại</th></tr></thead><tbody><tr><td>cần 05 viên/chỉ tiêu).</td></tr><tr><td>(Căn cứ theo mục 5.1.2 TCVN 1451:1998 và</td></tr><tr><td>TCVN 1450:2009)</td></tr></tbody></table>

<table><thead><tr><th>Gạch đất sét</th></tr></thead><tbody><tr><td>nung</td></tr></tbody></table>

<table><thead><tr><th>Gạch bê tông</th></tr></thead><tbody><tr><td>cốt liệu xi</td></tr><tr><td>măng</td></tr></tbody></table>

|<image_3>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th></th><th></th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>5. *Xác định độ thấm nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>5.1 TCVN 6477:2016). Lưu ý: Chỉ tiêu 1
cần 10 viên; chỉ tiêu 2, 4, 5 cần 3 viên;
chỉ tiêu 3 cần 5 viên.</td><td>định là 100000 viên; đối với loại gạch có
kích thước tương đương thể tích 2
dm3/viên hoặc nhỏ hơn, cỡ lô quy định
là 200000 viên.</td></tr><tr><td>8</td><td>Gạch bê tông
nhẹ</td><td></td><td></td><td></td><td>1. *Xác định kích thước hình học</td><td></td><td>TCVN 9030-2017</td><td></td><td></td><td>TCVN 7959-2017
TCVN 9029-2017</td><td></td><td></td><td>- Sản phẩm bê tông bọt, khí không chưng áp:
ít nhất 15 viên ngẫu nhiên trong lô. (Áp dụng
cho chỉ tiêu 1).
- Sản phẩm bê tông khí chưng áp: ít nhất 10
viên dạng khối hoặc 5 viên dạng tấm nhỏ. (Áp
dụng cho chỉ tiêu 1).
(Căn cứ theo mục 4.2 TCVN 9030:2017).
Các chỉ tiêu còn lại cần 01 viên/chỉ tiêu.</td><td>- Sản phẩm bê tông bọt, khí không
chưng áp: Cỡ lô 200m3.
- Sản phẩm bê tông khí chưng áp:Cỡ lô
500m3.
Nếu số lượng nhỏ hơn quy định trên thì
cũng coi là 1 lô.
(Căn cứ theo mục 4.1 TCVN 9030:2017)</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>và khuyết tật ngoại quan</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>2. Xác định khối lượng thể tích</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>khô</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>3. Xác định cường độ bền nén</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>4. Xác định độ co khô</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>Thép cốt bê
tông (Thép gai
và thép tròn
trơn)</td><td></td><td></td><td></td><td>1. Khối lượng trên 1 m dài và sai</td><td></td><td>TCVN 1651: 2018</td><td></td><td></td><td>TCVN 1651:2018</td><td></td><td></td><td>Mỗi loại đường kính thép lấy 01 tổ mẫu bao
gồm: Cắt 03 thanh dài 1m để thí nghiệm và 03
thanh dài 1 m để lưu – thí nghiệm đối chứng,
lưu 1 tuần kể từ khi có kết quả thí nghiệm</td><td>Cứ 50 tấn/1 tổ mẫu/1 loại đường kính.
Mỗi lô nhỏ hơn 50 tấn xem như một lô.
(Căn cứ theo mục 11.3.2.2 TCVN 1651-
2:2018)</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>lệch cho phép</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>2. Khả năng chịu kéo (Giới hạn
chảy, giới hạn bền)</td><td></td><td></td><td></td><td>TCVN 197-1:2014</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 7937-</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1:2013</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ISO 15630-1:2010</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. Khả năng chịu uốn</td><td></td><td></td><td></td><td>TCVN 198:2008</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7937-1:2013</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ISO 15630-1:2010</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>4. Độ giãn dài</td><td></td><td></td><td></td><td>TCVN 197-1:2014</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TCVN 7937-</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>1:2013</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ISO 15630-1:2010</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td></td><td>Thép Cacbon</td><td></td><td>1. *Xác định thành phần hóa</td><td></td><td></td><td></td><td>TCVN 1821 : 2009</td><td></td><td></td><td>Theo chỉ dẫn kỹ thuật của</td><td></td><td>Mỗi loại thép lấy 01 tổ mẫu 3 thanh 70cm.
(Căn cứ theo các phục lục B, C, D, E của
TCVN 197-1:2014).</td><td>Cứ 50 tấn/1 tổ mẫu/1 loại kích thước.
Mỗi lô nhỏ hơn 50 tấn xem như một lô.
(Căn cứ theo mục 6 TCVN 6522:2008).</td></tr><tr><td></td><td></td><td>cán nóng, cán</td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td>dự án hoặc chứng chỉ của</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>nguội (thép</td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td>nhà sản xuất đã được CĐT</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>hình, ống</td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td>phê duyệt.</td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>5.1 TCVN 6477:2016). Lưu ý: Chỉ tiêu 1</th></tr></thead><tbody><tr><td>cần 10 viên; chỉ tiêu 2, 4, 5 cần 3 viên;</td></tr><tr><td>chỉ tiêu 3 cần 5 viên.</td></tr></tbody></table>

<table><thead><tr><th>định là 100000 viên; đối với loại gạch có</th></tr></thead><tbody><tr><td>kích thước tương đương thể tích 2</td></tr><tr><td>dm3/viên hoặc nhỏ hơn, cỡ lô quy định</td></tr><tr><td>là 200000 viên.</td></tr></tbody></table>

<table><thead><tr><th>- Sản phẩm bê tông bọt, khí không chưng áp:</th></tr></thead><tbody><tr><td>ít nhất 15 viên ngẫu nhiên trong lô. (Áp dụng</td></tr><tr><td>cho chỉ tiêu 1).</td></tr><tr><td>- Sản phẩm bê tông khí chưng áp: ít nhất 10</td></tr><tr><td>viên dạng khối hoặc 5 viên dạng tấm nhỏ. (Áp</td></tr><tr><td>dụng cho chỉ tiêu 1).</td></tr><tr><td>(Căn cứ theo mục 4.2 TCVN 9030:2017).</td></tr><tr><td>Các chỉ tiêu còn lại cần 01 viên/chỉ tiêu.</td></tr></tbody></table>

<table><thead><tr><th>- Sản phẩm bê tông bọt, khí không</th></tr></thead><tbody><tr><td>chưng áp: Cỡ lô 200m3.</td></tr><tr><td>- Sản phẩm bê tông khí chưng áp:Cỡ lô</td></tr><tr><td>500m3.</td></tr><tr><td>Nếu số lượng nhỏ hơn quy định trên thì</td></tr><tr><td>cũng coi là 1 lô.</td></tr><tr><td>(Căn cứ theo mục 4.1 TCVN 9030:2017)</td></tr></tbody></table>

<table><thead><tr><th>Gạch bê tông</th></tr></thead><tbody><tr><td>nhẹ</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7959-2017</th></tr></thead><tbody><tr><td>TCVN 9029-2017</td></tr></tbody></table>

<table><thead><tr><th>2. Khả năng chịu kéo (Giới hạn</th></tr></thead><tbody><tr><td>chảy, giới hạn bền)</td></tr></tbody></table>

<table><thead><tr><th>Thép cốt bê</th></tr></thead><tbody><tr><td>tông (Thép gai</td></tr><tr><td>và thép tròn</td></tr><tr><td>trơn)</td></tr></tbody></table>

<table><thead><tr><th>Mỗi loại đường kính thép lấy 01 tổ mẫu bao</th></tr></thead><tbody><tr><td>gồm: Cắt 03 thanh dài 1m để thí nghiệm và 03</td></tr><tr><td>thanh dài 1 m để lưu – thí nghiệm đối chứng,</td></tr><tr><td>lưu 1 tuần kể từ khi có kết quả thí nghiệm</td></tr></tbody></table>

<table><thead><tr><th>Cứ 50 tấn/1 tổ mẫu/1 loại đường kính.</th></tr></thead><tbody><tr><td>Mỗi lô nhỏ hơn 50 tấn xem như một lô.</td></tr><tr><td>(Căn cứ theo mục 11.3.2.2 TCVN 1651-</td></tr><tr><td>2:2018)</td></tr></tbody></table>

<table><thead><tr><th>Mỗi loại thép lấy 01 tổ mẫu 3 thanh 70cm.</th></tr></thead><tbody><tr><td>(Căn cứ theo các phục lục B, C, D, E của</td></tr><tr><td>TCVN 197-1:2014).</td></tr></tbody></table>

<table><thead><tr><th>Cứ 50 tấn/1 tổ mẫu/1 loại kích thước.</th></tr></thead><tbody><tr><td>Mỗi lô nhỏ hơn 50 tấn xem như một lô.</td></tr><tr><td>(Căn cứ theo mục 6 TCVN 6522:2008).</td></tr></tbody></table>

|<image_4>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>thép, thép
tấm…)</td><td>2. Khả năng chịu kéo (Giới hạn
chảy, giới hạn bền, độ giãn dài)</td><td></td><td></td><td></td><td>TCVN 197-1: 2014</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Khả năng chịu uốn hoặc nén
bẹp</td><td></td><td></td><td></td><td>TCVN 198: 2008</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>4. *Độ dai va đập của thép</td><td></td><td></td><td></td><td>TCVN 312-1:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Lưu ý: Đối với vật liệu này nếu không có yêu cầu đặc biệt từ thiết kế có thể bỏ các chỉ tiêu * cho lần thí nghiệm đầu tiên.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>Bu lông</td><td></td><td>1. *Kích thước hình học</td><td></td><td>ASTM A370</td><td></td><td></td><td>TCVN 1916 :1995</td><td></td><td></td><td>Lấy 3 mẫu thí nghiệm. (Căn cứ theo mục 6
TCVN 128:1963).</td><td>- Đối với hệ MEP: Mỗi loại cứ 01 lô sản
phẩm lấy mẫu 01 lần
- Đối với hạng mục xây dựng, kết cấu…:
Mỗi loại cứ 01 lô 500 con lấy 01 tổ mẫu,
Lô ít hơn 500 con coi như 01 lô.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Cơ tính vật liệu chế tạo bu lông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>(Theo yêu cầu thiết kế của dự án).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Giới hạn bền của bu lông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>Cupler</td><td>1. Xác định giới hạn bền kéo của
mối nối</td><td></td><td></td><td>TCVN 8163:2009</td><td></td><td></td><td>TCVN 8163:2009</td><td></td><td></td><td>Lấy 3 mẫu.
(Căn cứ theo mục 8.2.6.3 TCVN 8163:2009).</td><td></td><td>Mỗi lô 500 mối nối lấy 1 tổ mẫu gồm 3</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mẫu. Lô ít hơn 500 mối nối coi như 1 lô.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(Căn cứ theo mục 8.2.6.5 TCVN</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8163:2009).</td><td></td></tr><tr><td>13</td><td>Cáp DUL, thép
cường độ cao</td><td></td><td>1. Cấu trúc tạo cáp sợi giữa + sợi</td><td></td><td>Theo yêu cầu thiết
kế của dự án</td><td></td><td></td><td>ASTM A416/A416
hoặc TC tương đương</td><td></td><td></td><td>Lấy 3 thanh có chiều dài từ 1,2 – 1,5 m tùy
thiết bị thí nghiệm.</td><td>Mỗi lô 20 tấn lấy mẫu 1 lần. Lô nhỏ hơn
20 tấn thì coi là 1 lô.
(Căn cứ theo mục 8.1.1 TCVN
10952:2015).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>ngoài (Áp dụng cho cáp DUL)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Chênh lệch kích thước sợi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>giữa+sợi ngoài (Áp dụng cho cáp</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>DUL)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Giới hạn chảy, bền, độ giãn dài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Đường kính danh nghĩa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Diện tích mặt cắt ngang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>6. Mô đun đàn hồi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. Đơn trọng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>thép, thép</th></tr></thead><tbody><tr><td>tấm…)</td></tr></tbody></table>

<table><thead><tr><th>2. Khả năng chịu kéo (Giới hạn</th></tr></thead><tbody><tr><td>chảy, giới hạn bền, độ giãn dài)</td></tr></tbody></table>

<table><thead><tr><th>3. Khả năng chịu uốn hoặc nén</th></tr></thead><tbody><tr><td>bẹp</td></tr></tbody></table>

<table><thead><tr><th>- Đối với hệ MEP: Mỗi loại cứ 01 lô sản</th></tr></thead><tbody><tr><td>phẩm lấy mẫu 01 lần</td></tr><tr><td>- Đối với hạng mục xây dựng, kết cấu…:</td></tr><tr><td>Mỗi loại cứ 01 lô 500 con lấy 01 tổ mẫu,</td></tr><tr><td>Lô ít hơn 500 con coi như 01 lô.</td></tr></tbody></table>

<table><thead><tr><th>Lấy 3 mẫu thí nghiệm. (Căn cứ theo mục 6</th></tr></thead><tbody><tr><td>TCVN 128:1963).</td></tr></tbody></table>

<table><thead><tr><th>1. Xác định giới hạn bền kéo của</th></tr></thead><tbody><tr><td>mối nối</td></tr></tbody></table>

<table><thead><tr><th>Lấy 3 mẫu.</th></tr></thead><tbody><tr><td>(Căn cứ theo mục 8.2.6.3 TCVN 8163:2009).</td></tr></tbody></table>

<table><thead><tr><th>Mỗi lô 20 tấn lấy mẫu 1 lần. Lô nhỏ hơn</th></tr></thead><tbody><tr><td>20 tấn thì coi là 1 lô.</td></tr><tr><td>(Căn cứ theo mục 8.1.1 TCVN</td></tr><tr><td>10952:2015).</td></tr></tbody></table>

<table><thead><tr><th>Cáp DUL, thép</th></tr></thead><tbody><tr><td>cường độ cao</td></tr></tbody></table>

<table><thead><tr><th>Theo yêu cầu thiết</th></tr></thead><tbody><tr><td>kế của dự án</td></tr></tbody></table>

<table><thead><tr><th>ASTM A416/A416</th></tr></thead><tbody><tr><td>hoặc TC tương đương</td></tr></tbody></table>

<table><thead><tr><th>Lấy 3 thanh có chiều dài từ 1,2 – 1,5 m tùy</th></tr></thead><tbody><tr><td>thiết bị thí nghiệm.</td></tr></tbody></table>

|<image_5>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8. Lực kéo chảy và cường độ tại</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>1% độ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>giãn dài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Vữa xi măng
trộn sẵn không
co ngót : Sika
grout 214…</td><td></td><td>1. *Độ tách nước</td><td></td><td>TCVN 9204:2012</td><td>TCVN 9204:2012</td><td></td><td></td><td>Mẫu thử lấy từ các bao vữa nguyên được lựa
chọn một cách ngẫu nhiên trong lô vữa cần
kiểm tra. Khi thí nghiệm mỗi chỉ tiêu riêng lẻ
cần lấy 2000 g vữa hoặc khối lượng đủ để
thực hiện thí nghiệm.
(Căn cứ theo mục 6.2.1 TCVN 9204:2012)</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. *Độ chảy xòe</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Cường độ nén của vữa đã đóng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>rắn 3 ngày, 7 ngày,28 ngày</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Thay đổi chiều dài mẫu vữa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>đóng rắn ở các tuổi 1, 3, 7, 14, 28</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>ngày</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>15</td><td>Vữa xây trát</td><td>1. Xác định cường độ uốn, nén
của vữa</td><td></td><td></td><td>TCVN 3121-
11:2003</td><td>TCVN 4314:2003</td><td></td><td></td><td></td><td>Mẫu thử có kích thước (40x40x160)mm,Lấy</td><td></td><td>Mỗi hạng mục công việc lấy ít nhất 1 tổ
mẫu .Số lượng lấy mẫu còn phải tuân
theo quy định trong Hợp đồng/PLHĐ
giữa nhà thầu và Chủ đầu tư.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>02 tổ mẫu (nén 01 tổ R28 và 01 tổ lưu) mỗi tổ</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mẫu bao gồm 03 viên.</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2*. Xác định độ lưu động của vữa
tươi (khi thiết kế cấp phối vữa )</td><td></td><td></td><td>TCVN 3121-
3:2003</td><td>TCVN 4314:2003</td><td></td><td></td><td>Khối lượng mẫu có thể tích/khối lượng không
nhỏ hơn 20 lít (với vữa tươi) hoặc 15kg (với
vữa khô).
(Căn cứ theo mục 4.1.2 TCVN 3121- 2:2003)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>16</td><td>Bê tông xi
măng</td><td></td><td>1. Cường độ chịu nén của bê tông:</td><td></td><td>TCVN 3118:1993</td><td>TCVN 4453:1995</td><td></td><td></td><td>Mẫu thử có kích thước (150x150x150)mm,
mỗi tổ mẫu bao gồm 03 viên, một tổ hợp mẫu
bao gồm 03 tổ mẫu (Nén 01 tổ R3 hoặc R7 và
01 tổ R28, 01 tổ lưu).</td><td></td><td></td><td></td><td>- BT khối &gt; 1.000 m3: 500m3/ 01 tổ</td><td></td></tr><tr><td></td><td></td><td>- Nén 3 ngày hoặc 7 ngày để xác
định sự phát triển cường độ, làm
căn cứ để chuyển công việc tiếp
theo.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mẫu.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>- BT khối &lt; 1.000 m3: 250m3/01 tổ mẫu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>- Bê tông móng lớn: 100m3/01 tổ mẫu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>- Bê tông nền, mặt đường: 200m3/01 tổ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mẫu</td><td></td></tr><tr><td></td><td></td><td>- Nén 28 ngày để xác định cường
độ so với thiết kế để làm căn cứ
nghiệm thu.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>- Bê tông khung và các loại kết cấu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mỏng (cột, dầm, bản, vòm): cứ 20m3/01</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tổ mẫu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>- (Căn cứ theo mục 7.1.7 TCVN
4453:1995)</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>- Bê tông cọc khoan nhồi: mỗi cọc lấy 3</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tổ mẫu ở 3 phần: đầu, giữa và mũi cọc</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(Căn cứ theo mục 12.5.1 TCVN</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>9395:2012).</td><td></td></tr><tr><td></td><td></td><td>2. Cường độ chịu kéo khi uốn (khi
có yêu cầu của thiết kế).</td><td></td><td></td><td>TCVN 3119:1993</td><td>TCVN 4453:1995</td><td></td><td></td><td></td><td>Mẫu thử có kích thước (150x150x600)mm,</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mỗi tổ mẫu bao gồm</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>03 viên</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(Căn cứ theo mục 2.1 TCVN 3119:1993)</td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Mẫu thử lấy từ các bao vữa nguyên được lựa</th></tr></thead><tbody><tr><td>chọn một cách ngẫu nhiên trong lô vữa cần</td></tr><tr><td>kiểm tra. Khi thí nghiệm mỗi chỉ tiêu riêng lẻ</td></tr><tr><td>cần lấy 2000 g vữa hoặc khối lượng đủ để</td></tr><tr><td>thực hiện thí nghiệm.</td></tr><tr><td>(Căn cứ theo mục 6.2.1 TCVN 9204:2012)</td></tr></tbody></table>

<table><thead><tr><th>Vữa xi măng</th></tr></thead><tbody><tr><td>trộn sẵn không</td></tr><tr><td>co ngót : Sika</td></tr><tr><td>grout 214…</td></tr></tbody></table>

<table><thead><tr><th>Mỗi hạng mục công việc lấy ít nhất 1 tổ</th></tr></thead><tbody><tr><td>mẫu .Số lượng lấy mẫu còn phải tuân
theo quy định trong Hợp đồng/PLHĐ</td></tr><tr><td>giữa nhà thầu và Chủ đầu tư.</td></tr></tbody></table>

<table><thead><tr><th>2*. Xác định độ lưu động của vữa</th></tr></thead><tbody><tr><td>tươi (khi thiết kế cấp phối vữa )</td></tr></tbody></table>

<table><thead><tr><th>TCVN 3121-</th></tr></thead><tbody><tr><td>3:2003</td></tr></tbody></table>

<table><thead><tr><th>nhỏ hơn 20 lít (với vữa tươi) hoặc 15kg (với</th></tr></thead><tbody><tr><td>vữa khô).</td></tr><tr><td>(Căn cứ theo mục 4.1.2 TCVN 3121- 2:2003)</td></tr></tbody></table>

<table><thead><tr><th>định sự phát triển cường độ, làm</th></tr></thead><tbody><tr><td>căn cứ để chuyển công việc tiếp</td></tr><tr><td>theo.</td></tr></tbody></table>

<table><thead><tr><th>Mẫu thử có kích thước (150x150x150)mm,</th></tr></thead><tbody><tr><td>mỗi tổ mẫu bao gồm 03 viên, một tổ hợp mẫu</td></tr><tr><td>bao gồm 03 tổ mẫu (Nén 01 tổ R3 hoặc R7 và
01 tổ R28, 01 tổ lưu).</td></tr></tbody></table>

<table><thead><tr><th>- Nén 28 ngày để xác định cường
độ so với thiết kế để làm căn cứ</th></tr></thead><tbody><tr><td>nghiệm thu.</td></tr></tbody></table>

<table><thead><tr><th>2. Cường độ chịu kéo khi uốn (khi</th></tr></thead><tbody><tr><td>có yêu cầu của thiết kế).</td></tr></tbody></table>

|<image_6>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th></th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Thí nghiệm độ chống thấm (khi
có yêu cầu của thiết kế)</td><td></td><td></td><td>TCVN 3116:1993</td><td></td><td></td><td>TCVN 4453:1995</td><td></td><td></td><td>Mẫu thử hình trụ có kích thước (D150x150)
mm, mỗi tổ mẫu bao gồm 06 viên.
(Căn cứ theo mục 3.1 TCVN 3105:1993)</td><td>500m3 lấy 01 tổ mẫu, ca đổ ít hơn
500m3 vẫn lấy 01 tổ mẫu.
(Căn cứ theo mục 7.1.7 TCVN
4453:1995) Đối với những hạng mục
quan trọng như vách tầng hầm, bề nước,
sàn hầm… thì lấy thêm mẫu thí nghiệm
tuân theo yêu cầu của CĐT.</td><td></td></tr><tr><td></td><td></td><td></td><td>Lưu ý:
- Với các kết cấu chịu lực chính của công trình (cọc khoan nhồi ,móng, cột, dầm sàn, vách thang máy, tường chắn đất…) có khối lượng bê tông &lt;50 m3/1 cấu kiện: cứ 3 tổ mẫu R28
thì lấy 1 tổ mẫu R7 và 1 tổ lưu. Trường hợp số tổ R28 nhỏ hơn 3 thì vẫn lấy 1 tổ R7 và 1 tổ lưu.
- Với các kết cấu chịu lực khác cần kết quả sớm phục vụ tháo dỡ cốp pha đà giáo (nắp bể ngầm, lanh tô, cầu thang…): chỉ lấy mẫu R7 và R28, không lấy mẫu lưu.
- Bê tông đường, nền và các cấu kiện khác: chỉ lấy mẫu R28.
- Thời hạn lưu mẫu bê tông: 1 tuần làm việc kể từ khi có kết quả ép mẫu R28. ◻</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>17</td><td></td><td>Bentonite</td><td></td><td>1. Xác định khối lượng riêng, độ</td><td></td><td>TCVN 11893:2017</td><td></td><td></td><td>TCVN 9395:2012</td><td></td><td></td><td>Lấy theo lô (hoặc theo đợt nhập) (Căn cứ theo
mục 4 TCVN 11893:2017)</td><td>Dung dịch trộn mới được kiểm tra hàng
ngày.
(Căn cứ theo mục 12.2.2 TCVN
9395:2012)</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nhớt, pH, hàm lượng nước mất và</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>độ dày áo sét</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>2. Hàm lượng cát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>18</td><td></td><td>Cọc bê tông ly
tâm</td><td></td><td>1. Khuyết tật ngoại quan</td><td></td><td></td><td>TCVN 7888:2014</td><td></td><td></td><td>TCVN 7888:2014</td><td></td><td>Lấy 02 đoạn cọc theo mục 7.2 TCVN
7888:2014</td><td>3000 cọc/01 tổ, dưới 3000 cọc vẫn lấy
01 tổ</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>2. Độ bền uốn nứt thân cọc</td><td></td><td></td><td>TCVN 7888:2014</td><td></td><td></td><td>TCVN 7888:2014</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. Độ bền uốn gãy thân cọc</td><td></td><td></td><td>TCVN 7888:2014</td><td></td><td></td><td>TCVN 7888:2014</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>VẬT LIỆU HOÀN THIỆN</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>19</td><td></td><td>Gạch ốp lát</td><td></td><td>1. *Xác định kích thước và chất</td><td></td><td></td><td>TCVN 6415-</td><td></td><td>TCVN 7745:2007</td><td></td><td></td><td>Lấy mẫu căn cứ theo mục 4.3 TCVN 6415-
1:2016 (lấy tối thiểu 15 viên để thí nghiệm đủ
các chỉ tiêu).</td><td>Cứ 5000m2 lấy mẫu 1 lần. Nếu số lượng
nhỏ hơn 5000m2 vẫn được coi như một
lô đủ.
(Căn cứ theo mục 3.2 TCVN 6415-
1:2016).</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>lượng bề mặt</td><td></td><td></td><td>2:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Xác định độ hút nước</td><td></td><td></td><td></td><td>TCVN 6415-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Xác định độ bền uốn</td><td></td><td></td><td></td><td>TCVN 6415-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>4:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>4. Xác định độ mài mòn sâu (với</td><td></td><td>TCVN 6415-
6,7:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>gạch không tráng men) và độ mài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>mòn bề mặt (với gạch tráng men).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>5. Xác định độ cứng bề mặt theo</td><td></td><td></td><td>TCVN 6415-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thang Mohs</td><td></td><td></td><td>18:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>500m3 lấy 01 tổ mẫu, ca đổ ít hơn</th></tr></thead><tbody><tr><td>500m3 vẫn lấy 01 tổ mẫu.</td></tr><tr><td>(Căn cứ theo mục 7.1.7 TCVN</td></tr><tr><td>4453:1995) Đối với những hạng mục</td></tr><tr><td>quan trọng như vách tầng hầm, bề nước,</td></tr><tr><td>sàn hầm… thì lấy thêm mẫu thí nghiệm</td></tr><tr><td>tuân theo yêu cầu của CĐT.</td></tr></tbody></table>

<table><thead><tr><th>Mẫu thử hình trụ có kích thước (D150x150)</th></tr></thead><tbody><tr><td>mm, mỗi tổ mẫu bao gồm 06 viên.</td></tr><tr><td>(Căn cứ theo mục 3.1 TCVN 3105:1993)</td></tr></tbody></table>

<table><thead><tr><th>3. Thí nghiệm độ chống thấm (khi</th></tr></thead><tbody><tr><td>có yêu cầu của thiết kế)</td></tr></tbody></table>

<table><thead><tr><th>Lưu ý:</th></tr></thead><tbody><tr><td>- Với các kết cấu chịu lực chính của công trình (cọc khoan nhồi ,móng, cột, dầm sàn, vách thang máy, tường chắn đất…) có khối lượng bê tông &lt;50 m3/1 cấu kiện: cứ 3 tổ mẫu R28</td></tr><tr><td>thì lấy 1 tổ mẫu R7 và 1 tổ lưu. Trường hợp số tổ R28 nhỏ hơn 3 thì vẫn lấy 1 tổ R7 và 1 tổ lưu.</td></tr><tr><td>- Với các kết cấu chịu lực khác cần kết quả sớm phục vụ tháo dỡ cốp pha đà giáo (nắp bể ngầm, lanh tô, cầu thang…): chỉ lấy mẫu R7 và R28, không lấy mẫu lưu.</td></tr><tr><td>- Bê tông đường, nền và các cấu kiện khác: chỉ lấy mẫu R28.</td></tr><tr><td>- Thời hạn lưu mẫu bê tông: 1 tuần làm việc kể từ khi có kết quả ép mẫu R28. ◻</td></tr></tbody></table>

<table><thead><tr><th>Lấy theo lô (hoặc theo đợt nhập) (Căn cứ theo</th></tr></thead><tbody><tr><td>mục 4 TCVN 11893:2017)</td></tr></tbody></table>

<table><thead><tr><th>ngày.</th></tr></thead><tbody><tr><td>(Căn cứ theo mục 12.2.2 TCVN</td></tr></tbody></table>

<table><thead><tr><th>Cọc bê tông ly</th></tr></thead><tbody><tr><td>tâm</td></tr></tbody></table>

<table><thead><tr><th>Lấy 02 đoạn cọc theo mục 7.2 TCVN</th></tr></thead><tbody><tr><td>7888:2014</td></tr></tbody></table>

<table><thead><tr><th>3000 cọc/01 tổ, dưới 3000 cọc vẫn lấy</th></tr></thead><tbody><tr><td>01 tổ</td></tr></tbody></table>

<table><thead><tr><th>Cứ 5000m2 lấy mẫu 1 lần. Nếu số lượng</th></tr></thead><tbody><tr><td>nhỏ hơn 5000m2 vẫn được coi như một</td></tr><tr><td>lô đủ.</td></tr><tr><td>(Căn cứ theo mục 3.2 TCVN 6415-</td></tr><tr><td>1:2016).</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu căn cứ theo mục 4.3 TCVN 6415-</th></tr></thead><tbody><tr><td>1:2016 (lấy tối thiểu 15 viên để thí nghiệm đủ</td></tr><tr><td>các chỉ tiêu).</td></tr></tbody></table>

<table><thead><tr><th>TCVN 6415-</th></tr></thead><tbody><tr><td>6,7:2016</td></tr></tbody></table>

|<image_7>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th></th><th></th><th>TÊN VẬT
LIỆU</th><th></th><th></th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>6. *Hệ số giãn nở nhiệt dài</td><td></td><td></td><td></td><td>TCVN 6415-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>8:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>7. *Hệ số giãn nở ẩm</td><td></td><td></td><td></td><td>TCVN 6415-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>10:2016</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>20</td><td></td><td></td><td>Vữa, keo dán
gạch gốc xi
măng</td><td></td><td></td><td></td><td>1. Xác định thời gian mở</td><td></td><td>TCVN 7899-
2:2008 (ISO
13007-2)</td><td></td><td></td><td>TCVN 7899-1:2008</td><td></td><td></td><td>Lấy mẫu đại diện với khối lượng không ít hơn
2 kg. (Căn cứ theo mục 3.1 TCVN 7899-
2:2008).</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2. Xác định cường độ bám dính</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>khi kéo</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3. Xác định cường độ bám dính</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sau khi ngâm nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>4. Xác định cường độ bám dính</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>sau khi gia nhiệt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>5. *Xác định độ trược</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>6. *Xác định biến dạng ngang</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>21</td><td></td><td></td><td>Kính dán nhiều
lớp và kính dán
an toàn nhiều
lớp, kính
phẳng tôi nhiệt</td><td></td><td></td><td></td><td>1. Sai lệch chiều dày</td><td></td><td></td><td>TCVN 7219:2018</td><td></td><td>TCVN 7364:2018</td><td></td><td></td><td>Lấy 3 mẫu kính, kích thước 610mmx610mm.
(Căn cứ theo mục 2.1 TCVN 7219:2018).</td><td></td><td></td><td>Các mẫu thử do nhà sản xuất cung cấp
theo mỗi lô hàng</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2. Khuyết tật ngoại quan</td><td></td><td></td><td>TCVN 7219:2018</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>3. Ứng suất bề mặt (Đối với kính</td><td></td><td>TCVN 8261:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>phẳng tôi nhiệt)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>4. Thử phá vỡ mẫu kính tôi nhiệt</td><td></td><td>TCVN 7455:2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>an toàn (Đối với kính phẳng tôi</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nhiệt)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>5. Độ bền chịu nhiệt độ cao</td><td></td><td></td><td>TCVN 7364-
4:2018</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Lấy 6 mẫu kính/ 1 lô sản phẩm, kích thước:</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(100x300)mm.</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Căn cứ theo mục 5.2 TCVN</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7364:2018).</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>6. Độ bền va đập bi rơi</td><td></td><td></td><td>TCVN 7368:2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Lấy 6 mẫu kính/ 1 lô sản phẩm, kích thước:</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(610x610)mm.</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Căn cứ theo mục 3.1.3 TCVN</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7368:2013).</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>7. Độ bền va đập con lắc</td><td></td><td></td><td>TCVN 7368:2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Lấy 4 mẫu kính/ 1 lô sản phẩm, kích thước:</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>(1900x860)mm.</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Căn cứ theo mục 3.2.3 TCVN 7368:2013).</td><td></td><td></td><td></td><td></td></tr><tr><td>22</td><td></td><td></td><td></td><td>Kính gương</td><td></td><td>1. Sai lệch chiều dày</td><td></td><td></td><td>TCVN 7219:2018</td><td></td><td></td><td></td><td>Bảng 1 của TCVN</td><td></td><td>3 mẫu, kích thước ≥ (600x600) mm</td><td></td><td></td><td></td><td>Các mẫu thử do nhà sản xuất cung cấp</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>tráng bạc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7624:2007</td><td></td><td></td><td></td><td></td><td></td><td>theo mỗi lô hàng.</td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Vữa, keo dán</th></tr></thead><tbody><tr><td>gạch gốc xi</td></tr><tr><td>măng</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7899-</th></tr></thead><tbody><tr><td>2:2008 (ISO</td></tr><tr><td>13007-2)</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu đại diện với khối lượng không ít hơn</th></tr></thead><tbody><tr><td>2 kg. (Căn cứ theo mục 3.1 TCVN 7899-</td></tr><tr><td>2:2008).</td></tr></tbody></table>

<table><thead><tr><th>Lấy 3 mẫu kính, kích thước 610mmx610mm.</th></tr></thead><tbody><tr><td>(Căn cứ theo mục 2.1 TCVN 7219:2018).</td></tr></tbody></table>

<table><thead><tr><th>Kính dán nhiều</th></tr></thead><tbody><tr><td>lớp và kính dán</td></tr><tr><td>an toàn nhiều</td></tr><tr><td>lớp, kính</td></tr><tr><td>phẳng tôi nhiệt</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7364-</th></tr></thead><tbody><tr><td>4:2018</td></tr></tbody></table>

<table><thead><tr><th>Các mẫu thử do nhà sản xuất cung cấp</th></tr></thead><tbody><tr><td>theo mỗi lô hàng</td></tr></tbody></table>

|<image_8>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th></th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Khuyết tật ngoại quan</td><td></td><td></td><td>TCVN 7219:2018</td><td></td><td></td><td></td><td>Phụ lục A của TCVN</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>7218:2002</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. Độ bám dính của lớp sơn phủ,</td><td></td><td>TCVN 7625:2007</td><td></td><td></td><td></td><td></td><td></td><td>4 mẫu, kích thước (100x100) mm</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>%, không nhỏ hơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>23</td><td></td><td>Tấm thạch cao
thường và chịu</td><td>1. Xác định kích thước</td><td></td><td></td><td></td><td>TCVN 8257-1</td><td></td><td>TCVN 8256:2009</td><td></td><td></td><td>Lấy &gt; 0,25% tổng số tấm và không ít hơn 3
tấm.
(Căn cứ theo mục 2 TCVN 8257-</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần, mỗi lô
không lớn hơn 2000 tấm</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ vuông góc của cạnh</td><td></td><td></td><td></td><td>TCVN 8257-1</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. Xác định độ cứng của cạnh, gờ</td><td></td><td></td><td>TCVN 8257-2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>và lõi</td><td></td><td></td><td>:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Xác định cường độ chịu uốn</td><td></td><td></td><td></td><td>TCVN 8257-3</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Xác định độ kháng nhổ đinh</td><td></td><td></td><td></td><td>TCVN 8257-4</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>6. Xác định độ biến dạng ẩm (áp</td><td></td><td></td><td>TCVN 8257-5</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dụng đối với tấm 9mm trở lên)</td><td></td><td></td><td>:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>7. Xác định độ hút nước (chỉ áp</td><td></td><td>TCVN 8257-6
:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>dụng đối với tấm thạch</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cao chịu ẩm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>ẩm</td><td></td><td>8. Xác định độ hấp thụ nước bề</td><td></td><td>TCVN 8257-7
:2009</td><td></td><td></td><td></td><td></td><td></td><td>1:2009).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>mặt (chỉ áp dụng đối với tấm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>thạch cao chịu ẩm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>9. *Xác định độ sâu của gờ vuốt
thon và độ vuông góc của cạnh
(Chỉ áp dụng với tấm thạch cao có
phần vát hoặc sâu xuống so với độ
dày của tấm)</td><td></td><td></td><td>TCVN 8257-1 :
2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>10. *Xác định độ thẩm thấu hơi</td><td></td><td>TCVN 8257-8 :
2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>nước (Chỉ áp dụng cho tấm thạch</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>cao có mặt sau tráng lớp kim loại)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>11. *Hợp chất lưu huỳnh dễ bay</td><td></td><td></td><td>ASTM C471M-16a</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>hơi</td><td></td><td></td><td>(*)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Lưu ý: Đối với các loại tấm thạch cao khác tuân theo các chỉ tiêu trong TCVN 8256:2009 (Từ bảng 1 đến bảng 14 TCVN 8256:2009)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>24</td><td></td><td>Khung xương
trần thạch cao</td><td></td><td>1. Xác định kích thước hình học</td><td></td><td>ASTM C635</td><td></td><td></td><td>ASTM C635</td><td></td><td></td><td>Lấy 3 đoạn, mỗi đoạn 1,5m</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>2. Khả năng chịu tải trọng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Lấy &gt; 0,25% tổng số tấm và không ít hơn 3</th></tr></thead><tbody><tr><td>tấm.</td></tr><tr><td>(Căn cứ theo mục 2 TCVN 8257-</td></tr></tbody></table>

<table><thead><tr><th>Tấm thạch cao</th></tr></thead><tbody><tr><td>thường và chịu</td></tr></tbody></table>

<table><thead><tr><th>Mỗi lô sản phẩm lấy mẫu 1 lần, mỗi lô</th></tr></thead><tbody><tr><td>không lớn hơn 2000 tấm</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8257-6</th></tr></thead><tbody><tr><td>:2009</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8257-7</th></tr></thead><tbody><tr><td>:2009</td></tr></tbody></table>

<table><thead><tr><th>thon và độ vuông góc của cạnh</th></tr></thead><tbody><tr><td>(Chỉ áp dụng với tấm thạch cao có</td></tr><tr><td>phần vát hoặc sâu xuống so với độ</td></tr><tr><td>dày của tấm)</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8257-1 :</th></tr></thead><tbody><tr><td>2009</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8257-8 :</th></tr></thead><tbody><tr><td>2009</td></tr></tbody></table>

|<image_9>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Chiều dày lớp mạ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>25</td><td>Tấm xi măng
sợi</td><td>1. Cường độ chịu uốn, Mpa</td><td></td><td></td><td></td><td>TCVN 8259-</td><td></td><td>TCVN 8258:2009</td><td></td><td></td><td>Lấy mẫu theo thỏa thuận giữa các bên tham
gia thử nghiệm.
(Căn cứ theo mục 4 TCVN 8259- 1:2009).</td><td></td><td></td><td>Mỗi hợp đồng lấy 1 lần. Mỗi loại lấy 1
tổ mẫu. Có thể tham khảo TCSX của nhà
SX.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2. Khả năng chống thấm nước</td><td></td><td></td><td>TCVN 8259-
6:2009</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>26</td><td>Nhôm và hợp
kim nhôm định
hình</td><td>1. Độ bền kéo, MPa, không nhỏ
hơn</td><td></td><td></td><td></td><td>TCVN 197-1: 2014</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td>Mỗi loại thép lấy 01 tổ mẫu 3 đoạn 50cm.
(Căn cứ theo các phục lục B, C, D, E của
TCVN 197-1:2014).</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.
Mỗi loại lấy 1 tổ mẫu. Có thể tham khảo
TCSX của nhà SX.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2. Độ cứng, HV, không nhỏ hơn</td><td></td><td></td><td></td><td>TCVN 258-1:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Chiều dày (khối lượng) lớp
phủ, chiều dày màng sơn, µm</td><td></td><td></td><td></td><td>TCVN 5878:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>TC nước ngoài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Thành phần hoá học</td><td></td><td></td><td>ASTM E1251(e)</td><td></td><td></td><td>TCVN 5910:1995</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>27</td><td>Inox</td><td>1. Xác định thành phần hóa học</td><td></td><td></td><td></td><td>JIS G1253:2013</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td></td><td>Mỗi loại lấy 01 tổ mẫu 3 đoạn 50cm. (Căn cứ</td><td></td><td>Lấy mẫu điển hình.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td>theo các phục lục B, C, D, E của TCVN 197-</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>theo TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td>1:2014).</td><td></td><td></td></tr><tr><td>28</td><td>Ván MDF/
Ván dăm</td><td></td><td>1. *Xác định kích thước</td><td></td><td></td><td>TCVN 11904:2017</td><td></td><td>TCVN 7753:2007/ TCVN
7754:2007</td><td></td><td></td><td>Lấy 2 tấm ván nguyên.
(Căn cứ theo mục 2.1 TCVN 7756- 1:2007).</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>2. Xác định độ ẩm</td><td></td><td></td><td>TCVN 11905:2017</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ trương nở chiều dày sau</td><td></td><td></td><td>TCVN 7756-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>24h ngâm trong nước</td><td></td><td></td><td>5:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Độ bền uốn tĩnh, modun đàn</td><td></td><td></td><td>TCVN 7756-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hồi uốn tĩnh</td><td></td><td></td><td>6:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Độ bền kéo vuông góc với mặt</td><td></td><td>TCVN 12447:2018</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>ván</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>6. Độ bền bề mặt (Đối với ván</td><td></td><td>TCVN 11906:2017</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>dăm)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu theo thỏa thuận giữa các bên tham</th></tr></thead><tbody><tr><td>gia thử nghiệm.</td></tr><tr><td>(Căn cứ theo mục 4 TCVN 8259- 1:2009).</td></tr></tbody></table>

<table><thead><tr><th>Mỗi hợp đồng lấy 1 lần. Mỗi loại lấy 1</th></tr></thead><tbody><tr><td>tổ mẫu. Có thể tham khảo TCSX của nhà</td></tr><tr><td>SX.</td></tr></tbody></table>

<table><thead><tr><th>Tấm xi măng</th></tr></thead><tbody><tr><td>sợi</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8259-</th></tr></thead><tbody><tr><td>6:2009</td></tr></tbody></table>

<table><thead><tr><th>1. Độ bền kéo, MPa, không nhỏ</th></tr></thead><tbody><tr><td>hơn</td></tr></tbody></table>

<table><thead><tr><th>Nhôm và hợp</th></tr></thead><tbody><tr><td>kim nhôm định</td></tr><tr><td>hình</td></tr></tbody></table>

<table><thead><tr><th>Theo yêu cầu thiết kế của</th></tr></thead><tbody><tr><td>dự án</td></tr></tbody></table>

<table><thead><tr><th>Mỗi loại thép lấy 01 tổ mẫu 3 đoạn 50cm.</th></tr></thead><tbody><tr><td>(Căn cứ theo các phục lục B, C, D, E của</td></tr><tr><td>TCVN 197-1:2014).</td></tr></tbody></table>

<table><thead><tr><th>Mỗi lô sản phẩm lấy mẫu 1 lần.</th></tr></thead><tbody><tr><td>Mỗi loại lấy 1 tổ mẫu. Có thể tham khảo</td></tr><tr><td>TCSX của nhà SX.</td></tr></tbody></table>

<table><thead><tr><th>3. Chiều dày (khối lượng) lớp</th></tr></thead><tbody><tr><td>phủ, chiều dày màng sơn, µm</td></tr></tbody></table>

<table><thead><tr><th>Theo yêu cầu thiết kế của</th></tr></thead><tbody><tr><td>dự án</td></tr></tbody></table>

<table><thead><tr><th>Ván MDF/</th></tr></thead><tbody><tr><td>Ván dăm</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7753:2007/ TCVN</th></tr></thead><tbody><tr><td>7754:2007</td></tr></tbody></table>

<table><thead><tr><th>Lấy 2 tấm ván nguyên.</th></tr></thead><tbody><tr><td>(Căn cứ theo mục 2.1 TCVN 7756- 1:2007).</td></tr></tbody></table>

|<image_10>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. *Hàm lượng focmanđêhyt theo</td><td></td><td>TCVN 7756-
12:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>phương</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>pháp chiết tách</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>29</td><td>Ván sàn gỗ
nhân tạo</td><td>1. Độ trương nở chiều dày</td><td></td><td></td><td></td><td>TCVN 11950-2018</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td>Lấy ngẫu nhiên tối thiểu 04 thanh nguyên khổ
ở mỗi lô hàng
(Căn cứ theo mục 8 bảng 2.4 QCVN
16:2014/BXD).</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>ISO 24366-2005</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ bền bề mặt, MPa, không</td><td></td><td></td><td>BS EN 13329-16</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nhỏ hơn</td><td></td><td></td><td>Annex D</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Độ thay đổi kích thước khi thay
đổi độ ẩm</td><td>3. Độ thay đổi kích thước khi thay</td><td></td><td></td><td>BS EN 13329-16</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>Annex C</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>4. *Độ mài mòn bề mặt</td><td></td><td></td><td></td><td>BS EN 13329-16
Annex E</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>5. *Khối lượng thể tích</td><td></td><td></td><td></td><td>TCVN 7756-</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>4:2007</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>6. *Hàm lượng formandehyt phát</td><td></td><td></td><td>ISO 12460-1/EN</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>tán</td><td></td><td></td><td>717-1</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>30</td><td>Sơn tường
dạng nhũ
tương</td><td></td><td>1. *Độ mịn, mm</td><td></td><td></td><td>TCVN 2091:2008</td><td></td><td>TCVN 8652-2012</td><td></td><td></td><td>Lấy 5 lít sơn.</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>2. Độ bám dính</td><td></td><td></td><td>TCVN 2097:2015</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. *Độ bền nước</td><td></td><td></td><td>TCVN 8653:2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. *Độ bền kiềm</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Độ rửa trôi sơn phủ ngoại thất,</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nội thất</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>6. Độ bền chu kỳ nóng lạnh (đối</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>với sơn phủ ngoại thất)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>31</td><td>Bột bả tường
gốc xi măng
poóc lăng</td><td>Cường độ bám dính
1. Ở điều kiện chuẩn
2. Sau khi ngâm nước 72h
3. Sau khi thử chu kỳ sốc nhiệt
(đối với bột bả ngoại thất)</td><td></td><td></td><td>TCVN 7239:2014</td><td></td><td></td><td>TCVN 7239:2014</td><td></td><td></td><td>Lấy 5 kg bột bả.
(Căn cứ theo mục 8.1 TCVN 4787:2009).</td><td>Cứ 500 bao lấy mẫu 01 lần. Dưới 500
bao vẫn lấy 01 mẫu.</td></tr><tr><td></td><td></td><td>Lưu ý:
- Nhà sản xuất sẽ phải gửi công văn cam kết chất lượng cho toàn bộ chất lượng sản phẩm cấp vào dự án và đảm bảo việc sản xuất trong các điều kiện giống nhau. Trường hợp các
điều kiện sản xuất khác nhau (như nguồn nguyên vật liệu, cấp phối,...) thì NSX phải thông báo cho CĐT để lấy mẫu riêng.
- Nhà máy phải có thông báo về quy cách in nhãn mác, thời gian, các số ký hiệu sản xuất trên bao bì tới BQLXD và Phòng KS LMTN để kiểm soát tránh trà trộn các loại không đúng
nguồn gốc.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7756-</th></tr></thead><tbody><tr><td>12:2007</td></tr></tbody></table>

<table><thead><tr><th>Lấy ngẫu nhiên tối thiểu 04 thanh nguyên khổ</th></tr></thead><tbody><tr><td>ở mỗi lô hàng</td></tr></tbody></table>

<table><thead><tr><th>Sơn tường</th></tr></thead><tbody><tr><td>dạng nhũ</td></tr><tr><td>tương</td></tr></tbody></table>

<table><thead><tr><th>1. Ở điều kiện chuẩn</th></tr></thead><tbody><tr><td>2. Sau khi ngâm nước 72h</td></tr><tr><td>3. Sau khi thử chu kỳ sốc nhiệt</td></tr><tr><td>(đối với bột bả ngoại thất)</td></tr></tbody></table>

<table><thead><tr><th>Lấy 5 kg bột bả.</th></tr></thead><tbody><tr><td>(Căn cứ theo mục 8.1 TCVN 4787:2009).</td></tr></tbody></table>

<table><thead><tr><th>Cứ 500 bao lấy mẫu 01 lần. Dưới 500</th></tr></thead><tbody><tr><td>bao vẫn lấy 01 mẫu.</td></tr></tbody></table>

<table><thead><tr><th>Bột bả tường</th></tr></thead><tbody><tr><td>gốc xi măng</td></tr><tr><td>poóc lăng</td></tr></tbody></table>

<table><thead><tr><th>Lưu ý:</th></tr></thead><tbody><tr><td>- Nhà sản xuất sẽ phải gửi công văn cam kết chất lượng cho toàn bộ chất lượng sản phẩm cấp vào dự án và đảm bảo việc sản xuất trong các điều kiện giống nhau. Trường hợp các</td></tr><tr><td>điều kiện sản xuất khác nhau (như nguồn nguyên vật liệu, cấp phối,...) thì NSX phải thông báo cho CĐT để lấy mẫu riêng.</td></tr><tr><td>- Nhà máy phải có thông báo về quy cách in nhãn mác, thời gian, các số ký hiệu sản xuất trên bao bì tới BQLXD và Phòng KS LMTN để kiểm soát tránh trà trộn các loại không đúng</td></tr><tr><td>nguồn gốc.</td></tr></tbody></table>

|<image_11>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td></tr><tr><td>32</td><td>Sơn epoxy</td><td></td><td>1. Thời gian khô (khô bề mặt), h,</td><td></td><td>TCVN 2096:2015</td><td></td><td></td><td>TCVN 9014:2011</td><td></td><td></td><td>Lấy 2 lít sơn.</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>không lớn hơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ bền va đập, kG.cm, không</td><td></td><td>ISO 6272-2: 2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nhỏ hơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>33</td><td>Sơn alkyd</td><td></td><td>1. Độ bám dính, điểm, không lớn</td><td></td><td>TCVN 2097: 2015</td><td></td><td></td><td>TCVN 5730:2008</td><td></td><td></td><td>Lấy 2 lít sơn.</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>hơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ bền uốn, mm, không lớn</td><td></td><td>TCVN 2099: 2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ bền va đập, kG.cm, không</td><td></td><td></td><td>ISO 6272-2:</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nhỏ hơn</td><td></td><td></td><td>2011(a)</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>34</td><td>Vật liệu chống
thấm gốc
ximăng-
polyme</td><td></td><td>1. Cường độ bám dính sau khi</td><td></td><td>BS EN14891:2017</td><td></td><td></td><td>BS EN14891:2017</td><td></td><td></td><td>Lấy mẫu đại diện với khối lượng không ít hơn
2 bao nguyên (đối với loại một thành phần)
hoặc 2 bộ nguyên (đối với loại hai thành
phần) trong một lô.
(Căn cứ theo mục 7 bảng 2.5 QCVN
16:2014/BXD).</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>ngâm nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Cường độ bám dính sau lão hóa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nhiệt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Khả năng tạo cầu vết nứt ở điều</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>kiện thường</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Độ thấm nước dưới áp lực thủy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>tĩnh 1,5bar/7 ngày</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>35</td><td>Vật liệu chống
thấm gốc
Polyuthane
(PU)</td><td></td><td>1. Cường độ bám dính trên nền bê</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>tông</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ cứng Shore A</td><td></td><td></td><td>ASTM D2240</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ giãn dài</td><td></td><td></td><td>ASTM D412</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Độ thấm nước dưới áp lực thủy</td><td></td><td>ASTM D7234</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>tĩnh</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>36</td><td>Vật liệu chống
thấm gốc bi
tum</td><td></td><td>1. Độ giãn dài</td><td></td><td></td><td>ASTM D412</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td>2. Độ cứng Shore A</td><td></td><td></td><td>ASTM D2240</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ thấm nước 0.5Bar trong 72h</td><td></td><td></td><td>BS EN 14891</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Cường độ bám dính khi ngâm</td><td></td><td>ASTM D7234</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>37</td><td>Vật liệu chống
thấm – Sơn
nhũ tương
bitum.</td><td></td><td>1. Độ mịn</td><td></td><td></td><td>TCVN 2091:2008</td><td></td><td>TCVN 9065 : 2012</td><td></td><td></td><td>Lấy tối thiểu 5 lít.</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td>2. Độ nhớt quy ước</td><td></td><td></td><td>TCVN 2092:2008</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ phủ</td><td></td><td></td><td>TCVN 2095:1993</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Hàm lượng chất không bay hơi</td><td></td><td></td><td>TCVN 2093:1993</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu đại diện với khối lượng không ít hơn</th></tr></thead><tbody><tr><td>2 bao nguyên (đối với loại một thành phần)</td></tr><tr><td>hoặc 2 bộ nguyên (đối với loại hai thành</td></tr><tr><td>phần) trong một lô.</td></tr><tr><td>(Căn cứ theo mục 7 bảng 2.5 QCVN</td></tr><tr><td>16:2014/BXD).</td></tr></tbody></table>

<table><thead><tr><th>Vật liệu chống</th></tr></thead><tbody><tr><td>thấm gốc</td></tr><tr><td>ximăng-</td></tr><tr><td>polyme</td></tr></tbody></table>

<table><thead><tr><th>Vật liệu chống</th></tr></thead><tbody><tr><td>thấm gốc</td></tr><tr><td>Polyuthane</td></tr><tr><td>(PU)</td></tr></tbody></table>

<table><thead><tr><th>Theo yêu cầu thiết kế của</th></tr></thead><tbody><tr><td>dự án</td></tr></tbody></table>

<table><thead><tr><th>thấm gốc bi</th></tr></thead><tbody><tr><td>tum</td></tr></tbody></table>

<table><thead><tr><th>Vật liệu chống</th></tr></thead><tbody><tr><td>thấm – Sơn</td></tr><tr><td>nhũ tương</td></tr><tr><td>bitum.</td></tr></tbody></table>

|<image_12>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Thời gian khô</td><td></td><td></td><td>TCVN 6557:2000</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>6. Độ bền uốn</td><td></td><td></td><td>TCVN 2099:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. Độ bám dính của màng sơn trên</td><td></td><td>TCVN 2097:1993</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>nền vữa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8. Độ chịu nhiệt</td><td></td><td></td><td>TCVN 6557:2000</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>9. Độ xuyên nước</td><td></td><td></td><td>TCVN 6557:2000</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10. Độ bền lâu</td><td></td><td></td><td>TCVN 6557:2000</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>1. Xác định kích thước</td><td></td><td></td><td></td><td>TCVN 7756-</td><td></td><td></td><td></td><td></td><td>Mẫu lấy từ một cuộn được lựa chọn</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>2:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Cường đô chịu kéo</td><td></td><td></td><td>TCVN 4509: 2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>38</td><td>Băng cản nước
PVC</td><td></td><td>3. Độ giãn dài khi đứt</td><td></td><td></td><td></td><td></td><td>TCVN 9407:2014</td><td></td><td></td><td>ngẫu nhiên từ một lô sản phẩm, có thể lấy
mẫu trong nhiều cuộn hoặc trong nhiều đơn vị
bao gói sao cho việc lấy mẫu là đại diện nhất.
Chia các mẫu thử thành những tấm có chiều
dài không nhỏ hơn 1m. (Căn cứ theo mục 5
TCVN 9407:2014).</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td>4. Độ cứng ShoreA</td><td></td><td></td><td></td><td>TCVN 1595-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>1:2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Tỉ lệ thay đổi khối lượng sau</td><td></td><td></td><td>TCVN 9407-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>khi lão hóa nhiệt</td><td></td><td></td><td>3:2014</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>6. Khối lượng riêng</td><td></td><td></td><td></td><td>TCVN 4866: 2013</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>ISO 2781: 1988</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. Độ bền hóa chất</td><td></td><td></td><td>TCVN 9407:2014</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>39</td><td>Phào bê tông
cốt sợi thủy
tinh</td><td>1. Cường độ chịu nén</td><td></td><td></td><td>TCVN 3118:1993</td><td></td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td></td><td>Lấy 6 mẫu kích thước 15x15x15 cm (3 viên</td><td></td><td>Mỗi hợp đồng lấy mẫu 01 lần khi kiểm
tra cấp phối.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nén 28 ngày, 3 viên lưu).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Cường độ chịu uốn</td><td></td><td>BS 1170-5:1998</td><td></td><td></td><td></td><td></td><td></td><td>Lấy 16 mẫu. Rộng 50mm, chiều dài phụ thuộc
vào độ dày theo bảng 1 BS1170-5:1998. (8
viên thử 28 ngày,
8 viên lưu).</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Độ hút nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>40</td><td>Latex</td><td>1. Hàm lượng chất rắn</td><td></td><td></td><td>TCVN 8826:2011</td><td></td><td></td><td></td><td>Theo yêu cầu thiết kế của</td><td></td><td>Lấy tối thiểu 3 lít.</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>dự án</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>41</td><td>Màng khò</td><td></td><td>1. Tải trọng kéo đứt</td><td></td><td>TCVN 9067:2012</td><td></td><td></td><td>TCVN 9066:2012</td><td></td><td></td><td>Lấy 15 tấm mẫu kích thước (300 x 300) mm ở
ba cuộn bất kỳ. Các tấm mẫu thử được cắt
cách mép cuộn ít nhất 150 mm. (Căn cứ theo
mục 3 TCVN 9067-1:2012)</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần. Mỗi lô
sản phẩm (qui định đến 3000 m2). Căn
cứ theo mục 3 TCVN 9067-1:2012</td></tr><tr><td></td><td></td><td></td><td>2. Độ giãn dài khi đứt</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Độ bền chọc thủng động</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>ngẫu nhiên từ một lô sản phẩm, có thể lấy</th></tr></thead><tbody><tr><td>mẫu trong nhiều cuộn hoặc trong nhiều đơn vị</td></tr><tr><td>bao gói sao cho việc lấy mẫu là đại diện nhất.</td></tr><tr><td>Chia các mẫu thử thành những tấm có chiều</td></tr><tr><td>dài không nhỏ hơn 1m. (Căn cứ theo mục 5</td></tr></tbody></table>

<table><thead><tr><th>Băng cản nước</th></tr></thead><tbody><tr><td>PVC</td></tr></tbody></table>

<table><thead><tr><th>Phào bê tông</th></tr></thead><tbody><tr><td>cốt sợi thủy</td></tr><tr><td>tinh</td></tr></tbody></table>

<table><thead><tr><th>Theo yêu cầu thiết kế của</th></tr></thead><tbody><tr><td>dự án</td></tr></tbody></table>

<table><thead><tr><th>Lấy 16 mẫu. Rộng 50mm, chiều dài phụ thuộc</th></tr></thead><tbody><tr><td>vào độ dày theo bảng 1 BS1170-5:1998. (8</td></tr><tr><td>viên thử 28 ngày,</td></tr><tr><td>8 viên lưu).</td></tr></tbody></table>

<table><thead><tr><th>Mỗi hợp đồng lấy mẫu 01 lần khi kiểm</th></tr></thead><tbody><tr><td>tra cấp phối.</td></tr></tbody></table>

<table><thead><tr><th>Lấy 15 tấm mẫu kích thước (300 x 300) mm ở</th></tr></thead><tbody><tr><td>ba cuộn bất kỳ. Các tấm mẫu thử được cắt</td></tr><tr><td>cách mép cuộn ít nhất 150 mm. (Căn cứ theo</td></tr><tr><td>mục 3 TCVN 9067-1:2012)</td></tr></tbody></table>

<table><thead><tr><th>Mỗi lô sản phẩm lấy mẫu 1 lần. Mỗi lô</th></tr></thead><tbody><tr><td>sản phẩm (qui định đến 3000 m2). Căn</td></tr><tr><td>cứ theo mục 3 TCVN 9067-1:2012</td></tr></tbody></table>

|<image_13>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th></th><th></th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>42</td><td></td><td></td><td>Thanh trương
nở</td><td></td><td>1. Khối lượng thể tích</td><td></td><td></td><td>ASTM D71</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td>Lấy 3 đoạn, mỗi đoạn 10cm.</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>2. Độ nở thể tích</td><td></td><td></td><td>ASTM D471</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>43</td><td></td><td></td><td>Gốc Xi măng 1
thành phần
(Tinh thể thẩm
thấu)</td><td></td><td>1. Cường độ nén</td><td></td><td></td><td>TCVN 3121:2003</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td>Lấy mẫu đại diện với khối lượng không ít hơn
2 bao nguyên (đối với loại một thành phần)
hoặc 2 bộ nguyên (đối với loại hai thành
phần) trong một lô.</td><td></td><td></td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>2. Độ thấm nước dưới áp lực thủy
tĩnh 500kPa/72h (5bar/72h)</td><td></td><td></td><td>BS EN 12390</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>VẬT LIỆU HỆ ĐIỆN NƯỚC (MEP)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>44</td><td></td><td></td><td>Dây, cáp
điện,dây
nguồn, dây
điều khiển hệ
ĐHKK</td><td></td><td>1. Kích thước cơ sở</td><td></td><td>Tiêu chuẩn IEC
60227</td><td></td><td></td><td>TCVN
5936 – 1995
( IEC 540)</td><td></td><td></td><td>Kiểm tra ruột dẫn, đo chiều dày cách điện và
vỏ bọc và đo đường kính ngoài phải được
thực hiện trên một đoạn cáp lấy từ từng seri
chế tạo của cùng kiểu và cùng một giá trị mặt
cắt ngang danh nghĩa của cáp nhưng phải
được giới hạn ở mức không quá 10% số đoạn
cáp trong bất kỳ hợp đồng nào.
(căn cứ theo mục 16.2.1 TCVN 5935-
1:2013).</td><td></td><td></td><td>Với cáp nhiều lõi : - Từ 2km đến 10 km
: lấy 1 tổ mẫu - Từ 10km đến 20 km lấy
2 tổ mẫu - Từ 20km đến 30km lấy 3 tổ
mẫu.
Với cáp 1 lõi : Số mẫu/ khối lượng cáp
giảm ½. Dưới 4km không cần lấy mẫu.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>2. Độ dẫn điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. An toàn cách điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>45</td><td></td><td></td><td>Dây cấp nguồn
và dây tín hiêụ
xoắn chống
nhiễu cho hệ
PCCC</td><td></td><td>1. Kích thước cơ sở</td><td></td><td>Tiêu chuẩn IEC
331 &amp; BS6387</td><td></td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td>Kiểm tra ruột dẫn, đo chiều dày cách
điện và vỏ bọc và đo đường kính ngoài phải
được thực hiện trên một đoạn cáp lấy từ từng
seri chế tạo của cùng kiểu và cùng một giá trị
mặt cắt ngang danh nghĩa của cáp nhưng phải
được giới hạn ở mức không quá 10% số đoạn
cáp trong bất kỳ hợp đồng nào.
(căn cứ theo mục 16.2.1 TCVN 5935-
1:2013).</td><td></td><td></td><td>Với cáp nhiều lõi : - Từ 2km đến 10 km
: lấy 1 tổ mẫu - Từ 10km đến 20 km lấy
2 tổ mẫu - Từ 20km đến 30km lấy 3 tổ
mẫu.
Với cáp 1 lõi : Số mẫu/ khối lượng cáp
giảm ½. Dưới 4km không cần lấy mẫu.</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>2. Độ dẫn điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. An toàn cách điện</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>46</td><td></td><td></td><td></td><td>1. Kích thước cơ sở</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Lấy 3 đoạn 1m.</td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Gốc Xi măng 1</th></tr></thead><tbody><tr><td>thành phần</td></tr><tr><td>(Tinh thể thẩm
thấu)</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu đại diện với khối lượng không ít hơn</th></tr></thead><tbody><tr><td>2 bao nguyên (đối với loại một thành phần)</td></tr><tr><td>hoặc 2 bộ nguyên (đối với loại hai thành
phần) trong một lô.</td></tr></tbody></table>

<table><thead><tr><th>2. Độ thấm nước dưới áp lực thủy</th></tr></thead><tbody><tr><td>tĩnh 500kPa/72h (5bar/72h)</td></tr></tbody></table>

<table><thead><tr><th>Kiểm tra ruột dẫn, đo chiều dày cách điện và</th></tr></thead><tbody><tr><td>vỏ bọc và đo đường kính ngoài phải được</td></tr><tr><td>thực hiện trên một đoạn cáp lấy từ từng seri</td></tr><tr><td>chế tạo của cùng kiểu và cùng một giá trị mặt</td></tr><tr><td>cắt ngang danh nghĩa của cáp nhưng phải</td></tr><tr><td>được giới hạn ở mức không quá 10% số đoạn</td></tr><tr><td>cáp trong bất kỳ hợp đồng nào.</td></tr><tr><td>(căn cứ theo mục 16.2.1 TCVN 5935-</td></tr><tr><td>1:2013).</td></tr></tbody></table>

<table><thead><tr><th>Với cáp nhiều lõi : - Từ 2km đến 10 km</th></tr></thead><tbody><tr><td>: lấy 1 tổ mẫu - Từ 10km đến 20 km lấy</td></tr><tr><td>2 tổ mẫu - Từ 20km đến 30km lấy 3 tổ</td></tr><tr><td>mẫu.</td></tr><tr><td>Với cáp 1 lõi : Số mẫu/ khối lượng cáp</td></tr><tr><td>giảm ½. Dưới 4km không cần lấy mẫu.</td></tr></tbody></table>

<table><thead><tr><th>Dây, cáp</th></tr></thead><tbody><tr><td>điện,dây</td></tr><tr><td>nguồn, dây</td></tr><tr><td>điều khiển hệ</td></tr><tr><td>ĐHKK</td></tr></tbody></table>

<table><thead><tr><th>TCVN</th></tr></thead><tbody><tr><td>5936 – 1995</td></tr><tr><td>( IEC 540)</td></tr></tbody></table>

<table><thead><tr><th>Tiêu chuẩn IEC</th></tr></thead><tbody><tr><td>60227</td></tr></tbody></table>

<table><thead><tr><th>Kiểm tra ruột dẫn, đo chiều dày cách</th></tr></thead><tbody><tr><td>điện và vỏ bọc và đo đường kính ngoài phải</td></tr><tr><td>được thực hiện trên một đoạn cáp lấy từ từng</td></tr><tr><td>seri chế tạo của cùng kiểu và cùng một giá trị</td></tr><tr><td>mặt cắt ngang danh nghĩa của cáp nhưng phải</td></tr><tr><td>được giới hạn ở mức không quá 10% số đoạn</td></tr><tr><td>cáp trong bất kỳ hợp đồng nào.</td></tr><tr><td>(căn cứ theo mục 16.2.1 TCVN 5935-</td></tr><tr><td>1:2013).</td></tr></tbody></table>

<table><thead><tr><th>Với cáp nhiều lõi : - Từ 2km đến 10 km</th></tr></thead><tbody><tr><td>: lấy 1 tổ mẫu - Từ 10km đến 20 km lấy</td></tr><tr><td>2 tổ mẫu - Từ 20km đến 30km lấy 3 tổ</td></tr><tr><td>mẫu.</td></tr><tr><td>Với cáp 1 lõi : Số mẫu/ khối lượng cáp</td></tr><tr><td>giảm ½. Dưới 4km không cần lấy mẫu.</td></tr></tbody></table>

<table><thead><tr><th>Dây cấp nguồn</th></tr></thead><tbody><tr><td>và dây tín hiêụ</td></tr><tr><td>xoắn chống</td></tr><tr><td>nhiễu cho hệ</td></tr><tr><td>PCCC</td></tr></tbody></table>

<table><thead><tr><th>Tiêu chuẩn IEC</th></tr></thead><tbody><tr><td>331 &amp; BS6387</td></tr></tbody></table>

<table><thead><tr><th>Theo yêu cầu thiết kế của</th></tr></thead><tbody><tr><td>dự án</td></tr></tbody></table>

|<image_14>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>Ống và phụ
kiện PPR</td><td></td><td>2. Độ bền với áp suất bên trong:</td><td></td><td></td><td>TCVN 6145:2007</td><td></td><td>Bảng 10 của TCVN 10097-
2:2013</td><td></td><td></td><td></td><td>Lấy mẫu đối với lô vật tư đầu tiên tập
kết về công trường (ống và phụ kiện lấy
mẫu điển hình). Đối với các lô hàng tiếp
theo sau khi kiểm tra tại hiện trường nếu
thấy nghi ngờ về chất lượng (so sánh
bảng mẫu) thì yêu cầu lấy mẫu mang đi
thí nghiệm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Ở 20°C, trong 1 giờ</td><td></td><td></td><td>TCVN 6149-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>- Ở 95°C, trong 22 giờ</td><td></td><td></td><td>1÷2:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ bền va đập, %, không lớn</td><td></td><td>ISO 9854-1÷2(e)</td><td></td><td></td><td>DIN 8077; 8078</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hơn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Độ cứng vòng (áp dụng cho</td><td></td><td>TCVN 8850:2011</td><td></td><td></td><td>TCVN 12305:2018</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>ống PP dùng để thoát nước chôn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>ngầm trong điều kiện không chịu</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>áp)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>47</td><td>Ống và phụ
kiện uPVC</td><td></td><td>1. Kích thước cơ sở</td><td></td><td></td><td>TCVN 6145:2007</td><td></td><td>TCVN 8491:2011
ISO 4435:2003</td><td></td><td></td><td>Lấy 3 đoạn 1m.</td><td>Lấy mẫu đối với lô vật tư đầu tiên tập
kết về công trường (ống và phụ kiện lấy
mẫu điển hình). Đối với các lô hàng tiếp
theo sau khi kiểm tra tại hiện trường nếu
thấy nghi ngờ về chất lượng (so sánh
bảng mẫu) thì yêu cầu lấy mẫu mang đi
thí nghiệm.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Áp suất làm việc</td><td></td><td></td><td>TCVN 6149:2007</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Độ bền va đập</td><td></td><td></td><td>TCVN 6144:2003</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Độ cứng vòng (áp dụng cho</td><td></td><td>TCVN 8850:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>ống PVC-U dùng để thoát nước</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>chôn ngầm trong điều kiện không</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>chịu áp).</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>48</td><td>Ống nhựa
Polyetylen
(PE) dùng để
cấp nước</td><td></td><td>1. Độ bền thủy tĩnh:</td><td></td><td>TCVN 6149-
1÷2:2007</td><td></td><td></td><td>TCVN 7305-2:2008</td><td></td><td></td><td>Lấy ngẫu nhiên ở tối thiểu 5 vị trí. Mỗi vị trí
lấy hai đoạn ống, mỗi đoạn có chiều dài tối
thiểu 1,0 m.</td><td></td><td>Lấy mẫu đối với lô vật tư đầu tiên tập</td><td></td></tr><tr><td></td><td></td><td></td><td>- Ở 20°C, trong 100 h</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>kết về công trường (ống và phụ kiện lấy</td><td></td></tr><tr><td></td><td></td><td></td><td>- Ở 80°C, trong 165 h</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>mẫu điển hình). Đối với các lô hàng tiếp</td><td></td></tr><tr><td></td><td></td><td>2. Độ dãn dài khi đứt, %, không
nhỏ hơn</td><td></td><td></td><td>TCVN 7434-
1:2004</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>theo sau khi kiểm tra tại hiện trường nếu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thấy nghi ngờ về chất lượng (so sánh</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>bảng mẫu) thì yêu cầu lấy mẫu mang đi</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>thí nghiệm.</td><td></td></tr><tr><td>49</td><td>Ống thép đen,
ống thép tráng
kẽm</td><td></td><td>1. Giới hạn chảy ; giới hạn bền,</td><td></td><td>ASTM A370 hoặc
TC
tương ứng</td><td></td><td></td><td>ASTM A53 hoặc TC tương
ứng</td><td></td><td></td><td>Mỗi loại thép lấy 01 tổ mẫu 3 đoạn 50cm.</td><td>Cứ 50 tấn/1 tổ mẫu/1 loại kích thước.
Mỗi lô nhỏ hơn 50 tấn xem như một lô.
(Căn cứ theo mục 6 TCVN 6522:2008).</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>độ giãn dài</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Thử nén bẹp hoặc Khả năng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>chịu uốn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>50</td><td>Thép dày mạ
kẽm dạng cuộn
(tole)</td><td>1. Độ bền kéo, MPa, không nhỏ
hơn</td><td></td><td></td><td></td><td>ASTM A370- 19</td><td></td><td>Theo yêu cầu thiết kế của
dự án</td><td></td><td></td><td>Mỗi loại thép lấy 01 tổ mẫu 3 đoạn 50cm,
chiều rộng mẫu của nguyên tấm</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.
Mỗi loại lấy 1 tổ mẫu. Có thể tham khảo
TCSX của nhà SX.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc
TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2. Độ cứng, HV, không nhỏ hơn</td><td></td><td></td><td>TCVN 257-1:2007
hoặc
TC nước ngoài
tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>Bảng 10 của TCVN 10097-</th></tr></thead><tbody><tr><td>2:2013</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu đối với lô vật tư đầu tiên tập</th></tr></thead><tbody><tr><td>kết về công trường (ống và phụ kiện lấy</td></tr><tr><td>mẫu điển hình). Đối với các lô hàng tiếp</td></tr><tr><td>theo sau khi kiểm tra tại hiện trường nếu</td></tr><tr><td>thấy nghi ngờ về chất lượng (so sánh</td></tr><tr><td>bảng mẫu) thì yêu cầu lấy mẫu mang đi</td></tr><tr><td>thí nghiệm.</td></tr></tbody></table>

<table><thead><tr><th>Ống và phụ</th></tr></thead><tbody><tr><td>kiện PPR</td></tr></tbody></table>

<table><thead><tr><th>Lấy mẫu đối với lô vật tư đầu tiên tập</th></tr></thead><tbody><tr><td>kết về công trường (ống và phụ kiện lấy</td></tr><tr><td>mẫu điển hình). Đối với các lô hàng tiếp</td></tr><tr><td>theo sau khi kiểm tra tại hiện trường nếu</td></tr><tr><td>thấy nghi ngờ về chất lượng (so sánh</td></tr><tr><td>bảng mẫu) thì yêu cầu lấy mẫu mang đi</td></tr><tr><td>thí nghiệm.</td></tr></tbody></table>

<table><thead><tr><th>Ống và phụ</th></tr></thead><tbody><tr><td>kiện uPVC</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8491:2011</th></tr></thead><tbody><tr><td>ISO 4435:2003</td></tr></tbody></table>

<table><thead><tr><th>Polyetylen</th></tr></thead><tbody><tr><td>(PE) dùng để</td></tr><tr><td>cấp nước</td></tr></tbody></table>

<table><thead><tr><th>Lấy ngẫu nhiên ở tối thiểu 5 vị trí. Mỗi vị trí</th></tr></thead><tbody><tr><td>lấy hai đoạn ống, mỗi đoạn có chiều dài tối</td></tr><tr><td>thiểu 1,0 m.</td></tr></tbody></table>

<table><thead><tr><th>2. Độ dãn dài khi đứt, %, không</th></tr></thead><tbody><tr><td>nhỏ hơn</td></tr></tbody></table>

<table><thead><tr><th>TCVN 7434-</th></tr></thead><tbody><tr><td>1:2004</td></tr></tbody></table>

<table><thead><tr><th>Ống thép đen,</th></tr></thead><tbody><tr><td>ống thép tráng</td></tr><tr><td>kẽm</td></tr></tbody></table>

<table><thead><tr><th>ASTM A370 hoặc</th></tr></thead><tbody><tr><td>TC</td></tr><tr><td>tương ứng</td></tr></tbody></table>

<table><thead><tr><th>Cứ 50 tấn/1 tổ mẫu/1 loại kích thước.</th></tr></thead><tbody><tr><td>Mỗi lô nhỏ hơn 50 tấn xem như một lô.</td></tr><tr><td>(Căn cứ theo mục 6 TCVN 6522:2008).</td></tr></tbody></table>

<table><thead><tr><th>ASTM A53 hoặc TC tương</th></tr></thead><tbody><tr><td>ứng</td></tr></tbody></table>

<table><thead><tr><th>hoặc
TC nước ngoài</th></tr></thead><tbody><tr><td>tương ứng</td></tr></tbody></table>

|<image_15>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th></th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Khối lượng lớp phủ, chiều dày
lớp mạ, µm</td><td></td><td></td><td></td><td>ASTM A1397-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>51</td><td></td><td>Ống đồng</td><td>1. Xác định kích thước (chiều
dày)</td><td></td><td></td><td></td><td>ASTM</td><td></td><td>ASTM B280-16
hoặc TC tương ứng</td><td></td><td></td><td>Mỗi loại thép lấy 01 tổ mẫu 3 đoạn 1m</td><td></td><td></td><td>Mỗi HĐ lấy mẫu 1 lần.
Mỗi loại lấy 1 tổ mẫu. Có thể tham khảo
TCSX của nhà SX.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>A1073/A1073M-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>16 hoặc TC tương</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ bền kéo, MPa, không nhỏ
hơn</td><td></td><td></td><td></td><td>ASTM A370- 19</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Thành phần hoá học</td><td></td><td></td><td></td><td>BSEN 15079- 15</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Độ cứng, HV1, không nhỏ hơn</td><td></td><td></td><td></td><td>ASTM ASTM</td><td></td><td>Jis H3300-2012
hoặc TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>E384- 16</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>hoặc TC tương ứng</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>VẬT LIỆU HẠ TẦNG CƠ SỞ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>1. Thành phần hạt</td><td></td><td></td><td>TCVN 4198 : 2014</td><td></td><td></td><td></td><td></td><td>Lấy 01 mẫu 50kg.
(Căn cứ theo TCVN 4198:2014, 22
TCN 333-06, 22TCN 332-06, TCVN
4197:2012)</td><td></td><td></td><td>Từ 20.000m3 đến 50.000m3 lấy mẫu 1
lần. (Căn cứ theo bảng 35 TCVN
4447.2012) Hoặc theo yêu cầu thiết kế
của dự án.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Xác định đầm chặt tiêu chuẩn</td><td></td><td></td><td>22TCN 333-06</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>3. *Xác định chỉ số CBR</td><td></td><td></td><td>22TCN 332-06</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>4. Hàm lượng các tạp chất (Đối</td><td></td><td></td><td>TCVN 7572-8 :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>với cát).</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Tạp chất hữu cơ (Đối với cát).</td><td></td><td></td><td></td><td>TCVN 7572-9 :</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>52</td><td></td><td>Cát (Đất) san
nền</td><td></td><td>6. Chỉ số dẻo (đối với đất)</td><td></td><td></td><td>TCVN 4197:2012</td><td></td><td>TCVN 4447:2012
hoặc theo thiết kế của dự
án.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. Xác định độ chặt hiện trường
bằng phương pháp dao vòng hoặc
rót cát</td><td></td><td></td><td>22TCN 02-71/
22TCN346:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Từ 100m3 đến 200m3 kiểm tra 1 điểm
độ chặt (Đối với đất sét, đất thịt và đất
pha cát). Từ 200m3 đến 400m3 kiểm tra
1 điểm độ chặt (Đối với cát sỏi, cát thô,
cát mịn). (Căn cứ theo bảng 35 TCVN
4447:2012).</td><td></td><td></td></tr><tr><td>53</td><td></td><td>Cấp phối đá
dăm</td><td></td><td>1. Xác định thành phần hạt</td><td></td><td></td><td>TCVN 7572: 2006</td><td></td><td>TCVN 8859:2011</td><td></td><td></td><td>- Loại cấp phối có Dmax=37.5 mm lấy 200kg
- Loại cấp phối có Dmax=25.0 mm lấy 150kg
- Loại cấp phối có Dmax=19.0 mm lấy 100kg</td><td></td><td></td><td>- Mẫu kiểm tra được lấy tại nguồn cung
cấp, cứ 3000 m3 vật liệu cung cấp cho
công trình thì ít nhất phải lấy một mẫu.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>2. Xác định độ hao mòn Los-</td><td></td><td></td><td>TCVN 7572-12:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>Angeles (LA)</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>3. Khối lượng lớp phủ, chiều dày</th></tr></thead><tbody><tr><td>lớp mạ, µm</td></tr></tbody></table>

<table><thead><tr><th>1. Xác định kích thước (chiều</th></tr></thead><tbody><tr><td>dày)</td></tr></tbody></table>

<table><thead><tr><th>ASTM B280-16</th></tr></thead><tbody><tr><td>hoặc TC tương ứng</td></tr></tbody></table>

<table><thead><tr><th>2. Độ bền kéo, MPa, không nhỏ</th></tr></thead><tbody><tr><td>hơn</td></tr></tbody></table>

<table><thead><tr><th>Mỗi HĐ lấy mẫu 1 lần.</th></tr></thead><tbody><tr><td>Mỗi loại lấy 1 tổ mẫu. Có thể tham khảo</td></tr><tr><td>TCSX của nhà SX.</td></tr></tbody></table>

<table><thead><tr><th>Jis H3300-2012</th></tr></thead><tbody><tr><td>hoặc TC tương ứng</td></tr></tbody></table>

<table><thead><tr><th>Lấy 01 mẫu 50kg.</th></tr></thead><tbody><tr><td>(Căn cứ theo TCVN 4198:2014, 22</td></tr><tr><td>TCN 333-06, 22TCN 332-06, TCVN</td></tr><tr><td>4197:2012)</td></tr></tbody></table>

<table><thead><tr><th>Từ 20.000m3 đến 50.000m3 lấy mẫu 1</th></tr></thead><tbody><tr><td>lần. (Căn cứ theo bảng 35 TCVN</td></tr><tr><td>4447.2012) Hoặc theo yêu cầu thiết kế</td></tr><tr><td>của dự án.</td></tr></tbody></table>

<table><thead><tr><th>Từ 100m3 đến 200m3 kiểm tra 1 điểm</th></tr></thead><tbody><tr><td>độ chặt (Đối với đất sét, đất thịt và đất</td></tr><tr><td>pha cát). Từ 200m3 đến 400m3 kiểm tra</td></tr><tr><td>1 điểm độ chặt (Đối với cát sỏi, cát thô,
cát mịn). (Căn cứ theo bảng 35 TCVN</td></tr><tr><td>4447:2012).</td></tr></tbody></table>

<table><thead><tr><th>TCVN 4447:2012</th></tr></thead><tbody><tr><td>hoặc theo thiết kế của dự</td></tr></tbody></table>

<table><thead><tr><th>7. Xác định độ chặt hiện trường
bằng phương pháp dao vòng hoặc</th></tr></thead><tbody><tr><td>rót cát</td></tr></tbody></table>

<table><thead><tr><th></th></tr></thead><tbody><tr><td>Cấp phối đá
dăm</td></tr></tbody></table>

<table><thead><tr><th>- Loại cấp phối có Dmax=25.0 mm lấy 150kg</th></tr></thead><tbody><tr><td>- Loại cấp phối có Dmax=19.0 mm lấy 100kg</td></tr></tbody></table>

<table><thead><tr><th>cấp, cứ 3000 m3 vật liệu cung cấp cho</th></tr></thead><tbody><tr><td>công trình thì ít nhất phải lấy một mẫu.</td></tr></tbody></table>

|<image_16>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th></th><th></th><th>GHI CHÚ</th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. *Xác định khối lượng riêng,</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td>- Lấy (50 - 250) kg
tuỳ theo cỡ đá/ 01 tổ mẫu.
(Căn cứ theo bảng 3 TCVN 7572- 01:2006)</td><td></td><td></td><td>- Mẫu kiểm tra được lấy ở bãi chứa tại
chân công trình, cứ 1000 m3 vật liệu
phải lấy ít nhất một mẫu cho mỗi nguồn
cung cấp hoặc khi có sự bất thường về
chất lượng vật liệu.
- Cứ 800 m2 phải tiến hành thí nghiệm
xác định độ chặt lu lèn tại một vị trí
ngẫu nhiên. (Căn cứ theo mục 8.3
TCVN 8859:2011)</td></tr><tr><td></td><td></td><td></td><td>khối lượng thể tích và độ h</td><td></td><td></td><td>4:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. *Xác định độ nén dập và hệ số</td><td></td><td></td><td>TCVN 7572-11:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>hóa mềm</td><td></td><td></td><td>2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Đầm chặt tiêu chuẩn</td><td></td><td></td><td>22TCN 333-06</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>6. Giới hạn chảy (WL)</td><td></td><td></td><td>TCVN 4197-2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. Chỉ số dẻo (Ip)</td><td></td><td></td><td>TCVN 4197-2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8. Tích số dẻo (PP)</td><td></td><td></td><td>TCVN 4197-2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>9. *Xác định chỉ số CBR</td><td></td><td></td><td>22TCN 332-06</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>10. Xác định hàm lượng hạt thoi</td><td></td><td></td><td>TCVN 7572-</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>dẹt</td><td></td><td></td><td>13:2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>11. Xác định độ chặt hiện trường</td><td></td><td>22 TCN 346 : 2006</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>bằng phễu rót cát</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>54</td><td>Bê tông nhựa</td><td></td><td>1. Thí nghiệm Marshall (độ ổn</td><td></td><td></td><td>TCVN 8860 -1</td><td></td><td>TCVN 8819:2011
hoặc QĐ858/BGTVT
(hoặc theo thiết kế của dự
án)</td><td></td><td></td><td>Lấy 1 xô/20kg.
(Lấy mẫu từng ngày thảm; tại xe rải đến các
dự án).
(Căn cứ theo bảng 11 TCVN 8819:2011)</td><td></td><td></td><td>- Nếu chia diện tích/ chiều dài trên ra các
ngày thảm khác nhau thì phải lấy mẫu
cho từng ngày thảm.
- Nếu 01 nhà cung cấp cùng ngày thi
công thảm nhiều vị trí khác nhau trong
dự án; thì lấy 01 tổ mẫu đại diện để thí
nghiệm.
- Các xe bê tông nhựa vá /bù đường
không cần lấy mẫu.</td></tr><tr><td></td><td></td><td></td><td>định, chỉ số dẻo,độ cứng quy ước)</td><td></td><td></td><td>:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2. Xác định hàm lượng nhựa bằng
phương pháp chiết sử dụng máy
quay li tâm</td><td>2. Xác định hàm lượng nhựa bằng</td><td></td><td>TCVN 8860 –2:
2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>phương pháp chiết sử dụng máy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3. Xác định thành phần hạt</td><td></td><td></td><td></td><td>TCVN 8860 –3:
2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>4. Xác định tỷ trọng lớn nhất, khối
lượng riêng của bê tông nhựa ở
trạng thái rời</td><td></td><td></td><td>TCVN 8860-4
:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>lượng riêng của bê tông nhựa ở</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>trạng thái rời</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>5. Xác định tỷ trọng khối, khối</td><td></td><td>TCVN 8860-5
:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>lượng thể tích của bê tông nhựa</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>đã đầm nén</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>6. Xác định độ rỗng dư</td><td></td><td></td><td></td><td>TCVN 8860-9</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>7. Độ sâu vệt hằn bánh xe</td><td></td><td></td><td>AASHTO T324-04</td><td></td><td></td><td></td><td></td><td></td><td></td><td>Chỉ kiểm tra đối với dự án đặc biệt</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>theo yêu cầu của CĐT</td><td></td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>- Lấy (50 - 250) kg</th></tr></thead><tbody><tr><td>tuỳ theo cỡ đá/ 01 tổ mẫu.</td></tr><tr><td>(Căn cứ theo bảng 3 TCVN 7572- 01:2006)</td></tr></tbody></table>

<table><thead><tr><th>- Mẫu kiểm tra được lấy ở bãi chứa tại</th></tr></thead><tbody><tr><td>chân công trình, cứ 1000 m3 vật liệu</td></tr><tr><td>phải lấy ít nhất một mẫu cho mỗi nguồn</td></tr><tr><td>cung cấp hoặc khi có sự bất thường về</td></tr><tr><td>chất lượng vật liệu.</td></tr><tr><td>- Cứ 800 m2 phải tiến hành thí nghiệm</td></tr><tr><td>xác định độ chặt lu lèn tại một vị trí</td></tr><tr><td>ngẫu nhiên. (Căn cứ theo mục 8.3</td></tr><tr><td>TCVN 8859:2011)</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8860 –2:</th></tr></thead><tbody><tr><td>2011</td></tr></tbody></table>

<table><thead><tr><th>- Nếu chia diện tích/ chiều dài trên ra các</th></tr></thead><tbody><tr><td>ngày thảm khác nhau thì phải lấy mẫu
cho từng ngày thảm.</td></tr><tr><td>- Nếu 01 nhà cung cấp cùng ngày thi</td></tr><tr><td>công thảm nhiều vị trí khác nhau trong</td></tr><tr><td>dự án; thì lấy 01 tổ mẫu đại diện để thí</td></tr><tr><td>nghiệm.</td></tr><tr><td>- Các xe bê tông nhựa vá /bù đường</td></tr><tr><td>không cần lấy mẫu.</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8819:2011
hoặc QĐ858/BGTVT</th></tr></thead><tbody><tr><td>(hoặc theo thiết kế của dự</td></tr><tr><td>án)</td></tr></tbody></table>

<table><thead><tr><th>(Lấy mẫu từng ngày thảm; tại xe rải đến các
dự án).</th></tr></thead><tbody><tr><td>(Căn cứ theo bảng 11 TCVN 8819:2011)</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8860-5</th></tr></thead><tbody><tr><td>:2011</td></tr></tbody></table>

|<image_17>|


## VIETTEL AI RACE

## TD647

## CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG

## Lần ban hành: 1

<table><thead><tr><th></th><th>VIETTEL AI RACE</th><th>TD647</th></tr></thead><tbody><tr><td></td><td>CHỈ TIÊU THÍ NGHIỆM VẬT LIỆU XÂY DỰNG</td><td>Lần ban hành: 1</td></tr></tbody></table>

<table><thead><tr><th>STT</th><th>TÊN VẬT
LIỆU</th><th>CHỈ TIÊU THÍ NGHIỆM</th><th></th><th></th><th>TIÊU CHUẨN
THÍ NGHIỆM</th><th></th><th></th><th></th><th>TIÊU CHUẨN LẤY</th><th></th><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH
MẪU THỬ</th><th>GHI CHÚ</th><th></th><th></th></tr></thead><tbody><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>MẪU, YÊU CẦU KỸ</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>THUẬT</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>8. Xác định hệ số độ chặt lu lèn</td><td></td><td></td><td>TCVN 8860-8
:2011</td><td></td><td></td><td></td><td></td><td></td><td></td><td>- 2500m2 mặt đường (hoặc 330m dài
đường 2 làn xe) /1 tổ 3 mẫu khoan.
- Nếu diện tích hoặc chiều dài đường
nhỏ hơn quy định trên thì cũng phải lấy
1 tổ mẫu.
(Căn cứ theo mục 9.6.4 TCVN
8819:2011).</td><td></td><td></td></tr><tr><td>55</td><td>Vải địa kỹ
thuật</td><td></td><td>1. Khối lượng riêng</td><td></td><td></td><td>ASTM D-5261</td><td></td><td>TCVN 9844:2013
hoặc theo YC của của dự án</td><td></td><td></td><td>Lấy 1 mẫu có kích thước &gt; 10 m2. (Căn cứ
theo bảng 4.2 TCVN 8222:2009)</td><td>Mỗi lô sản phẩm lấy mẫu 1 lần.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>2. Chiều dày</td><td></td><td></td><td>ASTM D-5199</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>3. Hệ số thấm</td><td></td><td></td><td>ASTM D-4491</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4. Rơi côn
5. Lực kéo đứt lớn nhất chiều</td><td></td><td>BS 6906- Part 6</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>cuộn
6. Độ giãn dài khi đứt theo chiều</td><td></td><td>ASTM D- 4595
ASTM D-4595</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>cuộn</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>7. CBR đâm thủng</td><td></td><td></td><td>ASTM D- 6241</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>8. Kích thước lỗ O95</td><td></td><td></td><td>ASTM D- 4751</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>56</td><td>Ống cống bê
tông cốt thép</td><td></td><td>1. Kiểm tra kích thước</td><td></td><td></td><td>TCVN 9113:2012</td><td></td><td>TCVN 9113:2012</td><td></td><td></td><td>Lấy 3 đoạn, mỗi đoạn 1m</td><td></td><td>Lấy mẫu đối với lô vật tư đầu tiên tập</td><td></td></tr><tr><td></td><td></td><td></td><td>2. Thử nén 3 cạnh</td><td></td><td></td><td>TCVN 9113:2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td>kết về công trường. Đối với các lô hàng</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>tiếp theo sau khi kiểm tra tại hiện trường</td><td></td></tr><tr><td></td><td></td><td>3. Thử thấm</td><td></td><td></td><td>TCVN 9113:2012</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>nếu thấy nghi ngờ về chất lượng thì yêu</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>cầu lấy mẫu mang đi thí nghiệm.</td><td></td></tr></tbody></table>

<table><thead><tr><th>TÊN VẬT</th></tr></thead><tbody><tr><td>LIỆU</td></tr></tbody></table>

<table><thead><tr><th>TIÊU CHUẨN</th></tr></thead><tbody><tr><td>THÍ NGHIỆM</td></tr></tbody></table>

<table><thead><tr><th>SỐ LƯỢNG/ KHỐI LƯỢNG/ QUY CÁCH</th></tr></thead><tbody><tr><td>MẪU THỬ</td></tr></tbody></table>

<table><thead><tr><th>- 2500m2 mặt đường (hoặc 330m dài</th></tr></thead><tbody><tr><td>đường 2 làn xe) /1 tổ 3 mẫu khoan.</td></tr><tr><td>- Nếu diện tích hoặc chiều dài đường</td></tr><tr><td>nhỏ hơn quy định trên thì cũng phải lấy</td></tr><tr><td>1 tổ mẫu.</td></tr><tr><td>(Căn cứ theo mục 9.6.4 TCVN</td></tr><tr><td>8819:2011).</td></tr></tbody></table>

<table><thead><tr><th>TCVN 8860-8</th></tr></thead><tbody><tr><td>:2011</td></tr></tbody></table>

<table><thead><tr><th>Ống cống bê</th></tr></thead><tbody><tr><td>tông cốt thép</td></tr></tbody></table>

|<image_18>|


